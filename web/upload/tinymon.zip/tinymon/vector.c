#include "monit.h"


extern  void start();
extern  void sci_putc();
extern  void sci_handler( void );
extern  void dummy_handler( void );

Interrupt void trap_handler( void )
{
}

Interrupt void nmi_handler( void )
{
}

#define	NULLFUNC  dummy_handler

typedef void (*func)(void);

const func IntVector[] __attribute__ ((section (".vectors"))) =
{
    start,			// 0 RESET
	NULLFUNC,		// 1 reserved.
	NULLFUNC,		// 2 reserved.
	NULLFUNC,		// 3 reserved.
	NULLFUNC,		// 4 reserved.
	NULLFUNC,		// 5 reserved.
	NULLFUNC,		// 6 reserved.
	nmi_handler,	// 7 NMI

	trap_handler,	// 8  TRAP#0
	trap_handler,	// 9  TRAP#1
	trap_handler,	// 10 TRAP#2
	trap_handler,	// 11 TRAP#3
	NULLFUNC,		// 12 Address Break
	NULLFUNC,		// 13 CPU Sleep
// External Interrupt:
	NULLFUNC,		// 14 IRQ0(PowerDown)
	NULLFUNC,		// 15 IRQ1

	NULLFUNC,		// 16 IRQ2
	NULLFUNC,		// 17 IRQ3
	NULLFUNC,		// 18 WKP
	NULLFUNC,		// 19 TIMER_A Overflow
	NULLFUNC,		// 20 reserved.
	NULLFUNC,		// 21 TIMER_W
	NULLFUNC,		// 22 TIMER_V
	sci_handler,	// 23 SCI3

	NULLFUNC,		// 24 IIC2
	NULLFUNC,		// 25 A/D
	NULLFUNC,		// 26 
	NULLFUNC,		// 27 
	NULLFUNC,		// 28 
	NULLFUNC,		// 29 
	NULLFUNC,		// 30 
	NULLFUNC,		// 31 

	NULLFUNC,		// 32 
	NULLFUNC,		// 33 
	NULLFUNC,		// 34 
	NULLFUNC,		// 35 
	NULLFUNC,		// 36 
	NULLFUNC,		// 37 
	NULLFUNC,		// 38 
	NULLFUNC,		// 39 

	NULLFUNC,		// 40 
	NULLFUNC,		// 41 
	NULLFUNC,		// 42 
	NULLFUNC,		// 43 
	NULLFUNC,		// 44 
	NULLFUNC,		// 45 
	NULLFUNC,		// 46 
	NULLFUNC,		// 47 

	NULLFUNC,		// 48
	sci_putc,		// 49
	NULLFUNC,		// 50 
	NULLFUNC,		// 51
	NULLFUNC,		// 52
	NULLFUNC,		// 53
	NULLFUNC,		// 54
	NULLFUNC,		// 55

	NULLFUNC,		// 56
	NULLFUNC,		// 57
	NULLFUNC,		// 58
	NULLFUNC,		// 59
	NULLFUNC,		// 60
	NULLFUNC,		// 61
	NULLFUNC,		// 62
	NULLFUNC,		// 63

};

