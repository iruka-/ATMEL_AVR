#include <string.h>

#define BUFMAX 		80
#define	STACK_SIZE	32

/*-------------------------------------------------------------------------*/
char remcomInBuffer[BUFMAX];
int work_area; /* work area of isr.S */

int stub_stack[STACK_SIZE] __attribute__ ((section (".stack"))) = {0};

extern void monitor_init_io(void);	// ��/�Ϥν����.
extern void getMonitorCmd(void);	// ��˥���ư.


/*-------------------------------------------------------------------------*/
void start_gdbstub(void)
{
  	monitor_init_io();
	while(1) {
		getMonitorCmd();
	}
}
#if	0
/*-------------------------------------------------------------------------*/
size_t strlen(const char *s)
{
	int n=0;
	while(*s) {
		s++;n++;
	}
	return n;
}
#endif
/*-------------------------------------------------------------------------*/
