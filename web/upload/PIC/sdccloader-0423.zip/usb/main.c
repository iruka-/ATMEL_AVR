/*********************************************************************
 *
 *                Microchip USB Bootloader Version 1.2
 *
 *********************************************************************
 * FileName:        main.c
 * Dependencies:    See INCLUDES section below
 * Processor:       PIC18
 * Compiler:        C18 3.11+/sdcc
 * Company:         Microchip Technology, Inc.
 *
 * Software License Agreement
 *
 * The software supplied herewith by Microchip Technology Incorporated
 * (the 'Company') for its PICmicro(TM) Microcontroller is intended and
 * supplied to you, the Company's customer, for use solely and
 * exclusively on Microchip PICmicro Microcontroller products. The
 * software is owned by the Company and/or its supplier, and is
 * protected under applicable copyright laws. All rights are reserved.
 * Any use in violation of the foregoing restrictions may subject the
 * user to criminal sanctions under applicable laws, as well as to
 * civil liability for the breach of the terms and conditions of this
 * license.
 *
 * THIS SOFTWARE IS PROVIDED IN AN 'AS IS' CONDITION. NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 * TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 * IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 * CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 * Author               Date        Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Rawin Rojvanit       11/19/04    Original.
 * Rawin Rojvanit       05/14/07    Minor updates.
 ********************************************************************/

/*********************************************************************
IMPORTANT NOTE: This booloader example code is not intended to work
with the PIC18F87J50 Family of microcontrollers.
*********************************************************************/


/** I N C L U D E S **********************************************************/
#ifdef SDCC
#include <pic18f2550.h>
#else
#include <p18cxxx.h>
#endif
#include "system/typedefs.h"                        // Required
#include "system/usb.h"                         // Required
#include "io_cfg.h"                                 // Required

#include "system/usb_compile_time_validation.h" // Optional
#include "fuse.h"

/** V A R I A B L E S ********************************************************/
#ifndef SDCC
#pragma udata
#endif

/** P R I V A T E  P R O T O T Y P E S ***************************************/

/** V E C T O R  R E M A P P I N G *******************************************/
#if	0
void _high_ISR (void) __naked interrupt 1
{
    _asm goto RM_HIGH_INTERRUPT_VECTOR _endasm;
}

void _low_ISR (void) __naked interrupt 2
{
    _asm goto RM_LOW_INTERRUPT_VECTOR _endasm;
}
#endif

#ifndef SDCC
#pragma code
#endif

/** D E C L A R A T I O N S **************************************************/
#ifndef SDCC
#pragma code
#endif

#if	0
void blink(void)
{
    static word led_count=0;
    
    led_count++;
	if(led_count & 0x8000) {
		mLED_1_On();
		mLED_2_Off();
	}else{
		mLED_1_Off();
		mLED_2_On();
	}
}
#endif
/******************************************************************************
 * Function:        void main(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        Main program entry point.
 *
 * Note:            None
 *****************************************************************************/
void main(void)
{
    byte temp;
    temp = ADCON1;
    ADCON1 |= 0x0F;
    
    //TRISBbits.TRISB4 = 1;     // Reset value is already '1'
    
#if MOD2553==1
	ADCON1 = 0b0011011;
	INTCON2bits.RBPU = 0;		//�@PORTB PULLUP
#endif

    //Check Bootload Mode Entry Condition
#if	0
    if(sw2 == 1)      // If not pressed, User Mode
    {
        ADCON1 = temp;          // Restore reset value
        _asm goto RM_RESET_VECTOR _endasm;
    }//end if
#endif

    //Bootload Mode
    mInitAllLEDs();
#if	0
	while(1) {
		blink();
	}
#endif

    mInitializeUSBDriver();     // See usbdrv.h
    USBCheckBusStatus();        // Modified to always enable USB module
    while(1) {
        USBDriverService();     // See usbdrv.c
        BootService();          // See boot.c
    }//end while
}//end main

#pragma code user = RM_RESET_VECTOR

/** EOF main.c ***************************************************************/
