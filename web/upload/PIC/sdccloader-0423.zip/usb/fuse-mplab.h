/** C O N F I G U R A T I O N ************************************************/

#if   defined(__18F4550)||defined(__18F4455)|| \
      defined(__18F2550)||defined(__18F2455)|| \
      defined(__18F4553)||defined(__18F4458)|| \
      defined(__18F2553)||defined(__18F2458)|| \
      defined(__18F2450)

// Note: Some of the below configuration bits are commented out
// to prevent build errors with some of the above listed devices.
// For example, on the PIC18F4458 CP3, WRT3, and EBTR3 don't exist.

#if	DEFINE_FUSE

#if F_CPU==20
#pragma config PLLDIV   = 5       // (20 MHz input)
#pragma config FOSC     = HSPLL_HS
#elif F_CPU==16
#pragma config PLLDIV   = 4       // (16 MHz input)
#pragma config FOSC     = HSPLL_HS
#elif F_CPU==12
#pragma config PLLDIV   = 3       // (12 MHz input)
#pragma config FOSC     = HSPLL_HS
#elif F_CPU==8
#pragma config PLLDIV   = 2       // (8 MHz input)
#pragma config FOSC     = HSPLL_HS
#else
#pragma config PLLDIV   = 1       // (4 MHz input)
#pragma config FOSC		= XTPLL_XT
#endif

#pragma config CPUDIV   = OSC1_PLL2
#pragma config USBDIV   = 2       // Clock source from 96MHz PLL/2
#pragma config FCMEN    = OFF
#pragma config IESO     = OFF
#pragma config PWRT     = OFF
#pragma config BOR      = ON

#if defined(__18F2450)
#pragma config BORV = 28
#else
#pragma config BORV     = 3
#endif

#pragma config VREGEN   = ON
#pragma config WDT      = OFF
#pragma config WDTPS    = 32768
#pragma config MCLRE    = ON
#pragma config LPT1OSC  = OFF
#pragma config PBADEN   = OFF

#if   !defined(__18F2450)
#pragma config CCP2MX   = ON
#endif

#pragma config STVREN   = ON
#pragma config LVP      = OFF
//#pragma config ICPRT    = OFF       // Dedicated In-Circuit Debug/Programming
#pragma config XINST    = OFF       // Extended Instruction Set
#pragma config CP0      = OFF
#pragma config CP1      = OFF

#if   !defined(__18F2450)
#pragma config CP2      = OFF
#endif

#pragma config CPB      = OFF
#pragma config WRT0     = OFF
#pragma config WRT1     = OFF

#if   !defined(__18F2450)
#pragma config CPD      = OFF
#pragma config WRT2     = OFF
#endif

#if   defined(__18F4550)||defined(__18F4455)|| \
      defined(__18F2550)||defined(__18F4553)||defined(__18F2553)
#pragma config CP3      = OFF
#pragma config WRT3     = OFF
#endif

#pragma config WRTB     = ON       // Boot Block Write Protection
#pragma config WRTC     = OFF

#if   !defined(__18F2450)
#pragma config WRTD     = OFF
#endif

#pragma config EBTR0    = OFF
#pragma config EBTR1    = OFF

#if defined(__18F2455) || defined(__18F2550) || defined(__18F2550) || defined(__18F4550)
#pragma config EBTR2    = OFF
#endif
#pragma config EBTRB    = OFF

#if defined(__18F2550) || defined(__18F2553) || defined(__18F4550)
#pragma config EBTR3 = OFF
#endif

#endif

#endif	//end DEFINE_FUSE
