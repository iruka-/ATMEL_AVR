/** C O N F I G U R A T I O N ************************************************/

#if   defined(__18F4550)||defined(__18F4455)|| \
      defined(__18F2550)||defined(__18F2455)|| \
      defined(__18F4553)||defined(__18F4458)|| \
      defined(__18F2553)||defined(__18F2458)|| \
      defined(__18F2450)

// Note: Some of the below configuration bits are commented out
// to prevent build errors with some of the above listed devices.
// For example, on the PIC18F4458 CP3, WRT3, and EBTR3 don't exist.

#define	DEFINE_FUSE	1

#if	DEFINE_FUSE

code int at __CONFIG1L __config1l = 0x24;
code int at __CONFIG1H __config1h = 0x0E;
code int at __CONFIG2L __config2l = 0x3F;
code int at __CONFIG2H __config2h = 0x1E;
//
code int at __CONFIG3H __config3h = 0x81;
code int at __CONFIG4L __config4l = 0x81;
//
code int at __CONFIG5L __config5l = 0x0F;
code int at __CONFIG5H __config5h = 0xC0;
code int at __CONFIG6L __config6l = 0x0F;
code int at __CONFIG6H __config6h = 0xA0;
code int at __CONFIG7L __config7l = 0x0F;
code int at __CONFIG7H __config7h = 0x40;


#endif	//end DEFINE_FUSE

#endif
