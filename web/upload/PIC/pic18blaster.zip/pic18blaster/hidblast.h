#define	DLL_int	__declspec(dllexport) int __stdcall
//DLL_int get_if_spec(void);

