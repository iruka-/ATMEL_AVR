#include <stdio.h>

int spi=0;

int genspi(int val)
{
	static int acc=0x8000;
	int i,f;
	for(i=0;i<32;i++) {
		acc += val;
		f = (acc >> 16);
		spi<<=1; spi |= f;
		acc &= 0xffff;
	}
	return spi;
}

int main(int argc,char **argv)
{
	int s=0x8198;
	int i;
	for(i=0;i<32;i++) {
		int c = genspi(s);
		printf("0x%08x\n",c);
	}
}
