#ifndef	_pindef_h_
#define	_pindef_h_

/* STM8S-D
	 +-- 10PIN ST-LINK ���ۂ�����--------+
   10| (nSRST)���ڑ�   |  -              |9
	8| PB4(JNTRST) 	   | GND 			 |7 
	6| PA15(JTDI) 	   | PA13(JTMS/SWDIO)|5 
	4| PA14(JTCK/SWCLK)| PB3(JTDO) 		 |3 
	2| - 			   | VDD_1 			 |1 
	 +-- 10PIN ST-LINK ���ۂ�����--------+
*/

#ifdef	STM8S_D
//	�|�[�g�o�̓f�[�^.   		  	  JTAG  PIC   AVR
//----------------------------------------------------------
#define	TCK	 		PA14			// TCK  PGC =(AVR-SCK)
#define	TDI	 		PA15			// TDI  PGM =(AVR-MOSI)
#define	TDO	 		PB3				// TDO  PGD =(AVR-MISO)
#define	TMS 		PA13			// TMS  MCLR=(AVR-RST)
#define	TRST		PB4				// TRST
#define	SRST		PB5				// SRST
#define	Vcc1		PB6				// Vcc1���o PB5��SWIM RESET
#define	Vcc2		PB7				// Vcc2���o
//----------------------------------------------------------
#endif	//STM8S_D

#define	TCK	 		0			// TCK  PGC =(AVR-SCK)
#define	TDI	 		1			// TDI  PGM =(AVR-MOSI)
#define	TDO	 		2			// TDO  PGD =(AVR-MISO)
#define	TMS 		3			// TMS  MCLR=(AVR-RST)
#define	TRST		4			// TRST
#define	SRST		5			// SRST
#define	Vcc1		6			// Vcc1���o PB5��SWIM RESET
#define	Vcc2		7			// Vcc2���o



//	PIC PGx�s����JTAG�s���̑Ή��\.
#define	PGM	 		TDI			// TDI  PGM =(AVR-MOSI)
#define	PGC	    	TCK			// TCK  PGC =(AVR-SCK)
#define	PGD	    	TDO			// TDO  PGD =(AVR-MISO)
#define	MCLR    	TMS			// TMS  MCLR=(AVR-RST)

#endif	// ifndef	_pindef_h_
