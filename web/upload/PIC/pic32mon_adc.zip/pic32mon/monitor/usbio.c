/********************************************************************
 *
 ********************************************************************
 */
#include <string.h>

#include "platform_config.h"
#include "hw_config.h"
#include "hidcmd.h"
#include "monit.h"

#include "usbio.h"

void USBTask(void);


#define	PUTBUF_SIZE	(64-8)

extern	uchar puts_buf[];		//[PUTBUF_SIZE];
extern	uchar puts_ptr;

/********************************************************************
 *	
 ********************************************************************
 */
int _user_putc(char c)
{
	uchar flush = 0;
	if( c == 0x0a) { flush = 1; }
	if( puts_ptr >= PUTBUF_SIZE ) {flush = 1;}

	if( flush ) {
		while(puts_ptr) {
			USBTask();
		}
	}

	if(	puts_ptr < PUTBUF_SIZE ) {
		puts_buf[puts_ptr++]=c;
	}

	return 1;
}
/********************************************************************
 *	
 ********************************************************************
 */
void *memcpy(void *dst,const void *src,size_t size)
{
	char *t = (char*)dst;
	char *s = (char*)src;
	while(size--) {*t++=*s++;}
	return t;
}


int _user_puts(char *s)
{
	while(*s) {
		_user_putc(*s++);
	}
	return 0;
}

#if	0
/********************************************************************
 *	��`
 ********************************************************************
 */
void memdump(char *mesg,void *src , int len )
{
	char buf[16];
	uchar *s=(uchar*)src;
	int i;

	_user_puts(mesg);

	for(i=0; i<len; i++) {
		sprintf(buf,"%02x ",*s);
		s++;
		_user_puts(buf);
	}
	_user_puts("\n");
}
#endif
