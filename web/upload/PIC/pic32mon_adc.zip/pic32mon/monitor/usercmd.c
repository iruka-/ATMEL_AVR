/********************************************************************
 *	���[�U�[��`�֐��̎��s
 ********************************************************************
 */
#include <stdio.h>
#include "../typedef.h"

int _user_putc(char c);
int _user_puts(char *s);

void analog_init(void);
u16  analogRead(u8 pin);

//------------------------------------------------
//PIC32MX 220F032B�� Analog In
//------------------------------------------------
//	AN0 =Pin 2 (RA0)
//	AN1 =Pin 3 (RA1)
//	AN2 =Pin 4 (RB0)
//	AN3 =Pin 5 (RB1)
//	AN4 =Pin 6 (RB2)
//	AN5 =Pin 7 (RB3)
//	AN6  ---   �s�����蓖�ĂȂ�.
//	AN7  ---   ''
//	AN8  ---   ''
//	AN9 =Pin26 (RB15) (�A��LED OUT�Ƃ��Ďg�p��)
//	AN10=Pin25 (RB14)
//	AN11=Pin24 (RB13)
//	AN12 ---   (VUSB3v3�Ȃ̂�220F032B�ł͎g�p�ł��Ȃ�)

#define	AIN_PIN	2	// RB0 (PIC32MX:PIN_4)



/********************************************************************
 *
 ********************************************************************
 */
void user_cmd(int arg)
{
	int i,j;
	analog_init();
	//
	//	printf()�e�X�g�̎��s.
	//
	for(i=0;i<100;i++) {
		j=analogRead(AIN_PIN);
//		printf("Hello World (%d)\n",i);
		printf("j=%d\n",j);
	}
//	_user_puts("Hello");
}

