/*	----------------------------------------------------------------------------
	FILE:			analog.c
	PROJECT:		pinguinoX
	PURPOSE:		
	PROGRAMER:		jean-pierre mandon <jp.mandon@gmail.com>
	FIRST RELEASE:	19 feb. 2011
	LAST RELEASE:	25 feb. 2012
	----------------------------------------------------------------------------
	CHANGELOG:
	[31-03-11][rblanchot@gamil.com][fixed conditional compilation for board support]
	// 08 nov. 2011 fixed a bug in analogRead ( stop and restart analog converter before sampling )
	// 25 feb. 2012 added support for PIC32_PINGUINO_220
	// 17 mar. 2012 [hgmvanbeek@gmail.com] added support for PIC32_PINGUINO_MICRO
	----------------------------------------------------------------------------
	This library is free software; you can redistribute it and/or
	modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation; either
	version 2.1 of the License, or (at your option) any later version.

	This library is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	Lesser General Public License for more details.

	You should have received a copy of the GNU Lesser General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
	--------------------------------------------------------------------------*/

#include <p32xxxx.h>			// always in first place to avoid conflict with const.h ON
#include "typedef.h"


#ifndef __ANALOG__
#define __ANALOG__

#define pA	0
#define pB	1
#define pC	2
#define pD	3
#define pE	4
#define pF	5
#define pG	6

#define _0	1<<0
#define _1	1<<1
#define _2	1<<2
#define _3	1<<3
#define _4	1<<4
#define _5	1<<5
#define _6	1<<6
#define _7	1<<7
#define _8	1<<8
#define _9	1<<9
#define _10	1<<10
#define _11	1<<11
#define _12	1<<12
#define _13	1<<13
#define _14	1<<14
#define _15	1<<15
#define nil 1<<16

#if 1	//defined(PIC32_PINGUINO_220)

//	1=PORTB 2=PORTA
u8  __portanalogmask[]=	{ 2, 2, 1, 1, 1, 1, 0, 0,
						  0, 2, 2, 2, 0, 0, 0, 0,
						  0, 0, 0, 0, 0, 0} ;  
                                              
//	PORT MASK (bit mask)
u16 __analogmask[]=    	{_0, _1, _0, _1,_2,_3, 0, 0,
						  0,_15,_14,_13, 0, 0, 0, 0,
						  0, 0, 0, 0, 0, 0} ;  

//u16 __bufmask[]=		{0x0018,0x001C,0x0008,0x000C,0x0010,0x0014,0x0000,0x0000,
//						 0x0000,0x0000,0x0000,0x0000,0x0000,0x0000,0x0018,0x001C,
//						 0x0008,0x000C,0x0010,0x0014,0x0000,0x0000};


//Analog In
//	AN0 =Pin 2 (RA0)
//	AN1 =Pin 3 (RA1)
//	AN2 =Pin 4 (RB0)
//	AN3 =Pin 5 (RB1)
//	AN4 =Pin 6 (RB2)
//	AN5 =Pin 7 (RB3)
//	AN6  ---   
//	AN7  ---   
//	AN8  ---   
//	AN9 =Pin26 (RB15)
//	AN10=Pin25 (RB14)
//	AN11=Pin24 (RB13)
//	AN12 ---   

//Pinguino Define (bufmask������): <===�g��Ȃ�
//	A0	110=6 
//	A1	111=7 
//	A2	010=2 
//	A3	011=3 
//	A4	100=4 
//	A5	101=5 
//	A6	000=0 
//	A7	000=0 

#endif



#define A0 0
#define A1 1
#define A2 2
#define A3 3
#define A4 4
#define A5 5
#define A6 6
#define A7 7

void SetAnalog(u8 pin)
{
	#if defined(PIC32_PINGUINO) || defined(PIC32_PINGUINO_OTG)
	if ((pin==4)||(pin==18)) TRISDbits.TRISD9=1;   // analog input 18 is shared with I2C
	if ((pin==5)||(pin==19)) TRISDbits.TRISD10=1;  // analog input 19 is shared with I2C
	#endif

	#if defined(PIC32_PINGUINO_220)
		switch (__portanalogmask[pin])
			{
			case 1:	ANSELBSET=__analogmask[pin];
					TRISBSET =__analogmask[pin];
					break;
			case 2: ANSELASET=__analogmask[pin];
					TRISASET =__analogmask[pin];
					break;
			}		
	#else
	TRISBSET  =__analogmask[pin];
	AD1PCFGCLR=__analogmask[pin];
	#endif
}

u8 IsDigital(u8 pin)
{
	#if defined(PIC32_PINGUINO_220)
		switch (__portanalogmask[pin])
			{
			case 1:	if (ANSELB&__analogmask[pin]) return 1;
					else return 0;
					break;
			case 2: if (ANSELA&__analogmask[pin]) return 1;
					else return 0;
					break;
			}		
	#else	
	if ((AD1PCFG&__analogmask[pin])!=0) return 1;
	else return 0;
	#endif
}

void analog_init(void)
{
	AD1CSSL = 0;
	AD1CON1 = 0x00E0;
	AD1CON2 = 0;
	AD1CON3 = 0x8F00;
	AD1CON1bits.ADON = 1;
}

u16 analogRead(u8 pin)
{
	AD1CON1bits.ADON = 0;				  // stop analogic converter
	if (IsDigital(pin)) SetAnalog(pin);	  // set analog

//	AD1CHS=(__bufmask[pin]/4)<<16;		  // select channel
	AD1CHS=pin<<16;						  // select channel
	AD1CON1bits.ADON = 1;				  // start analogic converter
	AD1CON1bits.SAMP=1;					  // start sampling
	while (!AD1CON1bits.DONE);			  // wait for conversion
	return(ADC1BUF0+(8*(AD1CON2bits.BUFS&0x01))); // return result
}

#endif
