#include<stdio.h>
#include<windows.h>
#include<WINUSB.H>
#include<usb100.h>
#include<setupapi.h>
#include<strsafe.h>

struct devInfo
{
  HANDLE deviceHandle;  
  WINUSB_INTERFACE_HANDLE winUSBHandle;
  unsigned char bulkInPipe;
  unsigned char bulkOutPipe;
  unsigned char interruptPipe;
  int deviceSpeed;   
}devInfo;

struct devInfo devInfo;

BOOL GetDevicePath(LPGUID InterfaceGuid, PCHAR DevicePath, size_t BufLen)
{
  BOOL bResult = FALSE;
  HDEVINFO deviceInfo;
  SP_DEVICE_INTERFACE_DATA interfaceData;
  PSP_DEVICE_INTERFACE_DETAIL_DATA detailData = NULL;
  ULONG length;
  ULONG requiredLength=0;
  HRESULT hr;

  deviceInfo = SetupDiGetClassDevs(InterfaceGuid, NULL, NULL, DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);

  interfaceData.cbSize = sizeof(SP_DEVICE_INTERFACE_DATA);
  bResult = SetupDiEnumDeviceInterfaces(deviceInfo, NULL, InterfaceGuid, 0, &interfaceData);
  
  SetupDiGetDeviceInterfaceDetail(deviceInfo, &interfaceData, NULL, 0, &requiredLength, NULL);
  detailData = (PSP_DEVICE_INTERFACE_DETAIL_DATA)LocalAlloc(LMEM_FIXED, requiredLength);

  if(NULL == detailData)
  {
    SetupDiDestroyDeviceInfoList(deviceInfo);
    return FALSE;
  }

  detailData->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);
  length = requiredLength;

  bResult = SetupDiGetDeviceInterfaceDetail(deviceInfo, &interfaceData, detailData, length, &requiredLength, NULL);

  if(FALSE == bResult)
  {
    LocalFree(detailData);
    return FALSE;
  }

  hr = StringCchCopy(DevicePath, BufLen, detailData->DevicePath);
  if(FAILED(hr))
  {
    SetupDiDestroyDeviceInfoList(deviceInfo);
    LocalFree(detailData);
  }
  LocalFree(detailData);

  return bResult;
}

//�f�o�C�X�̃t�@�C���n���h���̎擾
HANDLE OpenDevice()
{
  HANDLE hDev = NULL;
  char path[512];
  BOOL retVal;
  
  // Object interface: IUnknown, ver. 0.0,
  // GUID={0x00000000,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}}
  //  char guid[] = "01B6EB7B-7C81-4c65-84E2-73B6037E9465";
  GUID guid = {
    0x01B6EB7B,
    0x7C81,
    0x4c65,
    { 0x84, 0xE2, 0x73, 0xB6, 0x03, 0x7E, 0x94, 0x65}
  };


  retVal = GetDevicePath(&guid, path, 512);

  hDev = CreateFile(path,
                    GENERIC_WRITE | GENERIC_READ,
                    FILE_SHARE_WRITE | FILE_SHARE_READ,
                    NULL,
                    OPEN_EXISTING,
                    FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED,
                    NULL);
  return hDev;
}


//WinUSB�̏������ƃI���W�i���f�o�C�X�̍\��

BOOL Initialize_Device()
{
  BOOL bResult;
  WINUSB_INTERFACE_HANDLE usbHandle;
  USB_INTERFACE_DESCRIPTOR ifaceDescriptor;
  WINUSB_PIPE_INFORMATION pipeInfo;

  UCHAR speed;
  ULONG length;
  
//WinUSB������

  devInfo.winUSBHandle = OpenDevice(TRUE);
  bResult = WinUsb_Initialize(devInfo.winUSBHandle, &usbHandle);

  if(bResult)
  {
    devInfo.winUSBHandle = usbHandle;
    length = sizeof(UCHAR);
    bResult = WinUsb_QueryDeviceInformation(devInfo.winUSBHandle,
                                            DEVICE_SPEED,
                                            &length,
                                            &speed); 
  }

  if(bResult)
  {

    devInfo.deviceSpeed = speed;
    bResult = WinUsb_QueryInterfaceSettings(devInfo.winUSBHandle,
                                            0,
                                            &ifaceDescriptor);

  }
  if(bResult)
  {
    int i;
    for(i=0;i<ifaceDescriptor.bNumEndpoints;i++)
    {

      bResult = WinUsb_QueryPipe(devInfo.winUSBHandle,
                                 0,
                                 (UCHAR) i,
                                 &pipeInfo);

      if(pipeInfo.PipeType == UsbdPipeTypeBulk &&
                  USB_ENDPOINT_DIRECTION_IN(pipeInfo.PipeId))
      {
        devInfo.bulkInPipe = pipeInfo.PipeId;
      }
      else if(pipeInfo.PipeType == UsbdPipeTypeBulk &&
                  USB_ENDPOINT_DIRECTION_OUT(pipeInfo.PipeId))
      {
          
        devInfo.bulkOutPipe = pipeInfo.PipeId;
      }
      else if(pipeInfo.PipeType == UsbdPipeTypeInterrupt)
      {
        devInfo.interruptPipe = pipeInfo.PipeId;
      }
      else
      {
        bResult = FALSE;
        break;
      }
    }
  }
  return bResult;
}

BOOL WriteToDevice(unsigned char data)
{
  BOOL bResult;
  ULONG bytesReturned;
  WINUSB_SETUP_PACKET setupPacket;
  UCHAR lightedBars = 0;
  USHORT bufSize = 12;
  UCHAR szBuffer[12];
  ULONG bytesWritten;
  USB_ENDPOINT_DESCRIPTOR usbEndpointD;
  
  szBuffer[0] = data; 
  setupPacket.RequestType = 0; 
  setupPacket.Request = 0x08;
  setupPacket.Index = 0;
  setupPacket.Length = sizeof(UCHAR);
  setupPacket.Value = 0;

  bResult = WinUsb_ControlTransfer(devInfo.winUSBHandle,
                                   setupPacket,
                                   &lightedBars,
                                   sizeof(UCHAR),
                                   &bytesReturned,
                                   NULL);

  usbEndpointD.bEndpointAddress = 0x01; //������`����ƃG���h�|�C���g�Ƃ̒ʐM���ł���悤�ɂȂ���.

//pipeID�̕�����devInfo.bulkOutPipe����usbEndpointD.bEndpointAddress�ɕύX
  bResult = WinUsb_WritePipe(devInfo.winUSBHandle,
                             usbEndpointD.bEndpointAddress,
                             szBuffer,
                             1,
                             &bytesWritten,
                             NULL);
  return bResult;
}   

void main(void){

  unsigned char data;
  Initialize_Device();
  data = 0x02; //�����̐��l��ς���Əo�͂��ς��
  WriteToDevice(data);
}
>|c|

����͂�����̂̊��Ⴂ���Ă���ӏ�������Ƃ����Ȃ��̂�,

���낢�뒲�ׂĂ݂邱�Ƃɂ���.

Permalink | �R�����g(0) | �g���b�N�o�b�N(4) | 19:01

   
�R�����g�ꗗ

�͂Ăȃ��[�U�[�̂݃R�����g�ł��܂��B�͂ĂȂփ��O�C���������͐V�K�o�^�������Ȃ��Ă��������B

�g���b�N�o�b�N - http://d.hatena.ne.jp/Waroe/20090220/1235124086 
NoTitleStory - WinUSB�̃T���v���R�[�h�X�V. 
NoTitleStory - WinUSB�̃T���v���R�[�h. C����ł�. 
NoTitleStory - �T���v���R�[�h���\�~�X���Ă�Ȃ� 
NoTitleStory - WinUSB�����̉��̂��߂ɂ܂Ƃ߂Ă����Ă�낤. 
