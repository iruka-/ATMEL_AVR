int UsbGetDevCaps(void)					{return 0;}
int UsbGetDevId(void)					{return 0;}
int analize_infra(void)					{return 0;}
int cmdAinGraph(void)					{return 0;}
int cmdRegGraph(void)					{return 0;}

/*
int hidCommand(void)					{return 0;}
int hidReadBuffer(void)					{return 0;}
int hidReadPoll(void)					{return 0;}
int hidWriteBuffer(void)				{return 0;}
int hidWriteBuffer2(void)				{return 0;}
int hidasp_close(void)					{return 0;}
int hidasp_init(void)					{return 0;}
*/

int bfd_micromips_num_opcodes(void)		{return 0;}
int init_symbol(void)					{return 0;}
int is_crlf(void)						{return 0;}
int micromips_opcodes(void)				{return 0;}
int reg_symbol(void)					{return 0;}
int set_force_thumb(void)				{return 0;}
