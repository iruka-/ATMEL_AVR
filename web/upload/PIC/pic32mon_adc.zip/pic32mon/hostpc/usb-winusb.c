/****************************************************************************
 *
 ****************************************************************************
 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <windows.h>
#include <setupapi.h>
#include <ddk/hidsdi.h>
#include <ddk/hidpi.h>
#include <dbt.h>
#include  "sal.h"
#include  "packet.h"
#include  "mphidflash.h"

#include  "winusb.h"

#define	VID	0x04d8
#define	PID	0x0052

#define	OUT_EP	0x01
#define	IN_EP	0x81

#define	VERBOSE_DUMP	0	// USB�p�P�b�g���O���_���v����.


HANDLE usbdevhandle = INVALID_HANDLE_VALUE;
WINUSB_INTERFACE_HANDLE wUsbIfHandle;		//And then can call WinUsb_Initialize() to get the

unsigned char        usbBuf[64 * 1024];
unsigned char        readBuf[64 * 1024];

void	memdump_print(void *ptr,int len,int off);

//
//	������ str �� needle ���܂�ł��邩.
//
int	str_ichk(char *str,char *needle)
{
	while(*needle) {
		if(tolower(*str)!=tolower(*needle)) return -1;
		str++;
		needle++;
	}
	return 0;	//OK.
}

//
//	�啶���������𓯈ꎋ���� strindex()
//
int	str_iindex(char *str,char *needle)
{
	int len=strlen(str);
	int i;
	for(i=0;i<len;i++) {
		if(str_ichk(str+i,needle)==0) return i;
	}
	return -1;	//���s.
}

//
//	�Y������VID:PID�� WinUsb�f�o�C�X�̃p�X���𓾂�.
//
int	getDevicePath(char *Path,int vid,int pid)
{
	SP_DEVICE_INTERFACE_DATA interfaceData;
	PSP_DEVICE_INTERFACE_DETAIL_DATA detailData = NULL;
	ULONG length;
	ULONG requiredLength=0;
//	HRESULT hr;
	int rc,index;
	char DeviceVidPid[64];		//"\\usb#vid_%04x&pid_%04x"

	sprintf(DeviceVidPid,"\\usb#vid_%04x&pid_%04x",vid,pid);
	//
	//	GUID for USB peripheral devices
	//
	GUID guid = {0xa5dcbf10, 0x6530, 0x11d2, 0x90, 0x1F, 0x00, 0xC0, 0x4F, 0xB9, 0x51, 0xED};
	HDEVINFO deviceInfo = SetupDiGetClassDevs(&guid,NULL,NULL,DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);

	//
	//	�Y��GUID������ DeviceInterface ��񋓂���.
	//
	for(index=0;index<16;index++) {
		interfaceData.cbSize = sizeof(SP_DEVICE_INTERFACE_DATA);
		rc = SetupDiEnumDeviceInterfaces(deviceInfo, NULL, &guid, index, &interfaceData);
		if(rc == ERROR_NO_MORE_ITEMS) break;
		SetupDiGetDeviceInterfaceDetail(deviceInfo, &interfaceData, NULL, 0, &requiredLength, NULL);
		detailData = (PSP_DEVICE_INTERFACE_DETAIL_DATA)LocalAlloc(LMEM_FIXED, requiredLength);
		if(detailData == NULL) {	rc = 0;break; }
		detailData->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);
		length = requiredLength;
		rc = SetupDiGetDeviceInterfaceDetail(deviceInfo, &interfaceData, detailData
										, length, &requiredLength, NULL);
		strcpy(Path, detailData->DevicePath);
		LocalFree(detailData);
		//
		//	�p�X����  ������ "\usb#vid_04d8&pid_0052#" ���܂�ł��邩.
		//
		int idx = str_iindex(Path,DeviceVidPid);
#if	VERBOSE_DUMP	
		printf("idx=%d IF=%s\n",idx,Path);
#endif
		if(idx >= 0 ) {	rc=1;break;	}	//�܂�ł���.
		if(rc==0) 	  {		 break;	}
	}
	SetupDiDestroyDeviceInfoList(deviceInfo);
	return rc;
}

int	usbOpen(int vendorID,int productID)
{
	char path[512]="";
	int	rc = getDevicePath(path,VID,PID);
#if	VERBOSE_DUMP	
	printf("rc=%d path=%s\n",rc,path);
#endif
	usbdevhandle = CreateFile(path, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ
					 | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, 0);
//	if(devHandle != INVALID_HANDLE_VALUE) {
	DWORD ErrorStatus = GetLastError();
	if(ErrorStatus == ERROR_SUCCESS) {
		rc = WinUsb_Initialize(usbdevhandle, &wUsbIfHandle);
#if	VERBOSE_DUMP	
		printf("rc=%d devHandle=%d wUsbIfHandle=%x\n",rc,usbdevhandle ,wUsbIfHandle);
#endif
		return 0;
	}else{
		printf("CreateFile:Error Status=0x%x\n",(int)ErrorStatus);
		return -1;
	}
	(void)rc;
}

int	usbWrite(uchar *usbBuf,int len,uchar *readBuf,int readlen)
{
	DWORD   bytesWritten = 0;
	DWORD   bytesRead = 0;
	int rc = 0;

	//				 	  handle,   endpoint, buffer  , length, written , overlap;
	rc = WinUsb_WritePipe(wUsbIfHandle, OUT_EP, usbBuf , len , &bytesWritten, NULL);
	if(bytesWritten != len) {
		printf("ERROR:WinUsb_WritePipe(%d,%d)=%d\n",len,(int)bytesWritten,rc);
		return -1;
	}

#if	VERBOSE_DUMP	
	{
		printf("WinUsb_WritePipe(%d,%d)=%d\n",len,bytesWritten,rc);
		memdump_print(usbBuf,64,0);
		printf("\n");
	}
#endif

	if(readlen) {
		//				 	  handle,   endpoint, buffer  , length, written , overlap;
		rc = WinUsb_ReadPipe(wUsbIfHandle, IN_EP , readBuf , readlen , &bytesRead, NULL);
		if(bytesRead != readlen) {
			printf("ERROR:WinUsb_ReadPipe(%d,%d)=%d\n",readlen,(int)bytesRead,rc);
			return -1;
		}
#if	VERBOSE_DUMP	
		printf("WinUsb_ReadPipe(%d,%d)=%d\n",readlen,bytesRead,rc);
		memdump_print(readBuf,64,0);
		printf("\n");
#endif
	}
	return 0;	// Ok.
}


void usbClose(void)
{
	WinUsb_Free(wUsbIfHandle);
	CloseHandle(usbdevhandle);
}
