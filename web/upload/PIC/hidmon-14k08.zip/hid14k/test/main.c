/*********************************************************************
 *	�R���\�[���\���T���v��.
 *********************************************************************

 * register dump test

 */
#include "pic18fxxxx.h"
#include "io_cfg.h"
#include "bios.h"

#define	puts(s)		bios_puts(s)
#define	putch(c)	bios_putc(c)


#define	REGDUMP		(1)		//���W�X�^�\���ɂ��f�o�b�O�@�\On.

/*********************************************************************
 *
 *********************************************************************
 */
void LED_blink(void)
{
	static word led_count=0;
    
    led_count++;
	if(led_count & 0x8000) {
		mLED_1_On();
		mLED_2_Off();
	}else{
		mLED_1_Off();
		mLED_2_On();
	}
}

/*********************************************************************
 *
 *********************************************************************
 */
void print_hex1(uchar h)
{
	h &= 0x0f;
	if(h>=10) {
		h = h-10+'a';
	}else{
		h = h + '0';
	}
	putch(h);
}

/*********************************************************************
 *
 *********************************************************************
 */
void print_hex(uchar h)
{
	print_hex1(h>>4);
	print_hex1(h);
}

/*********************************************************************
 *
 *********************************************************************
 */
void print_key(char key)
{
	uchar c;
	puts("\n* Key Pressed: code=0x");
	print_hex(key);
	puts("\n* Press 'X' key to stop program.");
	puts("\n* Press any key to continue:");
	while(1) {
		bios_task();
		c = bios_getc();
		if( c !=0 ) break;
	}
	if((c == 'x') || (c == 'X')) {
		bios_exit();
	}
}

/*********************************************************************
 *
 *********************************************************************
 */
void main(void)
{
	uchar c=0x20;
	uchar key;
	mInitAllLEDs();

#if	1
	while(1) {
#else
	uchar count;
	for(count=0;count<10;count++) {
#endif
		bios_task();
		LED_blink();
		putch(c);
		c++;
#if	REGDUMP			//���W�X�^�\���ɂ��f�o�b�O�@�\On.
		bios_vregdump();
#endif
		if(c>=0x7f) {
#if	REGDUMP			//���W�X�^�\���ɂ��f�o�b�O�@�\On.
			bios_regdump();
#endif
			putch(0x0a);
			c=0x20;
		}
#if	1
		if(key=bios_getc()) {
		bios_vregdump();
			print_key(key);
		}
#endif
	}
	bios_exit();
}
/*********************************************************************
 *
 *********************************************************************
 */
