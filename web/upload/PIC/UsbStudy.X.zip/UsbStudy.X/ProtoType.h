#ifndef PROTOTYPES_H
#define	PROTOTYPES_H

#include "typedef.h"

// Define data types alias
	typedef unsigned char			UINT8;
	typedef unsigned short int		UINT16;
	typedef unsigned long int		UINT32;

	typedef char			INT8;
	typedef short int		INT16;

	typedef unsigned long long QWORD;                          /* 64-bit unsigned */


//  Sci block
UINT16 GetRxCount(void);
UINT16 GetTxCount(void);
UINT16 GetTxFreeSpace(void);
UINT16 CheckBreak(void);
UINT8 GetChar(void);
void SendChar(char ch);
void SendString(char *str);
void SendCrlf(void);
void SendSpace(void);
void SendHex8(int i);
void SendHex4(int i);
void SendHex2(int c);
void SendNum(unsigned int c);
void FlushQueue(void);
void SetBaudRate(UINT32 baud);
void UartInit(UINT8 *rxbuf, UINT16 rxsize, UINT8 *txbuf, UINT16 txsize);
UINT8 SkipSpace(UINT8 **p);
int  GetHex(UINT8 **p);
UINT8 SciGets(UINT8 *pBuffer, UINT8 len, UINT16 *p);

void UsbInit(void);	// Prototype

//	PIC32MX
void UserInit(void);
void zz(char *s,int n);
void hh(char *s,int n);
#define	ZZ	zz(__FILE__,__LINE__);


#endif	/* PROTOTYPES_H */

