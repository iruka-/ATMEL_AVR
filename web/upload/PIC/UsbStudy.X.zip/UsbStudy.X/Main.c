/*
 *******************************************************************************
 *	Main
 *******************************************************************************
 *
void	Delay1ms(void);
void	Delay(UINT16 msec);
void	ResetDataBits(void);
void	ResetUsbBus(void);
void	_USB1Interrupt(void);
INT8	DataProc(UINT8 token, UINT8 bd, UINT8 retry);
INT8	SendSetupSub(void);
INT8	SendSetConfig(void);
INT8	SendGetString(UINT8 index);
INT8	SendSetAddress(UINT8 adrs);
INT8	SendAck(void);
INT8	GetPacket(UINT8 *buf, UINT8 ep);
INT8	GetDescriptor(UINT8 index);
void	HexDump(UINT8 *buf, UINT16 size);
void	UsbInit(void);
UINT8	CheckDevice(void);
int		main(void);
 *******************************************************************************
 */

#if defined(__PIC24F__)
#	include <p24fxxxx.h>
#	define EnableInterrupts    __asm__ volatile("disi #0x0"); // Enable all interrupts
#else
#	include <p32xxxx.h>
#	define	no_auto_psv	nomips16
#	define EnableInterrupts    __asm__ volatile("ei"); // Enable all interrupts
#endif


#include	<string.h>		// for memset
#include	"ProtoType.h"
#include	"usbdefs.h"
#include	"led.h"


#if defined(__PIC24F__)
_CONFIG1(WDTPS_PS1 & FWPSA_PR32 & WINDIS_OFF & FWDTEN_OFF & ICS_PGx1 & GWRP_OFF & GCP_OFF & JTAGEN_OFF)
_CONFIG2(POSCMOD_XT & I2C1SEL_PRI & IOL1WAY_OFF & OSCIOFNC_ON & FCKSM_CSDCMD & FNOSC_PRIPLL & PLL96MHZ_ON & PLLDIV_NODIV & IESO_ON)
_CONFIG3(WPFP_WPFP0 & SOSCSEL_SOSC & WUTSEL_LEG & WPDIS_WPDIS & WPCFG_WPCFGDIS & WPEND_WPENDMEM)
_CONFIG4(DSWDTPS_DSWDTPS3 & DSWDTOSC_LPRC & RTCOSC_SOSC & DSBOREN_OFF & DSWDTEN_OFF)
#endif

#define	VERBOSE		(0)


#define	UARTBUF_SIZE	1024
UINT8	RxBuf[UARTBUF_SIZE];	// UART RX buffer
UINT8	TxBuf[UARTBUF_SIZE];	// UART TX buffer
UINT8   DataBuf[512];	// Data buffer
UINT8   UsbBuf[64];	// USB Transction buffer
UINT8   CmdBuf[80];	// Command input buffer
UINT8	DataBits[16];	// DATA0/DATA1 bits array

char	bfPingPongIn=0;
char	bfPingPongOut=0;
//static
BDT_ENTRY __attribute__((aligned(512))) bdt_entry[4];	//USB HOST�̏ꍇ�́AEP0�݂̂�OK.
UINT32	*BDT;	// BD array access pointer

//	pic32mx��BDT
/*	0xa0000200:(��) 
MIPS> d
a0000200 84 00 08 00 68 02 00 00  34 00 08 00 68 02 00 00
         ~~~~~ ~~~~~ ~~~~~~~~~~~
       BD_STAT COUNT PHY_ADRS(a000xxxx->0000xxxx)
pic24f�ł� BD_STAT��COUNT�͍��킹��16bit�ɋl�ߍ��܂��.
pic24f�ł� PHY_ADRS��16bit.�����PHY==LOGICAL ADRS�ɂȂ�.
pic32mx�ł� full ping pong���[�h�Œ肷�Ȃ킿
 BDT[0] EP0 RX (ping pong even IN)
 BDT[1] EP0 RX (ping pong odd IN)
 BDT[2] EP0 TX (ping pong even OUT)
 BDT[3] EP0 TX (ping pong odd OUT)
       ....
a0000210 64 00 00 00 40 02 00 00  24 00 01 00 40 02 00 00
a0000220 88 00 40 00 7c 03 00 00  44 00 40 00 7c 03 00 00
*/
#if defined(__PIC24F__)
enum {
	EP0_IN_0s=0,		// BDSTAT[6],COUNT[10]
	EP0_IN_0a=1,		// BUFADRS[16]
	EP0_IN_1s=0,
	EP0_IN_1a=1,
	EP0_OUT_0s=2,
	EP0_OUT_0a=3,
	EP0_OUT_1s=2,
	EP0_OUT_1a=3,
};
#else
enum {
// EP0 IN(EVEN)
	EP0_IN_0s=0,	// BDSTAT[16],COUNT[16]
	EP0_IN_0a,		// BUFADRS[32]
// EP0 IN(ODD)
	EP0_IN_1s,
	EP0_IN_1a,
// EP0 OUT(EVEN)
	EP0_OUT_0s,
	EP0_OUT_0a,
// EP0 OUT(ODD)
	EP0_OUT_1s,
	EP0_OUT_1a,
};
#endif
enum{
	INDIR=0,
	OUTDIR=1,
};

UINT16	LowSpeed;	// Low speed device flag
UINT16	PacketSize;	// Packet size (8 or 64)
UINT16	ReplySize;	// Reply data length
//UINT16	SendPtr;	// Send pointer index
UINT16	UirSave;	// U1IR register save
//UINT16	UstatSave;	// U1STAT register save
UINT16	UsbAttach;	// Attache flag
UINT16	ErrorCode;	// Error code
UINT16	ConfigLen;	// Config descriptor length
UINT16	SendLen;	// Send data length
volatile UINT16 SofCount;	// SOF counter

const UINT8 GetDesc[] = {0x80, 0x06, 0x00, 0x01, 0x00, 0x00, 0x40, 0x00};	// Get device descriptor SETUP contents
const UINT8 GetConfigDesc[] = {0x80, 0x06, 0x00, 0x02, 0x00, 0x00, 0x09, 0x00};	// Get config descriptor SETUP contents
const UINT8 GetReportDesc[] = {0x81, 0x06, 0x00, 0x22, 0x00, 0x00, 0xff, 0x00}; // Get report descriptor (interface 0)
const UINT8 GetReportDesc2[] = {0x81, 0x06, 0x00, 0x22, 0x01, 0x00, 0xff, 0x00};// Get report descriptor (interface 1)
const UINT32 PacketTable[] =
{(UINT32)GetDesc, (UINT32)GetConfigDesc, (UINT32)GetReportDesc, (UINT32)GetReportDesc2};// 0,1,2,3

const UINT8 GetString[] = {0x80, 0x06, 0x00, 0x03, 0x09, 0x04, 0xff, 0x00};// Get string descriptor contents
const UINT8 SetConfig[] = {0x00, 0x09, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00};// SET_CONFIG contents
const UINT8 SetAdrs[] = {0x00, 0x05, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00};	// SET_ADDRESS contents
//
//	Wait 1mS
//
void Delay1ms(void)
{
//	PR1 = 15999;	// 16000 count will be 1mS at 16MHz bus clock
	PR1 = 19999;	// 20000 count will be 1mS at 20MHz bus clock
	T1CON = 0x8000;	// Enable timer1
	IFS0bits.T1IF = 0;	// Clear timer1 overflow flag
	while(!IFS0bits.T1IF);	// Wait until timer1 overflows
	T1CON = 0x0000;	// Disable timer
}
//
//	Time delay (mS)
//
void Delay(UINT16 msec)
{
	while(msec--)// Repeat by (mS) number
		Delay1ms();	// Call 1mS delay
}
//
//	Reset DATA0/DATA1 bits
//
void ResetDataBits(void)
{
	memset(DataBits, 0, 16);	// Clear DATA0/1 bits of all endpoint
	ConfigLen = 0;	// Clear conig descriptor length
}
//
//	Reset USB bus
//
void ResetUsbBus(void)
{
	U1CONbits.SOFEN = 0;	// Turn off SOF's, SOF packet start
	U1CONbits.USBRST = 1;	// Invoke reset
	Delay(50);	// Wait 50mS
	U1CONbits.USBRST = 0;	// Release reset
	U1CONbits.SOFEN = 1;	// Turn on SOF's, SOF packet start
}

void led_toggle_x()
{
	static int cnt=0;
	cnt++;
	if(	cnt>=100) {
		cnt = 0;
		led_toggle();
	}
}

//
//	USB handler (Handle SOF ATTACH DETACH interrupts)
//
void __attribute__((__interrupt__,no_auto_psv)) _USB1Interrupt(void)
{
	UirSave = U1IR;	// Save USB status
	U1IR = 0xff;	// Clear all status bit
#if defined(__PIC24F__)
	IFS5bits.USB1IF = 0;	// Clear USB1 interrupt flag
#else //defined( __PIC32MX__)
	IFS1CLR = _IFS1_USBIF_MASK;
	led_toggle_x();
#endif
	if(UirSave & 0x04)	// SOF interrupts?
		SofCount++;	// Just increment SOF counter
	if(UsbAttach == 0)	// Device is not attached yet?
	{
		if(UirSave & 0x40)	// Check attache flag
		{
			U1IEbits.ATTACHIE = 0;	// Disable ATTACH interrupts
			U1IEbits.DETACHIE = 1;	// Enable DETACH interrupts
			UsbAttach = 1;	// Set attache flag
			Delay(100);	// Wait untill USB bus becomes staible
			if(!U1CONbits.JSTATE)	// Connected device is low speed?
				LowSpeed = 1;	// Set low speed flag
			U1ADDR = LowSpeed? 0x80: 0x00;	// Reset USB address (Set MSB if low speed device)
			U1EP0 = LowSpeed? 0xcd: 0x4d;	// Enable EP0 & Auto retry off (Set MSB if low speed device)
			SendString("Attached\r\n");	// Show attached message
			ResetUsbBus();	// Send BUS RESET condition
			ResetDataBits();	// Reset DATA0/1 bits
		}
	}
	else	// Device is already attached
	{
		if(UirSave & 0x01)	// Detach interrupt?
		{
			UsbInit();	// Reset USB registers to disable detach and enable attach
			SendString("Detached\r\n");	// Show detached message
		}
	}
}

//	Data�̕�������ABDT�̓Y�����ɕϊ�����.
//	pingpong���l��.
int	BDT_index(int dir)
{
	int bd;
	if(dir==0) {
		bd=EP0_IN_0s  + bfPingPongIn;		// BDT is IN(RX)
	}else{
		bd=EP0_OUT_0s + bfPingPongOut;		// BDT is OUT(TX)
	}
	return bd;
}
void FlipPingPongIn()
{
	bfPingPongIn ^= 2;
}
void FlipPingPongOut()
{
	bfPingPongOut ^= 2;
}

//		dir: 0=in 1=out
void BDT_flip(int dir)
{
	if(dir==0) {
		FlipPingPongIn();
	}else{
		FlipPingPongOut();
	}
}
//
//	Handle USB transaction (HOST mode)
//		dir: 0=in 1=out
INT8 DataProc(UINT8 token, UINT8 dir, UINT8 retry)
{
UINT16	pid;
UINT16	time;
UINT32	statsave;
UINT16	lasttick;
UINT16	sofsave;
//	Data�̕�������ABDT�̓Y�����ɕϊ�����.
	int	bd = BDT_index(dir);
	BDT_flip(dir);

	if(dir)	// SETUP or OUT transaction?
	{		// bd = 2;	// Use BDT[2] for OUT/SETUP transaction
		token += 0x10;	// Set OUT/SETUP token (0x10:OUT + EP 0xd0:SETUP)
	}
	else	// IN transaction?
	{	// bd is 0
#if defined(__PIC24F__)
		BDT[bd] = 0x80ff;// Setup BDT[0] for IN packet (max 255 byte)
#else
		BDT[bd] = 0x80 | (0xff<<16);// Setup BDT[0] for IN packet (max 255 byte)
#endif
		token += 0x90;	// Set IN token (0x90 + EP)
	}
	ErrorCode = 0;	// Clear error code first
	time = 0;	// Reset retry timer
	lasttick = SofCount;	// Load current timer value
	statsave = BDT[bd];	// Save original BDSTAT for retry
tryagain:
	BDT[bd] = statsave;	// Restore BDSTAT for retry
#if	VERBOSE
	hh("bd=",bd);
	hh("token=",token);
	hh("U1EP0=",U1EP0);
	memdump("BD",BDT,32);
#endif
	sofsave = SofCount;	// Ipdate latest SOF count
	while(sofsave == SofCount) wait_us(1);	// Wait until beginning of SOF frame

	U1TOK = token;	// Write U1TOK to send transaction packet
	// U1TOK  token type pid[4]:ep[4]
	//				     0b0001:      OUT(TX)
	//				     0b1001:      IN(RX)
	//				     0b1101:      SETUP(TX)

	for(;;)	{// Wait ACK forever

// Handle Stall
		if(U1IRbits.STALLIF)	// Check STALL bit
		{
			ErrorCode = 0x40;	// Set STALL error code
			U1IRbits.STALLIF = 1;	// Clear STALL bit
			return -2;	// STALL return
		}
//	Handle Errors
		if(U1IRbits.UERRIF)	// Check error bit
		{
			ErrorCode = U1EIR;	// Save error status
			U1EIR = 0xff;   // Clear all error status bit
			U1IRbits.UERRIF = 1;	// Clear error bit
			if(retry)	// retry mode is 0? (immediate return mode)
				goto tryagain;	// Ignore error and try again
			return -3;	// Transfer error result
		}
// Handle data
		else if(U1IRbits.TRNIF)	// Data transfer bit set?
		{
#if defined(__PIC24F__)
			pid = (BDT[bd] >> 10) & 15;	// Get PID
			U1IRbits.TRNIF = 1;	// Clear data transfer bit
			if(pid == 0x02 || pid == 0x03 || pid == 0x0b) {	// ACK/DATA0/DATA1 PID means success of transaction
				return BDT[bd] & 0xff;	// Return with transfered length
			}
#else
			pid = (BDT[bd] >>(10-8)) & 15;	// Get PID
#if	VERBOSE
	hh("pid",pid);
	memdump(">Buff",UsbBuf,16);
#endif
			U1IRbits.TRNIF = 1;	// Clear data transfer bit
			if(pid == 0x02 || pid == 0x03 || pid == 0x0b) {	// ACK/DATA0/DATA1 PID means success of transaction
				return (BDT[bd]>>16) & 0xff;	// Return with transfered length
			}
#endif
			else if(pid == 0x0a)	// NAK PID means USB device is not ready
			{
				if(retry)	// retry mode is enabled?
					goto tryagain;	// Retry transaction
				return 0;	// Return as NAK result
			}
			else if(pid == 0x0e)	// STALL PID?
			{
				ErrorCode = 0x40;	// Set STALL error code
				return -2;	// STALL return
			}
			else	// Umknow pid has come
				return -5;	// Unknow error return
		}
		if(lasttick != SofCount)	// 1mS past?
		{
			lasttick = SofCount;	// Update new tick value
			if(retry && GetRxCount())	// If retry mode enabled then check key abort
			{
				(void)GetChar();	// Dump input char
				return 0;	// Normal return
			}
		}
	}
}
//
//	Send Setup packet
//
INT8 SendSetupSub(void)
{
#if defined(__PIC24F__)
	BDT[2] = 0x8008;	// Setup BD to send 8 byte
#else
	int	bd = BDT_index(OUTDIR);
	BDT[bd] = 0x80 | (0x08 << 16);	// Setup BD to send 8 byte
#endif
	DataBits[0] = 1;	// SETUP request always begins DATA0

#if	VERBOSE
	memdump("bdt_entry",bdt_entry,32);
	memdump("Buff",UsbBuf,16);
#endif
	return DataProc(0xc0, 1, 1);	// Send SETUP token (Auto retry to wait ACK)
}
//
//	Send SET_CONFIG
//
INT8 SendSetConfig(void)
{
INT8 res;
	memcpy(UsbBuf, (void*)SetConfig, 8);// Copy SET_CONFIG request contents
	if((res = SendSetupSub()) < 0)	// Send SETUP transaction (8 bytes)
		return res;	// Error return
	return DataProc(0, 0, 1);	// Get ACK packet from device
}
//
//	Send GET_DESCRIPTOR(STRING)
//
INT8 SendGetString(UINT8 index)
{
	memcpy(UsbBuf, GetString, 8);	// Copy GET_DESCRIPTOR packet contents
	UsbBuf[2] = index;	// Rewrite string index field in the GET_DESCRIPTOR packet
	return SendSetupSub();	// Send SETUP transaction (8 bytes)
}
//
//	Send SET_ADDRESS
//
INT8 SendSetAddress(UINT8 adrs)
{
INT8 res;
	if(U1ADDR & 15){// Address already set?
		return 0;	// Do nothing and normal return
	}
	memcpy(UsbBuf, SetAdrs, 8);	// Copy SET_ADDRESS request packet to send buffer
	UsbBuf[2] = adrs;	// Rewrite address field in the SET_ADDRESS request packet
	if((res = SendSetupSub()) < 0){	// Send SET_ADDRESS request (8 bytes)
		return res;	// Error return
	}
	if((res = DataProc(0, 0, 1)) < 0){	// Wait 0 byte ACK packet from device (Retry untill ACK)
		return res;	// Error return
	}
	U1ADDR = (LowSpeed? 0x80: 0x00) + adrs;	// Set new address
	return 0;	// Normal return
}
//
//	Send 0 byte ACK packet
//
INT8 SendAck(void)
{
#if defined(__PIC24F__)
	BDT[2] = 0xc000;	// Set BD0STAT RX (ACK is always DATA1) packet
#else
	BDT[EP0_OUT_0s] = 0xc0 | (0x00<<16);	// Set BD0STAT RX (ACK is always DATA1) packet
#endif
	return DataProc(0, 1, 1);	// Send 0 byte DATA1 packet (Retry until ACK)
}
//
//	Get packet from USB device
//
INT8 GetPacket(UINT8 *buf, UINT8 ep)
{
int i;
	ReplySize = 0;	// Clear received length
	PacketSize = 0;	// Clear packet size first
	do
	{
		i = DataProc(ep, 0, 1);	// Get USB packet
		if(i < 0)	// Some error happens?
			return i;	// Error return
		memcpy(buf + ReplySize, UsbBuf, i);	// Copy received data to result buffer
		ReplySize += i;	// Accumulate length
		if(PacketSize == 0)	// First packe?
		{
			if(i <= 8)	// 8 byte packet?
				PacketSize = 8;	// Set packet size 8
			else
				PacketSize = 64;	// Set packet size 64
		}
	}
	while(i == PacketSize);	// Repeat until end of packets
	return 0;	// Normal return
}
//
//	Get descriptor from USB device(0:Device 1:Config 2:Report)
//
INT8 GetDescriptor(UINT8 index)
{
INT8 res;
	memcpy(UsbBuf, (void*)PacketTable[index], 8);	// Copy GET_DESCRIPTOR request contents (8 bytes)
	if(index == 1 && ConfigLen)	// If Get config descriptor and long size is set already?
	{
		UsbBuf[7] = ConfigLen >> 8; // Rewrite maximum length field to get long version config descriptor
		UsbBuf[6] = ConfigLen & 255; // Rewrite maximum length field to get long version config descriptor
	}
	if((res = SendSetupSub()) < 0)	// Send GET_DESCRIPTOR request packet (8 bytes)
		return res;	// Error return
	if((res = GetPacket(DataBuf, 0)) < 0)	// Get descriptor from USB device
		return res;	// Error return
	return SendAck();	// Send back 0 byte DATA1 packet for ACK
}
//
//	Show hex data
//
void HexDump(UINT8 *buf, UINT16 size)
{
UINT16 i;
	for(i = 0; i < size; i++)	// Repeat for specified size
	{
		SendHex2(buf[i]);	// Put hex digit
		SendChar(' ');	// Put space
		if((i & 15) == 15)	// 16 byte boundary?
		{
			SendCrlf();	// Go next line
			while(GetTxFreeSpace() < 60);	// Wait until Tx queue had space to put
		}
	}
	if(i & 15)	// Rest of 16 byte boundary remains?
		SendCrlf();	// Put final CR/LF
}

//extern volatile unsigned int        U1BDTP1 __attribute__((section("sfrs")));

#define USB_PING_PONG_MODE	USB_PING_PONG__FULL_PING_PONG	//���͋�����Ȃ�.

//
//	Init USB registers
//
void UsbInit(void)
{
#if defined(__PIC24F__)
	BDT = (UINT16*)0x2000;	// BDT address is 0x2000
	memset((void*)BD, 0, 16);	// Clear BDT tables
	U1BDTP1 = 0x20;	// Set BDT address
	U1EIR = 0;	// Clear all USB error interrupts
	U1IR = 0xff;	// Clear all USB interrupts
	memset((void*)&U1EP0, 0, 32);	// Clear all UEP register
	U1EIE = 0;	// Disable error int
	U1IE = 0;	// Disable all interrupt
	U1PWRCbits.USBPWR = 1;	// Turn power on
	U1ADDR = 0;	// Clear USB address register
	U1SOF = 0x4A;	// Threth hold is 64 bytes
	U1OTGCON = 0x30; // Pull down D+ and D- & VBUS off
	U1CON = 0x08;	// Host mode enable
	U1IEbits.ATTACHIE = 1;	// Enable ATTACH interrupt
	U1IEbits.SOFIE = 1;	// Enable SOFIE interrupt
	U1EIE = 0xbf;	// Enable all error interrupts
#else
	di();
	BDT = (UINT32*) &bdt_entry;
ZZ	{
			// Set up the hardware.
			U1IE                = 0;        // Clear and turn off interrupts.
			U1IR                = 0xFF;
			U1OTGIE             &= 0x8C;
			U1OTGIR             = 0x7D;
			U1EIE               = 0;
			U1EIR               = 0xFF;

			// Disable all EP's except EP0.
			U1EP0  = USB_ENDPOINT_CONTROL_SETUP;
			U1EP1  = USB_DISABLE_ENDPOINT;
			U1EP2  = USB_DISABLE_ENDPOINT;
			U1EP3  = USB_DISABLE_ENDPOINT;
			U1EP4  = USB_DISABLE_ENDPOINT;
			U1EP5  = USB_DISABLE_ENDPOINT;
			U1EP6  = USB_DISABLE_ENDPOINT;
			U1EP7  = USB_DISABLE_ENDPOINT;
			U1EP8  = USB_DISABLE_ENDPOINT;
			U1EP9  = USB_DISABLE_ENDPOINT;
			U1EP10 = USB_DISABLE_ENDPOINT;
			U1EP11 = USB_DISABLE_ENDPOINT;
			U1EP12 = USB_DISABLE_ENDPOINT;
			U1EP13 = USB_DISABLE_ENDPOINT;
			U1EP14 = USB_DISABLE_ENDPOINT;
			U1EP15 = USB_DISABLE_ENDPOINT;


ZZ			U1PWRCbits.USBPWR = 1;	// Turn power on

			U1BDTP1 = ((DWORD)KVA_TO_PA(&bdt_entry) & 0x0000FF00) >> 8;
			U1BDTP2 = ((DWORD)KVA_TO_PA(&bdt_entry) & 0x00FF0000) >> 16;
			U1BDTP3 = ((DWORD)KVA_TO_PA(&bdt_entry) & 0xFF000000) >> 24;
		
			// Configure the module
ZZ			U1CON               = USB_HOST_MODE_ENABLE | USB_SOF_DISABLE;                       // Turn of SOF's to cut down noise
			U1CON               = USB_HOST_MODE_ENABLE | USB_PINGPONG_RESET | USB_SOF_DISABLE;  // Reset the ping-pong buffers
			U1CON               = USB_HOST_MODE_ENABLE | USB_SOF_DISABLE;                       // Release the ping-pong buffers

			// Reset all ping-pong buffers if they are being used.
			U1CONbits.PPBRST= 1;
			U1CONbits.PPBRST= 0;
			bfPingPongIn    = 0;
			bfPingPongOut   = 0;

			U1OTGCON            = USB_DPLUS_PULLDOWN_ENABLE | USB_DMINUS_PULLDOWN_ENABLE; // Pull down D+ and D-
//			U1OTGCON |= USB_VBUS_ON;
			U1CNFG1             = USB_PING_PONG_MODE;

			U1ADDR              = 0;                        // Set default address and LSPDEN to 0
			U1EP0bits.LSPD      = 0;
			U1SOF               = USB_SOF_THRESHOLD_64;     // Maximum EP0 packet size

	U1IEbits.ATTACHIE = 1;	// Enable ATTACH interrupt
	U1IEbits.SOFIE = 1;	// Enable SOFIE interrupt
	U1EIE = 0xbf;	// Enable all error interrupts
	}
#endif


	UsbAttach = 0;	// Clear attach flag
	LowSpeed = 0;	// Reset USB bus speed
#if defined(__PIC24F__)
	BDT[1] = (UINT32)UsbBuf;	// Setup IN BD buffer address (max 64 bytes)
	BDT[3] = (UINT32)UsbBuf;	// Setup SETUP/OUT BD buffer address (max 64 bytes)
#else
	BDT[EP0_IN_0a] = (UINT32)KVA_TO_PA(UsbBuf);	// Setup IN BD buffer address (max 64 bytes)
	BDT[EP0_IN_1a] = (UINT32)KVA_TO_PA(UsbBuf);	// Setup IN BD buffer address (max 64 bytes)
	BDT[EP0_OUT_0a] = (UINT32)KVA_TO_PA(UsbBuf);	// Setup SETUP/OUT BD buffer address (max 64 bytes)
	BDT[EP0_OUT_1a] = (UINT32)KVA_TO_PA(UsbBuf);	// Setup SETUP/OUT BD buffer address (max 64 bytes)
#endif
	ei();

}
//
//	Check device exists
//
UINT8 CheckDevice(void)
{
	if(UsbAttach)	// Check USB attach flag
		return 0;	// Normal return (Device attached)
	SendString("No device\r\n");	// Show error message
	return 1;	// No device return
}

void _MIPS32 enableInterrupts()
{
	EnableInterrupts;	// Enable interrupt for UART and USB
}

void PrintHelp()
{
//	case
	SendString(
"'s':	Get string\r\n"
"'g':	get descriptor command\r\n"
"'a':	Set address command\r\n"
"'c':	set config command\r\n"
"'I':	IN command\r\n"
"'i':	IN command\r\n"
"'o':	OUT command (use default DATA0/1 sequence)\r\n"
"'t':	SETUP command\r\n"
"'w':	Clear & Write command\r\n"
"'W':	WRITE command (Append to current send buffer)\r\n"
"'r':	Reset command\r\n"
"'d':	Mem Dump\r\n"
"'.':	Print SofCount\r\n"
	);

}
//
//	Main
//
int main(void)
{
	INT16 i, j;
	UINT8	*p;
#if defined(__PIC24F__)
	CLKDIV = 0;        // clear register first
	CLKDIVbits.CPDIV = 0;	// 32MHz CPU clock (bus clock is 16MHz)
	CLKDIVbits.PLLEN = 1;	// PLL enable
	__builtin_write_OSCCONH(0x03);		// Initiate XTPLL
	__builtin_write_OSCCONL(0x01);		// Request clock change
	while (OSCCONbits.COSC != 0x3);	//	Wait for Clock switch complete
	while(!OSCCONbits.LOCK);	// Wait for PLL lock and BUSCLK is 16MHz
#endif

	UserInit();

	UartInit(RxBuf, UARTBUF_SIZE, TxBuf, UARTBUF_SIZE);	// UART register set
	UsbInit();	// Init USB registers

#if defined(__PIC24F__)
	IEC5bits.USB1IE = 1;	// USB interrupt enable
	IPC21bits.USB1IP = 1;	// USB int priority is one (low)
	EnableInterrupts;	// Enable interrupt for UART and USB
#else
	// Enable the USB interrupt.
	IFS1CLR  = _IFS1_USBIF_MASK;
     IPC7CLR = _IPC7_USBIP_MASK | _IPC7_USBIS_MASK;
     IPC7SET = _IPC7_USBIP_MASK & (0x00000004 << _IPC7_USBIP_POSITION);
	IEC1SET  = _IEC1_USBIE_MASK;                        
	enableInterrupts();	// Enable interrupt for UART and USB
#endif

//	led_test();
//	uart_test();
	
	SendLen = 0;	// Clear send buffer length
	for(;;)	// Main loop start here
	{
		p = CmdBuf;	// Reset parse pointer
		SendChar('>');	// Show prompt
		i = 0;	// Clear store pointer
		while(!SciGets(p, 79, (UINT16*)&i));// One line input (max 79 char)
		if(CheckDevice())	// Not attached yet?
			continue;	// Just ask again
		switch(*p++)	// Switch by first char
		{
		case 0:	// Blank line
			break;	// Just ask next command
// Get string
		case 's':	// Get string
			i = 0;	// Set default string index
			if(*p)	// Some argument?
				i = GetHex(&p);	// Get user specified string index
			j = SendGetString(i);	// Send GET_DESCRIPTOR(string) request
			if(j < 0)	// Error happens?
				goto errordisp;	// Show error message
			if(GetPacket(DataBuf, 0) < 0)	// Get string contents using IN request
				goto errordisp;	// Show error if error happens
			if(SendAck() < 0)	// Send 0 byte DATA1 packet (ACK)
				goto errordisp;	// Show error if some error happens
			for(i = 2; i < ReplySize; i++)	// Show string contents
				if(DataBuf[i] >= 0x20)	// Visible character?
					SendChar(DataBuf[i]);	// Show string contents
			SendCrlf();	// End of string then CR/LF
			break;	// Ask next command
// GET_DESCRIPTOR command (0:Device 1:Config 2:Report)
		case 'g':	// get descriptor command
			i = 0;	// Set default descriptor type (Device)
			if(*p)	// Argument exists?
				i = GetHex(&p);	// Get descriptor ID
			if(i > 4)	// Max descriptor ID is 2
				goto errordisp;	// SHow error if invalid descriptor type
			if(GetDescriptor(i) < 0)	// Send GET_DESCRIPTOR request
				goto errordisp;	// Show error message if some error happens
			if(i == 1 && ConfigLen == 0)	// Config descriptor & long length not set yet?
				ConfigLen = (DataBuf[3] << 8) + DataBuf[2];	// Set long config descriptor length
			HexDump(DataBuf, ReplySize);	// Dump result
			break;	// Ask next command
// SET_ADDRESS command
		case 'a':	// Set address command
			i = 1;	// Set default address
			if(*p)	// Argument exists?
				i = GetHex(&p);	// Get user specified adrs
			if(SendSetAddress(i) < 0)	// Send SET_ADDRESS request
				goto errordisp;	// Show error message if error happens
			SendString("Address\r\nOk\r\n");	// Show success message
			break;	// Ask next command
// SET_CONFIG command
		case 'c':	// set config command
			if(SendSetConfig() < 0)	// Send Setup
				goto errordisp;	// Show error message
			ResetDataBits();	// Reset DATA0/1 bit
			SendString("Configured\r\nOk\r\n");// SHow complete message
			break;	// Ask next command
// IN command (timeout mode)
		case 'I':	// IN command
			i = 1;	// Set default endpoint number
			if(*p)	// Argument exists?
				i = GetHex(&p);	// Get endpoint number
			j = DataProc(i, 0, 0);	// Send Setup
			if(j < 0)	// Error while IN transaction?
				goto errordisp;	// Show error message
			else if(j == 0)	// NAK has come?
				SendString("NAK\r\n");	// Show NAK has come from device
			else
			{
				HexDump(UsbBuf, j);	// Show received data
				SendString("Ok\r\n");	// Show success message
			}
			break;	// Ask next command
// IN command (No timeout mode)
		case 'i':	// IN command
			i = 1;	// Set default endpoint number
			if(*p)	// Argment exists?
				i = GetHex(&p);	// Get endpoint number
			j = DataProc(i, 0, 1);	// IN transaction (NAK return mode)
			if(j < 0)	// Some error happens
				goto errordisp;	// Show error message
			HexDump(UsbBuf, j);	// Show received data
			SendString("Ok\r\n");	// Show success message
			break;	// Ask next command
// OUT command
		case 'o':	// OUT command (use default DATA0/1 sequence)
			i = 1;	// Set default endpoint number
			if(*p)	// Some argment exists?
				i = GetHex(&p);	// Get end point number
			memcpy(UsbBuf, DataBuf, SendLen);	// Copy send buffer contents to USB send buffer
#if defined(__PIC24F__)
			BDT[2] = (DataBits[i] << 14)  | 0x8000 | SendLen;	// Setup OUT BD attr
#else
			BDT[EP0_OUT_0s] = (DataBits[i] << (14-8))  | 0x80 | (SendLen<<16);	// Setup OUT BD attr
#endif
			DataBits[i] ^= 1;	// Flip DATA0/1 bits for DTS handshake
			if(DataProc(i, 1, 1) < 0)	// Send OUT trequest (Retry until ACK)
				goto errordisp;	// Some error happeens then show error message
			HexDump(DataBuf, SendLen);	// Show sent data
			SendString("Ok\r\n");	// Show sccess message
			break;	// Ask next command
// SETUP command
		case 't':	// SETUP command
				memcpy(UsbBuf, DataBuf, SendLen);	// Copy send buffer contents to USB send buffer
				if(SendSetupSub() < 0)	// Send SETUP request
					goto errordisp;	// Error happens then show error
				SendString("Ok\r\n");	// Success!
				break;	// Ask next command again
// write data command (clear existing send buffer)
		case 'w':	// Clear & Write command
			SendLen = 0;	// Clear send length
// WRITE data command
		case 'W':	// WRITE command (Append to current send buffer)
			if(!*p)	// NO arguments?
			{	// Inquiry mode
				SendHex2(SendLen);	// Show send buffer length
				SendCrlf();	// Go new line
				HexDump(DataBuf, SendLen);	// Hex dump stored send data
				break;	// Ask next command
			}
			for(;;)	// Append hex data
			{
				DataBuf[SendLen++] = GetHex(&p);	// Parse hex string and append to send buffer
				if(!SkipSpace(&p))	// EOS found then exit append loop
					break;	// Exit append loop
			}
			break;	// Ask next command
// RESET command
		case 'r':	// Reset command
			if(CheckDevice())	// Check attached
				break;	// Do nothing if device is not attached
			ResetUsbBus();	// Invoke bus reset
			UsbInit();	// Init USB registers again
	// Enable the USB interrupt.
	IFS1CLR  = _IFS1_USBIF_MASK;
     IPC7CLR = _IPC7_USBIP_MASK | _IPC7_USBIS_MASK;
     IPC7SET = _IPC7_USBIP_MASK & (0x00000004 << _IPC7_USBIP_POSITION);
	IEC1SET  = _IEC1_USBIE_MASK;                        
			SendString("Ok\r\n");	// Show OK
			break;	// Ask command again
// USB transaction error message
		errordisp:	// Show error message
			SendString("Error ");	// Show error string
			SendHex2(ErrorCode);	// Show error code for debug
			SendCrlf();	// Go next line
			break;	// Ask next command
// Other command
		default:	// Command error
//			SendChar('?');// Show error message
			PrintHelp();
			SendCrlf();	// Go to next line to
			break;	// Ask next command
#if	1
		case 'd':	// dump command
			MemoryDumpCmd(p);
			break;	// Ask command again
		case '.':	// dump command
			zz("SofCount",SofCount);
			break;	// Ask command again
#endif
		}
	}
}
