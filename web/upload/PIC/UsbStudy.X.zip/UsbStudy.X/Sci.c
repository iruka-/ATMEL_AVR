/*
 *******************************************************************************
 *
 *******************************************************************************
UINT16	GetRxCount(void);
UINT16	GetTxCount(void);
UINT16	GetTxFreeSpace(void);
void	_U1RXInterrupt(void);
void	_U1TXInterrupt(void);
void	_UART1Interrupt(void);	// PIC32MX
UINT8	GetChar(void);
void	StartTx(void);
void	SendChar(char ch);
void	SendString(char *str);
void	SendCrlf(void);
void	SendSpace(void);
void	ConvHex(char *s, UINT8 c);
void	SendHex4(UINT16 i);
void	SendHex2(UINT8 c);
void	FlushQueue(void);
void	SetBaudRate(UINT32 baud);
void	UartInit(UINT8 *rxbuf, UINT16 rxsize, UINT8 *txbuf, UINT16 txsize);
UINT8	SkipSpace(UINT8 **p);
UINT16	GetHex(UINT8 **p);
UINT8	SciGets(UINT8 *pBuffer, UINT8 len, UINT16 *p);
 *******************************************************************************
 *
 */
#if defined(__PIC24F__)
#	include <p24fxxxx.h>
#	define EnableInterrupts    __asm__ volatile("disi #0x0"); // Enable all interrupts
#else
#	include <p32xxxx.h>
#	define	no_auto_psv	nomips16
#endif

#include	"ProtoType.h"
#include	"usbdefs.h"
#include	"led.h"

//	Variables
volatile UINT16	RxQueueIn;	// RX queue index
volatile UINT16	RxQueueOut;	//
volatile UINT16	TxQueueIn;	// TX queue index IN
volatile UINT16	TxQueueOut;	// TX queue index OUT
// Queue buffer pointer
UINT8	*RxQueue;	// RX queue pointer
UINT8	*TxQueue;	// TX queue pointer
// Max queue size
UINT16	RxQueueSize;
UINT16	TxQueueSize;
//
//	Get RX queued count
//
UINT16 GetRxCount(void)
{
INT16 i;
	i = RxQueueIn - RxQueueOut;	// Get IN pointer - OUT pointer
	if(i < 0)	// Negative?
		i += RxQueueSize;	// Make it plus
	return i;	// Return with RX queued length
}
//
//	Get TX queued count
//
UINT16 GetTxCount(void)
{
INT16 i;
	i = TxQueueIn - TxQueueOut;	// Get IN pointer - OUT pointer
	if(i < 0)	// Minus?
		i += TxQueueSize;	// Make it plus
	return i;	// Return with TX queued number
}
//
//	Get TX queued free space
//
UINT16 GetTxFreeSpace(void)
{
	return TxQueueSize - GetTxCount() - 1;	// Get TX queue free space
}


#if defined(__PIC24F__)
#define	ISR24E	__attribute__((__interrupt__,no_auto_psv))
#else
#define	ISR24E	// Nothing.
#endif
//
//	UART RX interrupt handler
//
void ISR24E _U1RXInterrupt(void)
{
	int c = U1RXREG;
#if defined(__PIC24F__)
	IFS0bits.U1RXIF = 0;	// Clear UART1 RX interrupt flag
#else
	IFS1bits.U1RXIF = 0;
#endif
	if(GetRxCount() < RxQueueSize - 1)	// RX queue has free space?
	{	// Yes!
		RxQueue[RxQueueIn] = c;	// Put RX data to RX queue
		if(RxQueueIn == RxQueueSize - 1)	// IN pointer reaches end of queue?
			RxQueueIn = 0;	// Return to top of queue
		else
			RxQueueIn++;	// Just advance RX queue
	}
//	else	// No space to put RX queue
//		(void)U1RXREG;	// Just dump received character
}

//
//	UART TX interrupt handler
//
void ISR24E _U1TXInterrupt(void)
{
#if defined(__PIC24F__)
	while(U2STAbits.TRMT==0);	// Dummy wait by errta
	IFS0bits.U1TXIF = 0;	// Clear UART1 TX interrupt flag
#endif

 	if(TxQueueIn != TxQueueOut)	// TX data in TX queue?
	{	// Yes!
		// Clear the TX interrupt flag before transmitting again
		IFS1bits.U1TXIF = 0;
		U1TXREG = TxQueue[TxQueueOut];	// Get TX data from TX queue and transmit
		if(TxQueueOut == TxQueueSize - 1)	// OUT pointer reaches to the end of queue?
			TxQueueOut = 0;	// Return to the top of queue
		else
			TxQueueOut++;	// Just advance TX OUT queue pointer


	}
	else	// Disable the TX interrupt if we are done so that we don't keep entering this ISR
	{
		IEC1bits.U1TXIE = 0;
	}
}

/*
//	debug only!
void SendCharDirect(int c)
{
	U1TXREG = c;	// transmit immediately.
}
*/

#if defined(__PIC24F__)
//	Nothing.
#else	// PIC32MX
void __attribute__((__interrupt__,no_auto_psv)) _UART1Interrupt(void)
{
	if(IFS1bits.U1RXIF) {
		_U1RXInterrupt();
	}

	if(IEC1bits.U1TXIE) {
		if(IFS1bits.U1TXIF) {
			_U1TXInterrupt();
		}
	}
}


#endif
//
//	Get RX queued data
//
UINT8 GetChar(void)
{
UINT8 data;
	if(!GetRxCount())	// RX data in RX queue?
		return 0;	// return NULL if no data is queued
	data = RxQueue[RxQueueOut];	// Get RX data from RX queue
	if(RxQueueOut == RxQueueSize - 1)	// OUT pointer reaches to the end of queue?
		RxQueueOut = 0;	// Yes then return to the top address
	else
		RxQueueOut++;	// Just advance RX queue OUT pointer
	return data;	// Return with data
}
//
//	Start TX
//
#if defined(__PIC24F__)
void StartTx(void)
{
	if(TxQueueOut != TxQueueIn && U1STAbits.TRMT)	// TX data queued and shift register is empty?
	{
		U1TXREG = TxQueue[TxQueueOut];	// Transmit first queued char
		if(TxQueueOut == TxQueueSize - 1)	// Advance TX queue OUT pointer
			TxQueueOut = 0;	// Reset pointer
		else
			TxQueueOut++;	// JUst advance pointer

	}
}
#else
void _MIPS32 StartTx(void)
{
	IEC1bits.U1TXIE=1;		//���M���荞��.
}
#endif

//
//	Send single character
//
void SendChar(char ch)
{
INT16 i;
	i = GetTxCount();	// Check TX queued data number
	if(i < TxQueueSize - 1)	// TX queue has free space?
	{
		TxQueue[TxQueueIn] = ch;	// Put TX data to TX queue
		if(TxQueueIn == TxQueueSize - 1)	// TX IN pointer reaches end of the queue?
			TxQueueIn = 0;	// Yes then reset TX queue IN pointer
		else
			TxQueueIn++;	// Just advance TX IN pointer
	}
	StartTx();	// Start TX
}
//
//	Send string
//
void SendString(char *str)
{
	while(*str)	// Repeat untill EOS
		SendChar(*str++);	// Send char one by one until EOS
}
//
//	Send CRLF
//
void SendCrlf(void)
{
	SendChar('\r');	// Send CR
	SendChar('\n');	// Send LF
}
//
//	Sci space
//
void SendSpace(void)
{
	SendChar(' ');	// Send Space
}
//
//	Convert decimal to hex char
//
#define	cvt	("0123456789abcdef")	// HEX char table
void ConvHex(char *s, UINT8 c)
{
	*s = cvt[c >> 4];	// Setup high 4 bit
	*(s + 1) = cvt[c & 15];	// Setup low 4 bits
	*(s + 2) = 0;	// Set EOS
}
//
//	Put 4 digit hexadecimal number
//
void SendHex8(int i)
{
char s[8+1];	// Buffer for string
	ConvHex(s    , (UINT8)(i >> 24));	// Create first 8 bit
	ConvHex(s + 2, (UINT8)(i >> 16));	// Create first 8 bit
	ConvHex(s + 4, (UINT8)(i >> 8));	// Create first 8 bit
	ConvHex(s + 6, (UINT8)i);	// Create next 8 bit
	SendString(s);	// Show 8 digits hexadecimal string
}
void SendHex4(int i)
{
char s[4+1];	// Buffer for string
	ConvHex(s, (UINT8)(i >> 8));	// Create first 8 bit
	ConvHex(s + 2, (UINT8)i);	// Create next 8 bit
	SendString(s);	// Show 4 digits hexadecimal string
}
//
//	Put 2 digit hexadecimal number
//
void SendHex2(int c)
{
char s[3];	// Buffer for string
	ConvHex(s, c);	// Create 2 digit hexadecimal number
	SendString(s);	// Show 2 digits hexadecimal number
}
//
//	Put decimal number
//
void SendNum(unsigned int c)
{
	char s[16];
	int  idx=15;
	s[idx]=0;
	if(c) {
		while(c) {
			s[--idx]='0' + c%10;
			c=c/10;
		}
	}else{
		s[--idx]='0';
	}
	SendString(s+idx);	// Show decimal number
}

//
//	Flush UART queue pointers
//
void FlushQueue(void)
{
	RxQueueIn = 0;	// Clear RX IN queue pointer
	RxQueueOut = 0;	// Clear RX OUT queue pointer
	TxQueueIn = 0;	// Clear TX IN queue pointer
	TxQueueOut = 0;	// Clear TX OUT queue pointer
}
#if defined(__PIC24F__)
//
//	Flush UART queue pointers
//
void SetBaudRate(UINT32 baud)
{
static const UINT32 BaudTable[] = {1200, 2400, 4800, 9600, 19200, 38400, 57600, 115200};
static const UINT16 Prescale[] = {832, 416, 207, 103, 51, 25, 16, 8};
UINT16 i;
	for(i = 0; i < 8; i++)	// Scan built in baud trate table
		if(baud <= BaudTable[i])	// Specified baud rate found?
			break;	// Yes! then exit scan loop
	U1BRG = Prescale[i];	// Set baud rate prescaler value
}
#else	// PIC32MX
//
//	�R�[�h�T�C�Y�팸�̂��߂Ɍ��ߑł��ɂ���.
//
int	get_PeripheralClock()
{
	return 72 * 1000 * 1000;	// 40MHz
}
//
//	�߂��l�𓾂鏜�Z.
//
//	pbc  = 5000000  (5MHz)
//	baud =  230400�Ƃ�.
//
int near_div(int pbc , int baud)
{
//	rc = pbc / baud;
	int rc = (pbc + baud/2) / baud;	//�l�̌ܓ��I��.
	return rc;
}
#define UART_ENABLE_HIGH_SPEED				1
void SetBaudRate(UINT32 baudrate)
{
	INT8 speed=0;
	u32 max, max1, max2;
	u32 min1, min2;
	u32 pbclock,pbc;

	pbclock = GetPeripheralClock();
//	pbclock = get_PeripheralClock();
	max1 = pbclock / 4;
	min1 = max1 / 65536;
	max2 = pbclock / 16;
	min2 = max2 / 65536;
	if (baudrate > max1) baudrate = max1;
	if (baudrate < min2) baudrate = min2;
	max = (min1 + max2) / 2;
	if (baudrate > max && baudrate < max1) speed = UART_ENABLE_HIGH_SPEED;

	if (speed == UART_ENABLE_HIGH_SPEED) {
		U1MODEbits.BRGH = UART_ENABLE_HIGH_SPEED;
		pbc = pbclock/4;
	}else{
//		U1MODEbits.BRGH = 0;
		pbc = pbclock/16;
	}
	U1BRG = (near_div(pbc , baudrate)) - 1;
}

#endif

static	void SerialIntConfigure(int priority, int subpriority)
{
	//IntConfigureSystem(INT_SYSTEM_CONFIG_MULT_VECTOR);
	
	IPC8bits.U1IP = priority;
	IPC8bits.U1IS = subpriority;
	IEC1bits.U1RXIE=1;		//��M���荞��.
}


#define INPUT	1
#define OUTPUT	0

static	void SerialPinConfigure()
{
	TRISBbits.TRISB4 = OUTPUT;	// RB4 / U1TX output
	TRISAbits.TRISA4 = INPUT;	// RA4 / U1RX input
}

//
//	Iniialize UART registers
//
void UartInit(UINT8 *rxbuf, UINT16 rxsize, UINT8 *txbuf, UINT16 txsize)
{
	RxQueue = rxbuf;	// Init RX queue buffer pointer
	RxQueueSize = rxsize;	// Init RX queue size
	TxQueue = txbuf;	// Init TX queue buffer pointer
	TxQueueSize = txsize;	// Init TX queue size
	FlushQueue();	// Clear queue pointers
#if defined(__PIC24F__)
	RPINR18 = 0x0009;	// RX uses RP9 pin
	RPOR4 = 0x0003;	// TX uses RP8 pin
#endif
	U1MODE = 0x8000;	// Enable UART1 module and baud rate is low speed
	SetBaudRate(9600);	// Setup default baud rate
#if defined(__PIC24F__)
	U1STA = 0x2400;	// Set UART buffer mode
	IPC2bits.U1RXIP = 7;	// UART RX interrupt priority is 7
	IPC3bits.U1TXIP = 7;	// UART TX interrupt priority is 7
	IEC0bits.U1RXIE = 1;	// Enable RX interrupt
	IEC0bits.U1TXIE = 1;	// Enable TX interrupt
#else	// PIC32MX
//	U1STA = 0x1400;		// RXEN set, TXEN set
	U1STA = 0x9400;		// RXEN set, TXEN set
	SerialPinConfigure();
	SerialIntConfigure(INT_PRIORITY_3, INT_SUBPRIORITY_3);
#endif
}
//
//	Skip space
//
UINT8 SkipSpace(UINT8 **p)
{
	while(**p == ' ')	// Repeat while pointer contens is space
		(*p)++;	// Advance character pointer
	return **p;	// Return char but space
}
//
//	Get command argument
//
int GetHex(UINT8 **p)
{
int res;
UINT8 ch;
	res = 0;	// Clear result first
	SkipSpace(p);	// Skip space first
	for( ; ; (*p)++)	// Repeat untill fetch EOS
	{
		ch = **p;	// Fetch one char
		if(ch < '0') break;	// less than '0' then abort loop
		else if(ch < ':') ch -= '0';	// '0' to '9' then get number
		else if(ch < 'A') break;	// less than 'A' then abort loop
		else if(ch < 'G') ch -= '7';	// 'A' to 'F' then get number
		else if(ch < 'a') break;	// less than 'a' then abort loop
		else if(ch < 'g') ch -= 'W';	// 'a' to 'f' then get number
		else break;	// Another char then abort loop
		res = (res << 4) + ch;	// SHift 4 bit and add current value
	}
	if(**p)	// Not EOS?
		(*p)++;	// Advance character pointer and skip delimitter fro next parse
	return res;	// Return with result
}
//
//	Sci 1 line input
//
UINT8 SciGets(UINT8 *pBuffer, UINT8 len, UINT16 *p)
{
UINT8 c;
	if(GetRxCount())	// Some char is typed?
	{
		c = GetChar();	// Get char from rx queue
		if(c == '\xd')	// Enter is pressed?
		{
			pBuffer[*p] = '\0';	// Set EOS
			SendCrlf();	// Put CR/LF
			return 1;	// Tell end of one line input to caller
		}
		if(c == '\x8' && *p)		// BS is pressed?
		{
			(*p)--;	// Decrement store pointor
			SendChar(c);	// Echo BS to move cursor left
			SendSpace();	// Echo space to overwrite erased char
			SendChar(c);	// Echo BS to move cursor left
		}
		else if(c >= ' ' && *p < (len - 1))	// Common char is pressed
		{
			pBuffer[*p] = c;	// Store char to buffer
			(*p)++;	// Advance store pointor
			SendChar(c);	// Echo typed char
		}
	}
	return 0;	// Tell no enter key is pressed to caller
}

void zz(char *s,int n)
{
	SendString(s);
	SendChar(':');
	SendNum(n);
	SendCrlf();
}

void hh(char *s,int n)
{
	SendString(s);
	SendChar(':');
	SendHex8(n);
	SendCrlf();
}

void uart_test(void)
{
	int c;
	while(1) {
		SendString("....123456789\r\n");	// Show error message
//		SendChar('1');
		wait_ms(500);
//		led_toggle();
#if	0
		c = GetChar();
		if(c) {SendChar(c);
			SendString("....No device\r\n");	// Show error message
		}
#endif
	}
}
