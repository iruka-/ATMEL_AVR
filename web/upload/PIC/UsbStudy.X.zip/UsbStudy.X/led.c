/*
 *******************************************************************************
 *	LED�_�Ńf�o�b�O��
 *******************************************************************************

 *���ԑ҂�
void	_MIPS32 wait_us(int us);
void	_MIPS32 wait_125ns(int ns);
void	wait_ms(int ms);
void	wait_0us(void);

 *���荞�݃R���g���[��
unsigned	int _MIPS32 IntDisableInterrupts();
unsigned	int _MIPS32 IntEnableInterrupts();
void	_MIPS32 IntRestoreInterrupts(unsigned int intStatus);
void	_MIPS32 IntSetEBASE(unsigned int ebase_address);
void 	_MIPS32 IntConfigureSystem(int mode);
_MIPS32	void ei();

 * LED �_�Ŋ֐�
void	led_test();
void	led_toggle();
void	led_on();
void	led_off();

 * Timer1���荞�ݏ���
void	init_timer1(void);
void	_Tmr1Interrupt(void);

 * I/O ������
void	IOsetDigital();
void	UserInit(void);
static	void InitializeSystem(void);
 *
 *******************************************************************************
 */

#include <p32xxxx.h>
#include	<string.h>		// for memset
#include	"ProtoType.h"
#include	"led.h"

#define	TIMER1_LED_BLINK_TEST	(0)		// (1)�Ȃ�A���荞�݃^�C�}�[��LED�_�ł�����.

    #define mLED_1              LATBbits.LATB15
    #define mLED_2              LATBbits.LATB14
    #define mLED_1_On()         mLED_1 = 1;
    #define mLED_2_On()         mLED_2 = 1;
    #define mLED_1_Off()        mLED_1 = 0;
    #define mLED_2_Off()        mLED_2 = 0;
    #define mLED_1_Toggle()     mLED_1 = !mLED_1;
    #define mLED_2_Toggle()     mLED_2 = !mLED_2;
    #define mInitAllLEDs()      TRISBbits.TRISB15=0;TRISBbits.TRISB14=0;mLED_1_Off();mLED_2_Off();
    /** SWITCH *********************************************************/
    #define mInitSwitch2()      TRISBbits.TRISB7=1;
    #define mInitSwitch3()      TRISBbits.TRISB3=1;
    #define mInitAllSwitches()  mInitSwitch2();
    #define sw2                 PORTBbits.RB7
    #define sw3                 PORTBbits.RB6



void _MIPS32 wait_125ns(int ns);

// procdefs.ld�ɂ��ݒ肳���.
extern	int _RESET_ADDR[];



/*	----------------------------------------------------------------------------
	SystemUnlock() perform a system unlock sequence
	--------------------------------------------------------------------------*/

void system_unlock()
{
	SYSKEY = 0;				// ensure OSCCON is locked
	SYSKEY = 0xAA996655;	// Write Key1 to SYSKEY
	SYSKEY = 0x556699AA;	// Write Key2 to SYSKEY
}

/*	----------------------------------------------------------------------------
	SystemLock() relock OSCCON by relocking the SYSKEY
	--------------------------------------------------------------------------*/

void system_lock()
{
	SYSKEY = 0x12345678;	// Write any value other than Key1 or Key2
}

/********************************************************************
 *		PIC32 Peripheral Remappage
 ********************************************************************
 */
void io_setRemap()
{
	system_unlock();
	CFGCONbits.IOLOCK=0;			// unlock configuration
	CFGCONbits.PMDLOCK=0;
	{
		U1RXRbits.U1RXR=2;			// Define U1RX as RA4 ( UEXT SERIAL )
		RPB4Rbits.RPB4R=1;			// Define U1TX as RB4 ( UEXT SERIAL )
	}
	CFGCONbits.IOLOCK=1;			// relock configuration
	CFGCONbits.PMDLOCK=1;
	system_lock();
}
/********************************************************************
 *	( ms ) * 1mS �҂�.
 ********************************************************************
 */
void wait_ms(int ms)
{
	int i;
	for(i=0; i<ms; i++) {
		wait_125ns(1000*8);
	}
}

/********************************************************************
 *	( us ) * 1uS �҂�.
 ********************************************************************
 */
void wait_us(int us)
{
	wait_125ns(us*8);
}
/********************************************************************
 *	( us * 1/8 ) uS �҂�. clock=72MHz�Ɖ���.
 ********************************************************************
 */
//clock=48MHz�Ɖ���.	�œK���I�v�V������R���p�C�����ς������Čv��.
void _MIPS32 wait_125ns(int ns)
{
	int i;
	for(i=0; i<ns; i++) {
		asm("nop");
	}
}
/********************************************************************
 *	
 ********************************************************************
 */
void _MIPS32 wait_0us(void)
{
}

/*	----------------------------------------------------------------------------
	IntDisableInterrupts
	----------------------------------------------------------------------------
	Disables the PIC32MX from handling interrupts.
	This routine disables the core from handling any pending interrupt requests.
	Returns:
	The previous state of the CP0 register Status.IE bit.  The INTRestoreInterrupts 
	function can be used in other routines to restore the system interrupt state.
	--------------------------------------------------------------------------*/

unsigned int _MIPS32 IntDisableInterrupts()
{
	unsigned int intStatus;

	intStatus = _CP0_GET_STATUS(); // Get Status
	asm("di"); // Disable all interrupts
	return intStatus;
}

/*	----------------------------------------------------------------------------
	IntEnableInterrupts
	----------------------------------------------------------------------------
	Enables the PIC32MX to handle interrupts.
	This routine enables the core to handle any pending interrupt requests.
	Need to configure system using INTConfigureSystem
	Returns: The previous state of the CP0 register Status.IE bit.
	The IntRestoreInterrupts function can be used in other routines to restore
	the system interrupt state.
	--------------------------------------------------------------------------*/

unsigned int _MIPS32 IntEnableInterrupts()
{
	unsigned int intStatus;

	intStatus = _CP0_GET_STATUS(); // Get Status
	asm("ei"); // Enable all interrupts
	return intStatus;
}

/*	----------------------------------------------------------------------------
	IntRestoreInterrupts
	----------------------------------------------------------------------------
	Restores the PIC32MX interrupt state.
	This routine restores the core to the previous interrupt handling state.
	Parameters:
		status      - the state of the CP0 register Status.IE
	--------------------------------------------------------------------------*/

void _MIPS32 IntRestoreInterrupts(unsigned int intStatus)
{
	_CP0_SET_STATUS(intStatus); // Update Status
}

/*	----------------------------------------------------------------------------
	IntSetEBASE
	----------------------------------------------------------------------------
	Sets the PIC32MX exception base.
	This routine sets the exception base of the core.
	Parameters:
		ebase_address   - The address of the EBASE.
		* must be be located in KSEG0 or KSEG1
		* must be 4KB aligned
	NB : EBASE at 0xBD000000 (microchip) or 0xBD005000 (jean-pierre mandon)
	--------------------------------------------------------------------------*/

void _MIPS32 IntSetEBASE(unsigned int ebase_address)
{
	_CP0_SET_EBASE(ebase_address);
}

/*	----------------------------------------------------------------------------
	IntConfigureSystem
	----------------------------------------------------------------------------
	Configures the system for  multi-vector or single vectored interrupts.
	This routine configures the core to receive interrupt requests and configures the 
	Interrupt module for Multi-vectored or Single Vectored mode.
	Parameters:
		config      - The interrupt configuration to set.
		IntConfigureSystem(INT_SYSTEM_CONFIG_MULT_VECTOR);
		IntConfigureSystem(INT_SYSTEM_CONFIG_SINGLE_VECTOR);
	NB : Place EBASE at 0xBD000000 (microchip) or 0xBD005000 (jean-pierre mandon)
	--------------------------------------------------------------------------*/

static	void _MIPS32 IntConfigureSystem(int mode)
{
	unsigned int temp;

	asm("di"); // Disable all interrupts
	temp = _CP0_GET_STATUS(); // Get Status
	temp |= 0x00400000; // Set BEV bit
	_CP0_SET_STATUS(temp); // Update Status
	_CP0_SET_EBASE(_RESET_ADDR); // Set an EBase value
	_CP0_SET_INTCTL(0x00000020); // Set the Vector Spacing to non-zero value
	temp = _CP0_GET_CAUSE(); // Get Cause
	temp |= 0x00800000; // Set IV
	_CP0_SET_CAUSE(temp); // Update Cause
	temp = _CP0_GET_STATUS(); // Get Status
	temp &= 0xFFBFFFFD; // Clear BEV and EXL
	_CP0_SET_STATUS(temp); // Update Status

	switch (mode)
	{
		case 1:	//INT_SYSTEM_CONFIG_MULT_VECTOR:
			// Set the CP0 registers for multi-vector interrupt
			INTCONSET = 0x1000; // Set MVEC bit
		break;
		case 2:	//INT_SYSTEM_CONFIG_SINGLE_VECTOR:
			// Set the CP0 registers for single-vector interrupt
			INTCONCLR = 0x1000; // Clear MVEC bit
		break;	
	}

	asm("ei"); // Enable all interrupts
}

void led_test()
{
//	mInitAllLEDs();
//	INTEnableInterrupts();	// ei����.
	while(1) {
		mLED_1_Toggle();
		wait_ms(100);
	}
}

void led_toggle()
{
	mLED_1_Toggle();
}

void led_on()
{
	mLED_1_On();
}

void led_off()
{
	mLED_1_Off();
}

_MIPS32 void di()
{
	asm("di");
}

_MIPS32 void ei()
{
	asm("ei");
}

_MIPS32 void ei_init()
{
//	crt0.S �̏������ɂāA���ł�MultiVectord�ɂ͂Ȃ��Ă���B
	INTCONSET=0x1000;		// EI PORT
//	INTEnableSystemMultiVectoredInt();	���̊֐����� INTCONSET�ݒ肪�܂܂��.

	INTEnableInterrupts();	// ei����.
}


//#define	HSYNC_PR	(528*2-1)		// (26.4uS * 20MHz) = 528
#define	HSYNC_PR	(65530-1)		// (26.4uS * 20MHz) = 528
/**********************************************************************
 *	TIMER1��HSYNC���荞��.
 **********************************************************************
 */
void init_timer1(void)
{
	T1CON=0;			// reset timer 1 configuration
	TMR1=0;				// reset timer 1 counter register
	PR1=HSYNC_PR;		// define the preload register
	IPC1SET=(7<<2);		// select interrupt priority and sub-priority
	IFS0CLR=(1<<4);		// clear interrupt flag
	IEC0SET=(1<<4);		// enable timer 1 interrupt
	T1CON=0x8000;		// start timer 1 and set prescaler(1/1)
}



/**********************************************************************
 *
 **********************************************************************
 */
void __attribute__((interrupt,nomips16,noinline)) _Tmr1Interrupt(void)
{
	if (IFS0bits.T1IF) {	// Timer Interrupt flag
		IFS0CLR=(1<<4);	// IFS04: Clear the timer interrupt flag
		// �E�E�E
		static int i=0;
		i++;
		if(i>500) {
			i=0;
#if	TIMER1_LED_BLINK_TEST			// (1)�Ȃ�A���荞�݃^�C�}�[��LED�_�ł�����.
			mLED_1_Toggle();
#endif
		}
		//
	}
}

// All Analog Pins as Digital IOs
void IOsetDigital()
{
	DDPCONbits.JTAGEN=0;		// check : already in system.c
	ANSELA = 0;
	ANSELB = 0;
}

void UserInit(void)
{
	IntConfigureSystem(1);

	IOsetDigital();
	io_setRemap();
	mInitAllLEDs();
	mInitAllSwitches();

	init_timer1();
}





#if	0
static void InitializeSystem(void)
{
#if defined(USE_USB_BUS_SENSE_IO)
	tris_usb_bus_sense = INPUT_PIN; // See HardwareProfile.h
#endif

#if defined(USE_SELF_POWER_SENSE_IO)
	tris_self_power = INPUT_PIN;	// See HardwareProfile.h
#endif

	USBGenericOutHandle = 0;
	USBGenericInHandle = 0;

	UserInit();			//Application related initialization.  See user.c

	USBDeviceInit();	//usb_device.c.  Initializes USB module SFRs and firmware
}
#endif


typedef	struct {
	u32	start,size;
} Region;

#define	AREA_MASK	0xe0000000
#define	ADDR_MASK	0x1FFFFFFF
static	Region region[]={
	{0x00000000,0x8000	},	// RAM
	{0x1D000000,0x20000	},	// FLASH
	{0x1FC00000,0x0C00	},	// BOOTROM
	{0x1F800000,0x10000	},	// PORT
	{0x1F880000,0x10000	},	// PORT
	{		  0,0		},	// END
};
static	int	   area_tab[4]={
	0x00000000,
	0x20000000,
	0x80000000,
	0xa0000000,
};

//static	
int	check_region(int addr,int size)
{
	int area = addr & AREA_MASK;
			   addr &= ADDR_MASK;
	int i;
	u32 off,sz;
	for(i=0;i<4;i++) {
		if(	area_tab[i] == area) {	// �G���A�u���b�N�ɛƂ��Ă���.
			Region *r = region;		// �̈�e�[�u�����r�߂�.
			while(r->size) {		// �e�[�u�����ł͂Ȃ��Ȃ�...
				off = addr - r->start;	// �v���A�h���X�̓x�[�X�A�h���X���牽�o�C�g��(off)��?
				if(off < (r->size) ) {	// �̈�T�C�Y���Ɏ��܂��Ă���.
					//�c�ʂ�Ԃ�.
					sz = (r->size - off);	//���̗̈���̎c�ʂ��v�Z.
					if(size >= sz) {size=sz;}
					return size;
				}
				r++;
			}
		}
	}
	return -1;
}


extern void *bdt_entry[];
void memdump(char *msg,void *ptr,int len)
{
	unsigned char *p = (unsigned char *)ptr;
	int i;
	if(msg) {
		SendString(msg);
		SendChar(':');SendCrlf();
	}
	for(i=0;i<len;i++) {
		if( (i & 15) == 0 ) SendHex8((int)p);
		SendChar(' ');
		SendHex2(*p++);

		if( (i & 15) == 7 )  SendChar(' ');
		if( (i & 15) == 15 ) SendCrlf();
	}
}
void help_region(void)
{
	SendString(
		"* PIC32MX220F032B Memory Map\r\n"
		"-------------:-----------------------\r\n"
		"BOOT-ROM(3k) : BFC0_0000 ~ BFC0_0BFF \r\n"
		"FLASH  (32k) : 9D00_0000 ~ 9D00_7FFF \r\n"
		"S-RAM   (8k) : A000_0000 ~ A000_1FFF \r\n"
		"PORT         : BF80_0000 ~ BF88_FFFF \r\n"
		"-------------:-----------------------\r\n"
		"Need Help ? >\r\n"
	);
}
void  MemoryDumpCmd(unsigned char *arg)
{
	static int adr = (int)bdt_entry;
	int len=64;
	if(*arg) {
		adr = GetHex(&arg);
	}
	int size = check_region(adr,len);
	if(	size > 0 ) {
		memdump(NULL,(void*) (adr | 0x80000000) ,size);
		adr += size;
	}else{
		help_region();
	}
}

