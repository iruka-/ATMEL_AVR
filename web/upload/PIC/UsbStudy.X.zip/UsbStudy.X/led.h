#ifndef LED_H
#define	LED_H

#define	_MIPS32 __attribute__((nomips16,noinline))

void	wait_ms(int ms);
void	wait_us(int us);
void	_MIPS32 wait_125ns(int ns);
void	_MIPS32 wait_0us(void);
unsigned	int _MIPS32 IntDisableInterrupts();
unsigned	int _MIPS32 IntEnableInterrupts();
void	_MIPS32 IntRestoreInterrupts(unsigned int intStatus);
void	_MIPS32 IntSetEBASE(unsigned int ebase_address);
static	void _MIPS32 IntConfigureSystem(int mode);
void	led_test();
void	led_toggle();
void	led_on();
void	led_off();
void	init_timer1(void);
void	__attribute__((interrupt,nomips16,noinline)) _Tmr1Interrupt(void);
void	IOsetDigital();
void	UserInit(void);
void    io_setRemap();
void    MemoryDumpCmd(unsigned char *arg);	// arg="9d000000"; e.t.c.
void 	memdump(char *msg,void *ptr,int len);

_MIPS32	void di();
_MIPS32	void ei();

#endif
