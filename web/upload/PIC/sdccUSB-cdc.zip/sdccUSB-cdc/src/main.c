/*********************************************************************
 *
 *                Microchip USB C18 Firmware Version 1.0
 *
 *********************************************************************
 * FileName:        main.c
 * Dependencies:    See INCLUDES section below
 * Processor:       PIC18
 * Compiler:        C18 2.30.01+/sdcc
 * Company:         Microchip Technology, Inc.
 *
 * Software License Agreement
 *
 * The software supplied herewith by Microchip Technology Incorporated
 * (the 'Company') for its PICmicro� Microcontroller is intended and
 * supplied to you, the Company's customer, for use solely and
 * exclusively on Microchip PICmicro Microcontroller products. The
 * software is owned by the Company and/or its supplier, and is
 * protected under applicable copyright laws. All rights are reserved.
 * Any use in violation of the foregoing restrictions may subject the
 * user to criminal sanctions under applicable laws, as well as to
 * civil liability for the breach of the terms and conditions of this
 * license.
 *
 * THIS SOFTWARE IS PROVIDED IN AN 'AS IS' CONDITION. NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 * TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 * IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 * CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 * Author               Date        Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Rawin Rojvanit       11/19/04    Original.
 ********************************************************************/

/** I N C L U D E S **********************************************************/
#ifdef SDCC
#include <pic18f2550.h>
#else
#include <p18cxxx.h>
#endif
#include "system/typedefs.h"	// Required
#include "system/usb.h"	// Required
#include "io_cfg.h"		// Required

#include "system/usb_compile_time_validation.h"	// Optional
#include "user.h"		// Modifiable

/** V A R I A B L E S ********************************************************/
#ifndef SDCC
#pragma udata
#endif

/** P R I V A T E  P R O T O T Y P E S ***************************************/
static void InitializeSystem(void);
void USBTasks(void);

#ifndef SDCC
#pragma code high_vector_section = 0x000808
#endif
void high_vector(void)
{
#ifdef SDCC
    _asm 
	extern _high_ISR
	goto _high_ISR
	_endasm;
#else
    _asm goto high_ISR _endasm;
#endif
}

#ifndef SDCC
#pragma code low_vector_section = 0x000818
#endif
void low_vector(void)
{
#ifdef SDCC
    _asm
	extern _low_ISR 
    goto _low_ISR 
    _endasm;
#else
    _asm goto low_ISR _endasm;
#endif
}

#ifndef SDCC
#pragma code
#endif

/** D E C L A R A T I O N S **************************************************/
#ifndef SDCC
#pragma code
#endif
/******************************************************************************
 * Function:        void main(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        Main program entry point.
 *
 * Note:            None
 *****************************************************************************/
void main(void)
{
    InitializeSystem();
    while (1) {
	USBTasks();		// USB Tasks
	ProcessIO();		// See user\user.c & .h
    }				//end while
}				//end main

/******************************************************************************
 * Function:        static void InitializeSystem(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        InitializeSystem is a centralize initialization routine.
 *                  All required USB initialization routines are called from
 *                  here.
 *
 *                  User application initialization routine should also be
 *                  called from here.                  
 *
 * Note:            None
 *****************************************************************************/
static void InitializeSystem(void)
{
    ADCON1 |= 0x0F;		// Default all pins to digital

    mInitializeUSBDriver();	// See usbdrv.h

    UserInit();			// See user.c & .h
#ifdef DEBUG
    //RS-232 Setup
    TRISCbits.TRISC7 = 1;	// RX
    TRISCbits.TRISC6 = 0;	// TX
    SPBRG = 103;		// 48 MHz/4/115200 = 104
    SPBRGH = 0;
    TXSTA = 0x24;		// TX enable BRGH=1
    RCSTA = 0x90;		// continuous RX
    BAUDCON = 0x08;		// BRG16 = 1

    OpenUSART(USART_TX_INT_OFF & USART_RX_INT_OFF & USART_ASYNCH_MODE & USART_EIGHT_BIT & USART_CONT_RX & USART_BRGH_HIGH, 103);	// 48 MHz/4/115200 = 104

#ifdef SDCC
    FPRINTF(_H_USART, "Init System sdcc\r\n");
#else
    FPRINTF(_H_USART, "Init System mplab\r\n");
#endif
    if (STKPTR & 0xc0) {	/* stop if we restarted */
	STKPTR = 0;
	while (1)
	    mLED_2_On();
    }
#endif


}				//end InitializeSystem

/******************************************************************************
 * Function:        void USBTasks(void)
 *
 * PreCondition:    InitializeSystem has been called.
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        Service loop for USB tasks.
 *
 * Note:            None
 *****************************************************************************/
void USBTasks(void)
{
    /*
     * Servicing Hardware
     */
    USBCheckBusStatus();	// Must use polling method
    if (UCFGbits.UTEYE != 1)
	USBDriverService();	// Interrupt or polling method

#if defined(USB_USE_CDC)
    CDCTxService();
#endif

}				// end USBTasks

/** EOF main.c ***************************************************************/
