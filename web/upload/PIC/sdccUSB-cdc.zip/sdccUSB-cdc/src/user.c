/*********************************************************************
 *
 *                Microchip USB C18 Firmware Version 1.0
 *
 *********************************************************************
 * FileName:        user.c
 * Dependencies:    See INCLUDES section below
 * Processor:       PIC18
 * Compiler:        C18 2.30.01+/sdcc
 * Company:         Microchip Technology, Inc.
 *
 * Software License Agreement
 *
 * The software supplied herewith by Microchip Technology Incorporated
 * (the 'Company') for its PICmicro� Microcontroller is intended and
 * supplied to you, the Company's customer, for use solely and
 * exclusively on Microchip PICmicro Microcontroller products. The
 * software is owned by the Company and/or its supplier, and is
 * protected under applicable copyright laws. All rights are reserved.
 * Any use in violation of the foregoing restrictions may subject the
 * user to criminal sanctions under applicable laws, as well as to
 * civil liability for the breach of the terms and conditions of this
 * license.
 *
 * THIS SOFTWARE IS PROVIDED IN AN 'AS IS' CONDITION. NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 * TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 * IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 * CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 * Author               Date        Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Rawin Rojvanit       11/19/04    Original.
 * Brian Schmalz		03/15/06	Added user code to impliment
 *									firmware version D v1.0 for UBW
 *									project. See www.greta.dhs.org/UBW
 * Brian Schmalz		05/04/06	Starting version 1.1, which will
 * 									include several fixes. See website.
 * BPS					06/21/06	Starting v1.2 -
 * - Fixed problem with I packets (from T command) filling up TX buffer
 * 		and not letting any incoming commands be received. (strange)
 * - Adding several commands - Analog inputs being the biggest set.
 * - Also Byte read/Byte write (PEEK/POKE) anywhere in memory
 * - Individual pin I/O and direction
 * BPS					08/16/06	v1.3 - Fixed bug with USB startup
 * BPS					09/09/06	v1.4 - Starting 1.4
 * - Fixed Microchip bug with early silicon - UCONbits.PKTDIS = 0;
 * - Adding BO and BC commands for parallel output to graphics pannels
 * BPS					12/06/06	v1.4 - More work on 1.4
 * - Re-wrote all I/O buffering code for increased speed and functionality
 * - Re-wrote error handling code
 * - Added delays to BC/BO commands to help Corey
 * BPS					01/06/07	v1.4 - Added RC command for servos
 * BPS					03/07/07	v1.4.1 - Changed blink rate for SFE
 * BPS					05/24/07	v1.4.2 - Fixed RC command bug - it
 *									wouldn't shut off.
 * BPS					08/28/07	v1.4.3 - Allowed UBW to run without
 *									usb connected.
 *
 ********************************************************************/

/** I N C L U D E S **********************************************************/
#ifdef SDCC
#include <pic18f2550.h>
#else
#include <p18cxxx.h>
#endif
#include <usart.h>
#include <stdio.h>
#include <ctype.h>
#ifndef SDCC
#include <delays.h>
#endif
#include "system/typedefs.h"
#include "system/usb.h"
#include "io_cfg.h"             // I/O pin mapping
#include "user.h"

/** D E F I N E S ********************************************************/
#define bitset(var,bitno) ((var) |= (1 << (bitno)))
#define bitclr(var,bitno) ((var) &= ~(1 << (bitno)))
#define bittst(var,bitno) (var& (1 << (bitno)))

// For the RC command, we define a little data structure that holds the
// values assoicated with a particular servo connection
// It's port, pin, value (position) and state (INACTIVE, PRIMED or TIMING)
// Later on we make an array of these (19 elements long - 19 pins) to track
// the values of all of the servos.
typedef enum {
	 kOFF = 1
	,kWAITING
	,kPRIMED
	,kTIMING
} tRC_state;


#define kTX_BUF_SIZE 			64				// In bytes
#define kRX_BUF_SIZE			64				// In bytes

#define kISR_FIFO_A_DEPTH		3
#define kISR_FIFO_D_DEPTH		3
#define kPR2_RELOAD				250		// For 1ms TMR2 tick
#define kCR						0x0D
#define kLF						0x0A

// defines for the error_byte byte - each bit has a meaning
#define kERROR_BYTE_TX_BUF_OVERRUN			2
#define kERROR_BYTE_RX_BUFFER_OVERRUN		3
#define kERROR_BYTE_MISSING_PARAMETER		4
#define kERROR_BYTE_PRINTED_ERROR			5			// We've already printed out an error
#define kERROR_BYTE_PARAMATER_OUTSIDE_LIMIT	6
#define kERROR_BYTE_EXTRA_CHARACTERS 		7
#define kERROR_BYTE_UNKNOWN_COMMAND			8			// Part of command parser, not error handler

/** V A R I A B L E S ********************************************************/
#ifndef SDCC
#pragma udata access fast_vars
#endif

// Rate variable - how fast does interrupt fire to capture inputs?
near unsigned int time_between_updates;

// This byte has each of its bits used as a seperate error flag
near unsigned char error_byte;

#ifndef SDCC
#pragma udata ISR_buf=0x100
#endif

#ifndef SDCC
#pragma udata com_buf=0x200
#endif

// USB Transmit buffer for packets (back to PC)
#ifdef SDCC
#pragma udata ram3 g_TX_buf
#pragma udata ram3 g_RX_buf

#pragma udata ram3 USB_In_Buffer
#pragma udata ram3 USB_Out_Buffer
#endif



unsigned char g_TX_buf[kTX_BUF_SIZE];
// USB Receiving buffer for commands as they come from PC
unsigned char g_RX_buf[kRX_BUF_SIZE];

unsigned char USB_In_Buffer[64];

unsigned char USB_Out_Buffer[64];


// These variables are in normal storage space
#ifndef SDCC
#pragma udata
#endif

// Pointers to USB transmit (back to PC) buffer
unsigned char g_TX_buf_in;
unsigned char g_TX_buf_out;

// Pointers to USB receive (from PC) buffer
unsigned char g_RX_buf_in;
unsigned char g_RX_buf_out;


/** P R I V A T E  P R O T O T Y P E S ***************************************/
void BlinkUSBStatus (void);		// Handles blinking the USB status LED
void parse_packet (void);		// Take a full packet and dispatch it to the right function
void check_and_send_TX_data (void); // See if there is any data to send to PC, and if so, do it
int _user_putc (char c);		// Our UBS based stream character printer

/** D E C L A R A T I O N S **************************************************/
#ifndef SDCC
#pragma code
#endif

#ifndef SDCC
#pragma interruptlow low_ISR
#endif
void low_ISR(void)
#ifdef SDCC
 interrupt 2
#endif
{
}


#ifndef SDCC
#pragma interrupt high_ISR
#endif
void high_ISR(void)
#ifdef SDCC
 interrupt 1
#endif
{
}

void UserInit(void)
{
	char i, j;

	// Make all of 3 digital inputs
	LATA = 0x00;
	TRISA = 0xFF;
	// Turn all analog inputs into digital inputs
	ADCON1 = 0x0F;
	// Turn off the ADC
	ADCON0bits.ADON = 0;
	// Turn off our own idea of how many analog channels to convert
	CMCON = 0x07;	// Comparators as digital inputs
	// Make all of PORTB inputs
	LATB = 0x00;
	TRISB = 0xFF;
	// Make all of PORTC inputs
	LATC = 0x00;
	TRISC = 0xFF;
#ifdef __18F4550
	// Make all of PORTD and PORTE inputs too
	LATD = 0x00;
	TRISD = 0xFF;
	LATE = 0x00;
	TRISE = 0xFF;
#endif

	// Initalize LED I/Os to outputs
    mInitAllLEDs();
	// Initalize switch as an input
    mInitSwitch();


	// Use our own special output function for STDOUT
#ifdef SDCC
	stdout = STREAM_USER;
#else
	stdout = _H_USER;
#endif

    // Now init our registers
	// The prescaler will be at 16
    T2CONbits.T2CKPS1 = 1;
    T2CONbits.T2CKPS0 = 1;
    // We want the TMR2 post scaler to be a 3
    T2CONbits.T2OUTPS3 = 0;
    T2CONbits.T2OUTPS2 = 0;
    T2CONbits.T2OUTPS1 = 1;
    T2CONbits.T2OUTPS0 = 0;
	// Set our reload value
	PR2 = kPR2_RELOAD;

    // Inialize USB TX and RX buffer management
    g_RX_buf_in = 0;
    g_RX_buf_out = 0;
	g_TX_buf_in = 0;
	g_TX_buf_out = 0;

	// Enable TMR0 for our RC timing operation
	T0CONbits.PSA = 1;		// Do NOT use the prescaler
	T0CONbits.T0CS = 0;		// Use internal clock
	T0CONbits.T08BIT = 0;	// 16 bit timer
	INTCONbits.TMR0IF = 0;	// Clear the interrupt flag
	INTCONbits.TMR0IE = 0;	// And clear the interrupt enable
	INTCON2bits.TMR0IP = 0;	// Low priority

#if	0
    // Enable interrupt priorities
    RCONbits.IPEN = 1;
	T2CONbits.TMR2ON = 0;

    PIE1bits.TMR2IE = 1;
    IPR1bits.TMR2IP = 0;

    INTCONbits.GIEH = 1;	// Turn high priority interrupts on
    INTCONbits.GIEL = 1;	// Turn low priority interrupts on

	// Turn on the Timer2
	T2CONbits.TMR2ON = 1;
#endif

}//end UserInit

void putUSBUSART(byte *d,byte len)
{
    if(cdc_trf_state != CDC_TX_READY) return;
    mUSBUSARTTxRam(d,len);     // See cdc.h
}

/******************************************************************************
 * Function:        void ProcessIO(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        In this function, we check for a new packet that just
 * 					arrived via USB. We do a few checks on the packet to see
 *					if it is worthy of us trying to interpret it. If it is,
 *					we go and call the proper function based upon the first
 *					character of the packet.
 *					NOTE: We need to see everything in one packet (i.e. we
 *					won't treat the USB data as a stream and try to find our
 *					start and end of packets within the stream. We just look
 *					at the first character of each packet for a command and
 * 					check that there's a CR as the last character of the
 *					packet.
 *
 * Note:            None
 *****************************************************************************/
void ProcessIO(void)
{
    byte numBytesRead;
	byte i;

	BlinkUSBStatus();

	if( ! mCDCUsartRxIsBusy() && 
		!((usb_device_state < CONFIGURED_STATE)|| (UCONbits.SUSPND == 1)) ) {

	    if(mUSBUSARTIsTxTrfReady()) {
			numBytesRead = getsUSBUSART(USB_Out_Buffer,64);
			if(numBytesRead != 0) {
				for(i=0;i<numBytesRead;i++) {
					USB_In_Buffer[i] = USB_Out_Buffer[i];
				}
				putUSBUSART(USB_In_Buffer,numBytesRead);
			}
			//CDC_BULK_BD_OUT.Cnt = sizeof(cdc_data_rx);
		//mUSBBufferReady(CDC_BULK_BD_OUT);
		}
	// Go send any data that needs sending to PC
	//check_and_send_TX_data ();
	}
	CDCTxService();
}

// This is our replacement for the standard putc routine
// This enables printf() and all related functions to print to
// the UBS output (i.e. to the PC) buffer
#ifndef SDCC
int _user_putc (char c)
#else
void putchar (char c) __wparam
#endif
{
	// Copy the character into the output buffer
	g_TX_buf[g_TX_buf_in++] = c;
	// Check for wrap around
	if (kTX_BUF_SIZE == g_TX_buf_in) {
		g_TX_buf_in = 0;
	}
	// Also check to see if we bumpted up against our output pointer
	if (g_TX_buf_in == g_TX_buf_out) {
		bitset (error_byte, kERROR_BYTE_TX_BUF_OVERRUN);
	}
#ifndef SDCC
	return (c);
#endif
}

// In this function, we check to see it is OK to transmit. If so
// we see if there is any data to transmit to PC. If so, we schedule
// it for sending.
void check_and_send_TX_data (void)
{
	char temp;

	// Only send if we're not already sending something
	if (mUSBUSARTIsTxTrfReady ()
		&& !( (usb_device_state < CONFIGURED_STATE) || (UCONbits.SUSPND == 1) ) ) {
		// And only send if there's something there to send
		if (g_TX_buf_out != g_TX_buf_in) {
			// Now decide if we need to break it up into two parts or not
			if (g_TX_buf_in > g_TX_buf_out) {
				// Since IN is beyond OUT, only need one chunk
				temp = g_TX_buf_in - g_TX_buf_out;
				mUSBUSARTTxRam (&g_TX_buf[g_TX_buf_out], temp);
				// Now that we've scheduled the data for sending,
				// update the pointer
				g_TX_buf_out = g_TX_buf_in;
			}else{
				// Since IN is before OUT, we need to send from OUT to the end
				// of the buffer, then the next time around we'll catch
				// from the beginning to IN.
				temp = kTX_BUF_SIZE - g_TX_buf_out;
				mUSBUSARTTxRam (&g_TX_buf[g_TX_buf_out], temp);
				// Now that we've scheduled the data for sending,
				// update the pointer
				g_TX_buf_out = 0;
			}
		}
	}
}

#define advance_RX_buf_out()						\
{ 													\
	g_RX_buf_out++;									\
	if (kRX_BUF_SIZE == g_RX_buf_out)				\
	{												\
		g_RX_buf_out = 0;							\
	}												\
}


// Look at the new packet, see what command it is, and
// route it appropriately. We come in knowing that
// our packet is in g_RX_buf[], and that the beginning
// of the packet is at g_RX_buf_out, and the end (CR) is at
// g_RX_buf_in. Note that because of buffer wrapping,
// g_RX_buf_in may be less than g_RX_buf_out.
void parse_packet(void)
{
	unsigned int	command = 0;
	unsigned char	cmd1 = 0;
	unsigned char	cmd2 = 0;

	// Always grab the first character (which is the first byte of the command)
	cmd1 = toupper (g_RX_buf[g_RX_buf_out]);
	advance_RX_buf_out();
	command = cmd1;

	// Only grab second one if it is not a comma
	if (g_RX_buf[g_RX_buf_out] != ',' && g_RX_buf[g_RX_buf_out] != kCR) {
		cmd2 = toupper (g_RX_buf[g_RX_buf_out]);
		advance_RX_buf_out();
		command = ((unsigned int)(cmd1) << 8) + cmd2;
	}

	// Double check that our output pointer is now at the ending <CR>
	// If it is not, this indicates that there were extra characters that
	// the command parsing routine didn't eat. This would be an error and needs
	// to be reported. (Ignore for Reset command because FIFO pointers get cleared.)
	if ((g_RX_buf[g_RX_buf_out] != kCR && 0 == error_byte) &&
		('R' != command)){
		bitset (error_byte, kERROR_BYTE_EXTRA_CHARACTERS);
	}

	// Clean up by skipping over any bytes we haven't eaten
	// This is safe since we parse each packet as we get a <CR>
	// (i.e. g_RX_buf_in doesn't move while we are in this routine)
	g_RX_buf_out = g_RX_buf_in;
}

/******************************************************************************
 * Function:        void BlinkUSBStatus(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        BlinkUSBStatus turns on and off LEDs corresponding to
 *                  the USB device state.
 *
 * Note:            mLED macros can be found in io_cfg.h
 *                  usb_device_state is declared in usbmmap.c and is modified
 *                  in usbdrv.c, usbctrltrf.c, and usb9.c
 *****************************************************************************/
void BlinkUSBStatus(void)
{
    static word LEDCount = 0;
	static unsigned char LEDState = 0;

    if (usb_device_state == DETACHED_STATE || 1 == UCONbits.SUSPND) {
		LEDCount--;
		if (0 == LEDState) {
			if (0 == LEDCount){
				mLED_1_On();
				LEDCount = 2000U;
				LEDState = 1;
			}
		}else{
			if (0 == LEDCount){
				mLED_1_Off();
				LEDCount = 2000U;
				LEDState = 0;
			}
		}
	} else if (
		usb_device_state == ATTACHED_STATE ||
		usb_device_state == POWERED_STATE  ||
		usb_device_state == DEFAULT_STATE  ||
		usb_device_state == ADDRESS_STATE ) {
        mLED_1_On();
    } else if (usb_device_state == CONFIGURED_STATE) {
		LEDCount--;
		if (0 == LEDState) {
			if (0 == LEDCount) {
				mLED_1_On();
				LEDCount = 10000U;
				LEDState = 1;
			}
		}else if (1 == LEDState) {
			if (0 == LEDCount) {
				mLED_1_Off();
				LEDCount = 10000U;
				LEDState = 2;
			}
		} else if (2 == LEDState) {
			if (0 == LEDCount) {
				mLED_1_On();
				LEDCount = 100000U;
				LEDState = 3;
			}
		} else if (LEDState >= 3) {
			if (0 == LEDCount) {
				mLED_1_Off();
				LEDCount = 10000U;
				LEDState = 0;
			}
		}
    }
}


/** EOF user.c ***************************************************************/
