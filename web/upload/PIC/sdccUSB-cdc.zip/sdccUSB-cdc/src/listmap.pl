#!/usr/bin/perl

#======================================================================
#	*.map �����₷������.
#======================================================================
#


sub help()
{
	print <<'EOH';
# Usage:
#   $ listmap.pl infile.map
# Option:

EOH
	exit 1;
}

###########################################################################
#	
###########################################################################
my %dircache;
my $opt_n = 1;   # dry-run.
my $opt_e = 0;   # real execution

# =====================================================
#      
# =====================================================
sub loadfile()
{
	my ($file)=@_;
	my @buf;
	open(FILE,$file) || die("Can't open file $file");
	@buf = <FILE>;
	close(FILE);
	return @buf;
}

###########################################################################
#
###########################################################################
sub list1()
{
	my ($line)=@_;
	$line =~ s/^[ ]+//;
	my ($symbol,$section,$adrs,$area,$size)=split(/[ ]+/,$line);
#	print "$symbol,$section,$adrs,$area,$size" . "\n"
	if($area eq 'program') {
		my ($module,$sym);
		my $i=index($symbol,'__');
		if($i>0) {
			$module = substr($symbol,0,$i);
			$sym    = substr($symbol,$i+2);
			$module =~ s/^S_//;
		}else{
			$module = '';
			$sym    = $symbol
		}
		$module = sprintf("%-16s",$module);
		print "$adrs $size $module $sym" . "\n"
	}
}
###########################################################################
#
###########################################################################
sub list()
{
	my ($listfile)=@_;
	my @filelist = &loadfile($listfile);
	my ($line,$s);
	my $cnt = 0;
    #===== �t�@�C���̂ݐ�ɏ������� =====
    foreach $line (@filelist) {
		$line =~ s/\n//;
		$line =~ s/\r//;
		$s = $line;
		$s =~ s/ //g;
		
		if( $cnt ) {$cnt++;}
		if( $line =~ 'Section Info') {
			$cnt = 1;
		}
		if( $s eq '' ) {
			$cnt = 0;
		}
		
		if($cnt > 3) {
#			print $line . "\n";
			&list1($line);
		}
	}
}

###########################################################################
#	�I�v�V�������.
###########################################################################
sub getarg()
{
	my @arg = @ARGV;
	my $m= scalar(@arg);
	my ($i,$s);
	for($i=0;$i<$m;$i++) {
		$s = $arg[0];
		if($s eq '-?') {
			&help();
		}
		if($s eq '--help') {
			&help();
		}
	}
	return @arg;
}

###########################################################################
#	���C��.
###########################################################################
sub	main()
{
	undef %dircache;
	my @arg = &getarg();
	my $listfile;

	if(scalar(@arg) < 1 ) {&help();}
	($listfile) = @arg;

	&list($listfile);
}

###########################################################################
#	
###########################################################################
&main();

#
