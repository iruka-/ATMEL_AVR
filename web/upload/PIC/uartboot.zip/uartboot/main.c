/********************************************************************
 *	PIC32MX220F032B �p UART�u�[�g���[�_�[ Main:
 ********************************************************************
 *

- Pinguino�R���p�C�����݂̂��g�p.(MicroChip gcc�w�b�_�[��ˑ�)
- �o�C�i���[�T�C�Y3kB�ȓ�. ( BOOT FLASH ROM �̂ݎg�p )

 ********************************************************************
 */
#include <p32xxxx.h>			// always in first place to avoid conflict with const.h ON
#include <typedef.h>			// Pinguino's types definitions
#include <const.h>				// Pinguino's constants definitions
#include <macro.h>				// Pinguino's macros definitions

/********************************************************************
 *
 ********************************************************************
 */
#define	__SERIAL__
#define __SYSTEM_C


#include <system.c>				// PIC32 System Core Functions
#include <io.c>					// Pinguino Boards Peripheral Remappage and IOs configurations

#include "serial1.h"

#define	_BOOTROM_  __attribute__((section(".bootrom")))

#ifndef	BAUDRATE
#define	BAUDRATE	500000
#endif

#define mInitBootSwitch()   TRISBbits.TRISB7=1;
#define mGetSWRFlag()       RCONbits.SWR
#define Boot_SW             PORTBbits.RB7

#if	1
#define BootMemStart					0x9D000000
#else
#define BootMemStart					0x9D001000
#endif

unsigned int *SoftwareKey = NULL;

#if	0
#define	Boot_SW_POLARITY	1		// If not PRESSED , Then Run Sketch Program (UBW32 Compat)
#else
#define	Boot_SW_POLARITY	0		// If PRESSED , Then Run Sketch Program (Pinguino Useful)
#endif

//
//	start_addr �ɕ��򂷂�.
//
static inline
void call_ptr(int start_addr)
{
	void (*fptr)(void);
	fptr = (void (*)(void)) start_addr;
	fptr();
}


/*	----------------------------------------------------------------------------
	SystemUnlock() perform a system unlock sequence
	--------------------------------------------------------------------------*/

void system_unlock()
{
	SYSKEY = 0;				// ensure OSCCON is locked
	SYSKEY = 0xAA996655;	// Write Key1 to SYSKEY
	SYSKEY = 0x556699AA;	// Write Key2 to SYSKEY
}

/*	----------------------------------------------------------------------------
	SystemLock() relock OSCCON by relocking the SYSKEY
	--------------------------------------------------------------------------*/

void system_lock()
{
	SYSKEY = 0x12345678;	// Write any value other than Key1 or Key2
}

/*	----------------------------------------------------------------------------
	call from cmd_boot()	adrs�͖���.
	--------------------------------------------------------------------------*/
void reset_device(int adrs)
{
	volatile int* p = &RSWRST;

	int j;

	IEC1bits.U1RXIE=0;			// U1RX disable.
	INTDisableInterrupts();		// DI

	*SoftwareKey = 0x12345678;	// Software Reset Signal:

//	U1CON = 0x0000;				//Disable USB module
//	for(j = 0; j < 0xFFFF; j++) {
//		Nop();
//	}

	system_unlock();

	RSWRSTSET=_RSWRST_SWRST_MASK;

	*p;	// RSWRST;

	while(1);

}
/********************************************************************
 *		PIC32 Peripheral Remappage
 ********************************************************************
 */
void io_setRemap()
{
	system_unlock();
	CFGCONbits.IOLOCK=0;			// unlock configuration
	CFGCONbits.PMDLOCK=0;
	{
		U1RXRbits.U1RXR=2;			// Define U1RX as RA4 ( UEXT SERIAL )
		RPB4Rbits.RPB4R=1;			// Define U1TX as RB4 ( UEXT SERIAL )
	}
	CFGCONbits.IOLOCK=1;			// relock configuration
	CFGCONbits.PMDLOCK=1;
	system_lock();
//	SystemLock();
}
/********************************************************************
 *		Arduino��:	����������
 ********************************************************************
 */
static	inline void setup()
{
	TRISBCLR=0x8000;	//	pinmode(13, OUTPUT);
	SerialConfigure(UART1, UART_ENABLE,	UART_RX_TX_ENABLED,	BAUDRATE);
}

/********************************************************************
 *		Arduino��:	�J��Ԃ�����
 ********************************************************************

 Packet�\��:

 [0xa5] ==> [0x55]   :�����t�G�R�[.

 [0xaa] [0x55]       :�R�}���h�t�F�[�Y�Ɉڍs����.

 [0x01] [�R�}���h�p�P�b�g(64byte)] : USB HID�Ɠ����p�P�b�g���󂯎��.

 */
static	inline	void loop(void)
{
	int ch = Serial1GetKey();
	if( ch == 0xaa) {
		ch = Serial1GetKey();
		if(	ch == 0x55) {
			UARTmonit();
		}
	} else if(ch == 0xa5) {
		Serial1WriteChar(0x55);
	}
}

/********************************************************************
 *		���C��
 ********************************************************************
 */

int _BOOTROM_ main()
{
//	AN1388�Ɠ����̏�����:
//	int	pbClk = SYSTEMConfig(SYS_FREQ, SYS_CFG_WAIT_STATES | SYS_CFG_PCACHE);

	mInitBootSwitch();
	SoftwareKey = (unsigned int *)0xA0000000;

#ifdef	USE_INTERNAL_FRC_OSC	// RC OSC
	InitializeFRC();
#endif

#if	1
	//  �N������̏���:
	//  -	BootSW��������Ă�����A���[�U�[�v���O�����֕��򂷂�.
	//  -	BootSW��������Ă��Ȃ��Ă��A
	//	-		�\�t�g�E�F�A���Z�b�g�N���A���A
	//	-		�X�P�b�`���s�L�[���������܂�Ă����烆�[�U�[�v���O�����֕��򂷂�.

	if(	(Boot_SW == Boot_SW_POLARITY) ||
	        (mGetSWRFlag() && (*SoftwareKey == 0x12345678) ) ) {
		*SoftwareKey = 0;
		//
		//���[�U�[�v���O������ 9D000000,9D001000,9D002000,9D003000,9D004000,9D005000 �̏��Ɍ�������.
		//
		int start_addr=BootMemStart;	// 9d001000
		for(; start_addr<=0x9d005000; start_addr+=0x1000) {
			if (*(int *)start_addr != 0xFFFFFFFF) {
				call_ptr(start_addr);
				while(1);
			}
		}
	}
#endif

	DDPCONbits.JTAGEN=0;		// PORTA is used as digital instead of JTAG
	IOsetSpecial();
	IOsetDigital();
	io_setRemap();
	//
	setup();
	while (1) {
		loop();
	}

	return(0);
}

/********************************************************************
 *
 ********************************************************************
 */
