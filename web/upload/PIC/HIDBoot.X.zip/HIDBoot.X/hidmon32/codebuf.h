int code_buf_init();
int code_buf_read(int adr,int size ,uchar *buf);
int code_buf_peek(int adr,int width);

