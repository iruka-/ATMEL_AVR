
#if defined(__18F4550) || defined(__18F2550)
    #include "HardwareProfile_PICDEM_FSUSB.h"
#elif defined(__18F14K50)
    #include "HardwareProfile_PIC18F14K50.h"
#endif

