#ifndef	typedefs_h
#define	typedefs_h

typedef unsigned char   byte;   
typedef unsigned int    word;   
typedef unsigned long   dword;  
typedef unsigned char   uchar;  
typedef unsigned short  ushort; 

#endif
