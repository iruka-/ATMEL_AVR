/********************************************************************
 *	GPIO�̐���.
 ********************************************************************
 *
 *	�ȉ���Arduino���֐�����������.
 *
void	pinMode(int	pin, int mode)
void	digitalWrite(int pin, int value)
int		digitalRead(int pin)
 *
 ********************************************************************
 */

#include "platform_config.h"
#include "monit.h"
#include "gpio.h"

/********************************************************************
 *	GPIO�̐���.

//	PORT DIRECTION
enum {
	INPUT = 0,
	OUTPUT= 1,
};
 ********************************************************************
 */
void	pinMode(int	pin, int mode)
{
	if(pin<16) {
		if (mode) 	TRISASET=1<<pin;
		else 		TRISACLR=1<<pin;
	}else{
		pin &= 0x0f;
		if (mode) 	TRISBSET=1<<pin;
		else 		TRISBCLR=1<<pin;
	}
}
/********************************************************************
 *	GPIO�̐���.
 ********************************************************************
 */
void	digitalWrite(int pin, int value)
{
	if(pin<16) {
		if (value) 	PORTASET=1<<pin;
		else 		PORTACLR=1<<pin;
	}else{
		pin &= 0x0f;
		if (value) 	PORTBSET=1<<pin;
		else 		PORTBCLR=1<<pin;
	}
}

/********************************************************************
 *	GPIO�̐���.
 ********************************************************************
 */
int		digitalRead(int pin)
{
	if(pin<16) {
		return((PORTA & (1<<pin) )!=0);
	}else{
		pin &= 0x0f;
		return((PORTB & (1<<pin) )!=0);
	}
}

/********************************************************************
 *	GPIO�̐���.
 ********************************************************************
 */
