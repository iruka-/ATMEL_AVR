/********************************************************************
 *	A/D�ϊ��Ȃǂ� �T���v�����O����.
 ********************************************************************
 *	int	sample_init(SAMPLE_PARAM *param);	//�T���v�����O�̏�����.
 *	int	sample_read(char *buf,int size);	//�T���v�����O�f�[�^�擾.
 *
 *	int	sample_start(SAMPLE_PARAM *param);	//�T���v�����O�J�n(�����֐�).
 *	int	sample_stop();						//�T���v�����O��~(�����֐�).
 ********************************************************************
 *	�T���v�����O�͊��荞�݂ɂ����s�����.
 *	�f�[�^�擾�͊i�[�L���[����̎��o���Ƃ���.
 */

#include <string.h>
#include "fifo.h"
#include "sample.h"


/********************************************************************
 *
 ********************************************************************
 */

#define UNIT_NO			0					//�g�p���郆�j�b�gNo.(0,1,2)

#define	INPUT_USE_CH16_31	1				//AN16�`31���A�i���O���͂ɂ���.

#define INPUT_CH_PRI1	0	//4					//�D��ϊ�1��CH
#define INPUT_CH_PRI2	0	//8					//�D��ϊ�2��CH
/********************************************************************
 *
 ********************************************************************
 */
//int	g_count=0;

/********************************************************************
 *	�\�t�g�E�F�AFIFO
 ********************************************************************
int FIFO_init( FIFO *queue,uchar *buf,int size);	//������.
int FIFO_enqueue(FIFO *queue,uchar *buf,int size);	//�L���[�ɂ��߂�.
int FIFO_dequeue(FIFO *queue,uchar *buf,int size);	//�L���[������o��.
int FIFO_getsize(FIFO *queue);					//�L���[�ɂ��܂��Ă���o�C�g���𓾂�.
int FIFO_getfreesize(FIFO *queue);				//�L���[�̋󂫗e�ʃo�C�g���𓾂�.
 */
#define	FIFOSIZE	1024		// DWORD��.

//static
FIFO	adque;
static	FIFO_t	adbuffer[FIFOSIZE];	//1024*4=4096 byte

static	char	flag_start;
static	char	flag_overrun;
static	SAMPLE_PARAM defparam;

static	int		debug_cnt=0;


void fifo_init()
{
	FIFO_init(&adque,adbuffer,FIFOSIZE);
}

/********************************************************************
 *	�T���v�����O�J�n.
 ********************************************************************
 */
int	sample_start(SAMPLE_PARAM *param)
{
	fifo_init();
	analogInit(param->rate,param->channels);

	flag_start = 1;
	flag_overrun = 0;
	return 0;
}
/********************************************************************
 *	�T���v�����O��~.
 ********************************************************************
 */
int	sample_stop()
{
	if( flag_start == 1 ) {
		analogStop();
		flag_start = 0;
	}
	return 0;
}
/********************************************************************
 *	�T���v�����O�̏�����.
 ********************************************************************
 */
int	sample_init(SAMPLE_PARAM *param)
{
	if( memcmp(&defparam,param,sizeof(SAMPLE_PARAM)) != 0 ) {	//�p�����[�^�ύX���ꂽ.
		memcpy(&defparam,param,sizeof(SAMPLE_PARAM));
		if(param->subcmd == ADC_STOP) {
			sample_stop();				//��~.
		} else {
			sample_stop();				//��~.
			sample_start(&defparam);	//�J�n.
		}
	}
	return 0;
}
/********************************************************************
 *	�T���v�����O�f�[�^�擾.
 ********************************************************************
 *	size = 64����.
 */
int	sample_read(int *buf,int size)
{
	size >>=2;	// 16

	int rsize = FIFO_dequeue(&adque,buf,size);

	int i;
	for(i=rsize;i<size;i++) {buf[i]=0;}	//64�o�C�g�����̏ꍇ�A�����O�ɂ���.

	return 0;
}

/********************************************************************
 *	�A�i���O����:
 ********************************************************************
 *
 ********************************************************************
 */

#include <p32xxxx.h>			// always in first place to avoid conflict with const.h ON


#define _0	1<<0
#define _1	1<<1
#define _2	1<<2
#define _3	1<<3
#define _4	1<<4
#define _5	1<<5
#define _6	1<<6
#define _7	1<<7
#define _8	1<<8
#define _9	1<<9
#define _10	1<<10
#define _11	1<<11
#define _12	1<<12
#define _13	1<<13
#define _14	1<<14
#define _15	1<<15


/********************************************************************
 *
 ********************************************************************
 */
//	1=PORTB 2=PORTA
uchar __portanalogmask[]= {2, 2, 1, 1, 1, 1, 0, 0,
                           0, 2, 2, 2, 0, 0, 0, 0,
                          } ;

//	PORT MASK (bit mask)
ushort __analogmask[]= 	{_0, _1, _0, _1,_2,_3, 0, 0,
                         0,_15,_14,_13, 0, 0, 0, 0,
                        } ;

//Analog In
//	AN0 =Pin 2 (RA0)
//	AN1 =Pin 3 (RA1)
//	AN2 =Pin 4 (RB0)
//	AN3 =Pin 5 (RB1)
//	AN4 =Pin 6 (RB2)
//	AN5 =Pin 7 (RB3)
//	AN6  ---
//	AN7  ---
//	AN8  ---
//	AN9 =Pin26 (RB15)
//	AN10=Pin25 (RB14)
//	AN11=Pin24 (RB13)
//	AN12 ---

//Pinguino Define (bufmask������): <===�g��Ȃ�
//	A0	110=6
//	A1	111=7
//	A2	010=2
//	A3	011=3
//	A4	100=4
//	A5	101=5
//	A6	000=0
//	A7	000=0

/********************************************************************
 *
 ********************************************************************
 */
void SetAnalog(int pin)
{
	switch (__portanalogmask[pin]) {
	 case 1:
		ANSELBSET=__analogmask[pin];
		TRISBSET =__analogmask[pin];
		break;
	 case 2:
		ANSELASET=__analogmask[pin];
		TRISASET =__analogmask[pin];
		break;
	}
}

/********************************************************************
 *
 ********************************************************************
 */
void SetDigital(int pin)
{
	switch (__portanalogmask[pin]) {
	 case 1:
		ANSELBCLR=__analogmask[pin];
//		TRISBSET =__analogmask[pin];
		break;
	 case 2:
		ANSELACLR=__analogmask[pin];
//		TRISASET =__analogmask[pin];
		break;
	}
}

/********************************************************************
 *
 ********************************************************************
 */
#define _IFS1_AD1IF_MASK                    (1<<28) // AD1 ���荞�݃t���O�̃r�b�g�ʒu.

#define mAD1ClearIntFlag()                  ( IFS0CLR = _IFS1_AD1IF_MASK)
#define mAD1IntEnable(enable)               ( IEC0CLR = _IEC0_AD1IE_MASK, IEC0SET = ((enable) << _IEC0_AD1IE_POSITION))
#define mAD1SetIntPriority(priority)        ( IPC5CLR = _IPC5_AD1IP_MASK, IPC5SET = ((priority) << _IPC5_AD1IP_POSITION))
#define mAD1SetIntSubPriority(subPriority)  ( IPC5CLR = _IPC5_AD1IS_MASK, IPC5SET = ((subPriority) << _IPC5_AD1IS_POSITION))

/********************************************************************
 *
 ********************************************************************
 */
void analogInit(int rate,int channels)
{
#if	0
//	500kSps
	int Tad=20-(12+1);	// [1..31]
	int ADCs=2+1;		// [1..256]
//	12sample/Interrupt
	int smpi=12;		// [0..15]
//	Input=AN2
	int pin =2;			// [0..15]
#endif

//	500kSps
	int Tad=(rate>>8) & 0x1f;	// [1..31]
	int ADCs=(rate)   & 0xff;	// [1..256]
//	12sample/Interrupt
	int smpi=12;		// [0..15]
//	Input=AN0
	int pin =0;			// [0..15]
	int scan=0;
	int i;
	for(i=0;i<4;i++) SetAnalog(i);

	if(channels==0x01) {
		scan=0;
		AD1CHS = pin<<16;			// select channel
		AD1CSSL = 0;				//Scan Select Register(AN0�`AN15)
	}else{
		scan=1;
		AD1CHS = pin<<16;			// select channel
		AD1CSSL = channels;			//Scan Select Register(AN0�`AN15)
	}

	mAD1ClearIntFlag();
	mAD1SetIntPriority(((4) & 7));
	mAD1SetIntSubPriority(((2) & 3));
	mAD1IntEnable(1);

	//	bit 31-16 Unimplemented:Read as �e0�f
	//	bit 15-0 CSSL<15:0>:ADC Input Pin Scan Selection bits
	//	1= Select ANx for input scan
	//	0= Skip ANx for input scan

	AD1CON1 = 0x00E0;	//ADC Control Register 1
	//Internal counter ends sampling and starts conversion (auto convert)

	/*
	bit 15 ON:ADC Operating Mode bit(1)
	1= ADC module is operating
	0= ADC is off
	bit 14 Unimplemented:Read as �e0�f
	bit 13 SIDL:Stop in Idle Mode bit
	1= Discontinue module operation when device enters Idle mode
	0= Continue module operation in Idle mode
	bit 12-11 Unimplemented:Read as �e0�f
	bit 10-8 FORM<2:0>: Data Output Format bits
	011= Signed Fractional 16-bit (DOUT = 0000 0000 0000 0000 sddd dddd dd00 0000)
	010= 		Fractional 16-bit (DOUT = 0000 0000 0000 0000 dddd dddd dd00 0000)
	001= Signed Integer    16-bit (DOUT = 0000 0000 0000 0000 ssss sssd dddd dddd)
	000= 		Integer    16-bit (DOUT = 0000 0000 0000 0000 0000 00dd dddd dddd)
	111= Signed Fractional 32-bit (DOUT = sddd dddd dd00 0000 0000 0000 0000)
	110= 	    Fractional 32-bit (DOUT = dddd dddd dd00 0000 0000 0000 0000 0000)
	101= Signed Integer    32-bit (DOUT = ssss ssss ssss ssss ssss sssd dddd dddd)
	100= 	    Integer    32-bit (DOUT = 0000 0000 0000 0000 0000 00dd dddd dddd)

	bit 7-5 SSRC<2:0>:Conversion Trigger Source Select bits
	111= Internal counter ends sampling and starts conversion (auto convert)
	110= Reserved
	101= Reserved
	100= Reserved
	011= Reserved
	010= Timer3 period match ends sampling and starts conversion
	001= Active transition on INT0 pin ends sampling and starts conversion
	000= Clearing SAMP bit ends sampling and starts conversion
	bit 4 CLRASAM:Stop Conversion Sequence bit (when the first ADC interrupt is generated)
	1= Stop conversions when the first ADC interrupt is generated. Hardware clears the ASAM bit when the
	ADC interrupt is generated.
	0= Normal operation, buffer contents will be overwritten by the next conversion sequence
	*/
	AD1CON2 = 0x0000|((smpi-1)<<2)|(scan<<10);/* Configure ADC voltage reference
						and buffer fill modes.
						VREF from AVDD and AVSS,
						Inputs are not scanned,
						Interrupt every sample */

	/*
	AD1CON2: ADC Control Register 2
	bit 15-13 VCFG<2:0>:Voltage Reference Configuration bits
			ADC VR+ ADC VR-
			000 AVDD AVSS
			001 External VREF+ pin AVSS
			010 AVDD External VREF- pin
			011 External VREF+ pin External VREF- pin
			1xx AVDD AVSS
	bit 12 	OFFCAL:Input Offset Calibration Mode Select bit
			1= Enable Offset Calibration mode
			VINHand VINLof the SHA are connected to VR-
			0= Disable Offset Calibration mode
			The inputs to the SHA are controlled by AD1CHS or AD1CSSL
	bit 11 	Unimplemented:Read as �e0�f
	bit 10 	CSCNA:Scan Input Selections for CH0+ SHA Inputfor MUX A Input Multiplexer Setting bit
			1= Scan inputs
			0= Do not scan inputs
	bit 9-8 Unimplemented:Read as �e0�f
	bit 7 	BUFS:Buffer Fill Status bit
			Only valid when BUFM = 1(ADRES split into 2 x 8-word buffers).
			1= ADC is currently filling buffer 0x8-0xF, user should access data in 0x0-0x7
			0= ADC is currently filling buffer 0x0-0x7, user should access data in 0x8-0xF
	bit 6 Unimplemented:Read as �e0�f

	bit 5-2 SMPI<3:0>:Sample/Convert Sequences Per Interrupt Selection bits
			1111= Interrupts at the completion of conversion for each 16th sample/convert sequence
			1110= Interrupts at the completion of conversion for each 15th sample/convert sequence
			.
			.
			.
			0001= Interrupts at the completion of conversion for each 2nd sample/convert sequence
			0000= Interrupts at the completion of conversion for each sample/convert sequence

	bit 1 BUFM:ADC Result Buffer Mode Select bit
			1= Buffer configured as two 8-word buffers, ADC1BUF(7...0), ADC1BUF(15...8)
			0= Buffer configured as one 16-word buffer ADC1BUF(15...0.)
	bit 0 ALTS:Alternate Input Sample Mode Select bit
			1= Uses MUX A input multiplexer settings for first sample, then alternates between MUX B and
			MUX A input multiplexer settings for all subsequent samples
			0= Always use MUX A input multiplexer settings
	*/

//	AD1CON3 = 0x8F00;
//	AD1CON3 = 0x0002;// Sample time manual, TAD = internal 6 TPB

	// Base Clock = 50nSec ( 20MHz ) (== TPB/2 )
//	ADCs= 2;			// [1..256] ConvertClock(nSec)= ADCs * 50
	// sampleTime Tad=7�̂Ƃ� 1sample = 20 * ConvertClock
//	Tad = 20-(12+1);	// [1..31]
	AD1CON3 = (Tad << 8) | (ADCs);

	/*
	bit 15 ADRC:ADC Conversion Clock Source bit
			1= ADC internal RC clock
			0= Clock derived from Peripheral Bus Clock (PBCLK)
	bit 14-13 Unimplemented:Read as �e0�f
	bit 12-8 SAMC<4:0>:Auto-sample Time bits
			11111= 31 TAD
			.
			.
			.
			00001= 1TAD
			00000= 0TAD(Not allowed)
	bit 7-0 ADCS<7:0>:ADC Conversion Clock Select bits(1)
			11111111= TPB* 2 * (ADCS<7:0> + 1) = 512 * TPB= TAD
			.
			00000001= TPB* 2 * (ADCS<7:0> + 1) = 4 * TPB= TAD
			00000000= TPB* 2 * (ADCS<7:0> + 1) = 2 * TPB= TAD
	cf.
			TPB = Peripheral Bus clock time period . = (2/40MHz) = 50nS
			Tad = 2 * TPB = 100nS
			Tad Min. 65nS  Sampling Min. 132nS
			sampletime = Tad * (SAMPC=3) = 300nS
	Summary:
		ADCS = 2: ADC clock is PB divided by 2
		SAMPC = 3: Sample time is 3 TADperiods

	*/

	AD1CON1bits.ADON = 1;				  // start analogic converter
	AD1CON1bits.ASAM = 1;				  // start Auto sampling

}

/********************************************************************
 *
 ********************************************************************
 */
void analogStop(void)
{
	AD1CON1bits.ASAM = 0;				  // start Auto sampling
	AD1CON1bits.ADON = 0;				  // start analogic converter

	mAD1ClearIntFlag();
	mAD1IntEnable(0);
}

/****************************************************************
 *	�����
 ****************************************************************
 *	�����F
 *			queue   : FIFO�L���[
 *			data  : �l�ߍ��ރf�[�^.
 *			size  : �l�ߍ��ރo�C�g��.
 *	�߂�l�F�l�ߍ��݂ɐ��������o�C�g��. (0 �������� size)
 *			�L���[�ɏ[���ȋ󂫂��Ȃ��Ƃ��͋l�ߍ��݂̓L�����Z��.
 *	note:	�L���[��2�o�C�g�Â��߂�.���o����2�̔{���łȂ��Ƒʖ�.
 */
static inline int FIFO_enqueue_fast(FIFO *queue,FIFO_t *data,int size)
{
	int i;
	int n = queue->inPtr;				// FIFO�̏������݃|�C���^.
	FIFO_t *t;
	for(i=0; i<size; i++) {
		t = (int *) &queue->buf[n];
		*t = *data++;
		n++;
		if(	n >= queue->size) {
			n = 0;
		}
		// FIFO���o���|�C���^�ɒǂ�������A�|�C���^���X�V���Ȃ��ŃL�����Z��.
		if(n == queue->outPtr) {
			return 0;
		}
	}
	queue->inPtr = n;
	return i;
}
/********************************************************************
 *	���荞�݃n���h���\.
 ********************************************************************
 */
void __attribute__((interrupt,nomips16)) _ADC1Interrupt(void)
{
	FIFO_t scan_data[4];
	int  rc,i,a0,a1,a2;
	uint *adc1buf= &ADC1BUF0;	// �o�b�t�@��16byte�����ɑ���.
	//	12 SAMPLE �� 4 DWORD �� PACK ����.
	for(i=0; i<4; i++) {
		a0 = adc1buf[0];	//ADC1BUF0
		a1 = adc1buf[4];	//ADC1BUF1
		a2 = adc1buf[8];	//ADC1BUF2
		adc1buf += (4*3);
		scan_data[i]=a0|(a1<<10)|(a2<<20)|0x80000000;	// MSB�𗧂Ă�.
	}



#if	0
	for(i=0; i<4; i++) {
		scan_data[i]=g_count|0x80000000;	// MSB�𗧂Ă�.
	}
#endif
	//	16byte��FIFO��queueing����.
	rc = FIFO_enqueue_fast(&adque,scan_data,4);		//�L���[�ɂ��߂�.
	if(rc==0) {
//		FIFO_reset(&adque);
		flag_overrun=1;
	}
	mAD1ClearIntFlag();
//	g_count++;
}

/********************************************************************
 *
 ********************************************************************
 */
