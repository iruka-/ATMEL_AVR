/*	----------------------------------------------------------------------------
	FILE:			spi.c
	PROJECT:		pinguino
	PURPOSE:		Serial Peripheral Interface functions
	PROGRAMER:		Régis Blanchot <rblanchot@gmail.com>
					Marcus Fazzi <anunakin@gmail.com>
					Jean-Pierre Mandon <jp.mandon@gmail.com>
	FIRST RELEASE:	16 Mar 2011
	LAST RELEASE:	28 May 2012
	----------------------------------------------------------------------------
	CHANGELOG : 
	24 May 2011 - jp.mandon - fixed a bug in SPI_write, RX int flag must be called even for write
	20 Feb 2012 - r.blanchot - added PIC32_PINGUINO_220 support
	28 May 2012 - MFH - 	added PIC32_PINGUINO_MICRO support and fixed a bug
								in SPI_clock() identified by dk (KiloOne)
 	----------------------------------------------------------------------------
	TODO : 
	----------------------------------------------------------------------------
	This library is free software; you can redistribute it and/or
	modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation; either
	version 2.1 of the License, or (at your option) any later version.

	This library is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	Lesser General Public License for more details.

	You should have received a copy of the GNU Lesser General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
	--------------------------------------------------------------------------*/
/**
 *	Microchip making changes do SPI SFR numbers and changing 2A to 3, and 3A to 4
 * but it need a new processor.o and updated compiler libraries, not released at this time.
 *  
 *  MX440 and MX460 have only 2 SPI ports
 */
#ifndef __SPI1h__
#define __SPI1h__

#include <p32xxxx.h>			// always in first place to avoid conflict with const.h ON
//#include "utype.h"
#include "interrupt.h"

//#include <system.c>
//#include <interrupt.c>

#ifndef SPIx				// Use SPI port 1, see PIC32 Datasheet
	#if defined(PIC32_PINGUINO_OTG) || defined(PIC32_PINGUINO) || defined(PIC32_PINGUINO_MICRO)  //dk MICRO added
		#define SPIx 2		// default SPI port is 2 for 32MX440F256H which has only one SPI port
	#else
		#define SPIx 1		// default SPI port is 1
	#endif
#endif

#if defined(UBW32_460) || defined(EMPEROR460) || defined(PIC32_PINGUINO_220)
#if (SPIx == 1)
	#define BUFFER		SPI1BUF
	#define STATUS		SPI1STATbits.SPIROV	// Receive Overflow Flag bit
	#define STATRX  	SPI1STATbits.SPIRBF	// receive buffer full
	#define STATTX		SPI1STATbits.SPITBF	// transmit buffer full
	#define SPICONF		SPI1CON
	#define SPICONCLR	SPI1CONCLR
	#define CLKSPD		SPI1BRG
	#define INTFAULT	INT_SPI1_FAULT
	#define INTTXDONE 	INT_SPI1_TRANSFER_DONE
	#define INTRXDONE 	INT_SPI1_RECEIVE_DONE
	#define INTVECTOR 	INT_SPI1_VECTOR
#endif
#endif

#if (SPIx == 2)
	#define BUFFER		SPI2BUF
	#define STATUS		SPI2STATbits.SPIROV	// Receive Overflow Flag bit
	#define STATRX  	SPI2STATbits.SPIRBF	// Receive buffer full
	#define STATTX		SPI2STATbits.SPITBF	// Transmit buffer full
	#define SPICONF		SPI2CON
	#define SPICONCLR	SPI2CONCLR
	#define SPIENHBUF	SPI2CONbits.ENHBUF
	#define CLKSPD		SPI2BRG
	#define PULLUPS		0xF00 //Use CNPUE = PULLUPS for enable internal pullups 8,9,10,11
	#define INTFAULT	INT_SPI2_FAULT
	#define INTTXDONE 	INT_SPI2_TRANSFER_DONE
	#define INTRXDONE 	INT_SPI2_RECEIVE_DONE
	#define INTVECTOR 	INT_SPI2_VECTOR
#endif

//Only 795 boards have SPI3 and SPI4
#if defined(UBW32_795) || defined(EMPEROR795)
	#if (SPIx == 3)
		#define BUFFER		SPI3BUF
		#define STATUS		SPI3STATbits.SPIROV	// Receive Overflow Flag bit
		#define STATRX  	SPI3STATbits.SPIRBF	// receive buffer full
		#define STATTX		SPI3STATbits.SPITBF	// transmit buffer full
		#define SPICONF		SPI3CON
		#define CLKSPD		SPI3BRG
		#define INTFAULT	INT_SPI3_FAULT
		#define INTTXDONE 	INT_SPI3_TRANSFER_DONE
		#define INTRXDONE 	INT_SPI3_RECEIVE_DONE
		#define INTVECTOR 	INT_SPI3_VECTOR
	#endif
	#if (SPIx == 4)
		#define BUFFER		SPI4ABUF
		#define STATUS		SPI4STATbits.SPIROV	// Receive Overflow Flag bit
		#define STATRX  	SPI4STATbits.SPIRBF	// receive buffer full
		#define STATTX		SPI4STATbits.SPITBF	// transmit buffer full
		#define SPICONF		SPI4CON
		#define CLKSPD		SPI4BRG
		#define INTFAULT	INT_SPI4_FAULT
		#define INTTXDONE 	INT_SPI4_TRANSFER_DONE
		#define INTRXDONE 	INT_SPI4_RECEIVE_DONE
		#define INTVECTOR 	INT_SPI4_VECTOR
	#endif
#endif

// The SPI module offers the following operating modes:
// • 8-Bit, 16-Bit, and 32-bit data transmission modes
// • 8-Bit, 16-Bit, and 32-bit data reception modes
// • Master and Slave modes
// • Framed SPI modes

// SPIxCON.MSTEN
#define SPI_MASTER			1
#define SPI_SLAVE			0
#define SPI_PBCLOCK_DIV2	2
#define SPI_PBCLOCK_DIV4	4
#define SPI_PBCLOCK_DIV8	8
#define SPI_PBCLOCK_DIV16	16
#define SPI_PBCLOCK_DIV32	32
#define SPI_PBCLOCK_DIV64	64

void SPI_mode(uchar mode);
void SPI_clock(unsigned int speed);
void SPI_close();

void SPI_init();
void SPIxInterrupt(void);
unsigned char SPI_read(void);
unsigned char SPI_write(unsigned char data_out);


#endif	/* __SPI__ */
