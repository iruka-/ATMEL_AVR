/*	----------------------------------------------------------------------------
	FILE:			spi.c
	PROJECT:		pinguino
	PURPOSE:		Serial Peripheral Interface functions
	PROGRAMER:		Régis Blanchot <rblanchot@gmail.com>
					Marcus Fazzi <anunakin@gmail.com>
					Jean-Pierre Mandon <jp.mandon@gmail.com>
	FIRST RELEASE:	16 Mar 2011
	LAST RELEASE:	28 May 2012
	----------------------------------------------------------------------------
	CHANGELOG : 
	24 May 2011 - jp.mandon - fixed a bug in SPI_write, RX int flag must be called even for write
	20 Feb 2012 - r.blanchot - added PIC32_PINGUINO_220 support
	28 May 2012 - MFH - 	added PIC32_PINGUINO_MICRO support and fixed a bug
								in SPI_clock() identified by dk (KiloOne)
 	----------------------------------------------------------------------------
	TODO : 
	----------------------------------------------------------------------------
	This library is free software; you can redistribute it and/or
	modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation; either
	version 2.1 of the License, or (at your option) any later version.

	This library is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
	Lesser General Public License for more details.

	You should have received a copy of the GNU Lesser General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
	--------------------------------------------------------------------------*/
/**
 *	Microchip making changes do SPI SFR numbers and changing 2A to 3, and 3A to 4
 * but it need a new processor.o and updated compiler libraries, not released at this time.
 *  
 *  MX440 and MX460 have only 2 SPI ports
 */

#include <p32xxxx.h>			// always in first place to avoid conflict with const.h ON
//#include "utype.h"
#include "interrupt.h"

#include "spi1.h"
#include "../HardwareProfile.h"

void SetDigital(int pin);


void SPI_mode(uchar mode)
{
	// 7. Clear the SPIROV bit (SPIxSTAT<6>).
	STATUS = 0;					// clear the Overflow

	// 8. Write the desired settings to the SPIxCON register with MSTEN (SPIxCON<5>) = 1.
	// 9. Enable SPI operation by setting the ON bit (SPIxCON<15>).
	if (mode == SPI_MASTER) {
		SPICONF=0x8120;		// or 0x8220 SPI ON, 8 bits transfer, SMP=1, Master mode
	}
	if (mode == SPI_SLAVE) {
		SPICONF=0x8000;		// SPI ON, 8 bits transfer, Slave mode
	}
}

// Fsck = Fpb / (2 * (SPIxBRG + 1)
// SPIxBRG = (Fpb / (2 * Fsck)) - 1 
// speed must be in bauds
void SPI_clock(unsigned int speed)
{
	unsigned int Fpb;
	unsigned short clk;

	Fpb = GetPeripheralClock();
	if (speed > (Fpb / 2))
	{
		CLKSPD = 0;			// use the maximum baud rate possible
		return;
	}
	else
	{
		clk = (Fpb / (2 * speed)) - 1;
		if (clk > 511)
			CLKSPD = 511;	// use the minimum baud rate possible
		else					// ** fix for bug identified by dk=KiloOne
			CLKSPD = clk;	// use calculated divider-baud rate
	}
}

void SPI_close() //(u8 num)
{
	unsigned char rData;
	// Disable all SPIx interrupts
	IntDisable(INTFAULT); 
	IntDisable(INTTXDONE); 
	IntDisable(INTRXDONE);
	// Stops and resets the SPIx
	SPICONF=0;
	// clears the receive buffer
	rData=BUFFER;
}

/*	-----------------------------------------------------------------------------
	The following code assumes that none of the SPIx input pins are shared with
	an analog input. If so, the AD1PCFG and corresponding TRIS registers have to 
	be properly configured.

	Perform the following steps to set up the SPI module for the Master mode operation:
	1.  Disable the SPI interrupts in the respective IEC0/1 register.
	2.  Stop and reset the SPI module by clearing the ON bit.
	3.  Clear the receive buffer.
	4.  Clear the ENHBUF bit (SPIxCON<16>) if using Standard Buffer mode or set the bit if using
		 Enhanced Buffer mode.
	5. If SPI interrupts are not going to be used, skip this step and continue to step 5. Otherwise
		 the following additional steps are performed:
		 a) Clear the SPIx interrupt flags/events in the respective IFS0/1 register.
		 b) Set the SPIx interrupt enable bits in the respective IEC0/1 register.
		 c) Write the SPIx interrupt priority and subpriority bits in the respective IPC5/7 register.
	6. Write the Baud Rate register, SPIxBRG.
	7. Clear the SPIROV bit (SPIxSTAT<6>).
	8. Write the desired settings to the SPIxCON register with MSTEN (SPIxCON<5>) = 1.
	9. Enable SPI operation by setting the ON bit (SPIxCON<15>).
	10. Write the data to be transmitted to the SPIxBUF register. Transmission (and reception) will
		 start as soon as data is written to the SPIxBUF register.
	---------------------------------------------------------------------------*/

void SPI_init()
{
	unsigned char rData;
#if	0
	// 1.  Disable the SPI interrupts in the respective IEC0/1 register.
	IntDisable(INTFAULT); 
	IntDisable(INTTXDONE); 
	IntDisable(INTRXDONE);
#endif
	// 2.  Stop and reset the SPI module by clearing the ON bit.
	SPICONCLR = 0x8000; // bit 15

	// 3.  Clear the receive buffer.
	rData = BUFFER;

	// 4.  Clear the ENHBUF bit (SPIxCON<16>) if using Standard Buffer mode.
	// This bit can only be written when the ON bit = 0
	// SPIENHBUF = 0; // not available on all devices

	// 5. If SPI interrupts are not going to be used, skip this step and
	// continue to step 6. Otherwise the following additional steps are performed:
	//	 a) Clear the SPIx interrupt flags/events in the respective IFS0/1 register.
/*
	IntClearFlag(INTFAULT);
	IntClearFlag(INTTXDONE);
	IntClearFlag(INTRXDONE);
	//	 b) Set the SPIx interrupt enable bits in the respective IEC0/1 register.
	IntEnable(INTFAULT); 
	IntEnable(INTTXDONE); 
	IntEnable(INTRXDONE);
	//	 c) Write the SPIx interrupt priority and subpriority bits in the respective IPC5/7 register.
	IntSetVectorPriority(INTVECTOR, 3, 1);
*/
	// 6. Write the Baud Rate register, SPIxBRG.
	SPI_clock(250000); // 250 kbps (low data rate) or could be also 625000
	SPI_mode(SPI_MASTER);

	// SDO PIN SELECT
	SetDigital(16+1);
	RPB1R=0x03;		// PB1=SDO1
	TRISBCLR=1<<1;	// PB1 output.

}

// 10. Write the data to be transmitted to the SPIxBUF register.
// Transmission (and reception) will start as soon as data is written to the SPIxBUF register.
unsigned char SPI_write(unsigned char data_out)
{
	BUFFER = data_out;	// write to buffer for TX
	while (!STATRX);		// wait for the receive flag (transfer complete)
	return BUFFER;
}

unsigned char SPI_read(void)
{
	// return SPI_write(0);
	BUFFER = 0x00;			// dummy byte to capture the response
	while (!STATRX);		// wait until cycle complete
	return BUFFER;			// return with byte read
}

/*	----------------------------------------------------------------------------
	SPIInterrupt
	TODO: move this to interrupt library and add it to main32.c ?
	--------------------------------------------------------------------------*/

void SPIxInterrupt(void)
{
	unsigned char rData;

	// Is this an RX interrupt ?
	if (IntGetFlag(INTRXDONE))
	{
		rData = BUFFER;			// Read SPI data buffer
		IntClearFlag(INTRXDONE);
	}
	// Is this an TX interrupt ?
	if (IntGetFlag(INTTXDONE))
	{
		IntClearFlag(INTTXDONE);
	}
}

