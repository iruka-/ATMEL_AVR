
This is libusb-win32 (http://libusb-win32.sourceforge.net) version 0.1.12.2.
Libusb-win32 is a library that allows userspace application to access USB
devices on Windows operation systems (Win98SE, WinME, Win2k, WinXP).
It is derived from and fully API compatible to libusb available at
http://libusb.sourceforge.net.

For more information visit the project's web site at:

http://libusb-win32.sourceforge.net
http://sourceforge.net/projects/libusb-win32


Package Information
~~~~~~~~~~~~~~~~~~~
ALL ARCHITECTURES:
  x86\libusb0_x86.dll: x86 32-bit library. Must be renamed to libusb0.dll
    On 64 bit, Installs to Windows\syswow64\libusb0.dll.
    On 32 bit, Installs to Windows\system32\libusb0.dll.

X86 ONLY ARCHITECTURES:
  x86\libusb0.sys: x86 32-bit driver.
    Installs to Windows\system32\drivers\libusb0.sys

AMD64-INTEL64 ONLY ARCHITECTURES:
  amd64\libusb0.sys: x64 64-bit driver.
    Installs to Windows\system32\drivers\libusb0.sys

  amd64\libusb0.dll: x64 64-bit library.
    Installs to Windows\system32\libusb0.dll

IA64 ONLY ARCHITECTURES:
  ia64\libusb0.sys: IA64 64-bit driver.
    Installs to Windows\system32\drivers\libusb0.sys

  ia64\libusb0.dll: IA64 64-bit library.
    Installs to Windows\system32\libusb0.dll
