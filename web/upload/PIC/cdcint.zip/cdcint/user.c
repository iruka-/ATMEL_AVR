
unsigned int counter=0;

//
//	Timer1 Interrupt service proc.
//
void __attribute__ ((interrupt,noinline)) Tmr1Interrupt(void)
{
	if (IFS0bits.T1IF) {	
		TMR1=0;				
		IFS0CLR=0x10;		
		counter++;			
	}
}

//=Timer1 Interrupt Entry Point:
//	9d003280 <ISR_wrapper_vector_4>:
//	bfc00280 <ISR_wrapper_vector_4>:
//
//	Jump to Tmr1Interrupt()
//
void __attribute__ ((section (".vector_4"))) ISR_wrapper_vector_4(void) 
{
	Tmr1Interrupt();
}

//
//	Initialize Timer:
//
void init_timer1(void)
{
	IntConfigureSystem(INT_SYSTEM_CONFIG_MULT_VECTOR);	
#ifdef	USE_SELFBOOT
	_CP0_SET_EBASE(0xBFC00000); 	// ���荞�݃x�N�^�[�����Z�b�g���̂��̂ɖ߂�.
#else
	_CP0_SET_EBASE(_RESET_ADDR); 	// ���荞�݃x�N�^�[��9D00_2000 �ɕύX����.
#endif

	T1CON=0;		
	TMR1=0;			
	PR1=0x9999;		
	IPC1SET=0x7;		
	IFS0CLR=0x10;		
	IEC0SET=0x10;		
	T1CONSET=0x8010;	
}

//
//	Sketch
//


void setup()
{
	pinmode(13, OUTPUT);
	init_timer1();
}

void loop()
{
  	static int cnt=0;
  	cnt++;
  	if(cnt >= 5000) {
  		CDCprintf("%d\n\r",counter);	
    	toggle(13);
    	cnt=0;
  	}
	Delayus(125);
}



