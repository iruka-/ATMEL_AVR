
#define	CDCPRINTF	// rev-999�ł͕K�v?  See pinguino/core/__cdc.c





#include <__cdc.c>
#include <delay.c>
#include <interrupt.c>
#include <typedef.h>
#include <digitalw.c>
