/******************** (C) COPYRIGHT 2010 STMicroelectronics ********************
* File Name          : main.c
* Author             : MCD Application Team
* Version            : V3.1.1
* Date               : 04/07/2010
* Description        : Virtual Com Port Demo main file
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "usb_lib.h"
#include "usb_desc.h"
#include "hw_config.h"
#include "usb_pwr.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Extern variables ----------------------------------------------------------*/
extern __IO uint32_t count_out;
extern uint8_t buffer_out[VIRTUAL_COM_PORT_DATA_SIZE];

void led_blink3(int x);
void led_blink4(int x);

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

static void led_blink()
{
	static int cnt=0;
	cnt++;
	if((cnt & 0xffff)==0) {
    	GPIOC->ODR ^= 0x40;    // LED�̏o�͂𔽓]������B
	}
}
static void inf_blink()
{
    GPIOC->CRL = 0x43444444;   // PC6���o�͂ɂ���B�@�@
	while(1) {
		led_blink();
	}
}
/*******************************************************************************
* Function Name  : main.
* Description    : Main routine.
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
int main1(void)
{
  Set_System();

  Set_USBClock();

  USB_Interrupts_Config();

//  led_blink4(20);

  USB_Init();

//  led_blink3(0);

  GPIOC->CRL = 0x43444444;   // PC6���o�͂ɂ���B�@�@
  while (1) {
    if ((count_out != 0) && (bDeviceState == CONFIGURED)){
      USB_To_USART_Send_Data(&buffer_out[0], count_out);
      count_out = 0;
    }
	led_blink();
  }
}

#ifdef USE_FULL_ASSERT
/*******************************************************************************
* Function Name  : assert_failed
* Description    : Reports the name of the source file and the source line number
*                  where the assert_param error has occurred.
* Input          : - file: pointer to the source file name
*                  - line: assert_param error line source number
* Output         : None
* Return         : None
*******************************************************************************/
void assert_failed(uint8_t* file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {}
}
#endif


//-----------------------------------------------------------
// DesignWave 2008�N5����
//�@�@STM32�]���{�[�hLED�_�Ńv���O����
//-----------------------------------------------------------
//#include <ST\iostm32f10x.h>


volatile int xx;

void timer(unsigned long)  ;
void timer(unsigned long i) // �^�C�}�[
{
  xx=i;
  while(xx--) ;
}  

int main(void)
{
	unsigned long t;
	int i;
//  Set_System();

//  RCC_APB2ENR |= 0x10;     // CPIOC���g�p�ł���悤�ɂ���B
  RCC->APB2ENR |= 0x10;     // CPIOC���g�p�ł���悤�ɂ���B

//  GPIOC_CRL = 0x43444444;   // PC6���o�͂ɂ���B�@�@
  GPIOC->CRL = 0x43444444;   // PC6���o�͂ɂ���B�@�@

  for(i=0; i < 4 ; i++) {
      for(t=0; t < 0x1000; t++) {
        timer(100);
      }
      
//      GPIOC_ODR ^= 0x40;    // LED�̏o�͂𔽓]������B
      GPIOC->ODR ^= 0x40;    // LED�̏o�͂𔽓]������B
  }
#if	1
  main1();
#else
  main2();
#endif
}

/******************* (C) COPYRIGHT 2010 STMicroelectronics *****END OF FILE****/
