/*----------------------------------------------------------------------------
 *      Name:    vcomdemo.c
 *      Purpose: USB virtual COM port Demo
 *      Version: V1.02
 *----------------------------------------------------------------------------
 *      This software is supplied "AS IS" without any warranties, express,
 *      implied or statutory, including but not limited to the implied
 *      warranties of fitness for purpose, satisfactory quality and
 *      noninfringement. Keil extends you a royalty-free right to reproduce
 *      and distribute executable files created using this software for use
 *      on NXP Semiconductors LPC microcontroller devices only. Nothing else
 *      gives you the right to use this software.
 *
 * Copyright (c) 2009 Keil - An ARM Company. All rights reserved.
 *---------------------------------------------------------------------------*/

#include "LPC13xx.h"
#include "type.h"

#include "usb.h"
#include "usbcfg.h"
#include "usbhw.h"
#include "usbcore.h"
#include "cdc.h"
#include "cdcuser.h"
#include "serial.h"
#include "vcomdemo.h"

#include "gpio.h"

#define     EN_TIMER32_1    (1<<10)
#define     EN_IOCON        (1<<16)
#define     EN_USBREG       (1<<14)


#define LED_PORT 0		// Port for led
#define LED_BIT 7		// Bit on port for led

/* Define the output pins controlled by the USB HID client */
#define OUTPUT0_PORT	LED_PORT
#define OUTPUT0_BIT		LED_BIT

#define	led_on()	led_set(1)
#define	led_off()	led_set(0)

int	USB_GetConfiguration(void);

void led_set(int f)
{
	GPIOSetValue(OUTPUT0_PORT, OUTPUT0_BIT, f);
}

static int led_count=0;

#define	LED_POWMAX 1024
static int led_pow=0;	//���邳(0..1023)
static int led_cnt=0;

/********************************************************************
 *	LED �̋P�x��ݒ�
 ********************************************************************
 */
void led_power(int p)
{
	led_pow=p;
}
void led_freerun()
{
	led_count++;

	if(	led_count>=768) {
		led_count=256;
		return;
	}
	if(	led_count>=512) {
		led_power(512+256-led_count);
		return;
	}
	if(	led_count>=256) {
		led_power(led_count-256);
		return;
	}
}
/********************************************************************
 *	LED �� �\�t�gPWM�œ_�� (���邳=led_pow)
 ********************************************************************
 */
void led_task(void)
{
	led_cnt++;
	if(	led_cnt >= LED_POWMAX) {
		led_cnt = 0;

		led_freerun();

		if(led_pow) led_on();
	}
	if(	led_cnt == led_pow) {
		led_off();
	}
}
/********************************************************************
 *	LED �̓_��/�����𔽓]
 ********************************************************************
 */
void led_flip(void)
{
	if(led_pow) {
		led_pow=0;
	}else{
		led_pow=LED_POWMAX;
	}
	led_count = 0;
}

/*----------------------------------------------------------------------------
 Initializes the VCOM port.
 Call this function before using VCOM_putchar or VCOM_getchar
 *---------------------------------------------------------------------------*/
void VCOM_Init(void)
{

	CDC_Init ();
}


/*----------------------------------------------------------------------------
  Reads character from serial port buffer and writes to USB buffer
 *---------------------------------------------------------------------------*/
void VCOM_Serial2Usb(void)
{
	static char serBuf [USB_CDC_BUFSIZE];
	int  numBytesRead, numAvailByte;

	ser_AvailChar (&numAvailByte);
	if (numAvailByte > 0) {
		if (CDC_DepInEmpty) {
			numBytesRead = ser_Read (&serBuf[0], &numAvailByte);

			CDC_DepInEmpty = 0;
			USB_WriteEP (CDC_DEP_IN, (unsigned char *)&serBuf[0], numBytesRead);

		}
	}

}

/*----------------------------------------------------------------------------
  Reads character from USB buffer and writes to serial port buffer
 *---------------------------------------------------------------------------*/
void VCOM_Usb2Serial(void)
{
	static char serBuf [32];
	int  numBytesToRead, numBytesRead, numAvailByte;

	CDC_OutBufAvailChar (&numAvailByte);
	if (numAvailByte > 0) {
		numBytesToRead = numAvailByte > 32 ? 32 : numAvailByte;
		numBytesRead = CDC_RdOutBuf (&serBuf[0], &numBytesToRead);
		ser_Write (&serBuf[0], &numBytesRead);

		led_flip();
	}
}


/*----------------------------------------------------------------------------
  checks the serial state and initiates notification
 *---------------------------------------------------------------------------*/
void VCOM_CheckSerialState (void)
{
	unsigned short temp;
	static unsigned short serialState;

	temp = CDC_GetSerialState();
	if (serialState != temp) {
		serialState = temp;
		CDC_NotificationIn();                  // send SERIAL_STATE notification
	}
}

/*----------------------------------------------------------------------------
  Main Program
 *---------------------------------------------------------------------------*/
int main (void)
{
	/* Basic chip initialization is taken care of in SystemInit() called
	 * from the startup code. SystemInit() and chip settings are defined
	 * in the CMSIS system_<part family>.c file.
	 */
//#if	APPLICATION_MODE
	SCB->VTOR = _ROMADRS;	// Vector Table Offset Reg.
//#endif

	/* Enable Timer32_1, IOCON, and USB blocks */
	LPC_SYSCON->SYSAHBCLKCTRL |= (EN_TIMER32_1 | EN_IOCON | EN_USBREG);

	/* Initialize output port pins */
	GPIOSetDir( OUTPUT0_PORT, OUTPUT0_BIT, 1 );
	led_off();

	USBIOClkConfig();

	VCOM_Init();                              // VCOM Initialization

	USB_Init();                               // USB Initialization
	USB_Connect(TRUE);                        // USB Connect

//	�Ȃ񂩍œK������Ă��܂��H�H�H
//	while (!USB_Configuration) ;              // wait until USB is configured

	while( !USB_GetConfiguration() );

	while (1) {                               // Loop forever

		VCOM_Serial2Usb();                      // read serial port and initiate USB event
		VCOM_CheckSerialState();
		VCOM_Usb2Serial();

		led_task();

	} // end while
} // end main ()

