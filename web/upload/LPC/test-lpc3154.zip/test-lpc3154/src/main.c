/***************************************************************
 *
 ***************************************************************
 */
#include "lpc_types.h"
#include "lpc_irq_fiq.h"
#include "lpc_arm922t_cp15_driver.h"
#include "lpc313x_ioconf_driver.h"

/********************************************************************
 *	
 ********************************************************************
 */
void wait_us(int us);
/********************************************************************
 *	
 ********************************************************************
 */
void wait_ms(int ms)
{
	int i;
	for(i=0;i<ms;i++) {
		wait_us(1000*8);
	}
}

/********************************************************************
 *	
 ********************************************************************
 */
void wait_us(int us)
{
	int i;
	for(i=0;i<us;i++) {
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
	}
}


/********************************************************************
 *	
 ********************************************************************
 */
void LED_flip(void)
{
	static int state = 0;
	state ^= 1;

	/* Toggle mode0 LED */
	if (state)  gpio_set_outpin_high(IOCONF_GPIO, 2);
	else  	    gpio_set_outpin_low(IOCONF_GPIO, 2);
}

/********************************************************************
 *	
 ********************************************************************
 */
int main(void)
{
	/* Disable interrupts in ARM core */
	disable_irq_fiq();

	/* Setup miscellaneous board functions */
	//ea3131_board_init();

	/* Set virtual address of MMU table */
	cp15_set_vmmu_addr((void *)ISROM_MMU_TTB_BASE);

	/* Initialize interrupt system */
	int_initialize(0xFFFFFFFF);

	while(1) {
		wait_ms(1000);
		LED_flip();
	}

	return 0;
}


int c_entry()
{
	main();
}
