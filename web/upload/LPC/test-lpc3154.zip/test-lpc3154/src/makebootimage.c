#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#define LPC313X_IMAGE_LENGTH_OFFSET 0x20


int main(int argc, char *argv[])
{
	FILE *fin = NULL;
	FILE *fout = NULL;
	unsigned int copy_length = 0;
	unsigned char image_header[64];
	unsigned int ret = 0, i = 0;
	unsigned char *data = NULL;

	if(argc != 3)
	{
		printf("usage: ./mkbootimg inputfile outfile\n");
		goto error;
	}


	memset(image_header, 0x0, 64);

	fin = fopen(argv[1], "rb");
	if(fin == NULL)
	{
		printf("not able to open file in read binary mode\n");
		goto error;
	}
	
	fout = fopen(argv[2], "wb");
	if(fout == NULL)
	{
		printf("not able to open file in write binary mode\n");
		goto error_1;
	}

	ret = fread(image_header, 1, 64, fin);
	copy_length = *((unsigned int*)((unsigned int)image_header + LPC313X_IMAGE_LENGTH_OFFSET));
	printf("copy_len: %x\n",copy_length);

	rewind(fin);
	data = (unsigned char*)malloc(copy_length);
	if(data == NULL)
	{
		printf("could not allocate memory\n");
		goto error_2;
	}
	memset(data, 0x0, copy_length);

	ret = fread(data, 1, copy_length, fin);
	if(ret < copy_length)
	{
		printf("warning: could not read all data (0x%x < 0x%x)\n",ret,copy_length);
//		goto error_3;
//		free(data);
	}
	
	ret = fwrite(data, 1, copy_length, fout);
	if(ret < copy_length)
	{
		printf("could not write all data\n");
		goto error_3;
	}
			
error_3:
	free(data);		
error_2:
	fclose(fout);		
error_1:
	fclose(fin);		
error:		
	return 0;
}
