
int FIQ_Routine(void)					{return 0;}
int UNDEF_Routine(void)					{return 0;}
int __bss_end__(void)					{return 0;}
int __bss_start__(void)					{return 0;}
int _bss_end(void)						{return 0;}
int _bss_start(void)					{return 0;}
int _data(void)							{return 0;}
int _edata(void)						{return 0;}
int _etext(void)						{return 0;}
int _stack_end(void)					{return 0;}

int int_initialize(void)				{return 0;}
int ea3131_init(void)					{return 0;}

#if	0
int cp15_set_vmmu_addr(void)			{return 0;}
int ea3131_board_init(void)				{return 0;}
int int_enable(void)					{return 0;}
int int_install_irq_handler(void)		{return 0;}
int timer_ioctl(void)					{return 0;}
int timer_open(void)					{return 0;}
int uart_open(void)						{return 0;}
int uart_write(void)					{return 0;}
#endif

