/*
 sz adrs tp data                           sm
:22 0080 00 000102030405060708090a0b0c0d0e ee
:00000001FF
 */
#define GETLN 1
#include <std.h>

char buf[1024];
char hexbuf[1024];
char *lp;

unsigned int adrsf=0;
unsigned int size;
unsigned int adrs;
unsigned int type;
unsigned int topadrs;
unsigned int oldadrs;

static char dxhdr[16]="ARAMDATA";
int		bmode=0;
unsigned int	badrs=0;

Usage(
	"*****	Intel HEX to DX,ISX converter Ver 1.1 *****\n"
	"hex2dx infile.hex outfile.dx\n"
	"	-b	binary\n"
	"	-s<start>\n"
	" or\n"
	"hex2dx infile.hex outfile.dx symfile.isx\n"
)

Main
	if(argc<3) usage();
	if(IsOpt('b')) bmode=1;
	if(IsOpt('s')) sscanf(Opt('s'),"%x",&badrs);

	Ropen(argv[1]);
	Wopen(argv[2]);
		if(bmode)bin_to_dx();
		else	hex_to_dx();
	Wclose();

	if(argc>=4) {
		Wopen(argv[3]);
			sym_to_isx();
		Wclose();
	}

	Rclose();
End

fatal(s)
char *s;
{
	printf("fatal:%s\n",s);
	exit(1);
}

bin_to_dx()
{
	int i,c;

	dxhdr[8]=badrs;
	dxhdr[9]=badrs>>8;
//	Write(dxhdr,16);
	
	i=0;
	while(1) {
		c=getc(ifp);if(c == EOF) break;
		putc(c,ofp);i++;
	}
	
	i += badrs;i--;
	
	
	dxhdr[12]=i;
	dxhdr[13]=i>>8;
	fseek(ofp,0L,0);
//	Write(dxhdr,16);
	
}


hex_to_dx()
{
	int i;
	while(1) {
		if(getln(buf,ifp)==EOF) break;
		if(buf[0]!=':') {
			fatal("err :");
		}
		lp=buf+1;
		size = get2hex();
		adrs = get4hex();
		type = get2hex();
		for(i=0;i<size;i++) hexbuf[i]=get2hex();

		/*printf("adrs,size,type=%x,%x,%x\n",adrs,size,type);*/

		if(type!=0) break;

		output(hexbuf,adrs,size);
	}
	
	oldadrs--;
	dxhdr[12]=oldadrs;
	dxhdr[13]=oldadrs>>8;
	fseek(ofp,0L,0);
//	Write(dxhdr,16);
	
}


/***************************************************************
 *	�D�������̃V���{����ǂݍ���.
 *
 *	[ 0x04 ]	 	. . .	�敪�R�[�h
 *	[  Nsymbols    ]	. . .	�V���{���̑���
 *	{
 *		[ Nlength ] [ �V���{���l�[�� ]
 *		[ flag    ]
 *		[ bank    ]
 *		[   offset         ]
 *	} x Nsymbols
 */

typedef struct {
		 char	id;	/* +00 */
	unsigned char	bank;	/* +01 */
	unsigned int	offset;	/* +02 */
		 int	length;	/* +04 */

		char	sid;
		int	nsym;
} ISX_HDR;

ISX_HDR isx_hdr={1,0,0,0,4,0};

sym_to_isx()
{
	int i,val;

	isx_hdr.nsym=0;
	Write(&isx_hdr,sizeof(isx_hdr));

	while(1) {
		if(getln(buf,ifp)==EOF) break;
		/* ; 0123 sybol */
		if(buf[0]==';') {
			sscanf(buf+2,"%x",&val);
			outisx(buf+7,val);
			isx_hdr.nsym++;
		}
	}

	fseek(ofp,0L,0);
	Write(&isx_hdr,sizeof(isx_hdr));
}

outisx(sym,val)
char *sym;
{
	int len;
	len=strlen(sym);
	putc(len,ofp);
	fprintf(ofp,"%s",sym);
	putc(0,ofp);	// flag
	putc(0,ofp);	// bank
	putc(val,ofp);	// offset l
	val >>=8;
	putc(val,ofp);	// offset h
}



output(s,a,l)
char *s;
{
	if(adrsf==0) {
		dxhdr[8]=a;
		dxhdr[9]=a>>8;
		//Write(dxhdr,16);
		adrsf=1;
		oldadrs=adrs;
		topadrs=adrs;
	}
	
	if(oldadrs>adrs) {
		fatal("address back!");
	}
	
	while(oldadrs!=adrs) {
		putc(0,ofp);oldadrs++;
	}
	
	while(l) {
		putc(*s,ofp);oldadrs++;
		s++;l--;
	}
}



get1hex()
{
	int c;
	c=*lp++;
	if(c< '0')  return(-1);
	if(c<='9') return(c-'0');
	if(c< 'A') return(-1);
	if(c<='F') return(c-'A'+10);
	if(c< 'a') return(-1);
	if(c<='f') return(c-'a'+10);
	return(-1);
}

get2hex()
{
	int c,c2;
	c=get1hex();
	if(c==(-1)) return(-1);
	c2=get1hex();
	if(c2==(-1)) return(-1);
	return(c*16+c2);
}

get4hex()
{
	int c,c2;
	c=get2hex();
	c2=get2hex();
	return(c*256+c2);
}

