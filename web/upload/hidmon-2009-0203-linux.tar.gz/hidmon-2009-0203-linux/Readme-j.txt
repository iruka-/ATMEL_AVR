                                                             2008年11月25日
                                                                  千秋広幸

[1] hidmonの紹介

　iruka さんが作成されている hidmon

　hidmon コマンドは、HIDaspx を USB-IO として操作するツールです。AVR マイコ
ン用の学習教材としても利用可能です。hidmon の機能の一部を抽出した DLL を利
用することにより、外部 I/O としても活用できます。詳細は、DLL のフォルダをご
覧ください。

最新の版は、以下の URL から入手してください。

http://hp.vector.co.jp/authors/VA000177/html/A3C8A3C9A3C4A3E1A3F3A3F0B9E2C2AEB2BD.html


[2] hidmonの構成

.\
├─bin      ........... hidmon.exe (0割り算の対策済み)
├─dll      ........... hidmon.dllのソースファイル(MinGWでコンパイル可能)
├─firmware ........... AVRマイコンのライタ機能を省いたファームウェアソース
│  └─usbdrv
├─scripts  ........... 各種の自動実行用スクリプト(ぜひ中身をご覧ください)
├─src      ........... hidmonのソースファイル(MinGWでコンパイル可能)
├─test     ........... hidmon.dllの使用例（C言語とBASICの2種類）
└─develop  ........... build-all.batを追加（開発者向け）

 　iruka さんが以前から取組まれている AVR_Monit の HID 版です。ドライバのイ
 ンストールは必要なく、以下のように簡単に動作を確認できます。

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃  >hidmon -?                                                    ┃
┃  * HID_Monit Ver 0.1 (Nov  5 2008)                             ┃
┃  Usage is                                                      ┃
┃    monit [Options]                                             ┃
┃  Options                                                       ┃
┃    -p[:XXXX]   ...  select Serial number (default=0000).       ┃
┃    -l<logfile> ...  save log file.                             ┃
┃    -i<file>    ...  input script file to execute.              ┃
┃    -v          ...  print verbose.                             ┃
┃                                                                ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃>hidmon                                                         ┃
┃HIDaspx is Programmer mode.                                     ┃
┃AVR> help                                                       ┃
┃* HID_Monit Ver 0.1                                             ┃
┃Command List                                                    ┃
┃ d  <ADDRESS1> <ADDRESS2>    Dump Memory(RAM)                   ┃
┃ e  <ADDRESS1> <DATA>        Edit Memory                        ┃
┃ f  <ADDRESS1> <ADDRESS2> <DATA> Fill Memory                    ┃
┃ p ?                         Print PortName-List                ┃
┃ p .                         Print All Port (column format)     ┃
┃ p *                         Print All Port (dump format)       ┃
┃ p <PortName>                Print PortAddress and data         ┃
┃ p <PortName> <DATA>         Write Data to PortName             ┃
┃ p <PortName>.<bit> <DATA>   Write Data to PortName.bit         ┃
┃ sleep <n>                   sleep <n> mSec                     ┃
┃ bench <CNT>                 HID Write Speed Test               ┃
┃ poll <portName> <CNT>       continuous polling port            ┃
┃ poll  *  <CNT>              continuous polling port A,B,D      ┃
┃ graph <portName>            Graphic display                    ┃
┃ q                           Quit to DOS                        ┃
┃AVR> p ?                                                        ┃
┃   DIDR = 0x21   GPIOR0 = 0x33    GTCCR = 0x43   TCNT1H = 0x4d  ┃
┃  UBRRH = 0x22   GPIOR1 = 0x34     ICR1 = 0x44   TCCR1B = 0x4e  ┃
┃  UCSRC = 0x23   GPIOR2 = 0x35    ICR1L = 0x44   TCCR1A = 0x4f  ┃
┃   ACSR = 0x28     PINB = 0x36    ICR1H = 0x45   TCCR0A = 0x50  ┃
┃  UBRRL = 0x29     DDRB = 0x37    CLKPR = 0x46   OSCCAL = 0x51  ┃
┃  UCSRB = 0x2a    PORTB = 0x38    OCR1B = 0x48    TCNT0 = 0x52  ┃
┃  UCSRA = 0x2b     PINA = 0x39   OCR1BL = 0x48   TCCR0B = 0x53  ┃
┃    UDR = 0x2c     DDRA = 0x3a   OCR1BH = 0x49    MCUSR = 0x54  ┃
┃    RXB = 0x2c    PORTA = 0x3b     OCR1 = 0x4a    MCUCR = 0x55  ┃
┃    TXB = 0x2c     EECR = 0x3c    OCR1L = 0x4a    OCR0A = 0x56  ┃
┃  USICR = 0x2d     EEDR = 0x3d    OCR1H = 0x4b   SPMCSR = 0x57  ┃
┃  USISR = 0x2e     EEAR = 0x3e    OCR1A = 0x4a     TIFR = 0x58  ┃
┃  USIDR = 0x2f    EEARL = 0x3e   OCR1AL = 0x4a    TIMSK = 0x59  ┃
┃   PIND = 0x30    PCMSK = 0x40   OCR1AH = 0x4b     EIFR = 0x5a  ┃
┃   DDRD = 0x31   WDTCSR = 0x41    TCNT1 = 0x4c    GIMSK = 0x5b  ┃
┃  PORTD = 0x32   TCCR1C = 0x42   TCNT1L = 0x4c    OCR0B = 0x5c  ┃
┃AVR>                                                            ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

    help を参考にコマンドを入力してみてください。p .と入力すると 2 進表記で
    レジスタの内容を確認できます。ATtiny2313 が内蔵する多数のレジスタを対話
    的に操作できるので、AVR マイコンの理解を深めることができます。なお、当
    然ですが、USB 通信用のポートなどの操作してはいけません。

    コマンド入力が面倒に思えますが、←→のキーで編集ができ、↑↓のキーにて
    過去に入力したコマンドを呼び出せるので便利に操作できます。

    AVR> p .
      DIDR = 0000_0000  PORTD = 0000_0000 WDTCSR = 0000_0000 TCCR1A = 0000_0000
     UBRRH = 0000_0000 GPIOR0 = 0000_0000 TCCR1C = 0000_0000 TCCR0A = 0000_0000
     UCSRC = 0000_0110 GPIOR1 = 0000_0000  GTCCR = 0000_0000 OSCCAL = 0110_0100
      ACSR = 0011_0000 GPIOR2 = 0000_0000  ICR1L = 0000_0000  TCNT0 = 0000_0000
     UBRRL = 0000_0000   PINB = 1011_1000  ICR1H = 0000_0000 TCCR0B = 0000_0000
     UCSRB = 0000_0000   DDRB = 1111_1111  CLKPR = 0000_0000  MCUSR = 0000_0001
     UCSRA = 0010_0000  PORTB = 1111_1000 OCR1BL = 0000_0000  MCUCR = 0000_1100
       UDR = 0000_0000   PINA = 0000_0000 OCR1BH = 0000_0000  OCR0A = 0000_0000
       RXB = 0000_0000   DDRA = 0000_0000  OCR1L = 0000_0000 SPMCSR = 0000_0000
       TXB = 0000_0000  PORTA = 0000_0000  OCR1H = 0000_0000   TIFR = 0000_0000
     USICR = 0001_1010   EECR = 0000_0000 OCR1AL = 0000_0000  TIMSK = 0000_0000
     USISR = 1100_0000   EEDR = 0000_0000 OCR1AH = 0000_0000   EIFR = 0000_0000
     USIDR = 1111_1111   EEAR = 0111_1111 TCNT1L = 0000_0000  GIMSK = 1000_0000
      PIND = 0001_0100  EEARL = 0111_1111 TCNT1H = 0000_0000  OCR0B = 0000_0000
      DDRD = 0110_0111  PCMSK = 0000_0000 TCCR1B = 0000_0000

    また、スクリプトで一括実行もできます。付属のスクリプトは、hidmon の具体
    的な操作例です。HIDaspx の PORTB に、スイッチや LED、リレーなどを付けて
    おけば、それだけで制御実験が可能です。
    コマンドプロンプトから hidmon コマンドを起動する時に

      hidmon -i script.txt

    を指定して実行すると、このscript.txtに書かれた内容を順に実行します。

        1	#   サンプルスクリプトファイル(script.txtの内容).
        2	# 使い方:
        3	#   monit -i script.txt
        4	#
        5	dp 0 7ff
        6	dr 0 7f
        7	d 0 df
        8
        9	p ddrb ff
       10
       11	p portb 0
       12	sleep 100
       13	p portb ff
       14	sleep 100
    :
       82	q

    script.txt には繰り返しの制御構造や条件判断はできませんが、hidmon.dll
    を利用すれば、C 言語や Visual BASIC などの一般的な言語から HIDaspx を操
    作できます。また hidmon を利用することで プログラムを書くことなく、
    ATtiy2313 を操作可能です。これによって、HIDaspx が、USB I/O の一種であ
    ることを理解していただけると思います。

----- * ----- * ----- * ----- * ----- * ----- * ----- * ----- * ----- * -----
[3] サンプルスクリプトの走らせ方

 例)
  hidmon -i ../scripts/script1
 のようにして実行してください。


 script1 :  PORTB(PB2) を1秒単位でON/OFFする。
	LED（POWER）、あるいはテスターで動作を確認できます。

 script2 :  PB2(pin14) に TIMER0 のクロックを出力する。
	PB2 の先にオーディオアンプとかヘッドフォンを適当な抵抗経由で繋いで
	ください。5V スイングするので、入力オーバーには注意してください。

 script3 :  PD5(pin9) に TIMER0 のPWM波形を出力する。（回路が変更されたため使用禁止）
	PWMの比較出力はPD5になります。これもオーディオ帯域の波形です。

 script4 :  PB2(pin14) に TIMER0 のクロック1MHzを出力する。
	 -.-. --.- CW発生:傍にラジオを持ってくると聞こえるかもしれません。

 script5 :  PB7-0 を全入力にして内容をコンソールに表示。
	poll コマンドの実行例です。サンプル数 10000 なので、10〜 40秒間 (UHCI
	の場合)、コンソールに 2 進表示されます。

 script6 :  PB2(pin14) に TIMER0 のクロックを出力する。
	TIMER0を最大周期で実行して、その出力をpollで見る例です。

 script7 :	グラフィック表示(ESCキーで終了)。
	PORTB を全入力にして、ポートの状態をリアルタイムにグラフ表示します。

 script8 :	PB2(pin14) に TIMER0 のクロックを出力する。
	TIMER0を最大周期で実行して、その出力をgraphで見る例です。

上記スクリプトは適当に思いつきで作られたものですが、自由な発想で各種ポート
を使用してみてください。

また、ポートの読み書きだけでは処理できないようなもの (例えば A/D 変換など)
は、ファームウェアにコマンドを追加して実装してみてください。


----- * ----- * ----- * ----- * ----- * ----- * ----- * ----- * ----- * -----

[4] おまけ

    * senshu 2008-09-29 (月) 17:53:54 New!
      HIDaspxの環境の評価も可能です。

      ■ OHCIのベンチマークテスト
      AVR> bench 100
      hid write start
      hid write end 6200 406 s  15270 byte/s
      AVR> exit
      Bye.

      ■ UHCIのベンチマークテスト
      AVR> bench 100
      hid write start
      hid write end 6200 1391 s  4457 byte/s

      ということで、OHCI は UCHI よりも 3 倍以上も転送速度が速いことがわかります。
      USB I/F の違いで HIDaspx の性能の違いが生じるのも理解できます。
      hidmon を hidspx の補助コマンドとして、ペアで配るのも有効に思えてきました。

[5] hidmonの変更履歴

2008-10-28 hidmon-1028.zip
- firmwareをhidspx-1028.zipに同梱するものと同一にしました。
- hidmonコマンドは、USB-IO(HIDaspx)に対し、指示が無い限り何の操作も
  行わないように変更を行いました。

2008-11-04 hidmon-1104.zip
- PORTDに関する操作にて、USBボートに関する操作を保護する（irukaさんの手になる修正）
- hidmonコマンドは、HIDaspxのモードを識別するように修正しました。
- develop/build-all.bat の実行で、一括して最新の実行ファイルを得ることが出来ます。

2008-11-05 hidmon-1105.zip
- シリアル情報指定にて、-p:0001 を -p1 と指定可能にした。
- 説明書の内容を修正した。

2008-11-05 hidmon-1107.zip
- 簡易セットアップツール(setup.bat)を追加

2008-11-11 hidmon-1111.zip
- セットアップツール(setup.bat)の標準インストール先を「c:\bin」に変更

2008-11-21 hidmon-1121.zip
- 内蔵RC発振モードを追加（USB-IO機能のみをサポート）
- hidmonのbench表示のBUGを修正

2008-11-25 hidmon-1125.zip
- 内蔵RC発振モードを改良（USB-IO機能のみをサポート）

- usbconfig から osctune マクロを削除し、 avrusb-20081022 にある osctune.h
  を include に変更。(osctune.h は OSCCAL への 0x20 の加算を削除)

- 1 サイクル前のタイマーの値を覚えておく必要があるので、main.c 内に 
  lastTimer0Value 変数を追加。


