------------------------------------------------------
   ファイルの説明    2009-0203
------------------------------------------------------

このアーカーブは iruka さんが移植した「hidmon-1125.zip の Linux 移植版」を
元に、senshu が改造を施したものです。

出来る限りWindows 版からの修正を最小限にするため、ソースを共通にしています。

============   Ｃ言語ソース  ==============
src/
  Makefile       : Windows/Linux共通 Makefile
  dos.mak        : Windows 判定処理 
  monit.c        : hidmonのメイン処理 Windows/Linux共通 
  portlist.c     : Windows/Linux共通 
  util.c         : Windows/Linux共通 
  hidasp.c       : Linux専用 libusbアクセス.
  gr-dmy.c       : Linux専用 gr.c のダミーおよび関数の代替など.

============   Ｃ言語ヘッダー  ==============
  gr.h
  avrspx.h
  hidasp.h
  hidcmd.h
  monit.h
  portlist.h
  usbhid.h
  util.h

============   Windows版のみで使用するファイル  ==============
  gr.c
  hidasp-dos.c
  avrspx-dos.h
  icon.rc


------------------------------------------------------
   ビルド方法の説明
------------------------------------------------------
・Windows/Linuxともに、gccを用います。
・Windowsでは MinGW-gcc (www.mingw.org) を用います。
  どうしてもCygwinのgccが良いとおっしゃる場合は、コマンドラインに 
  -mno-cygwinオプションを入れてください。

・ビルドは make もしくは gmake で行います。



------------------------------------------------------
   実行方法の説明
------------------------------------------------------
・ATtiny2313用の HIDaspxファームを焼いたAVRをUSB経由でLinux機に接続します。

・srcディレクトリにて make を実行し、./hidmon を実行してください。
  OSへのインストールは sudo make install です。

・hidmonコマンドの使用方法については、Windows版の説明書を参照願います。

------------------------------------------------------
  一般利用者権限でhidspx,hidmonを使う方法
------------------------------------------------------

■ Vine Linux 4.2の場合
      root 権限で、/etc/udev/rules.d/95-my-permissions.rules に以下の内容を
      書き込みます。

SUBSYSTEM=="usb_device",SYSFS{idVendor}=="16c0",SYSFS{idProduct}=="05dc",MODE="0666"
SUBSYSTEM=="usb_device",SYSFS{idVendor}=="16c0",SYSFS{idProduct}=="05df",MODE="0666"

      その後、HIDaspxデバイスを差し込んでAVRの読み出しに成功しました。

■ Ubuntu 8.10の場合

      Ubuntu 8.10で動作させるには、好みのエディタ（たとえば gedit）で

      sudo gedit /etc/udev/rules.d/95-my-permissions.rules

      以下の内容を書き込みます。（参考までに AVR マイコン関連の udev 情報を
      書いておきます。利用したいものがあれば、追加してください）

# ADD by senshu

# USBasp(OLD)
SUBSYSTEM=="usb",SYSFS{idVendor}=="03eb",SYSFS{idProduct}=="c7b4",MODE="0666"
# USBasp(NEW), HIDaspx (libusb mode)
SUBSYSTEM=="usb",SYSFS{idVendor}=="16c0",SYSFS{idProduct}=="05dc",MODE="0666"

# HIDaspx (HID mode)
SUBSYSTEM=="usb",SYSFS{idVendor}=="16c0",SYSFS{idProduct}=="05df",MODE="0666"

###
#AVRISP mkII
SUBSYSTEM=="usb",SYSFS{idVendor}=="03eb",SYSFS{idProduct}=="2104",MODE="0666"
# AVR Dragon
SUBSYSTEM=="usb",SYSFS{idVendor}=="03eb",SYSFS{idProduct}=="2107",MODE="0666"

      この設定後、

      sudo /etc/init.d/udev restart

      でデバイスを再認識させます（rule ファイルを修正時のみ必要）。利用者権
      限で hidspx, hidmon コマンドが正常に動作することを確認しました。

------------------------------------------------------
   制限事項と使い方
------------------------------------------------------
・コンパイル警告を抑える修正を実施しました。
・リトルエンディアンのLinuxでしか動作を確認していませんので、ビッグエンディアン機
　では動作しないかもしれません。
・グラフィック表示は出来ません。
・Poll命令による高速なポート読み取りモードはサポートしていません。
・kbhit()関数の実装し、キー入力によるポート読み取りループの中断を可能にしました。
・ATmega88ファームウェアには非対応です。
・usbtoolを同梱しました。
・hidmon -p? が未実装です。
  代わりに、usbtoolをmakeし、これを使ってください。

$ ./hidmon -p? ... 以下のように表示される（未サポートのため）
hidasp_list not support. Use 'usbtool list'.

$ usbtool list ... usbtoolにて、以下の表示が可能
VID=0x16c0 PID=0x05df vendor="YCIT" product="HIDaspx" serial="0000"
VID=0x0409 PID=0x0059 vendor="" product=""
：

VID, PID, シリアル番号が確認できます。

・「-pXXXX」でシリアル番号指定を有効にしました。


