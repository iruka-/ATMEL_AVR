/*********************************************************************
 *	�t�r�a�f�o�C�X�̎g�p�J�n�A�I���A�A�N�Z�X���̃��[�e�B���e�B.
 *********************************************************************
 *
 *�`�o�h:
int		UsbInit(int verbose,int enable_bulk);	������.
int		UsbExit(void);	�I��.
void 	UsbBench(int cnt,int psize);
void	UsbDump(int adr,int arena,int size);
void 	UsbPoke(int adr,int arena,int data0,int data1);
int 	UsbPeek(int adr,int arena);
int 	UsbRead(int adr,int arena,uchar *buf,int size);
 *
 *�����֐�:
usb_dev_handle	*open_dev(void);
void	transfer_bench_bulk(usb_dev_handle *dev,int cnt,int psize);
void	dumpmem(usb_dev_handle *dev,int adr,int cnt);
void	pokemem(usb_dev_handle *dev,int adr,int data0,int data1);
void	memdump(void *ptr,int len,int off);
 */

#include <stdio.h>
#include <time.h>
#include <usb.h>

#include "monit.h"

void dump_info(  struct usb_device *dev );

//	obdev
#define MY_VID 0x16c0
#define MY_PID 0x05dc

#define	MY_Manufacturer	"A"
//#define	MY_Product		"M"


/* the device's endpoints */
#define EP_IN  				0x81
#define EP_OUT 				0x01
#define PACKET_SIZE 		8
#define	VERBOSE				0
#define	REPORT_MATCH_DEVICE	1
#define	REPORT_ALL_DEVICES	0

#define	USE_BULK_TRANSFER	1		//1:�o���N�]���g�p���f�t�H���g�ɂ���.



#define	if_V	if(VERBOSE)

static  usb_dev_handle *usb_dev = NULL; /* the device handle */
static	int	use_bulk = USE_BULK_TRANSFER;
static	char verbose_mode = 0;

/****************************************************************************
 *	�������[���e���_���v.
 ****************************************************************************
 */
void memdump(void *ptr,int len,int off)
{
	unsigned char *p = (unsigned char *)ptr;
	int i,j,c;

	for(i=0;i<len;i++) {
		if( (i & 15) == 0 ) printf("%06x",(int)p - (int)ptr + off);
		printf(" %02x",*p);p++;
		if( (i & 15) == 15 ) 
		{
#if	1	// ASCII DUMP
			printf("  ");
			for(j=0;j<16;j++) {
				c=p[j-16];
				if(c<' ') c='.';
				if(c>=0x7f) c='.';
				printf("%c",c);
			}
#endif
			printf("\n");
		}
	}
	printf("\n");
}




/*********************************************************************
 *	�ꎞ�o�b�t�@�ɉ��f�[�^��u��. �����l���O������add
 *********************************************************************
 */
void set_temp(char *tmp,int cnt,int add)
{
	int i;
	int c=0;
	for(i=0;i<cnt;i++,tmp++) {
		*tmp = c;
		c+= add;
	}
}

/*********************************************************************
 *
 *********************************************************************
 */
void transfer_bench_bulk(usb_dev_handle *dev,int cnt,int psize)
{
    char tmp[1024];
	int nBytes  = 0;
	int nLength = psize;
	int i;
	int total=0;
	
	if(	  (psize != 8)
		&&(psize !=16)
		&&(psize !=32)
		&&(psize !=64)
		&&(psize !=128) ) {
		printf("illegal packet size (not 2^n or  >128)\n");
		return;
	}

	set_temp(tmp,1024,0);
   	printf("bulk write start\n");

	int time0 = clock();
	for(i=0;i<cnt;i++) {

	  if((nBytes = usb_bulk_write(dev, EP_OUT, tmp, nLength, 5000) )
	     != nLength)
    	{
    	  printf("error: bulk write failed\n");
    	}
   		 else{
			total += nBytes;
if_V      printf("bulk write nBytes = %d.\n",nBytes);
		}
	}
   	
	int time1 = clock() - time0;
	int rate = 0;
	if(time1) {
		rate = total * 1000 / time1;
	}
   	printf("bulk write end total bytes=%d time=%d mS speed=%d byte/s\n",total,time1,rate);
}

/*********************************************************************
 *
 *********************************************************************
 */
int QueryAVRbulk(usb_dev_handle *dev,RxBuf *cmd,uchar *buf)
{
	int nBytes  = 0;
	int nLength = 8;

	if((nBytes = usb_bulk_write(dev, EP_OUT, (void*)cmd, nLength, 5000) )
	     != nLength)
    	{
    	  	printf("error: bulk write failed\n");
			return 0;
    	}
	if( (cmd->cmd & CMD_MASK) == CMD_PEEK ) {
	  if((nBytes = usb_bulk_read(dev, EP_IN, buf , nLength, 5000) )
	     != nLength)
    	{
    	  	printf("error: bulk read failed\n");
			return 0;
    	}
	}
    return 8;
}
/*********************************************************************
 *
 *********************************************************************
 */
int QueryAVRctrl(usb_dev_handle *dev,RxBuf *cmd,uchar *buf)
{
	int nBytes  = 0;
	int nLength = 8;
	int	wValue  = cmd->adr;
	int wIndex  = cmd->data0 | (cmd->data1 << 8);

	nBytes = usb_control_msg(dev,cmd->bmRequestType,cmd->cmd, 
							wValue,wIndex,
							buf, nLength, 5000);
	if(nBytes != nLength)
    	{
    	  	printf("error: control write failed %d\n",nBytes);
			return 0;
    	}

    return 8;
}
/*********************************************************************
 *
 *********************************************************************
 */
int QueryAVR(usb_dev_handle *dev,RxBuf *cmd,uchar *buf)
{
	if(use_bulk) return QueryAVRbulk(dev,cmd,buf);
	else		 return QueryAVRctrl(dev,cmd,buf);
}
/*********************************************************************
 *
 *********************************************************************
 */
int dumpmem(usb_dev_handle *dev,int adr,int arena,int size,unsigned char *buf)
{
	RxBuf cmd;
	
	memset(&cmd,0,sizeof(RxBuf));
	cmd.bmRequestType = USB_TYPE_VENDOR | USB_RECIP_DEVICE |USB_ENDPOINT_IN;
	cmd.cmd   = CMD_PEEK | arena;
	cmd.adr   = adr;
	cmd.data0 = size;

	if( QueryAVR(dev,&cmd,buf) == 0) return 0;	//���s.
	return size;
}
/*********************************************************************
 *
 *********************************************************************
 */
void pokemem(usb_dev_handle *dev,int adr,int arena,int data0,int data1)
{
    RxBuf cmd;
	char buf[16];	// dummy

	memset(&cmd,0,sizeof(RxBuf));

	cmd.bmRequestType = USB_TYPE_VENDOR | USB_RECIP_DEVICE |USB_ENDPOINT_IN;
	cmd.cmd   = CMD_POKE | arena;
	cmd.adr   = adr;
	cmd.data0 = data0;
	cmd.data1 = data1;

	QueryAVR(dev,&cmd,buf);
}

/*********************************************************************
 *
 *********************************************************************
 */
void transfer_bench_intr(usb_dev_handle *dev,int cnt)
{
    char tmp[1024];
	int nBytes  = 0;
	int nLength = PACKET_SIZE;
	int i;
	int total=0;
	
	set_temp(tmp,1024,1);
   	printf("intr write start\n");

	int time0 = clock();
	for(i=0;i<cnt;i++) {

	  if((nBytes = usb_interrupt_write(dev, EP_OUT, tmp, nLength, 5000) )
	     != nLength)
    	{
    	  printf("error: intr write failed\n");
    	}
   		 else{
			total += nBytes;
if_V      printf("intr write nBytes = %d.\n",nBytes);
		}
	}

	int time1 = clock() - time0;
	int rate = total * 1000 / time1;

   	printf("intr write end %d %d s  %d byte/s\n",total,time1,rate);
}

/*********************************************************************
 *
 *********************************************************************
 */
void transfer_bench_ctrl(usb_dev_handle *dev,int cnt,int psize)
{
    char tmp[1024];
	int nBytes  = 0;
	int nLength = psize;
	int i;
	int total=0;
	
	set_temp(tmp,1024,0);
   	printf("ctrl write start\n");

	int time0 = clock();
	for(i=0;i<cnt;i++) {

        nBytes = usb_control_msg(dev, USB_TYPE_VENDOR | USB_RECIP_DEVICE 
//											|USB_ENDPOINT_IN, PSCMD_ECHO, 
											, 0, 
							0 , 0, tmp, nLength, 5000);
	  if(nBytes != nLength)
    	{
    	  printf("error: ctrl write failed %d\n",nBytes);
    	}
   		 else{
			total += nBytes;
if_V      printf("ctrl write nBytes = %d.\n",nBytes);
		}
	}
	int time1 = clock() - time0;
	int rate = total * 1000 / time1;

   	printf("ctrl write end %d %d s  %d byte/s\n",total,time1,rate);
}

static int  usbGetStringAscii(usb_dev_handle *dev, int index, int langid, char *buf, int buflen)
{
char    buffer[256];
int     rval, i;

    if((rval = usb_control_msg(dev, USB_ENDPOINT_IN, USB_REQ_GET_DESCRIPTOR, (USB_DT_STRING << 8) + index, langid, buffer, sizeof(buffer), 1000)) < 0)
        return rval;
    if(buffer[1] != USB_DT_STRING)
        return 0;
    if((unsigned char)buffer[0] < rval)
        rval = (unsigned char)buffer[0];
    rval /= 2;
    /* lossy conversion to ISO Latin1 */
    for(i=1;i<rval;i++){
        if(i > buflen)  /* destination buffer overflow */
            break;
        buf[i-1] = buffer[2 * i];
        if(buffer[2 * i + 1] != 0)  /* outside of ISO Latin1 range */
            buf[i-1] = '?';
    }
    buf[i-1] = 0;
    return i-1;
}

int	open_dev_check_string(struct usb_device *dev,usb_dev_handle *handle)
{
	int len1,len2;
	char string1[256];
	char string2[256];

	len1 = usbGetStringAscii(handle, dev->descriptor.iManufacturer, 
							0x0409, string1, sizeof(string1));
    len2 = usbGetStringAscii(handle, dev->descriptor.iProduct, 
							0x0409, string2, sizeof(string2));
	if((len1<0)||(len2<0)) return 0;

#if	0
	printf("iManufacturer:%s\n",string1);
	printf("iProduct:%s\n",string2);
#endif

#ifdef	MY_Manufacturer
	if(strcmp(string1, MY_Manufacturer) != 0) return 0;
#endif

#ifdef	MY_Product
	if(strcmp(string2, MY_Product) != 0)      return 0;
#endif

	return 1;	//���v����.
}


usb_dev_handle *open_dev(void)
{
	struct usb_bus *bus;
	struct usb_device *dev;
	usb_dev_handle *handle;

  	for(bus = usb_get_busses(); bus; bus = bus->next) {
      	for(dev = bus->devices; dev; dev = dev->next) {

#if	REPORT_ALL_DEVICES
			dump_info(dev);
#endif

			//
			//	VendorID,ProductID �̈�v�`�F�b�N.
			//
          if(dev->descriptor.idVendor  == MY_VID &&
             dev->descriptor.idProduct == MY_PID) {
#if	REPORT_MATCH_DEVICE
			  	if(verbose_mode) {
			  		dump_info(dev);
			  	}
#endif
				handle = usb_open(dev);
				if( open_dev_check_string(dev,handle) == 1) {
					return handle;	//��v.
				}
                usb_close(handle);
                handle = NULL;
            }
        }
    }
	return NULL;
}


/*********************************************************************
 *
 *********************************************************************
 */
void UsbBench(int cnt,int psize)
{
	if(use_bulk) {		//1:�o���N�]�����g�p����.
		transfer_bench_bulk(usb_dev,cnt,psize);
	}else{
		transfer_bench_ctrl(usb_dev,cnt,psize);
	}
}
/*********************************************************************
 *
 *********************************************************************
 */
void UsbDump(int adr,int arena,int cnt)
{
	unsigned char buf[16];
	int size;
	int rc;
	while(cnt) {
		size = cnt;
		if(size>=8) size = 8;
		rc = dumpmem(usb_dev,adr,arena,size,buf);
		if(rc !=size) return;
		memdump(buf,size,adr);
		adr += size;
		cnt -= size;
	}
}
/*********************************************************************
 *
 *********************************************************************
 */
int UsbRead(int adr,int arena,uchar *buf,int size)
{
	int rc = size;
	int len;
	while(size) {
		len = size;
		if(len >= 8) len = 8;
		int rc = dumpmem(usb_dev,adr,arena,len,buf);
		if( rc!= len) {
			return -1;
		}
		adr  += len;	// �^�[�Q�b�g�A�h���X��i�߂�.
		buf  += len;	// �ǂݍ��ݐ�o�b�t�@��i�߂�.
		size -= len; 	// �c��T�C�Y�����炷.
	}
	return rc;
}
/*********************************************************************
 *
 *********************************************************************
 */
int UsbPeek(int adr,int arena)
{
	unsigned char buf[16];
	int size=1;
	int rc = UsbRead(adr,arena,buf,size);
	if( rc != size) {
		return -1;
	}
	return buf[0];
}
/*********************************************************************
 *
 *********************************************************************
 */
void UsbPoke(int adr,int arena,int data0,int data1)
{
	pokemem(usb_dev,adr,arena,data0,data1);
}
/*********************************************************************
 *
 *********************************************************************
 */
int UsbInit(int verbose,int enable_bulk)
{
  use_bulk = enable_bulk;
  verbose_mode = verbose;

  usb_init(); /* initialize the library */
  usb_find_busses(); /* find all busses */
  usb_find_devices(); /* find all connected devices */


  if(!(usb_dev = open_dev()))
    {
      printf("error: device not found!\n");
      return 0;
    }

 if(use_bulk) {		//1:�o���N�]�����g�p����.

	//�o���N�p�G���h�|�C���g�� set_configuration���Ȃ���
	//�g���Ȃ��悤��.

  if(usb_set_configuration(usb_dev, 1 ) < 0)
    {
      printf("error: setting config 1 failed\n");
      usb_close(usb_dev);
      return 0;
    }
  if(usb_claim_interface(usb_dev, 0) < 0)
    {
      printf("error: claiming interface 0 failed\n");
      usb_close(usb_dev);
      return 0;
    }


 }

	return 1;	// OK.
}



/*********************************************************************
 *
 *********************************************************************
 */
int UsbExit(void)
{
	if(	usb_dev ) {
		usb_release_interface(usb_dev, 0);
		usb_close(usb_dev);
	}
	return 0;
}
/*********************************************************************
 *
 *********************************************************************
 */

