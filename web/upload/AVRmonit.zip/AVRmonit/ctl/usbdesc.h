/******************************************************************
 *				�t�r�a�o���N�]���T���v���v���O����.
 ******************************************************************
 *	�t�r�a�f�o�C�X�L�q�q	deviceDesc[18]
 *	�t�r�a�ݒ�L�q�q		configDesc[18+7+7]
 *		����щ����֐�	usbFunctionDescriptor(*rq);
 *	
 */

static PROGMEM uchar deviceDesc[] = {    /* USB device descriptor */
    18,         /* sizeof(usbDescriptorDevice): length of descriptor in bytes */
    USBDESCR_DEVICE,        /* descriptor type */
    0x10, 0x01,             /* USB version supported */
    0xff,                   /* device class: CDC = 2  */
    0,                      /* subclass */
    0,                      /* protocol */
    8,                      /* max packet size */
    USB_CFG_VENDOR_ID,      /* 2 bytes */
    USB_CFG_DEVICE_ID,      /* 2 bytes: shared PID for CDC-ACM devices = 0xe1,0x05 */
    USB_CFG_DEVICE_VERSION, /* 2 bytes */
    1,                      /* manufacturer string index */
    2,                      /* product string index */
    0,                      /* serial number string index */
    1,                      /* number of configurations */
};

static PROGMEM uchar configDesc[] = {   /* USB configuration descriptor */
    9,          /* sizeof(usbDescrConfig): length of descriptor in bytes */
    USBDESCR_CONFIG,    /* descriptor type */
    18,
    0,          /* total length of data returned (including inlined descriptors) */
    1,          /* number of interfaces in this configuration */
    1,          /* index of this configuration */
    0,          /* configuration name string index */
#if USB_CFG_IS_SELF_POWERED
    USBATTR_SELFPOWER,  /* attributes */
#else
    USBATTR_BUSPOWER,   /* attributes */
#endif
    USB_CFG_MAX_BUS_POWER/2,            /* max USB current in 2mA units */

    /* Interface Descriptor  */
    9,           /* sizeof(usbDescrInterface): length of descriptor in bytes */
    USBDESCR_INTERFACE,           /* descriptor type */
    0,           /* index of this interface */
    0,           /* alternate setting for this interface */
    0,           /* endpoints excl 0: number of endpoint descriptors to follow */
    0x0A,        /* Data Interface Class Codes */
    0,
    0,           /* Data Interface Class Protocol Codes */
    0,           /* string index for interface */
};

uchar usbFunctionDescriptor(usbRequest_t *rq)
{
    if(rq->wValue.bytes[1] == USBDESCR_DEVICE){
        usbMsgPtr = (uchar*)deviceDesc;	return sizeof(deviceDesc);
    }else{
        usbMsgPtr = (uchar*)configDesc;	return sizeof(configDesc);
    }
}

