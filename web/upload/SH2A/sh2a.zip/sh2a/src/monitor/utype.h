#ifndef	_utype_h_
#define	_utype_h_

#include <sys/types.h>
#if	0	// sys/types.h�Ƃ��Ԃ�.
typedef unsigned short  ushort;         // 16-bit
typedef unsigned int    uint;           // 32-bit
#endif

typedef unsigned char   uchar;          // 8-bit
typedef unsigned char   byte;           // 8-bit
typedef unsigned short  word;           // 16-bit
typedef unsigned int    dword;          // 32-bit




#endif

