#include <stdio.h>
#include <string.h>
#include <machine.h>
#include "iodefine.h"       /* SH7264 iodefine  */
#include "m3a_hs64.h"
#include "usb_firm.h"
