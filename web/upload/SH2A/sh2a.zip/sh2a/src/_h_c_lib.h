
extern void _CALL_INIT(void); /* for global class object initial processing */
extern void _CALL_END(void);  /* for global class object post-processing */
extern void _INITSCT(void);   /* Clear BSS, and copy DATA from ROM to RAM */

