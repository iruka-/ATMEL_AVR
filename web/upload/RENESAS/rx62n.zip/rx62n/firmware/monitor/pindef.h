#ifndef	_pindef_h_
#define	_pindef_h_

#ifdef	RX62N
//	�|�[�g�o�̓f�[�^.   		  	  JTAG  PIC   AVR
//----------------------------------------------------------
#define	TRST		PA_2		// TRST
#define	TDI 		PA_4		// TDI  PGM =(AVR-MOSI)
#define	TMS			PA_6		// TMS  MCLR=(AVR-RST)
#define	TCK 		PB_0		// TCK  PGC =(AVR-SCK)
//-                  
#define	TDO 		PB_4		// TDO  PGD =(AVR-MISO)
#define	SRST		PB_6		// SRST
//----------------------------------------------------------
#endif	//RX62N



//	PIC PGx�s����JTAG�s���̑Ή��\.
#define	PGM	 		TDI			// TDI  PGM =(AVR-MOSI)
#define	PGC	    	TCK			// TCK  PGC =(AVR-SCK)
#define	PGD	    	TDO			// TDO  PGD =(AVR-MISO)
#define	MCLR    	TMS			// TMS  MCLR=(AVR-RST)

#endif	// ifndef	_pindef_h_
