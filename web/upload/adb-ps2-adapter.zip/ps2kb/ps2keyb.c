/**********************************************************************
 *	PS2 Keyboard Library
 **********************************************************************
 *
 */
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>

#include "ps2keyb.h"

/**********************************************************************
 *	
 **********************************************************************
 */


//	PortD
#define  PS2_PORT PORTD      	// 
#define  PS2_PIN  PIND      	// 
#define  PS2_DDR  DDRD       	// 

#define  ADB_DAT   (1<<3)		// PD3: ADB
#define  PS2_DAT   (1<<4)       // PD4: PS2 DATA
#define  PS2_CLK   (1<<5)       // PD5: PS2 CLK

//	PortB
#define  LED_PORT  PORTB      	// 
#define  MASK_LED  (1<<0)		// PB0: LED

void ps2_sendbyte(uchar dat);
int  ps2_recvbyte(void);
void ps2_recvcmd(void);
//void timer_wait(unsigned int cnt);


#ifndef F_CPU
#define   F_CPU   8000000    //CPU�N���b�N���g�� 8MHz
#endif

#define  PRESCALE   1        //�v���X�P�[���l
#define  PRESCALECR 1        //�v���X�P�[���ݒ�l

#define  SIO_TIFR    TIFR   //�^�C�}1�t���O
#define  SIO_MAXCNT  0x10000 //�^�C�}�ő�l

#define TCNT_1MS    (SIO_MAXCNT-((F_CPU/PRESCALE)/1000))
#define TCNT_50US   (SIO_MAXCNT-((F_CPU/PRESCALE)/(1000000/50)))
#define TCNT_10US   (SIO_MAXCNT-((F_CPU/PRESCALE)/(1000000/10)))
#define TCNT_5US    (SIO_MAXCNT-((F_CPU/PRESCALE)/(1000000/5)))

static	uchar	reset_done=0;

//-----------------------------------------------------------------------
// �E�G�C�g
static void timer_wait(unsigned int cnt)
{
    TCNT1 = cnt;
    SIO_TIFR |= (1 << TOV1);  // TIFR�̃r�b�g���N���A
    while(!(SIO_TIFR & (1 << TOV1)));
}

//----------------------------------
void wait_msec(int i)
{
	while(i--)
	{
		timer_wait(TCNT_1MS);
	}
}

void ps2_sendclk(void)
{
    timer_wait(TCNT_10US);	PS2_DDR |=  PS2_CLK;	
    timer_wait(TCNT_50US);	PS2_DDR &= ~PS2_CLK;	
    timer_wait(TCNT_10US);
}

void ps2_init(void)
{
	PORTD |=  ADB_DAT;	//ADB Pullup
	DDRD  &= ~ADB_DAT;	//ADB input

	PORTB = 0xff;		//Pullup

	LED_PORT |= MASK_LED;

	PS2_PORT &= ~(PS2_DAT|PS2_CLK);
	PS2_DDR  &= ~(PS2_DAT|PS2_CLK);

    TCCR1A= 0;                // �^�C�}1 ���[�h 
    TCCR1B= PRESCALECR;       // �^�C�}1 �v���X�P�[���ݒ�
	LED_PORT &= ~MASK_LED;

	wait_msec(500);	//��500msec
}

char ps2_recvbit(void)
{
	ps2_sendclk();
	return(PS2_PIN & (PS2_DAT));
}

void ps2_sendbyte(uchar dat)
{
	char parity;
	int i,wdat;

	if((PS2_PIN & (PS2_CLK))==0) {
		return;
	}
	while((PS2_PIN & (PS2_DAT))==0) {
		ps2_recvcmd();
	}

	wdat = (int)dat << 1;

	parity=0;
	for(i=0; i<8; i++){
		if((1<<i) & dat){
			parity++;	
		}
	}
	if((parity & 1)==0){
		//�r�b�g1�̐�������
		wdat |= (1<<9);	//�r�b�g9(�p���e�B)=1
	}
	wdat |= (1<<10);	//�r�b�g10(�X�g�b�v�r�b�g)=1

	for(i=0; i<11; i++){	//���ʂ���11�r�b�g���M
		if((1 << i) & wdat){
			PS2_DDR &= ~(PS2_DAT);	//1(High�C���s�[�_���X)
		}else{
			PS2_DDR |= (PS2_DAT);	//0
		}
		ps2_sendclk();	//send 1bit clock
		if((PS2_PIN & (PS2_CLK))==0)
			break;	//CLK��L�̏ꍇ�A����
	}
	PS2_DDR &= ~(PS2_DAT);
	wait_msec(2);
}

// PS2�R�l�N�^ 1bytes��M
int	ps2_recvbyte(void)
{
	uchar mask=0x01;
	uchar data=0x0;

	if((PS2_PIN & (PS2_CLK))==0)
		return -1;		//CLK=Low�̏ꍇ�A����

	if((PS2_PIN & (PS2_DAT))!=0)
		return -1;		//DAT��High�̏ꍇ�A����(�f�[�^�Ȃ�)

	ps2_recvbit();	//startbit

	while(mask != 0) {
		if(ps2_recvbit()) {
			data |= mask;
		}
		mask <<= 1;
	}
	ps2_recvbit();	//parity
	if(ps2_recvbit()){
		PS2_DDR |=  (PS2_DAT);ps2_sendclk();
		PS2_DDR &= ~(PS2_DAT);
	}else{
		return -1;		// Stop Bit Error
	}
	return data;
}

void	ps2_recvcmd(void)
{
	uchar data;
	int c;
	c = ps2_recvbyte();
	if(c<0) return;
	wait_msec(2);	//2msec
					// *�@��ɂ���ă^�C�~���O���Ⴄ�\������
	data=c;
	//��M�f�[�^��ǂƕԐM
	switch(data) {
	  case 0xff:				//Reset�R�}���h
		ps2_sendbyte(0xFA);		//Ack����
		wait_msec(600);			//600msec
		ps2_sendbyte(0xAA);		//BAT����
		reset_done=1;
		break;
	  case 0xf2:				//ID�ǂݏo���R�}���h
		ps2_sendbyte(0xFA);		//Ack����
		ps2_sendbyte(0xab);		//�L�[�{�[�hID
		ps2_sendbyte(0x83);		//�L�[�{�[�hID
		break;
	  case 0xed:				//ID�ǂݏo���R�}���h
		ps2_recvbyte();
		ps2_sendbyte(0xFA);		//Ack����
		break;
	  case 0xf3:				//set typematic rate
		ps2_recvbyte();
		ps2_sendbyte(0xFA);		//Ack����
		break;
	  case 0xee:				//�G�R�[�R�}���h
		ps2_sendbyte(0xEE);		//����
		break;
	  default:
		ps2_sendbyte(0xFA);		//Ack����
		break;
	}

#if	1
	{
		static	char swnum;
		swnum++;
		if(swnum==0) {
			if(reset_done==0) {
				ps2_sendbyte(0xfa);		/*code(�J�[�\���L�[)*/
			}
		}
	}
#endif

}

#define FLAG_MAKECODE 0
#define FLAG_BREAKCODE 1

void ps2_sendcode(char swnum,char flag)
{
	if(swnum & 0x80){
		ps2_sendbyte(0xE0);		/*code(�J�[�\���L�[)*/
		swnum &= 0x7f;
	}

	if(flag == FLAG_BREAKCODE) {
		ps2_sendbyte(0xF0);		/*break code*/
	}
	ps2_sendbyte(swnum);		/*code*/

#if	0
//	if(mode != MODE_PS2)return;
	// PS/2 mode

	PGM_P p = (PGM_P)ps2table;

	if(swnum >= SWNUM_CURSOR)
		ps2_sendbyte(0xE0);		/*code(�J�[�\���L�[)*/

	if(flag == FLAG_BREAKCODE)
		ps2_sendbyte(0xF0);		/*break code*/

	ps2_sendbyte(pgm_read_byte(p+swnum));		/*code*/
#endif
}

//
//	f=0	LED ON
//	f=1	LED OFF
//
void led(int f)
{
	if(f) {
		LED_PORT |=  MASK_LED;
	}else{
		LED_PORT &= ~MASK_LED;
	}
}

//	f=0	Break
//	f=1	Make
void keypress(char swnum,char f)
{
	if(f==0) {
		ps2_sendcode(swnum,FLAG_BREAKCODE);	// Break Code
	}else{
		ps2_sendcode(swnum,FLAG_MAKECODE);		// Make code
	}
}



