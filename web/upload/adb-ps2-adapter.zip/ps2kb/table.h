/*
, //========================================================
, //		ADB�̃L�[�{�[�h�̌ŗL�l(0�`127)��
, //		IBM	PC/AT�̃L�[�R�[�h�ɕϊ�����e�[�u��.
, //========================================================
*/

#define	E0		0x80	// E0 +	nn �ƂȂ�L�[ (MSB�����ʂɎg�p)
/*
						// ���� 0x83	�Ƃ����L�[�l�����݂��邪�A
						// ����͗�O�I�� E0	��O�u���Ȃ�.
						// E0 ��O�u���邩�ǂ����̔��f�́A�L�[�l
						// �� 0x90�ȏォ�ǂ����ł����Ȃ�.
						//(0x80�`0x8f�͈̔͂�E0��O�u����L�[��
						// �V�݂��ꂽ�ꍇ��A
						// 0x90�`0xff�͈̔͂�E0��O�u���Ȃ��L�[��
						// �V�݂��ꂽ�ꍇ�͂��̕\�͔j�]����)
						
*/
#define	kFF		0x00	 // ����` invalid

PROGMEM	unsigned char adb2at[]=
{
//		PC/AT			ADB		[key]
		0x1c	, //	00		A
		0x1b	, //	01		S
		0x23	, //	02		D
		0x2b	, //	03		F
		0x33	, //	04		H
		0x34	, //	05		G
		0x1a	, //	06		Z
		0x22	, //	07		X
		0x21	, //	08		C
		0x2a	, //	09		V
		kFF		, //	0a		
		0x32	, //	0b		B
		0x15	, //	0c		Q
		0x1d	, //	0d		W
		0x24	, //	0e		E
		0x2d	, //	0f		R

		0x35	, //	10		Y
		0x2c	, //	11		T
		0x16	, //	12		1
		0x1e	, //	13		2
		0x26	, //	14		3
		0x25	, //	15		4
		0x36	, //	16		6
		0x2e	, //	17		5
		0x55	, //	18		=
		0x46	, //	19		9
		0x3d	, //	1a		7
		0x4e	, //	1b		-
		0x3e	, //	1c		8
		0x45	, //	1d		0
		0x5b	, //	1e		]
		0x44	, //	1f		O

		0x3c	, //	20		U
		0x54	, //	21		[
		0x43	, //	22		I
		0x4d	, //	23		P
		0x5a	, //	24		RET
		0x4b	, //	25		L
		0x3b	, //	26		J
		0x52	, //	27		'
		0x42	, //	28		K
		0x4c	, //	29		, //
		0x5d	, //	2a		��
		0x41	, //	2b		,
		0x4a	, //	2c		/
		0x31	, //	2d		N
		0x3a	, //	2e		M
		0x49	, //	2f		.

		0x0d	, //	30		TAB
		0x29	, //	31		SPACE
		0x0e	, //	32		~
		0x66	, //	33		BS
		kFF		, //	34		
		0x76	, //	35		ESC
		0x14	, //	36		CTRL
		0x11	, //	37		COMMAND(ALT)
		0x12	, //	38		SHIFT
		0x58	, //	39		CAPS LOCK(alternative)
		0x14	, //	3a		OPTION
		0x6b|E0	, //	3b		��
		0x74|E0	, //	3c		��
		0x72|E0	, //	3d		��
		0x75|E0	, //	3e		��
		kFF		, //	3f		

		kFF		, //	40		
		0x71	, //	41		.(TENKEY)
		kFF		, //	42		
		0x7c	, //	43		*(TENKEY)
		kFF		, //	44		
		0x79	, //	45		+(TENKEY)
		kFF		, //	46		
		0x77	, //	47		CLEAR(NUM LOCK)
		kFF		, //	48		
		kFF		, //	49		
		kFF		, //	4a		
		0x4a|E0	, //	4b		/(TENKEY)
		0x5a|E0	, //	4c		ENTER(TENKEY)
		kFF		, //	4d		
		0x7b	, //	4e		-(TENKEY)
		kFF		, //	4f		

		kFF		, //	50		
		0x55	, //	51		=(TENKEY)
		0x70	, //	52		0(TENKEY)
		0x69	, //	53		1(TENKEY)
		0x72	, //	54		2(TENKEY)
		0x7a	, //	55		3(TENKEY)
		0x6b	, //	56		4(TENKEY)
		0x73	, //	57		5(TENKEY)
		0x74	, //	58		6(TENKEY)
		0x6c	, //	59		7(TENKEY)
		kFF		, //	5a		
		0x75	, //	5b		8(TENKEY)
		0x7d	, //	5c		9(TENKEY)
		kFF		, //	5d		
		kFF		, //	5e		
		kFF		, //	5f		
		
		0x03	, //	60		F5
		0x0b	, //	61		F6
		0x83	, //	62		F7
		0x04	, //	63		F3
		0x0a	, //	64		F8
		0x01	, //	65		F9
		kFF		, //	66		
		0x78	, //	67		F11
		kFF		, //	68		
		kFF		, //	69		PRINT
		kFF		, //	6a		
		0x7e	, //	6b		SCREEN
		kFF		, //	6c		
		0x09	, //	6d		F10
		kFF		, //	6e		
		0x07	, //	6f		F12
		
		kFF		, //	70		
		0x69|E0	, //	71		PAUSE --> END
		0x70|E0	, //	72		HELP(INS)
		0x6c|E0	, //	73		HOME(*)
		0x7d|E0	, //	74		ROLL UP
		0x71|E0	, //	75		DEL(TENKEY)
		0x0c	, //	76		F4
		0x69|E0	, //	77		END(*)
		0x06	, //	78		F2
		0x7a|E0	, //	79		ROLL DOWN
		0x05	, //	7a		F1
		kFF		, //	7b		
		kFF		, //	7c		
		kFF		, //	7d		
		kFF		, //	7e		
		kFF		, //	7f		POWER ON(*)
};
//	(*)	= full size	keyboard only
