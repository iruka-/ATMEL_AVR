#ifndef	ps2keyb_h_
#define	ps2keyb_h_


typedef	unsigned char	uchar;

void	wait_10us(uchar us);
void	wait_msec(int i);
void	delay_usec();
void	ps2_sendclk(void);
void	ps2_init(void);
char	ps2_recvbit(void);
void	ps2_sendbyte(unsigned char dat);
int		ps2_recvbyte(void);
void	ps2_recvcmd(void);
void	ps2_sendcode(char swnum,char flag);
void	led(int f);
void	keypress(char swnum,char f);


#endif

