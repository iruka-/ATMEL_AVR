#ifndef	adb_h_
#define	adb_h_


void	adb_cmd(uchar c);
void	adb_init(void);
void	adb_scan(void);

#endif

