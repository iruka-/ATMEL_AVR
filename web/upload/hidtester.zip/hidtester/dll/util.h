/* util.h */
//#define	DLL_int	__declspec(dllexport) int __cdecl //__stdcall
#define	DLL_int	__declspec(dllexport) int __stdcall
#define	DLL_double	__declspec(dllexport) double __stdcall

/* util.c */
DLL_int PortAddress (const char *string);
DLL_int UsbPeek (int adr, int arena);
DLL_int UsbSetPoll (int adr, int arena);
DLL_int UsbPoll (void);
DLL_int UsbPoke (int adr, int arena, int data, int mask);
DLL_int UsbInit (const char *string);
DLL_int UsbExit (void);
DLL_int UsbAnalogSetup(double Vcc,double Vref,double Ref_k_Ohm);
DLL_int UsbAnalogPoll(int mode,unsigned char *abuf);
DLL_double UsbAnalogInput(int mode);

int UsbSetPoll_slow (int adr, int arena);
int UsbPoll_slow (void);
int QueryAVR (cmdBuf *cmd, uchar *buf, int reply_len);

