#include <stddef.h>

/* Implementation taken from Linux kernel (linux/lib/string.c) */

size_t strlen(const char * s)
{
    const char *sc;

    for (sc = s; *sc != '\0'; ++sc)
        /* nothing */;
    return sc - s;
}

/* */
char *strchr(const char *s, int c)
{
  c = (char)c;
  do
    if (*s == c)
      return (char*)s;
  while (*s++ != '\0');
  return NULL;
}

int strcmp(const char *s1, const char *s2)
{
  register const unsigned char *ss1, *ss2;
  for (ss1 = (const unsigned char*)s1, ss2 = (const unsigned char*)s2;
       *ss1 == *ss2 && *ss1 != '\0';
       ss1++, ss2++)
    ;
  return *ss1 - *ss2;
} 

char *strcat(char * __restrict__ s1, const char * __restrict__ s2)
{
  register char *ss;
  for (ss = s1; *ss != '\0'; ss++)
    ;
  for (; (*ss = *s2) != '\0'; ss++, s2++)
    ;
 return s1;
}

char *strcpy(char * __restrict__ s1, const char * __restrict__ s2)
{
  char *ss;

  for (ss = s1; (*ss = *s2) != '\0'; ss++, s2++)
    ;
  return s1;
}
 
size_t strnlen(const char *s, size_t count)
{
        const char *sc;

        for (sc = s; count-- && *sc != '\0'; ++sc)
                /* nothing */;
        return sc - s;
}

int strncmp(const char *s1, const char *s2, size_t n)
{
  register const unsigned char *ss1, *ss2, *t;
  for (ss1 = (const unsigned char*)s1, ss2 = (const unsigned char*)s2, t = ss1 + n;
       ss1 != t && *ss1 == *ss2 && *ss1 != '\0';
       ss1++, ss2++)
    ;
  return *ss1 - *ss2;
} 

char *strncat(char * __restrict__ s1, const char * __restrict__ s2, size_t n)
{
  register char *ss, *t;
  for (ss = s1; *ss != '\0'; ss++)
    ;
  for (t = ss + n; ss != t && (*ss = *s2) != '\0'; ss++, s2++)
    ;
  if (ss == t)
    *ss = '\0';
  return s1;
} 

char *strncpy(char * __restrict__ s1, const char * __restrict__ s2, size_t n)
{
  register char *ss, *t;
  for (ss = s1, t = ss + n;
       ss != t && (*ss = *s2) != '\0';
       ss++, s2++)
    ;
  for (; ss != t; ss++)
    *ss = '\0';
  return s1;
} 

void *memchr(const void *s, int c, size_t n)
{
  register const unsigned char *ss = s;
  register const unsigned char *t = ss + n;
  c = (unsigned char)c;
  while (ss != t && *ss != c)
    ++ss;
  return ss != t ? (void*)ss : NULL;
}
 
void *memset(void *s, int c, size_t n)
{
  if (n != 0)
  {
    register unsigned char *addr = (unsigned char*)s;
    register unsigned char* t = addr + n;
    for (; addr < t; ++addr)
      *addr = c;
  }
  return s;
}

void * memcpy(void * dest,const void *src,size_t count)
{
    char *tmp = (char *) dest, *s = (char *) src;

    while (count--)
        *tmp++ = *s++;

    return dest;
}

