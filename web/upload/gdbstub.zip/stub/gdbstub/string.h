#ifndef __STRING_H
#define __STRING_H

#include <stddef.h>

extern size_t strlen(const char *__s);
extern char  *strchr(const char *s, int c);
extern int    strcmp(const char *s1, const char *s2);
extern char  *strcat(char * __restrict__ s1, const char * __restrict__ s2);
extern char  *strcpy(char * __restrict__ s1, const char * __restrict__ s2);
extern size_t strnlen(const char *s, size_t count);
extern int    strncmp(const char *s1, const char *s2, size_t n);
extern char  *strncat(char * __restrict__ s1, const char * __restrict__ s2, size_t n);
extern char  *strncpy(char * __restrict__ s1, const char * __restrict__ s2, size_t n);

extern void *memchr(const void *s, int c, size_t n);
extern void *memset(void *s, int c, size_t n);
extern void *memcpy(void * dest,const void *src,size_t count);

#endif /* __STRING_H */
