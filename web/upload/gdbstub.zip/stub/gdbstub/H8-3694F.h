#ifndef _H8_3694F_h_
#define _H8_3694F_h_

/* Registers */
/* LVD   Address*/
#define LVDCR   (*(volatile unsigned char   *)0xf730)
#define LVDSR   (*(volatile unsigned char   *)0xf731)
/* IIC2  Address*/
#define IICR1   (*(volatile unsigned char   *)0xf748)
#define IICR2   (*(volatile unsigned char   *)0xf749)
#define ICMR    (*(volatile unsigned char   *)0xf74a)
#define ICIER   (*(volatile unsigned char   *)0xf74b)
#define ICSR    (*(volatile unsigned char   *)0xf74c)
#define SAR     (*(volatile unsigned char   *)0xf74d)
#define ICDRT   (*(volatile unsigned char   *)0xf74e)
#define ICDRR   (*(volatile unsigned char   *)0xf74f)
/* TW    Address*/
#define TMRW    (*(volatile unsigned char   *)0xff80)
#define TCRW    (*(volatile unsigned char   *)0xff81)
#define TIERW   (*(volatile unsigned char   *)0xff82)
#define TSRW    (*(volatile unsigned char   *)0xff83)
#define TIOR0   (*(volatile unsigned char   *)0xff84)
#define TIOR1   (*(volatile unsigned char   *)0xff85)
#define TCNT    (*(volatile unsigned char   *)0xff86)
#define GRA     (*(volatile unsigned char   *)0xff87)
#define GRB     (*(volatile unsigned char   *)0xff88)
#define GRC     (*(volatile unsigned char   *)0xff89)
#define GRD     (*(volatile unsigned char   *)0xff8a)
/* FLASH Address*/
#define FLMCR1  (*(volatile unsigned char   *)0xff90)
#define FLMCR2  (*(volatile unsigned char   *)0xff91)
#define FLPWCR  (*(volatile unsigned char   *)0xff92)
#define EBR1    (*(volatile unsigned char   *)0xff93)
#define FENR    (*(volatile unsigned char   *)0xff9b)
/* TV    Address*/
#define TCRV0   (*(volatile unsigned char   *)0xFFA0)
#define TCSRV   (*(volatile unsigned char   *)0xFFA1)
#define TCORA   (*(volatile unsigned char   *)0xFFA2)
#define TCORB   (*(volatile unsigned char   *)0xFFA3)
#define TCNTV   (*(volatile unsigned char   *)0xFFA4)
#define TCRV1   (*(volatile unsigned char   *)0xFFA5)
/* TA    Address*/
#define TMA     (*(volatile unsigned char   *)0xFFA6)
#define TCA     (*(volatile unsigned char   *)0xFFA7)
/* SCI3  Address*/
#define SMR     (*(volatile unsigned char   *)0xffa8)
#define BRR     (*(volatile unsigned char   *)0xffa9)
#define SCR3    (*(volatile unsigned char   *)0xffaa)
#define TDR     (*(volatile unsigned char   *)0xffab)
#define SSR     (*(volatile unsigned char   *)0xffac)
#define RDR     (*(volatile unsigned char   *)0xffad)
/* A/D   Address*/
#define ADDRA   (*(volatile unsigned short  *)0xFFB0)
#define ADDRB   (*(volatile unsigned short  *)0xFFB2)
#define ADDRC   (*(volatile unsigned short  *)0xFFB4)
#define ADDRD   (*(volatile unsigned short  *)0xFFB6)
#define ADCSR   (*(volatile unsigned char   *)0xFFB8)
#define ADCR    (*(volatile unsigned char   *)0xFFB9)
/* WDT   Address*/
#define TCSRWD  (*(volatile unsigned char   *)0xFFC0)
#define TCWD    (*(volatile unsigned char   *)0xFFC1)
#define TMWD    (*(volatile unsigned char   *)0xFFC2)
/* ABRK  Address*/
#define ABRKCR  (*(volatile unsigned char   *)0xFFC8)
#define ABRKSR  (*(volatile unsigned char   *)0xFFC9)
#define BARH    (*(volatile unsigned char   *)0xFFCA)
#define BARL    (*(volatile unsigned char   *)0xFFCB)
#define BDRH    (*(volatile unsigned char   *)0xFFCC)
#define BDRL    (*(volatile unsigned char   *)0xFFCD)
/* IO    Address*/
#define PUCR1   (*(volatile unsigned char   *)0xFFD0)
#define PUCR5   (*(volatile unsigned char   *)0xFFD1)
#define PDR1    (*(volatile unsigned char   *)0xFFD4)
#define PDR2    (*(volatile unsigned char   *)0xFFD5)
#define PDR5    (*(volatile unsigned char   *)0xFFD8)
#define PDR7    (*(volatile unsigned char   *)0xFFDA)
#define PDR8    (*(volatile unsigned char   *)0xffdb)
#define PDRB    (*(volatile unsigned char   *)0xFFDD)
#define PMR1    (*(volatile unsigned char   *)0xffe0)
#define PMR5    (*(volatile unsigned char   *)0xFFE1)
#define PCR1    (*(volatile unsigned char   *)0xFFE4)
#define PCR2    (*(volatile unsigned char   *)0xFFE5)
#define PCR5    (*(volatile unsigned char   *)0xFFE8)
#define PCR7    (*(volatile unsigned char   *)0xFFEA)
#define PCR8    (*(volatile unsigned char   *)0xFFEB)
/* SYSCR1Address*/
#define SYSCR1  (*(volatile unsigned char   *)0xFFF0)
/* SYSCR2Address*/
#define SYSCR2  (*(volatile unsigned char   *)0xFFF1)
/* IEGR1 Address*/
#define IEGR1   (*(volatile unsigned char   *)0xFFF2)
/* IEGR2 Address*/
#define IEGR2   (*(volatile unsigned char   *)0xFFF3)
/* IENR1 Address*/
#define IENR1   (*(volatile unsigned char   *)0xFFF4)
/* IRR1  Address*/
#define IRR1    (*(volatile unsigned char   *)0xFFF6)
/* IWPR  Address*/
#define IWPR    (*(volatile unsigned char   *)0xFFF8)
/* MSTCR1Address*/
#define MSTCR1  (*(volatile unsigned char   *)0xFFF9)

#endif /* _H8_3694F_h_ */
