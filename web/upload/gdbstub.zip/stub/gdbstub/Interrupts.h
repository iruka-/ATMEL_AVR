#ifndef _H8_3964_Interupts_H_
#define _H8_3964_Interupts_H_

/* Interrupt ID */
#define IntID_start			0
#define IntID_Reserved			1
#define IntID_NMI			7
#define IntID_TRAP0			8
#define IntID_TRAP1			9
#define IntID_TRAP2			10
#define IntID_TRAP3			11
#define IntID_ABRK			12
#define IntID_SLEEP			13
#define IntID_IRQ0			14
#define IntID_IRQ1			15
#define IntID_IRQ2			16
#define IntID_IRQ3			17
#define IntID_WKP			18
#define IntID_TA			19
#define IntID_TW			21
#define IntID_TV			22
#define IntID_SCI3			23
#define IntID_IIC2			24
#define IntID_ADI			25

#endif /*_H8_3964_Interupts_H_*/

