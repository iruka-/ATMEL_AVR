/* Lisence is GPL2 */
#include <stddef.h>
#include <stdarg.h>
#include <string.h>

#define BARDEF		 0x80
#define DOTDEF		 0x40
#define ZERODEF	 	 0x20
#define SIZEDEF		 0x10
#define ESCAPE 		 1

const char hextbl[] = "0123456789ABCDEF";

static int atodec(char *buf)
{
  int result = 0;

  while( '0' <= *buf && *buf <= '9' ){
    result = result*10 + (*buf-'0');
    buf++;
  }

  return result;
}

static inline unsigned char outchar(char c, char *ptr, unsigned char off)
{
  ptr[off] = c;
  return off + 1;
}

static unsigned char
outstring(char *data, unsigned char len, char *ptr,
          unsigned char offset, unsigned char _num)
{
  unsigned char i, num1, siz, off;

  off = offset;
  num1 = _num & 0x0f;
  siz = len;
  if((_num & (SIZEDEF | BARDEF | DOTDEF)) == SIZEDEF)
    for(i = num1;i > len;i--){
      ptr[off] = ' ';
      off++;
    }
  if((_num & SIZEDEF) && (_num & DOTDEF) && (siz > num1)) siz = num1;
  memcpy(&(ptr[off]), data, siz);
  off += siz;
  if((_num & (SIZEDEF | BARDEF | DOTDEF)) == (SIZEDEF | BARDEF))
    for(i = num1;i > len;i--){
      ptr[off] = ' ';
      off++;
    }
  return off;
}

unsigned char
dec(unsigned int value, char *ptr, unsigned char offset, unsigned char _num)
{
  unsigned int  a, b, i;
  unsigned char off, num1, k, f;

  off = offset;
  num1 = _num & 0x0f;
  for(k = 10, i = 1000000000;i >= 10;i /= 10, k--) if(value / i) break;
  if((_num & (SIZEDEF | BARDEF)) == SIZEDEF)
    for(i = num1;i > k;i--){
      ptr[off] = (_num & ZERODEF) ? '0' : ' ';
      off++;
    }
  f = 0;
  for(a = value, i = 1000000000;i >= 10;i /= 10) {
    a = value / i;
    b = a;
    if(a > 0) f = 1;
    if(f == 1){
      ptr[off] = hextbl[a];
      off++;
    }
    value = value - a * i;
  }
  ptr[off] = hextbl[value];
  off++;
  if((_num & (SIZEDEF | BARDEF)) == (SIZEDEF | BARDEF))
    for(i = num1;i > k;i--){
      ptr[off] = (_num & ZERODEF) ? '0' : ' ';
      off++;
    }
  return off;
}

unsigned char
hex(unsigned int value, char *ptr,
    unsigned char offset, unsigned char _num)
{
  int	sft, nm, i;
  unsigned int bits;
  unsigned char off, num1, index, f;
//  char	c;

  off = offset;
  num1 = _num & 0x0f;
  for(nm = 36,bits = 0xffffffff;bits > 0;bits >>= 1, nm--)
    if(~bits & value) break;
  nm >>= 2;
  if((_num & (SIZEDEF | BARDEF)) == SIZEDEF)
    for(i = num1;i > nm;i--){
      ptr[off] = (_num & ZERODEF ) ? '0' : ' ';
      off++;
    }
  f = 0;
  for(sft = 28;sft >= 0;sft -= 4) {
    index = (value >> sft) & 0xf;
    if(index > 0) f = 1;
    if(index > 0 || f == 1 || sft == 0){
      ptr[off] = hextbl[index];
      off++;
    }
  }
  if((_num & (SIZEDEF | BARDEF)) == (SIZEDEF | BARDEF))
    for(i = num1;i > nm;i--){
      ptr[off] = (_num & ZERODEF ) ? '0' : ' ';
      off++;
    }
  return off;
}


int sprintf(char *buf, const char *fmt, ...)
{
  int	         value=0;
  char	         flag, numbuf[5], *ptr=0, numindex;
  unsigned char  i, n, off, opt=0, num;

  va_list args;

  flag = 0;
  off = 0;

  va_start(args, fmt);
  n = strlen(fmt);
  for(i=0 ;i<n; i++){

    if(flag & ESCAPE) {
      value = va_arg(args, int);
    }
    if(fmt[i] == '%') {
      if(i > 0 && fmt[i-1] == '%'){
	flag &= ~ESCAPE;
	off = outchar(fmt[i], buf, off); 
      }
      else {
	flag |= ESCAPE;
	numindex = -1;
	num = 0;
	opt = 0;
      }
    }
    else if((flag & ESCAPE) && (fmt[i] == 'd' || fmt[i] == 'i')) {
      if(value<0){
        off = outchar('-', ptr, off);
        off = dec(~value+1, ptr, off, num|opt);
      }
      else{
        off = dec(value, ptr, off, num|opt);
      }
      flag &= ~ESCAPE;
    }
    else if((flag & ESCAPE) && fmt[i] == 'u') {
      off = dec(value, buf, off, num | opt);
      flag &= ~ESCAPE;
    }
    else if((flag & ESCAPE) && (fmt[i] == 'x' || fmt[i] == 'X')) {
      off = hex(value, buf, off, num | opt);
      flag &= ~ESCAPE;
    }
    else if((flag & ESCAPE) && fmt[i] == 's') {
      ptr = (char*)(short)value;
      off = outstring(ptr, strlen(ptr), buf, off, num | opt);
      flag &= ~ESCAPE;
    }
    else if((flag & ESCAPE) && fmt[i] == 'c') {
      off = outchar((char)value, buf, off);
      flag &= ~ESCAPE;
    }
    else if((flag & ESCAPE) && ('0' <= fmt[i] && fmt[i] <= '9')){
      if(numindex > 3) flag &= ~ESCAPE;
      else {
	numbuf[(int)++numindex] = fmt[i];
	numbuf[numindex + 1] = 0;
	num = atodec(numbuf);
	opt |= SIZEDEF;
	if(fmt[i] == '0') opt |= ZERODEF;
      }
    }
    else if((flag & ESCAPE) && 
	    (fmt[i] == '.' || fmt[i] == ' ' ||
	     fmt[i] == 'l' || fmt[i] == '-')) {
      if(fmt[i] == '.') opt |= DOTDEF;
      if(fmt[i] == '-') opt |= BARDEF;
    }
    else {
      flag &= ~ESCAPE;
      off = outchar(fmt[i], buf, off); 
    }
  }

  va_end(args);
  return off;
}

