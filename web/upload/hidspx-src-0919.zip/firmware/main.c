/* Name: main.c
 * Project: AVR-monkey
 * Author: VA000177
 * Creation Date: 2008-09-18
 * Tabsize: 4
 * License: GNU GPL v2 (see License.txt) or proprietary (CommercialLicense.txt)
 * Revision: $Id: main.c 571 2008-04-27 14:39:33Z cs $
 */


#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/wdt.h>
#include <util/delay.h>
#include <string.h>

#include "usbdrv.h"
#include "utils.h"

/* ------------------------------------------------------------------------- */

#define ID4    4
#define	SIZE4 32

PROGMEM char usbHidReportDescriptor[51] = {
    0x06, 0x00, 0xff,              // USAGE_PAGE (Generic Desktop)
    0x09, 0x01,                    // USAGE (Vendor Usage 1)
    0xa1, 0x01,                    // COLLECTION (Application)
    0x15, 0x00,                    //   LOGICAL_MINIMUM (0)
    0x26, 0xff, 0x00,              //   LOGICAL_MAXIMUM (255)
    0x75, 0x08,                    //   REPORT_SIZE (8)

    0x85, 0x01,                    //   REPORT_ID (1)
    0x95, 0x06,                    //   REPORT_COUNT (6)
    0x09, 0x00,                    //   USAGE (Undefined)
    0xb2, 0x02, 0x01,              //   FEATURE (Data,Var,Abs,Buf)

    0x85, 0x02,                    //   REPORT_ID (2)
    0x95, 0x0e,                    //   REPORT_COUNT (14)
    0x09, 0x00,                    //   USAGE (Undefined)
    0xb2, 0x02, 0x01,              //   FEATURE (Data,Var,Abs,Buf)

    0x85, 0x03,                    //   REPORT_ID (3)
    0x95, 0x16,                    //   REPORT_COUNT (22)
    0x09, 0x00,                    //   USAGE (Undefined)
    0xb2, 0x02, 0x01,              //   FEATURE (Data,Var,Abs,Buf)

    0x85, 0x04,                    //   REPORT_ID (4)
    0x95, 0x1e,                    //   REPORT_COUNT (30)
    0x09, 0x00,                    //   USAGE (Undefined)
    0xb2, 0x02, 0x01,              //   FEATURE (Data,Var,Abs,Buf)

    0xc0                           // END_COLLECTION
};
/* Note: REPORT_COUNT does not include report-ID byte */


static uchar hidStatus;			   // HID Report ID
static uchar requestType;

//
//	��M�o�b�t�@.
//
static uchar currentPosition, bytesRemaining; // Receive Data Pointer

typedef struct {
	uchar id[1];
	uchar buf[31];
} ReportBuf_t;

static ReportBuf_t report;

// ���M�o�b�t�@�͎�M�o�b�t�@�𗬗p����.
//	�A���A�擪1�o�C�g��Report ID��u���K�v������̂�,�P�o�C�g�����.
#define	usbData report.buf
#define	buffer  report.id


// �œK���p
#define hbyte(a) (*((uchar*)&(a)+1))
#define lbyte(a) (*((uchar*)&(a)))
inline static uint8_t byte(uint8_t t) {return t;}

static void delay(uchar d) {
	while(d--) {
		asm("nop");
	}
}
static uint8_t wait=60; // 160

static uint8_t usi_trans(uint8_t data){
	USIDR=data;
	USISR=(1<<USIOIF);
	do{
		delay(wait);
		USICR=(1<<USIWM0)|(1<<USICS1)|(1<<USICLK)|(1<<USITC);
	} while(!(USISR&(1<<USIOIF)));

	return USIDR;
}


static inline void isp_command(uint8_t *data){
	int i;
	for (i=0;i<4;i++) {
		usbData[i]=usi_trans(data[i]);
	}
}

/* ------------------------------------------------------------------------- */
/* ----------------------------- execute Buffer ---------------------------- */
/* ------------------------------------------------------------------------- */
//
//		hidasp�̃��C������.
//
//	���M�o�b�t�@�Ǝ�M�o�b�t�@�����ʂȂ̂ŁA
//	�����ׂ������Ƃ̃f�[�^���g��Ȃ��悤�ɒ���.
void hidasp_main(uchar *data)
{
	static uchar page_mode;
	static uint16_t page_addr;
	uchar i;
	uint8_t data0 = data[0];
	uint8_t data1 = data[1];
	uint8_t cmd   = data0 & 0xfe;
	if ( data[0] == 0x01 ) { // TEST
		usbData[0] = data1;
	} else if ( data0 == 0x02 ) { // SET_LED
		PORTD = (PORTD&~3)    | (data1 & 3);
		PORTB = (PORTB&~0x10) | (data[2]&0x10);
	} else if ( cmd==0x10) { // SPI
		isp_command(data+1);
	} else if ( data0 == 20 ) { // Page set
		page_mode = data1;
		page_addr = 0;
	} else if ( cmd == 22 ) { // Page buf
		for(i=0;i<data1;i++) {
			usi_trans(page_mode);
			usi_trans(hbyte(page_addr));
			usi_trans(lbyte(page_addr));
			usbData[i]=usi_trans(data[i+2]);
			if (page_mode&0x88) { // EEPROM or FlashH
				page_addr++;
				page_mode&=~0x08;
			} else {
				page_mode|=0x08;
			}
		}
	} else if ( data0 == 60 ) { // Set wait
		wait=data1;
	}

//	if (data[0]&1) {
//		usbSetInterrupt(usbData, 8);
//	}

//	return 8;
}


/* ------------------------------------------------------------------------- */
/* ----------------------------- USB interface ----------------------------- */
/* ------------------------------------------------------------------------- */

// �f�t�H���g�ȊO�� usb setup �R�}���h�p�P�b�g�������ŉ��߂���.
uchar usbFunctionSetup(uchar data[8])
{
	usbRequest_t    *rq = (void *)data;
	uchar           rqType = rq->bmRequestType & USBRQ_TYPE_MASK;
    if(rqType == USBRQ_TYPE_CLASS){    /* class request type */
        if(	rq->bRequest == USBRQ_HID_GET_REPORT ) { 
        		report.id[0] = ID4;             /* report ID */
        		usbMsgPtr = report.id;
        		return SIZE4;
		}
        if(	rq->bRequest == USBRQ_HID_SET_REPORT ) { 
            hidStatus = rq->wValue.bytes[0];    /* store report ID */
		    currentPosition = 0;                // initialize position index
        	bytesRemaining = rq->wLength.word;  // store the amount of data requested
        	if(	bytesRemaining > sizeof(report)) { // limit to buffer size
            	bytesRemaining = sizeof(report);
			}
          	return 0xff;						// tell driver to use usbFunctionWrite()
        }
    }
    return 0;
}


// �R���g���[���]�����㑱�f�[�^�������Ă���ꍇ�A������W�o�C�g�P�ʂŎ󂯎��.
// 	�E���ʂ�report�\���̂ɓ����.
//	�E�S���󂯎������Ahidasp_main()���Ăяo��.
uchar usbFunctionWrite(uchar *data, uchar len)
{
    uchar i;
    if(	len > bytesRemaining) {             // if this is the last incomplete chunk
        len = bytesRemaining;               // limit to the amount we can store
	}
    bytesRemaining -= len;
    for(i = 0; i < len; i++) {
        report.id[currentPosition++] = data[i];
	}
	// �S���󂯎������A�o�b�t�@���e�����s.
    if( bytesRemaining == 0 ) {
		if( hidStatus > 0 ) {
			hidasp_main(report.buf);
		}
	    return 1;	// return 1 if we have all data
	}
	return 0;		// continue data.
}

/*
	   ATtyny2313
       ___    ___
RESET [1  |__| 20]Vcc
PD0   [2       19]PB7(SCK)
PD1   [3       18]PB6(MISO)
XTAL2 [4       17]PB5(MOSI)
XTAL1 [5       16]PB4(RST)
PD2   [6       15]
PD3   [7       14]
      [8       13]
      [9       12]
GND   [10      11]
       ~~~~~~~~~~

   ---------------------------------------
   SPI:     PB7-4 ===> [Target AVR Device]
   USB:     PD3   ===> USB D-
            PD2   ===> USB D+
   XTAL:    XTAL1,2 => Crystal 12MHz
   LED:(Optional) PD0,PD1
   ---------------------------------------
*/

int main(void)
{
//	PORTD = 0x00;
    DDRD = ~USBMASK;   /* all outputs except USB data */
//	PORTB = 0x08;      /* no pullups on USB pins */ // LED off
    DDRB = ~(1<<5);    /* all outputs except USI input data */
	hidStatus = -1;
    usbInit();
    sei();
    for(;;){    /* main event loop */
        usbPoll();
    }
    return 0;
}
