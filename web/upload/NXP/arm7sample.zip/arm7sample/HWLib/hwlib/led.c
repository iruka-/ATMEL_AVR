/*********************************************************************
 *	�b�p�t�^�m�w�o-�`�q�l ��p	�k�d�c���j�^.
 *********************************************************************
 */


#include <string.h>

#ifdef	LPC214x
#include "LPC214x.h"
#else
#include "LPC23xx.h"
#endif

#include "swi.h"
#include "led.h"

typedef	unsigned int	uint;
volatile uint Timer;		/* 1kHz increment timer */

/*********************************************************************
 *	���̂k�d�c�_�ŏ���.
 *********************************************************************
 */

/* FGPIO�R���g���[���̃��W�X�^ */
#define FGPIO_FIO1DIR	((volatile uint *)(0x3FFFC020))
#define FGPIO_FIO1MASK	((volatile uint *)(0x3FFFC030))
#define FGPIO_FIO1PIN	((volatile uint *)(0x3FFFC034))
#define FGPIO_FIO1CLR	((volatile uint *)(0x3FFFC03C))


/* LED��_�����鏈�� */
void LED_On(void)
{
    *FGPIO_FIO1PIN=0x00000000; /* P1[18] ��'0'�ɁiLED��_����j */
}

/* LED���������鏈�� */
void LED_Off(void)
{
    *FGPIO_FIO1PIN=0x00040000; /* P1[18] ��'1'�ɁiLED�������j   */
}

	static int ledcnt = 0;

void LED_Flip(int period)
{
	int	maskbit=(1<<period);
	ledcnt++;
	if((ledcnt & (maskbit-1))==0) {
    	if(ledcnt & maskbit) LED_On();
    	else 				 LED_Off();
	}
}

void LED_Flip_Loop(int period,int cnt)
{
#if	0
	while(1) LED_Flip(period);
#else
	int i,j,flip=(2<<period);
	ledcnt=0;
	for(i=0;i<cnt;i++) {
		for(j=0;j<flip;j++) {
			LED_Flip(period);
		}
	}
	ledcnt=0;
	for(i=0;i<2;i++) {
		for(j=0;j<flip;j++) {
			LED_Flip(31);
		}
	}
#endif
}


/*********************************************************************
 *	�^�C�}�[���荞�݁F�P���r�P��
 *********************************************************************
 */
void Isr_TIMER0(void)
{
	T0IR = 1;	/* Clear irq flag */
	Timer++;

#if	0	// Debug
	LED_Flip(6);
	while(1) ;
#endif
}


void TIMER0_Init(void)
{
	/* Initialize Timer0 as 1kHz interval timer */
	RegisterVector(TIMER0_INT, Isr_TIMER0, PRI_LOWEST, CLASS_IRQ);

	T0CTCR = 0;
	T0MR0 = 18000 - 1;	/* 18M / 1k = 18000 */
	T0MCR = 0x3;		/* Clear TC and Interrupt on MR0 match */
	T0TCR = 1;
}
/*********************************************************************
 *	
 *********************************************************************
 */
