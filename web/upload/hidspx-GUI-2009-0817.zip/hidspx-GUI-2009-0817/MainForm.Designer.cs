﻿namespace hidspxGUI
{
    partial class MainForm
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ExtFuse = new System.Windows.Forms.Label();
            this.WriteFuseButton = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.EFuseTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.LFuseTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.HFuseTextBox = new System.Windows.Forms.TextBox();
            this.ChipButton = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.hidspxButton = new System.Windows.Forms.Button();
            this.hidspxTextBox = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.HexDumpFlashMButton = new System.Windows.Forms.Button();
            this.WriteFlashButton = new System.Windows.Forms.Button();
            this.VerifyFlashButton = new System.Windows.Forms.Button();
            this.ReadFlashButton = new System.Windows.Forms.Button();
            this.FlashFileButton = new System.Windows.Forms.Button();
            this.FlashFileTextBox = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.HexDumpEEPROMButton = new System.Windows.Forms.Button();
            this.VerifyEEPROMButton = new System.Windows.Forms.Button();
            this.WriteEEPROMButton = new System.Windows.Forms.Button();
            this.ReadEEPROMButton = new System.Windows.Forms.Button();
            this.EEPROMFileButton = new System.Windows.Forms.Button();
            this.EEPROMFileTextBox = new System.Windows.Forms.TextBox();
            this.ProgressBar = new System.Windows.Forms.ProgressBar();
            this.OpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.SaveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.CommandLineOptionTextBox = new System.Windows.Forms.TextBox();
            this.ChipEraseButton = new System.Windows.Forms.Button();
            this.LockBitTextBox = new System.Windows.Forms.TextBox();
            this.WriteLockBitButton = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.LogTextBox = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.EnterButton = new System.Windows.Forms.Button();
            this.ParmTextBox = new System.Windows.Forms.TextBox();
            this.LogClearButton = new System.Windows.Forms.Button();
            this.SimpleModeCheckBox = new System.Windows.Forms.CheckBox();
            this.DeviceName = new System.Windows.Forms.Label();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.FileMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cMDPromptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.writeBothToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.writeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.writeWWPROMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DeviceMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.readToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fuseInfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SettingMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.hidspxexeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.HelpMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.fuseCalcToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.aVRDocumentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hIDaspxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hidspxTipsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ExtFuse);
            this.groupBox2.Controls.Add(this.WriteFuseButton);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.EFuseTextBox);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.LFuseTextBox);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.HFuseTextBox);
            this.groupBox2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(123, 26);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Size = new System.Drawing.Size(289, 45);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Fuse (HEX)";
            // 
            // ExtFuse
            // 
            this.ExtFuse.AutoSize = true;
            this.ExtFuse.Location = new System.Drawing.Point(189, 20);
            this.ExtFuse.Name = "ExtFuse";
            this.ExtFuse.Size = new System.Drawing.Size(15, 15);
            this.ExtFuse.TabIndex = 0;
            this.ExtFuse.Text = "--";
            // 
            // WriteFuseButton
            // 
            this.WriteFuseButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.WriteFuseButton.Location = new System.Drawing.Point(215, 15);
            this.WriteFuseButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.WriteFuseButton.Name = "WriteFuseButton";
            this.WriteFuseButton.Size = new System.Drawing.Size(65, 22);
            this.WriteFuseButton.TabIndex = 4;
            this.WriteFuseButton.Text = "Write";
            this.WriteFuseButton.UseVisualStyleBackColor = true;
            this.WriteFuseButton.Click += new System.EventHandler(this.WriteFuseButton_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(127, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(20, 15);
            this.label6.TabIndex = 0;
            this.label6.Text = "Ex";
            // 
            // EFuseTextBox
            // 
            this.EFuseTextBox.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EFuseTextBox.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.EFuseTextBox.Location = new System.Drawing.Point(153, 17);
            this.EFuseTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.EFuseTextBox.MaxLength = 2;
            this.EFuseTextBox.Name = "EFuseTextBox";
            this.EFuseTextBox.Size = new System.Drawing.Size(28, 21);
            this.EFuseTextBox.TabIndex = 3;
            this.EFuseTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(21, 15);
            this.label4.TabIndex = 0;
            this.label4.Text = "Lo";
            // 
            // LFuseTextBox
            // 
            this.LFuseTextBox.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LFuseTextBox.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.LFuseTextBox.Location = new System.Drawing.Point(35, 17);
            this.LFuseTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.LFuseTextBox.MaxLength = 2;
            this.LFuseTextBox.Name = "LFuseTextBox";
            this.LFuseTextBox.Size = new System.Drawing.Size(28, 21);
            this.LFuseTextBox.TabIndex = 1;
            this.LFuseTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(69, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(19, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hi";
            // 
            // HFuseTextBox
            // 
            this.HFuseTextBox.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HFuseTextBox.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.HFuseTextBox.Location = new System.Drawing.Point(92, 17);
            this.HFuseTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.HFuseTextBox.MaxLength = 2;
            this.HFuseTextBox.Name = "HFuseTextBox";
            this.HFuseTextBox.Size = new System.Drawing.Size(28, 21);
            this.HFuseTextBox.TabIndex = 2;
            this.HFuseTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ChipButton
            // 
            this.ChipButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ChipButton.BackgroundImage")));
            this.ChipButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ChipButton.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChipButton.Location = new System.Drawing.Point(20, 50);
            this.ChipButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ChipButton.Name = "ChipButton";
            this.ChipButton.Size = new System.Drawing.Size(69, 22);
            this.ChipButton.TabIndex = 0;
            this.ChipButton.Text = " Read";
            this.ChipButton.UseVisualStyleBackColor = true;
            this.ChipButton.Click += new System.EventHandler(this.ChipButton_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.hidspxButton);
            this.groupBox4.Controls.Add(this.hidspxTextBox);
            this.groupBox4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(7, 370);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox4.Size = new System.Drawing.Size(184, 50);
            this.groupBox4.TabIndex = 8;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "hidspx.exe File";
            // 
            // hidspxButton
            // 
            this.hidspxButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("hidspxButton.BackgroundImage")));
            this.hidspxButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.hidspxButton.Location = new System.Drawing.Point(159, 22);
            this.hidspxButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.hidspxButton.Name = "hidspxButton";
            this.hidspxButton.Size = new System.Drawing.Size(20, 15);
            this.hidspxButton.TabIndex = 1;
            this.hidspxButton.UseVisualStyleBackColor = true;
            this.hidspxButton.Click += new System.EventHandler(this.hidspxSelectButton);
            // 
            // hidspxTextBox
            // 
            this.hidspxTextBox.Location = new System.Drawing.Point(5, 20);
            this.hidspxTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.hidspxTextBox.MaxLength = 0;
            this.hidspxTextBox.Name = "hidspxTextBox";
            this.hidspxTextBox.Size = new System.Drawing.Size(148, 21);
            this.hidspxTextBox.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.HexDumpFlashMButton);
            this.groupBox5.Controls.Add(this.WriteFlashButton);
            this.groupBox5.Controls.Add(this.VerifyFlashButton);
            this.groupBox5.Controls.Add(this.ReadFlashButton);
            this.groupBox5.Controls.Add(this.FlashFileButton);
            this.groupBox5.Controls.Add(this.FlashFileTextBox);
            this.groupBox5.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(6, 210);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox5.Size = new System.Drawing.Size(316, 73);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Flash";
            // 
            // HexDumpFlashMButton
            // 
            this.HexDumpFlashMButton.Location = new System.Drawing.Point(166, 44);
            this.HexDumpFlashMButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.HexDumpFlashMButton.Name = "HexDumpFlashMButton";
            this.HexDumpFlashMButton.Size = new System.Drawing.Size(71, 22);
            this.HexDumpFlashMButton.TabIndex = 4;
            this.HexDumpFlashMButton.Text = "Dump";
            this.HexDumpFlashMButton.UseVisualStyleBackColor = true;
            this.HexDumpFlashMButton.Click += new System.EventHandler(this.HexDumpFlashButton_Click);
            // 
            // WriteFlashButton
            // 
            this.WriteFlashButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("WriteFlashButton.BackgroundImage")));
            this.WriteFlashButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.WriteFlashButton.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WriteFlashButton.Location = new System.Drawing.Point(7, 44);
            this.WriteFlashButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.WriteFlashButton.Name = "WriteFlashButton";
            this.WriteFlashButton.Size = new System.Drawing.Size(76, 22);
            this.WriteFlashButton.TabIndex = 2;
            this.WriteFlashButton.Text = "Write";
            this.WriteFlashButton.UseVisualStyleBackColor = true;
            this.WriteFlashButton.Click += new System.EventHandler(this.WriteFlashButton_Click);
            // 
            // VerifyFlashButton
            // 
            this.VerifyFlashButton.Location = new System.Drawing.Point(89, 44);
            this.VerifyFlashButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.VerifyFlashButton.Name = "VerifyFlashButton";
            this.VerifyFlashButton.Size = new System.Drawing.Size(71, 22);
            this.VerifyFlashButton.TabIndex = 3;
            this.VerifyFlashButton.Text = "Verify";
            this.VerifyFlashButton.UseVisualStyleBackColor = true;
            this.VerifyFlashButton.Click += new System.EventHandler(this.VerifyFlashButton_Click);
            // 
            // ReadFlashButton
            // 
            this.ReadFlashButton.Location = new System.Drawing.Point(243, 44);
            this.ReadFlashButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ReadFlashButton.Name = "ReadFlashButton";
            this.ReadFlashButton.Size = new System.Drawing.Size(61, 22);
            this.ReadFlashButton.TabIndex = 5;
            this.ReadFlashButton.Text = "Save";
            this.ReadFlashButton.UseVisualStyleBackColor = true;
            this.ReadFlashButton.Click += new System.EventHandler(this.ReadFlashButton_Click);
            // 
            // FlashFileButton
            // 
            this.FlashFileButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("FlashFileButton.BackgroundImage")));
            this.FlashFileButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.FlashFileButton.Location = new System.Drawing.Point(284, 18);
            this.FlashFileButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.FlashFileButton.Name = "FlashFileButton";
            this.FlashFileButton.Size = new System.Drawing.Size(20, 15);
            this.FlashFileButton.TabIndex = 1;
            this.FlashFileButton.UseVisualStyleBackColor = true;
            this.FlashFileButton.Click += new System.EventHandler(this.FlashFileButton_Click);
            // 
            // FlashFileTextBox
            // 
            this.FlashFileTextBox.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FlashFileTextBox.Location = new System.Drawing.Point(4, 17);
            this.FlashFileTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.FlashFileTextBox.Name = "FlashFileTextBox";
            this.FlashFileTextBox.Size = new System.Drawing.Size(274, 19);
            this.FlashFileTextBox.TabIndex = 0;
            this.FlashFileTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.HexDumpEEPROMButton);
            this.groupBox6.Controls.Add(this.VerifyEEPROMButton);
            this.groupBox6.Controls.Add(this.WriteEEPROMButton);
            this.groupBox6.Controls.Add(this.ReadEEPROMButton);
            this.groupBox6.Controls.Add(this.EEPROMFileButton);
            this.groupBox6.Controls.Add(this.EEPROMFileTextBox);
            this.groupBox6.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(6, 285);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox6.Size = new System.Drawing.Size(316, 73);
            this.groupBox6.TabIndex = 3;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "EEPROM";
            // 
            // HexDumpEEPROMButton
            // 
            this.HexDumpEEPROMButton.Location = new System.Drawing.Point(166, 43);
            this.HexDumpEEPROMButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.HexDumpEEPROMButton.Name = "HexDumpEEPROMButton";
            this.HexDumpEEPROMButton.Size = new System.Drawing.Size(71, 22);
            this.HexDumpEEPROMButton.TabIndex = 4;
            this.HexDumpEEPROMButton.Text = "Dump";
            this.HexDumpEEPROMButton.UseVisualStyleBackColor = true;
            this.HexDumpEEPROMButton.Click += new System.EventHandler(this.HexDumpEEPROMButton_Click);
            // 
            // VerifyEEPROMButton
            // 
            this.VerifyEEPROMButton.Location = new System.Drawing.Point(89, 43);
            this.VerifyEEPROMButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.VerifyEEPROMButton.Name = "VerifyEEPROMButton";
            this.VerifyEEPROMButton.Size = new System.Drawing.Size(71, 22);
            this.VerifyEEPROMButton.TabIndex = 3;
            this.VerifyEEPROMButton.Text = "Verify";
            this.VerifyEEPROMButton.UseVisualStyleBackColor = true;
            this.VerifyEEPROMButton.Click += new System.EventHandler(this.VerifyEEPROMButton_Click);
            // 
            // WriteEEPROMButton
            // 
            this.WriteEEPROMButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("WriteEEPROMButton.BackgroundImage")));
            this.WriteEEPROMButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.WriteEEPROMButton.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WriteEEPROMButton.Location = new System.Drawing.Point(7, 43);
            this.WriteEEPROMButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.WriteEEPROMButton.Name = "WriteEEPROMButton";
            this.WriteEEPROMButton.Size = new System.Drawing.Size(76, 22);
            this.WriteEEPROMButton.TabIndex = 2;
            this.WriteEEPROMButton.Text = "Write";
            this.WriteEEPROMButton.UseVisualStyleBackColor = true;
            this.WriteEEPROMButton.Click += new System.EventHandler(this.WriteEEPROMButton_Click);
            // 
            // ReadEEPROMButton
            // 
            this.ReadEEPROMButton.Location = new System.Drawing.Point(243, 43);
            this.ReadEEPROMButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ReadEEPROMButton.Name = "ReadEEPROMButton";
            this.ReadEEPROMButton.Size = new System.Drawing.Size(61, 22);
            this.ReadEEPROMButton.TabIndex = 5;
            this.ReadEEPROMButton.Text = "Save";
            this.ReadEEPROMButton.UseVisualStyleBackColor = true;
            this.ReadEEPROMButton.Click += new System.EventHandler(this.ReadEEPROMButton_Click);
            // 
            // EEPROMFileButton
            // 
            this.EEPROMFileButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("EEPROMFileButton.BackgroundImage")));
            this.EEPROMFileButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.EEPROMFileButton.Location = new System.Drawing.Point(284, 19);
            this.EEPROMFileButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.EEPROMFileButton.Name = "EEPROMFileButton";
            this.EEPROMFileButton.Size = new System.Drawing.Size(20, 15);
            this.EEPROMFileButton.TabIndex = 1;
            this.EEPROMFileButton.UseVisualStyleBackColor = true;
            this.EEPROMFileButton.Click += new System.EventHandler(this.EEPROMFileButton_Click);
            // 
            // EEPROMFileTextBox
            // 
            this.EEPROMFileTextBox.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EEPROMFileTextBox.Location = new System.Drawing.Point(4, 15);
            this.EEPROMFileTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.EEPROMFileTextBox.Name = "EEPROMFileTextBox";
            this.EEPROMFileTextBox.Size = new System.Drawing.Size(274, 19);
            this.EEPROMFileTextBox.TabIndex = 0;
            this.EEPROMFileTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ProgressBar
            // 
            this.ProgressBar.Location = new System.Drawing.Point(6, 193);
            this.ProgressBar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProgressBar.Name = "ProgressBar";
            this.ProgressBar.Size = new System.Drawing.Size(504, 10);
            this.ProgressBar.TabIndex = 0;
            // 
            // OpenFileDialog
            // 
            this.OpenFileDialog.FileName = "openFileDialog1";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.CommandLineOptionTextBox);
            this.groupBox9.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.Location = new System.Drawing.Point(327, 304);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(184, 54);
            this.groupBox9.TabIndex = 7;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Command line Option";
            // 
            // CommandLineOptionTextBox
            // 
            this.CommandLineOptionTextBox.Location = new System.Drawing.Point(7, 23);
            this.CommandLineOptionTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CommandLineOptionTextBox.Name = "CommandLineOptionTextBox";
            this.CommandLineOptionTextBox.Size = new System.Drawing.Size(166, 21);
            this.CommandLineOptionTextBox.TabIndex = 0;
            // 
            // ChipEraseButton
            // 
            this.ChipEraseButton.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChipEraseButton.Location = new System.Drawing.Point(423, 216);
            this.ChipEraseButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ChipEraseButton.Name = "ChipEraseButton";
            this.ChipEraseButton.Size = new System.Drawing.Size(84, 22);
            this.ChipEraseButton.TabIndex = 5;
            this.ChipEraseButton.Text = "ChipErase";
            this.ChipEraseButton.UseVisualStyleBackColor = true;
            this.ChipEraseButton.Click += new System.EventHandler(this.ChipEraseButton_Click);
            // 
            // LockBitTextBox
            // 
            this.LockBitTextBox.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LockBitTextBox.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.LockBitTextBox.Location = new System.Drawing.Point(46, 19);
            this.LockBitTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.LockBitTextBox.MaxLength = 2;
            this.LockBitTextBox.Name = "LockBitTextBox";
            this.LockBitTextBox.Size = new System.Drawing.Size(26, 21);
            this.LockBitTextBox.TabIndex = 0;
            this.LockBitTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // WriteLockBitButton
            // 
            this.WriteLockBitButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.WriteLockBitButton.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WriteLockBitButton.Location = new System.Drawing.Point(94, 18);
            this.WriteLockBitButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.WriteLockBitButton.Name = "WriteLockBitButton";
            this.WriteLockBitButton.Size = new System.Drawing.Size(84, 22);
            this.WriteLockBitButton.TabIndex = 1;
            this.WriteLockBitButton.Text = "Write";
            this.WriteLockBitButton.UseVisualStyleBackColor = true;
            this.WriteLockBitButton.Click += new System.EventHandler(this.WriteLockBitButton_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label2);
            this.groupBox7.Controls.Add(this.WriteLockBitButton);
            this.groupBox7.Controls.Add(this.LockBitTextBox);
            this.groupBox7.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.Location = new System.Drawing.Point(327, 248);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox7.Size = new System.Drawing.Size(184, 51);
            this.groupBox7.TabIndex = 6;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Lock Bit";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Image = ((System.Drawing.Image)(resources.GetObject("label2.Image")));
            this.label2.Location = new System.Drawing.Point(8, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "   ";
            // 
            // LogTextBox
            // 
            this.LogTextBox.BackColor = System.Drawing.SystemColors.InfoText;
            this.LogTextBox.ContextMenuStrip = this.contextMenuStrip1;
            this.LogTextBox.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogTextBox.ForeColor = System.Drawing.SystemColors.Info;
            this.LogTextBox.Location = new System.Drawing.Point(7, 78);
            this.LogTextBox.MaxLength = 0;
            this.LogTextBox.Multiline = true;
            this.LogTextBox.Name = "LogTextBox";
            this.LogTextBox.ReadOnly = true;
            this.LogTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.LogTextBox.Size = new System.Drawing.Size(504, 109);
            this.LogTextBox.TabIndex = 0;
            this.LogTextBox.TabStop = false;
            this.LogTextBox.WordWrap = false;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.EnterButton);
            this.groupBox1.Controls.Add(this.ParmTextBox);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(204, 370);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(307, 50);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Command Execute (for Expart)";
            // 
            // EnterButton
            // 
            this.EnterButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.EnterButton.Location = new System.Drawing.Point(248, 19);
            this.EnterButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.EnterButton.Name = "EnterButton";
            this.EnterButton.Size = new System.Drawing.Size(53, 22);
            this.EnterButton.TabIndex = 1;
            this.EnterButton.Text = "Enter";
            this.EnterButton.UseVisualStyleBackColor = true;
            this.EnterButton.Click += new System.EventHandler(this.EnterButton_Click);
            // 
            // ParmTextBox
            // 
            this.ParmTextBox.AcceptsReturn = true;
            this.ParmTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.ParmTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.ParmTextBox.Location = new System.Drawing.Point(8, 19);
            this.ParmTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ParmTextBox.Name = "ParmTextBox";
            this.ParmTextBox.Size = new System.Drawing.Size(234, 21);
            this.ParmTextBox.TabIndex = 0;
            this.ParmTextBox.WordWrap = false;
            this.ParmTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Enter_KeyDown);
            // 
            // LogClearButton
            // 
            this.LogClearButton.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogClearButton.Location = new System.Drawing.Point(328, 216);
            this.LogClearButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.LogClearButton.Name = "LogClearButton";
            this.LogClearButton.Size = new System.Drawing.Size(84, 22);
            this.LogClearButton.TabIndex = 4;
            this.LogClearButton.Text = "Log CLR";
            this.LogClearButton.UseVisualStyleBackColor = true;
            this.LogClearButton.Click += new System.EventHandler(this.LogClearButton_Click);
            // 
            // SimpleModeCheckBox
            // 
            this.SimpleModeCheckBox.AutoSize = true;
            this.SimpleModeCheckBox.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SimpleModeCheckBox.Location = new System.Drawing.Point(255, 1);
            this.SimpleModeCheckBox.Name = "SimpleModeCheckBox";
            this.SimpleModeCheckBox.Size = new System.Drawing.Size(67, 20);
            this.SimpleModeCheckBox.TabIndex = 0;
            this.SimpleModeCheckBox.TabStop = false;
            this.SimpleModeCheckBox.Text = "Simple";
            this.SimpleModeCheckBox.UseVisualStyleBackColor = true;
            this.SimpleModeCheckBox.CheckedChanged += new System.EventHandler(this.ModeChange);
            // 
            // DeviceName
            // 
            this.DeviceName.AutoSize = true;
            this.DeviceName.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.DeviceName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.DeviceName.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeviceName.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.DeviceName.Location = new System.Drawing.Point(7, 26);
            this.DeviceName.Name = "DeviceName";
            this.DeviceName.Size = new System.Drawing.Size(100, 20);
            this.DeviceName.TabIndex = 32;
            this.DeviceName.Text = "DeviceName";
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FileMenu,
            this.DeviceMenu,
            this.SettingMenu,
            this.HelpMenu});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(514, 24);
            this.menuStrip.TabIndex = 34;
            this.menuStrip.Text = "menuStrip1";
            // 
            // FileMenu
            // 
            this.FileMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.cMDPromptToolStripMenuItem,
            this.writeBothToolStripMenuItem,
            this.writeToolStripMenuItem,
            this.writeWWPROMToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.FileMenu.Name = "FileMenu";
            this.FileMenu.ShortcutKeyDisplayString = "Alt+B";
            this.FileMenu.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.B)));
            this.FileMenu.Size = new System.Drawing.Size(51, 20);
            this.FileMenu.Text = "&File(F)";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.openToolStripMenuItem.Text = "Open HEX file(&O)";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.MenuOpenFile);
            // 
            // cMDPromptToolStripMenuItem
            // 
            this.cMDPromptToolStripMenuItem.Name = "cMDPromptToolStripMenuItem";
            this.cMDPromptToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.cMDPromptToolStripMenuItem.Text = "CMD prompt(&P)";
            this.cMDPromptToolStripMenuItem.Click += new System.EventHandler(this.MenuCMDPrompt);
            // 
            // writeBothToolStripMenuItem
            // 
            this.writeBothToolStripMenuItem.Name = "writeBothToolStripMenuItem";
            this.writeBothToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.writeBothToolStripMenuItem.Text = "Write(&Both)";
            this.writeBothToolStripMenuItem.Click += new System.EventHandler(this.MenuWriteBoth);
            // 
            // writeToolStripMenuItem
            // 
            this.writeToolStripMenuItem.Name = "writeToolStripMenuItem";
            this.writeToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.writeToolStripMenuItem.Text = "Write(Flash)";
            this.writeToolStripMenuItem.Click += new System.EventHandler(this.MenuFlashWrite);
            // 
            // writeWWPROMToolStripMenuItem
            // 
            this.writeWWPROMToolStripMenuItem.Name = "writeWWPROMToolStripMenuItem";
            this.writeWWPROMToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.writeWWPROMToolStripMenuItem.Text = "Write(EEPROM)";
            this.writeWWPROMToolStripMenuItem.Click += new System.EventHandler(this.MenuWriteEEPROM);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.exitToolStripMenuItem.Text = "Exit(&X)";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.MenuExit);
            // 
            // DeviceMenu
            // 
            this.DeviceMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.readToolStripMenuItem,
            this.fuseInfoToolStripMenuItem});
            this.DeviceMenu.Name = "DeviceMenu";
            this.DeviceMenu.Size = new System.Drawing.Size(52, 20);
            this.DeviceMenu.Text = "&Device";
            // 
            // readToolStripMenuItem
            // 
            this.readToolStripMenuItem.Name = "readToolStripMenuItem";
            this.readToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.readToolStripMenuItem.Text = "Device Read";
            this.readToolStripMenuItem.Click += new System.EventHandler(this.MenuChipRead);
            // 
            // fuseInfoToolStripMenuItem
            // 
            this.fuseInfoToolStripMenuItem.Name = "fuseInfoToolStripMenuItem";
            this.fuseInfoToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.fuseInfoToolStripMenuItem.Text = "Fuse Info";
            this.fuseInfoToolStripMenuItem.Click += new System.EventHandler(this.MenuFuseInfo);
            // 
            // SettingMenu
            // 
            this.SettingMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hidspxexeToolStripMenuItem});
            this.SettingMenu.Name = "SettingMenu";
            this.SettingMenu.Size = new System.Drawing.Size(59, 20);
            this.SettingMenu.Text = "&Settings";
            // 
            // hidspxexeToolStripMenuItem
            // 
            this.hidspxexeToolStripMenuItem.Name = "hidspxexeToolStripMenuItem";
            this.hidspxexeToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.hidspxexeToolStripMenuItem.Text = "Set programmer";
            this.hidspxexeToolStripMenuItem.Click += new System.EventHandler(this.MenuSetupHIDSPX);
            // 
            // HelpMenu
            // 
            this.HelpMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fuseCalcToolStripMenuItem1,
            this.aVRDocumentToolStripMenuItem,
            this.hIDaspxToolStripMenuItem,
            this.hidspxTipsToolStripMenuItem,
            this.newsToolStripMenuItem});
            this.HelpMenu.Name = "HelpMenu";
            this.HelpMenu.Size = new System.Drawing.Size(40, 20);
            this.HelpMenu.Text = "&Help";
            // 
            // fuseCalcToolStripMenuItem1
            // 
            this.fuseCalcToolStripMenuItem1.Name = "fuseCalcToolStripMenuItem1";
            this.fuseCalcToolStripMenuItem1.Size = new System.Drawing.Size(171, 22);
            this.fuseCalcToolStripMenuItem1.Text = "FuseCalc";
            this.fuseCalcToolStripMenuItem1.Click += new System.EventHandler(this.MenuFuseCalc);
            // 
            // aVRDocumentToolStripMenuItem
            // 
            this.aVRDocumentToolStripMenuItem.Name = "aVRDocumentToolStripMenuItem";
            this.aVRDocumentToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.aVRDocumentToolStripMenuItem.Text = "AVR document";
            this.aVRDocumentToolStripMenuItem.Click += new System.EventHandler(this.MenuAVRDocument);
            // 
            // hIDaspxToolStripMenuItem
            // 
            this.hIDaspxToolStripMenuItem.Name = "hIDaspxToolStripMenuItem";
            this.hIDaspxToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.hIDaspxToolStripMenuItem.Text = "&HIDaspx";
            this.hIDaspxToolStripMenuItem.Click += new System.EventHandler(this.MenuHIDaspx);
            // 
            // hidspxTipsToolStripMenuItem
            // 
            this.hidspxTipsToolStripMenuItem.Name = "hidspxTipsToolStripMenuItem";
            this.hidspxTipsToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.hidspxTipsToolStripMenuItem.Text = "hidspx-&Tips";
            this.hidspxTipsToolStripMenuItem.Click += new System.EventHandler(this.MenuHidspxTips);
            // 
            // newsToolStripMenuItem
            // 
            this.newsToolStripMenuItem.Name = "newsToolStripMenuItem";
            this.newsToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.newsToolStripMenuItem.Text = "&News (Update info.)";
            this.newsToolStripMenuItem.Click += new System.EventHandler(this.MenuHELP);
            // 
            // toolTip1
            // 
            this.toolTip1.AutoPopDelay = 3000;
            this.toolTip1.InitialDelay = 500;
            this.toolTip1.ReshowDelay = 100;
            // 
            // button1
            // 
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(452, 43);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(53, 22);
            this.button1.TabIndex = 35;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // MainForm
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(514, 427);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.ChipButton);
            this.Controls.Add(this.SimpleModeCheckBox);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.DeviceName);
            this.Controls.Add(this.LogTextBox);
            this.Controls.Add(this.ProgressBar);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.LogClearButton);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.menuStrip);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.ChipEraseButton);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox9);
            this.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Text = "hidspx-GUI [ver ";
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.MainForm_DragDrop);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.DragEnter += new System.Windows.Forms.DragEventHandler(this.MainForm_DragEnter);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox EFuseTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox LFuseTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox HFuseTextBox;
        private System.Windows.Forms.Button WriteFuseButton;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox hidspxTextBox;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button ReadFlashButton;
        private System.Windows.Forms.Button FlashFileButton;
        private System.Windows.Forms.TextBox FlashFileTextBox;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button WriteEEPROMButton;
        private System.Windows.Forms.Button ReadEEPROMButton;
        private System.Windows.Forms.Button EEPROMFileButton;
        private System.Windows.Forms.TextBox EEPROMFileTextBox;
        private System.Windows.Forms.ProgressBar ProgressBar;
        private System.Windows.Forms.Button WriteFlashButton;
        private System.Windows.Forms.Button VerifyFlashButton;
        private System.Windows.Forms.OpenFileDialog OpenFileDialog;
        private System.Windows.Forms.Button hidspxButton;
        private System.Windows.Forms.SaveFileDialog SaveFileDialog;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox CommandLineOptionTextBox;
        private System.Windows.Forms.Button ChipEraseButton;
        private System.Windows.Forms.TextBox LockBitTextBox;
        private System.Windows.Forms.Button WriteLockBitButton;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button VerifyEEPROMButton;
        private System.Windows.Forms.TextBox LogTextBox;
        private System.Windows.Forms.Button ChipButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button EnterButton;
        private System.Windows.Forms.TextBox ParmTextBox;
        private System.Windows.Forms.Button LogClearButton;
        private System.Windows.Forms.CheckBox SimpleModeCheckBox;
        private System.Windows.Forms.Button HexDumpFlashMButton;
        private System.Windows.Forms.Label DeviceName;
        private System.Windows.Forms.Button HexDumpEEPROMButton;
        private System.Windows.Forms.Label ExtFuse;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem DeviceMenu;
        private System.Windows.Forms.ToolStripMenuItem readToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SettingMenu;
        private System.Windows.Forms.ToolStripMenuItem HelpMenu;
        private System.Windows.Forms.ToolStripMenuItem hIDaspxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hidspxTipsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hidspxexeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem FileMenu;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem writeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem writeWWPROMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem writeBothToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cMDPromptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fuseInfoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fuseCalcToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem aVRDocumentToolStripMenuItem;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button button1;
    }
}

