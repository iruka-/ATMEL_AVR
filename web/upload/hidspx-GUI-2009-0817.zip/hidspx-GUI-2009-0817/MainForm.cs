/* MainForm.cs */
/* Base:: avrdude-GUI */
/* modified by senshu */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;


namespace hidspxGUI {
    public partial class MainForm : Form {
        // add by senshu

        AutoCompleteStringCollection autoCompList;

        public int CmdLineNumber = 0;

        // 実行プログラム名
        private const string DEFAULT_PROGRAMMER = "hidspx.exe";

        // 現在に使用している実行プログラム名(no_extention)をセットする
        private string CURRENT_PROGRAMMER = "";

        // 256文字程度までの文字列を扱うことを仮定する
        StringBuilder CmdsString = new StringBuilder(256);

        private void log_put(string s) {
            LogTextBox.AppendText(s);
            show_last_line();
        }

        private void log_puts(string s) {
            CmdsString.Length = 0;  // 文字列を空にする
            CmdsString.Append("# ");
            CmdsString.Append(s);
            CmdsString.Append("\r\n");
            LogTextBox.AppendText(CmdsString.ToString());
            show_last_line();
        }

        private void cmd_echo(string s) {
            CmdsString.Length = 0;  // 文字列を空にする
            CmdsString.Append(s);
            CmdsString.Append("\r\n");
            LogTextBox.AppendText(CmdsString.ToString());
            show_last_line();
        }

        private void show_last_line() {
            //カレット位置を末尾に移動
            LogTextBox.SelectionStart = LogTextBox.Text.Length;

            //テキストボックスにフォーカスを移動
            LogTextBox.Focus();

            //カレット位置までスクロール
            LogTextBox.ScrollToCaret();
        }

        private bool CheckFileCount() {
            int files = 0;
            // ファイル指定を確認する
            if (File.Exists(FlashFileTextBox.Text)) files++;
            if (File.Exists(EEPROMFileTextBox.Text)) files++;

#if false
            if (files == 2 && SimpleModeCheckBox.Checked) {
                WriteFlashButton.Text = "Write(F/E)";
                return true;
            } else {
                WriteFlashButton.Text = "Write";
                return false;
            }
#else
            if (files == 2) {
                return true;
            } else {
                return false;
            }
#endif
        }

        private bool ReadFuseData() {
            string temp_fname;
            bool r_val = false;

            HFuseTextBox.Text = "";
            LFuseTextBox.Text = "";
            EFuseTextBox.Text = "";

            CheckFileCount();

            temp_fname = Path.GetTempFileName();
            File.Delete(temp_fname);
            /*
            ---- 「hidspx -rl」では、以下の形式の一行でFUSE情報を得ることができる ----
             device  Low:MSK   Hi:MSK  EXT:VAL  LOCK
            ATtiny26 E4:FF     F7:17   --:--     FF
             [0]     [1][2]    [3][4]  [5][6]    [7]
             */

            try {
                if (ExecCommand("-rl", 0, false, temp_fname) == 0) {
                    // fuse読み込み
                    if (File.Exists(temp_fname)) {
                        char[] delimiterChars = { ' ', ':' };
                        string data;
                        StreamReader sr = new StreamReader(temp_fname);
                        data = sr.ReadLine();
                        sr.Close();

                        DeviceName.Text = "";
                        LFuseTextBox.Text = "";
                        HFuseTextBox.Text = "";
                        EFuseTextBox.Text = "";
                        LockBitTextBox.Text = "";

                        if (data.Length > 10) {
                            string[] fuses = data.Split(delimiterChars);
                            if (fuses[0] != "--") {
                                DeviceName.Text = fuses[0];
                            }

                            if (fuses[1] != "--") {
                                LFuseTextBox.Text = fuses[1];
                            }

                            if (fuses[3] != "--") {
                                HFuseTextBox.Text = fuses[3];
                            }

                            if (fuses[5] != "--") {
                                EFuseTextBox.Text = fuses[5];
                            }

                            if (fuses[6] != "--") {
                                ExtFuse.Text = fuses[6];
                            }

                            if (fuses[7] != "--") {
                                LockBitTextBox.Text = fuses[7];
                            }
                            File.Delete(temp_fname);
                            r_val = true;
                        }
                    }
                }
                if (r_val == true) {
                    log_puts("Fuse Read ... [OK].");
                } else {
                    log_puts("Fuse Read ... [NG].");
                }
                return r_val;
            }
            catch (Exception ex) {
                //例外をキャッチした時、例外を説明するメッセージを表示
                log_puts(ex.Message);
                return false;
            }
        }

        private void SetFilename(string fullpath) {
            string ext;

            if (File.Exists(fullpath)) {
                ext = System.IO.Path.GetExtension(fullpath);

                if (ext.ToLower() == ".hex") {
                    FlashFileTextBox.Text = fullpath;
                } else if (ext.ToLower() == ".eep") {
                    EEPROMFileTextBox.Text = fullpath;
                } else if (ext.ToLower() == ".exe") {
                    // 未設定時は、DEFAULT_PROGRAMMERをセットする
                    if (System.IO.Path.GetFileName(fullpath).ToLower() == DEFAULT_PROGRAMMER) {
                        hidspxTextBox.Text = fullpath;
                    }
                }
            }

            if (File.Exists(FlashFileTextBox.Text)) {
                toolTip1.SetToolTip(FlashFileTextBox, FlashFileTextBox.Text);
            } else {
                toolTip1.SetToolTip(FlashFileTextBox, "Flash (No File)");
            }

            if (File.Exists(EEPROMFileTextBox.Text)) {
                toolTip1.SetToolTip(EEPROMFileTextBox, EEPROMFileTextBox.Text);
            } else {
                toolTip1.SetToolTip(EEPROMFileTextBox, "EEPROM (No File)");
            }
        }

        // hidspx.iniに登録されているuser_bookmarkの値を得る
        private bool GetUserBookmark() {
            string temp_fname;
            bool r_val = false;

            temp_fname = Path.GetTempFileName();
            File.Delete(temp_fname);
            /*
            ---- 「hidspx -!」では、以下の形式の一行でFUSE情報を得ることができる ----
          === user bookmarks ===
          --avrlibc4   = [http://www11.ocn.ne.jp/~akibow/AVR/avr-libc-user-manual-1.4.3/index.html]
          ：
          --Help       = [file://c:/bin/HIDaspx.pdf]
          --hidspx     = [file://c:/bin/avrx-tool.txt]
          --avrstudio  = [C:\PROGRA~1\ATMEL\AVRTOO~1\AVRSTU~1\AVRSTU~1.EXE]
             */

            try {
                if (ExecCommand("-!", 0, false, temp_fname) == 0) {

                    // Bookmark Listを読み込む

                    if (File.Exists(temp_fname)) {
                        char[] delimiterChars = { '=' };

                        string data;
                        StreamReader sr = new StreamReader(temp_fname);

                        while (!sr.EndOfStream) {
                            data = sr.ReadLine().Trim();

                            if (data.IndexOf("--") == 0) {
                                // 候補リストに項目を追加
                                string newItem;
                                string[] item = data.Split(delimiterChars);
                                newItem = item[0].Trim();
                                if (!String.IsNullOrEmpty(newItem) && !autoCompList.Contains(newItem)) {
                                    autoCompList.Add(newItem);
                                }
                            }
                        }
                        sr.Close();
                        File.Delete(temp_fname);
                        r_val = true;
                    }
                }
                if (r_val == true) {
                    log_puts("Get user_bookmark ... [OK].");
                } else {
                    log_puts("Get user_bookmark ... [NG].");
                }
                return r_val;
            }
            catch (Exception ex) {
                //例外をキャッチした時、例外を説明するメッセージを表示
                log_puts(ex.Message);
                return false;
            }
        }

        // Command Executeは[Enter]キーで実行する
        private void Enter_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e) {
            if (e.KeyCode == Keys.Enter) {
                EnterButton.PerformClick();
                ParmTextBox.Focus();
                ParmTextBox.SelectionStart = ParmTextBox.Text.Length;
            }

        }

        // Drag and Drop対応ハンドラー
        private void MainForm_DragEnter(object sender, DragEventArgs e) {
            if (e.Data.GetDataPresent(DataFormats.FileDrop)) {
                // ドラッグ中のファイルやディレクトリの取得
                string[] drags = (string[])e.Data.GetData(DataFormats.FileDrop);

                foreach (string d in drags) {
                    if (!System.IO.File.Exists(d)) {
                        // ファイル以外であればイベント・ハンドラを抜ける
                        return;
                    }
                }
                e.Effect = DragDropEffects.Copy;
            }
        }

        private void MainForm_DragDrop(object sender, DragEventArgs e) {
            // ドラッグ＆ドロップされたファイル
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            for (int i = 0; i < files.Length; i++) {
                SetFilename(files[i]);
            }
            CheckFileCount();
            this.Activate();
        }

        /// <summary>
        /// DEFAULT_PROGRAMMER ファイル選択ボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void hidspxSelectButton(object sender, EventArgs e) {
            OpenFileDialog.CheckFileExists = true;
            OpenFileDialog.Filter = DEFAULT_PROGRAMMER + "|*spx*.exe";
            OpenFileDialog.FileName = "";
            OpenFileDialog.Title = "Select " + DEFAULT_PROGRAMMER + " File";
            OpenFileDialog.ShowDialog();
            if (OpenFileDialog.FileName.Length > 0) {
                hidspxTextBox.Text = OpenFileDialog.FileName;
                // 指定したコマンドのHelpメッセージを表示
                hidspxInfo();
            }
        }

        /// <summary>
        /// チップ消去ボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChipEraseButton_Click(object sender, EventArgs e) {
            if (MessageBox.Show("All the settings and data in the device are deleted. Is it good ?", this.Text,
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
                == DialogResult.Yes) {
                if (ExecCommand("-e", 0, false, "") == 0) {
                    log_puts("Chip Erase ... [OK].");
                } else {
                    log_puts("Chip Erase ... [NG].");
                }
            }
        }

        /// <summary>
        /// CMD prompt 起動ボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CMDpromptButton_Click(object sender, EventArgs e) {
            string dir;

            if (FlashFileTextBox.Text.Length != 0) {
                dir = Path.GetDirectoryName(FlashFileTextBox.Text);
            } else if (EEPROMFileTextBox.Text.Length != 0) {
                dir = Path.GetDirectoryName(EEPROMFileTextBox.Text);
            } else {
                MessageBox.Show("Select Hex File", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                hidspxButton.Focus();
                return;
            }

            System.Diagnostics.Process prc = null;
            System.Diagnostics.ProcessStartInfo psi = new System.Diagnostics.ProcessStartInfo();
            psi.FileName = System.Environment.GetEnvironmentVariable("comspec");
            psi.Arguments = " /f:on /K \"cd /d" + dir + "\" ";
            prc = System.Diagnostics.Process.Start(psi);
            //prc.WaitForExit();
        }

        private void ChipButton_Click(object sender, EventArgs e) {
            bool res = false;
            SetFilename("");    // Hint情報を更新
            if (ExecCommand("-r", 0, false, "") == 0) {
                ReadFuseData();
                if (ExecCommand("-rf", 0, false, "") == 0) {
                    res = true;
                }
            }

            if (res == true) {
                log_puts("Chip status ... [OK].");
            } else {
                log_puts("Chip status ... [NG].");
            }
        }

        /// <summary>
        /// ヒューズ読み込みボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ReadFuseButton_Click(object sender, EventArgs e) {
            ReadFuseData();
        }

        /// <summary>
        /// ヒューズ書き込みボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WriteFuseButton_Click(object sender, EventArgs e) {

            Regex reg = new Regex("^[0-9A-Fa-f]{2}$");

            if ((HFuseTextBox.Text.Length > 0) && (reg.Match(HFuseTextBox.Text).Success == false)) {
                MessageBox.Show("Please Set hfuse by the hexadecimal number of 2 charactors. ",
                    this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                HFuseTextBox.Focus();
                return;
            }
            if ((LFuseTextBox.Text.Length > 0) && (reg.Match(LFuseTextBox.Text).Success == false)) {
                MessageBox.Show("Please Set lfuse by the hexadecimal number of 2 charactors. ",
                    this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                LFuseTextBox.Focus();
                return;
            }
            if ((EFuseTextBox.Text.Length > 0) && (reg.Match(EFuseTextBox.Text).Success == false)) {
                MessageBox.Show("Please Set efuse by the hexadecimal number of 2 charactors. ",
                    this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                EFuseTextBox.Focus();
                return;
            }
            if ((HFuseTextBox.Text.Length == 0) && (LFuseTextBox.Text.Length == 0) && (EFuseTextBox.Text.Length == 0)) {
                MessageBox.Show("Please Set hfuse, lfuse or efuse.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            if (MessageBox.Show("Fuses is ReWritten. Is it good ?",
                this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
                != DialogResult.Yes) {
                return;
            }
#if true
		  
            string arg = "-d30";
#else
            string arg = "-d10";
#endif
            if (LFuseTextBox.Text.Length > 0) {
                arg += " -fL0x" + LFuseTextBox.Text;
            }
            if (HFuseTextBox.Text.Length > 0) {
                arg += " -fH0x" + HFuseTextBox.Text;
            }
            if (EFuseTextBox.Text.Length > 0) {
                arg += " -fX0x" + EFuseTextBox.Text;
            }

            if (ExecCommand(arg, 0, false, "") == 0) {
                log_puts("Fuse Write ... [OK].");
            } else {
                log_puts("Fuse Write ... [NG].");
            }
        }

        /// <summary>
        /// ロックビット書き込みボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WriteLockBitButton_Click(object sender, EventArgs e) {
            Regex reg = new Regex("^[0-9A-Fa-f]{2}$");

            if (LockBitTextBox.Text.Length == 0) {
                MessageBox.Show("Please Set Lock bit.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            if (reg.Match(LockBitTextBox.Text).Success == false) {
                MessageBox.Show("Please Set Lock bit by the hexadecimal number of 2 charactors. ",
                    this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                LockBitTextBox.Focus();
                return;
            }

            if (MessageBox.Show("Lock bit is ReWritten. Is it good ?",
                this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
                != DialogResult.Yes) {
                return;
            }

            if (ExecCommand("-l0x" + LockBitTextBox.Text, 0, false, "") == 0) {
                log_puts("Lock Bit Write ... [OK].");
            } else {
                log_puts("Lock Bit Write ... [NG].");
            }
        }

        /// <summary>
        /// Flash ファイル選択ボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FlashFileButton_Click(object sender, EventArgs e) {

            OpenFileDialog.CheckFileExists = false;
            OpenFileDialog.AddExtension = true;
            OpenFileDialog.DefaultExt = "hex";
            OpenFileDialog.Filter = "Intel Hex File(*.hex)|*.hex|All File(*.*)|*.*";
            OpenFileDialog.FileName = "";
            OpenFileDialog.ShowDialog();
            if (OpenFileDialog.FileName.Length > 0) {
                SetFilename(OpenFileDialog.FileName);
            }
        }

        /// <summary>
        /// Flash 読み込みボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ReadFlashButton_Click(object sender, EventArgs e) {
            if (FlashFileTextBox.Text.Length > 0) {
                if (File.Exists(FlashFileTextBox.Text)) {
                    if (MessageBox.Show("File Exists. Is it good ?",
                            this.Text, MessageBoxButtons.YesNo,
                            MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
                        != DialogResult.Yes) {
                        return;
                    }
                }
            } else {
                SaveFileDialog.AddExtension = true;
                SaveFileDialog.DefaultExt = "hex";
                SaveFileDialog.FileName = "";
                SaveFileDialog.Filter = "Hex File (*.hex)|*.hex|All File (*.*)|*.*";
                SaveFileDialog.OverwritePrompt = true;
                SaveFileDialog.Title = "Save Flash data";
                SaveFileDialog.ValidateNames = true;
                if (SaveFileDialog.ShowDialog() != DialogResult.OK) {
                    // 書き込みを望まない
                    return;
                } else {
                    SetFilename(SaveFileDialog.FileName);
                }

            }
            this.Refresh();
            if (ExecCommand("-rp", 50, false, FlashFileTextBox.Text) == 0) {
                log_puts("Flash Read and Save ... [OK].");
            } else {
                log_puts("Flash Read and Save ... [NG].");
            }
        }

        /// <summary>
        /// Flash 書き込みボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WriteOnlyFlashButton_Click(object sender, EventArgs e) {

            if (FlashFileTextBox.Text.Length == 0) {
                MessageBox.Show("Select Flash file", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                FlashFileButton.Focus();
                return;
            }
            if (!File.Exists(FlashFileTextBox.Text)) {
                MessageBox.Show("File not found", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                FlashFileButton.Focus();
                return;
            }

            if (ExecCommand("-v- \"" + FlashFileTextBox.Text + "\"", 50, false, "") == 0) {
                log_puts("Flash Write (No Verify) ... [OK].");
            } else {
                log_puts("Flash Write (No Verify) ... [NG].");
            }

        }

        /// <summary>
        /// Flash Verifyボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void VerifyFlashButton_Click(object sender, EventArgs e) {

            if (FlashFileTextBox.Text.Length == 0) {
                MessageBox.Show("Select Flash file", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                FlashFileButton.Focus();
                return;
            }
            if (!File.Exists(FlashFileTextBox.Text)) {
                MessageBox.Show("File not found", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                FlashFileButton.Focus();
                return;
            }

            if (ExecCommand("-v \"" + FlashFileTextBox.Text + "\"", 50, false, "") == 0) {
                log_puts("Flash Verify ... [OK].");
            } else {
                log_puts("Flash Verify ... [NG].");
            }

        }

        /// <summary>
        /// Flash Erase - Write - Verify ボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WriteFlashButton_Click(object sender, EventArgs e) {
            bool both_write = CheckFileCount();

            if (FlashFileTextBox.Text.Length == 0) {
                MessageBox.Show("Select Flash file", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                FlashFileButton.Focus();
                return;
            }
            if (!File.Exists(FlashFileTextBox.Text)) {
                MessageBox.Show("File not found", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                FlashFileButton.Focus();
                return;
            }

            if (SimpleModeCheckBox.Checked) {
                ChipButton_Click(sender, e);
            }

            this.Refresh();
            if (ExecCommand("\"" + FlashFileTextBox.Text + "\"", 100, false, "") == 0) {
                log_puts("Flash Write ... [OK].");
            } else {
                log_puts("Flash Write ... [NG].");
            }

#if false
            if (SimpleModeCheckBox.Checked && both_write) {
                WriteEEPROMButton_Click(sender, e);
            }
#endif
        }

        /// <summary>
        /// EEPROM ファイル選択ボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EEPROMFileButton_Click(object sender, EventArgs e) {

            OpenFileDialog.CheckFileExists = false;
            OpenFileDialog.AddExtension = true;
            OpenFileDialog.DefaultExt = "eep";
            OpenFileDialog.Filter = "EEPROM File(*.eep)|*.eep|All File(*.*)|*.*";
            OpenFileDialog.FileName = "";
            OpenFileDialog.ShowDialog();
            if (OpenFileDialog.FileName.Length > 0) {
                SetFilename(OpenFileDialog.FileName);
            }
        }

        /// <summary>
        /// EEPROM 読み込みボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ReadEEPROMButton_Click(object sender, EventArgs e) {
            if (EEPROMFileTextBox.Text.Length > 0) {
                if (File.Exists(EEPROMFileTextBox.Text)) {
                    if (MessageBox.Show("File Exists. Is it good ?",
                            this.Text, MessageBoxButtons.YesNo,
                            MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
                        != DialogResult.Yes) {
                        return;
                    }
                }
            } else {
                SaveFileDialog.AddExtension = true;
                SaveFileDialog.DefaultExt = "eep";
                SaveFileDialog.FileName = "";
                SaveFileDialog.Filter = "EEPROM File (*.eep)|*.eep|All File (*.*)|*.*";
                SaveFileDialog.OverwritePrompt = true;
                SaveFileDialog.Title = "Save EEPROM data";
                SaveFileDialog.ValidateNames = true;
                if (SaveFileDialog.ShowDialog() != DialogResult.OK) {
                    // 書き込みを望まない
                    return;
                } else {
                    SetFilename(SaveFileDialog.FileName);
                }
            }
            this.Refresh();
            if (ExecCommand("-re", 50, false, EEPROMFileTextBox.Text) == 0) {
                log_puts("EEPROM Read and Save ... [OK].");
            } else {
                log_puts("EEPROM Read and Save ... [NG].");
            }
        }

        /// <summary>
        /// EEPROM 書き込みボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WriteEEPROMButton_Click(object sender, EventArgs e) {

            if (EEPROMFileTextBox.Text.Length == 0) {
                MessageBox.Show("Select EEPROM file", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                EEPROMFileButton.Focus();
                return;
            }
            if (!File.Exists(EEPROMFileTextBox.Text)) {
                MessageBox.Show("File not found", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                EEPROMFileButton.Focus();
                return;
            }

            if (ExecCommand("\"" + EEPROMFileTextBox.Text + "\"", 50, false, "") == 0) {
                log_puts("EEPROM Write ... [OK].");
            } else {
                log_puts("EEPROM Write ... [NG].");
            }

        }

        private void VerifyEEPROMButton_Click(object sender, EventArgs e) {
            if (EEPROMFileTextBox.Text.Length == 0) {
                MessageBox.Show("Select EEPROM file", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                EEPROMFileButton.Focus();
                return;
            }
            if (!File.Exists(EEPROMFileTextBox.Text)) {
                MessageBox.Show("File not found", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                EEPROMFileButton.Focus();
                return;
            }

            if (ExecCommand("-v \"" + EEPROMFileTextBox.Text + "\"", 50, false, "") == 0) {
                log_puts("EEPROM Verify ... [OK].");
            } else {
                log_puts("EEPROM Verify ... [NG].");
            }

        }

        private void Both_write_Click(object sender, EventArgs e) {
            if (File.Exists(FlashFileTextBox.Text)) {
                WriteFlashButton_Click(sender, e);
            }
            if (File.Exists(EEPROMFileTextBox.Text)) {
                WriteEEPROMButton_Click(sender, e);
            }
        }

        /// <summary>
        /// 終了ボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ExitButton_Click(object sender, EventArgs e) {
            Application.Exit();
        }

        /// <summary>
        /// メインフォームコンストラクタ
        /// </summary>
        /// ==== Form LOAD ====
        public MainForm(string[] args) {
            string dir, prog_path, exec_path = Application.ExecutablePath;

            dir = Path.GetDirectoryName(exec_path);
            prog_path = dir + "\\" + DEFAULT_PROGRAMMER;

            InitializeComponent();

            for (int i = 0; i < args.Length; i++) {
                string fullpath, fname;

                fname = args[i];

                try {
                    fullpath = System.IO.Path.GetFullPath(fname);
                }
                catch {
                    fullpath = "";   // 無視する
                }
                if (fullpath.Length > 0) {
                    SetFilename(fullpath);
                }

            }
            // ユーザ設定復元
            // 1回目の起動時は、hidspx-GUI.exeのある場所からDEFAULT_PROGRAMMERを探す
            if (hidspxGUI.Default.hidspx.Length == 0) {
                if (hidspxTextBox.Text.Length == 0) {
                    if (File.Exists(prog_path)) {
                        hidspxTextBox.Text = prog_path;
                    } else {
                        hidspxTextBox.Text = DEFAULT_PROGRAMMER;
                    }
                }
            } else {
                hidspxTextBox.Text = hidspxGUI.Default.hidspx;
            }

            // DEFAULT_PROGRAMMERのHelpメッセージ表示
            if (File.Exists(hidspxTextBox.Text.ToString())) {
                hidspxInfo();

                autoCompList = new AutoCompleteStringCollection();
                ParmTextBox.AutoCompleteCustomSource = autoCompList;

                // 候補リストに項目を追加（初期設定）
                autoCompList.AddRange(
                    new string[] {
                        "-r", "-rl", "-rF", "-ri", "-rI", "-rd", 
                        "--avr-devices", "--atmel-avr",                
                    }
                );
                GetUserBookmark();
            }

            CommandLineOptionTextBox.Text = hidspxGUI.Default.CommandLineOption;

            // add by senshu
            if (args.Length == 0) {
                SetFilename(hidspxGUI.Default.FlashFile);
                SetFilename(hidspxGUI.Default.EEPROMFile);
            }

            // タイトルバー文字列
            this.Text += Application.ProductVersion;
            this.Text = this.Text.Substring(0, this.Text.LastIndexOf('.')); // バージョン番号末尾削除
            this.Text += "]";

            SimpleModeCheckBox.Checked = hidspxGUI.Default.SimpleMode;

            // add by senshu
            this.ActiveControl = this.ChipButton;
            if (ReadFuseData() == false) {
                DeviceName.Text = "Not Connect";
            }

            CheckFileCount();

        }

        /// <summary>
        /// Form Closed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainForm_FormClosed(object sender, FormClosedEventArgs e) {
            // ユーザ設定保存
            hidspxGUI.Default.hidspx = hidspxTextBox.Text;
            hidspxGUI.Default.CommandLineOption = CommandLineOptionTextBox.Text;
            hidspxGUI.Default.FlashFile = FlashFileTextBox.Text;
            hidspxGUI.Default.EEPROMFile = EEPROMFileTextBox.Text;
            hidspxGUI.Default.SimpleMode = SimpleModeCheckBox.Checked;
            hidspxGUI.Default.Save();
        }

        private void EnterButton_Click(object sender, EventArgs e) {
            // 候補リストに項目を追加
            string newItem = ParmTextBox.Text.Trim();

            if (!String.IsNullOrEmpty(newItem) && !autoCompList.Contains(newItem)) {
                autoCompList.Add(newItem);
            }

            ParmTextBox.Text = ParmTextBox.Text.Trim();

            if (ParmTextBox.Text.Length > 0) {
                bool no_wait = false;
                int sharp_counts = 0;

                switch (ParmTextBox.Text) {
                    // 実行終了を待たないオプションをチェックする
                    case "-ri":
                    case "-rI":
                    case "-rd":
                    case "--avr-devices":
                    case "--atmel-avr":
                        no_wait = true;
                        break;

                    case "-rp":
                    case "-rph":
                    case "-re":
                    case "-reh":
                        sharp_counts = 50;
                        break;
                }
                // bookmarkのチェック（--で始まり、3文字以降に-が無いものはBookmark）
                if (ParmTextBox.Text.StartsWith("--")) {
                    if (ParmTextBox.Text.IndexOf('-', 3) < 0) {
                        no_wait = true;
                    }
                }
                if (ExecCommand(ParmTextBox.Text, sharp_counts, no_wait, "") == 0) {
                    System.Windows.Forms.Cursor cur = System.Windows.Forms.Cursor.Current;
                    if (no_wait) {
                        System.Windows.Forms.Cursor.Current = Cursors.WaitCursor;   // 砂時計カーソル
                        //ミリ秒、停止する
                        System.Threading.Thread.Sleep(3000);
                        System.Windows.Forms.Cursor.Current = cur;  // カーソルを戻す
                    }
                    log_puts("Command execute ... [OK].");
                } else {
                    log_puts("Command execute ... [NG].");
                }
            }

        }

        /// <summary>
        /// DEFAULT_PROGRAMMERのバージョン表示
        /// </summary>
        /// <returns></returns>
        private void hidspxInfo() {
            //this.Refresh();
            if (ExecCommand("-h", 0, false, "") == 0) {
                log_puts("Version Check ... [OK].");
            } else {
                log_puts("Version Check ... [NG].");
            }
        }

        /// <summary>
        /// プログラマにオプション文字列を追加する
        /// </summary>
        /// <returns></returns>
        private string GetOptions() {
            string arg = "";

            // コマンドラインの追加パラメータ 
            CommandLineOptionTextBox.Text = CommandLineOptionTextBox.Text.Trim();
            if (CommandLineOptionTextBox.Text.Length > 0) {
                arg += " " + CommandLineOptionTextBox.Text + " ";
            }

            return arg;
        }

        /// <summary>
        /// DEFAULT_PROGRAMMER 実行開始
        /// </summary>
        /// <param name="arg">実行時の引数</param>
        /// <returns>Processオブジェクト</returns>
        private System.Diagnostics.Process hidspx(string arg) {
            if (hidspxTextBox.Text.Length == 0) return null;

            System.Diagnostics.Process prc;
            try {
                System.Diagnostics.ProcessStartInfo psi = new System.Diagnostics.ProcessStartInfo();
                psi.FileName = hidspxTextBox.Text;
                psi.RedirectStandardOutput = true;   // 標準出力を取り込む
                psi.RedirectStandardError = true;   // 標準エラー出力を取り込む
                psi.CreateNoWindow = true;          // ウインドウ表示しない
                psi.UseShellExecute = false;        // 必須
                psi.Arguments = arg;                // 引数
                prc = System.Diagnostics.Process.Start(psi);
            }
            catch {
                prc = null;
            }
            return prc;
        }

        /// <summary>
        /// DEFAULT_PROGRAMMER コマンド実行 (@@@)
        /// </summary>
        /// <param name="arg">hidspxの引数</param>
        /// <param name="maxProgress">hidspxの出力文字列中の # の数(=プログレスバーの最大値)</param>
        /// <param name="ignoreError">== true : エラーが発生してもエラーダイアログを表示しない</param>
        /// <returns>hidspxの戻り値</returns>
        private int ExecCommand(string arg, int maxProgress, bool no_wait, string filename) {
            string temp_stdout_file, temp_arg_fname;

            if (hidspxTextBox.Text.Length == 0) {
                MessageBox.Show("Select " + DEFAULT_PROGRAMMER + " File", this.Text,
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                hidspxButton.Focus();
                return 0;
            }
            // 使用するPROGRAM名をセットする
            CURRENT_PROGRAMMER = System.IO.Path.GetFileNameWithoutExtension(hidspxTextBox.Text);

            System.Windows.Forms.Cursor cur = System.Windows.Forms.Cursor.Current;

            try {
                System.Windows.Forms.Cursor.Current = Cursors.WaitCursor;   // 砂時計カーソル

                System.Diagnostics.ProcessStartInfo psi = new System.Diagnostics.ProcessStartInfo();
                psi.Arguments = "";

                // 通常モード
                psi.FileName = hidspxTextBox.Text;

                // Window表示なし

                // add by senshu
                if (filename == "") {
                    // テンポラリで作業する
                    psi.WorkingDirectory = Environment.GetEnvironmentVariable("temp");

                    // ファイル指定がない場合には、一時ファイルを生成する
                    temp_stdout_file = Path.GetTempFileName();
                    File.Delete(temp_stdout_file);
                } else {
                    temp_stdout_file = filename;
                }

                if (no_wait) {
                    temp_stdout_file = filename = "NUL";
                }

                if (temp_stdout_file.Substring(0, 1) != "\"" && temp_stdout_file.IndexOf(" ") >= 0) {
                    // 空白ありのファイル名は、""で囲む
                    temp_arg_fname = "\"" + temp_stdout_file + "\"";
                } else {    // 空白なしなら、そのまま利用する
                    temp_arg_fname = temp_stdout_file;
                }

                psi.Arguments += GetOptions() + arg;

                psi.Arguments += " -o" + temp_arg_fname;

                log_put("> " + CURRENT_PROGRAMMER + " ");

                //cmd_echo(psi.Arguments);
                if ((filename == "")
                    || psi.Arguments.IndexOf("-rl -o") >= 0
                    || psi.Arguments.IndexOf("-! -o") >= 0) {
                    string cmd_string;

                    // 出力FILE指定がない時と、'-rl -oXXX'は、ファイル名を表示しない
                    int pos = psi.Arguments.IndexOf(" -o");

                    if (pos < 0) {
                        cmd_string = psi.Arguments;
                    } else {
                        cmd_string = psi.Arguments.Substring(0, pos);
                    }
                    cmd_echo(cmd_string.Trim());
                } else {
                    // 出力FILE指定がある時には、そのファイル名を表示する
                    cmd_echo(psi.Arguments.Replace("-oNUL", ""));
                }

                psi.CreateNoWindow = true;          // Window表示しない
                psi.RedirectStandardOutput = true;  // ファイル経由で標準out出力を受け取る
                psi.RedirectStandardError = true;   // 標準error出力を取り込む
                psi.UseShellExecute = false;        // 必須


                // hidspx起動
#if false       // DEBUG用
                MessageBox.Show(psi.Arguments, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                ProgressBar.Value = 0;
                return 0;
#else
                DateTime dtStart, dtNow;

                dtStart = DateTime.Now;
                //cmd_echo("Exec > hidpsx " + psi.Arguments);  // for Debug

                System.Diagnostics.Process prc = System.Diagnostics.Process.Start(psi);

                StringBuilder sb = new StringBuilder(1024 * 16);
                if (!no_wait) {
                    // 標準エラーを取得する
                    ProgressBar.Maximum = maxProgress;
                    ProgressBar.Value = 0;

                    while (!prc.StandardError.EndOfStream) {
                        int c, diff;
                        dtNow = DateTime.Now;

                        diff = dtNow.Second - dtStart.Second;
                        if (diff < 0) diff += 60;

                        if (diff > 5) {
                            // 開始後、5秒以上の処理時間を要する場合には、
                            // フォームを無効にしてボタンの押下を無効にする
                            this.Enabled = false;
                        }
                        c = prc.StandardError.Read();
                        // # が出力されたらプログレスバーを進める
                        if ((c == (int)'#') && (ProgressBar.Value < ProgressBar.Maximum)) {
                            ProgressBar.Value += 1;

                            // メッセージ・キューにあるWindowsメッセージをすべて処理する
                            Application.DoEvents();
                        }
                        sb.Append((char)c); // 出力メッセージを取得する
                    }
                    // フォームを有効に戻す
                    this.Enabled = true;

                    // 終了を待つ
                    prc.WaitForExit();
                    System.Windows.Forms.Cursor.Current = cur;  // カーソルを戻す

                    if (prc.ExitCode != 0) {
                        // エラーが発生したので出力メッセージを表示する
                        System.Media.SystemSounds.Asterisk.Play();  // チャイム音？
                        log_put(sb.ToString());

                        File.Delete(temp_stdout_file);
                        ProgressBar.Value = 0;
                        return 1;
                    }
                }
                // 正常時も、stderr を表示
                log_put(sb.ToString());

                // -------------------------------------
                // stdout を取得する
                if (!no_wait) {
                    sb.Length = 0;  // sbをクリア

                    System.IO.FileInfo fi = new System.IO.FileInfo(temp_stdout_file);

                    //ファイルのサイズを取得
                    if (filename == "" && File.Exists(temp_stdout_file)) {
                        // ←文字コードをSHIT_JISに指定
                        Encoding enc = System.Text.Encoding.GetEncoding("Shift_jis");
                        StreamReader sr = new StreamReader(temp_stdout_file, enc);
                        while (!sr.EndOfStream) {
                            sb.Append(sr.ReadLine() + "\r\n");
                        }
                        log_put(sb.ToString());
                        sr.Close();
                        File.Delete(temp_stdout_file);
                    }
                }

                ProgressBar.Value = 0;
                return 0;
#endif
            }
#pragma warning disable 168 // 警告メッセージを抑止する
            catch (ArgumentException ex) {
                // -re, -rp で発生する例外は、無視する。
#if false
                // 詳細なメッセージは利用者を不安にするため、コメント化する
                log_puts("An exception is ignored. (" + ex.Message + ")");
#endif
                System.Windows.Forms.Cursor.Current = cur;  // カーソルを戻す
                ProgressBar.Value = 0;
                return 0;
            }
#pragma warning restore 168
            catch (Exception ex) {
                //例外をキャッチした時、例外を説明するメッセージを表示
                //空の文字列を返す
                log_puts(ex.Message);
                System.Windows.Forms.Cursor.Current = cur;  // カーソルを戻す
                ProgressBar.Value = 0;
                return 1;
            }
        }

        /* add by senshu */
        private void FuseViewButton_Click(object sender, EventArgs e) {
            if (ReadFuseData() == true) {
                if (ExecCommand("-rI", 0, true, "") == 0) {
                    log_puts("Open Fuse Calc ... [OK].");
                } else {
                    log_puts("Open Fuse Calc ... [NG].");
                }
            }
        }

        private void HelpButtonClick(object sender, EventArgs e) {
            string url = "http://www-ice.yamagata-cit.ac.jp/ken/senshu/sitedev/index.php?AVR%2FHIDaspx00";

            // add by senshu
            try {
                log_puts("start " + url);
                System.Diagnostics.Process.Start(url);
            }
            catch {
                log_puts("Web browser Start error.");
            }
        }

        private void AVRdocButton_Click(object sender, EventArgs e) {
            if (ReadFuseData() == true) {
                if (ExecCommand("-rd", 0, true, "") == 0) {
                    log_puts("Open Web (AVR documents) ... [OK].");
                } else {
                    log_puts("Open Web (AVR documents) ... [NG].");
                }
            }
        }

        private void LogClearButton_Click(object sender, EventArgs e) {
            LogTextBox.Clear();
            show_last_line();
        }

        private void ModeChange(object sender, EventArgs e) {
            if (SimpleModeCheckBox.Checked) {   // Simple
                groupBox1.Enabled = false;
                groupBox7.Enabled = false;   // Lock bit
                groupBox9.Enabled = false;      // Command line option
                //groupBox9.Hide();            // Command options
                CommandLineOptionTextBox.ReadOnly = true;
                ChipEraseButton.Enabled = false;
                WriteFuseButton.Enabled = false;
                ReadFlashButton.Enabled = false;
                ReadEEPROMButton.Enabled = false;

                LogTextBox.Width = ProgressBar.Width = 402;
                CommandLineOptionTextBox.Width = 76;
                this.Width = 420;
                this.Height = 390;
            } else {   // Normal
                groupBox1.Enabled = true;
                groupBox7.Enabled = true;
                groupBox9.Enabled = true;   // Command line option
                ChipEraseButton.Enabled = true;
                CommandLineOptionTextBox.ReadOnly = false;

                ChipEraseButton.Enabled = true;
                WriteFuseButton.Enabled = true;
                ReadFlashButton.Enabled = true;
                ReadEEPROMButton.Enabled = true;

                LogTextBox.Width = ProgressBar.Width = 504;
                CommandLineOptionTextBox.Width = 166;
                this.Width = 520;

                this.Height = 450;
            }
        }

        private void HexDumpFlashButton_Click(object sender, EventArgs e) {
            this.Refresh();
            if (ExecCommand("-rph", 50, false, "") == 0) {
                log_puts("Flash HEX dump ... [OK].");
            } else {
                log_puts("Flash HEX dump ... [NG].");
            }
        }

        private void HexDumpEEPROMButton_Click(object sender, EventArgs e) {
            this.Refresh();
            if (ExecCommand("-reh", 50, false, "") == 0) {
                log_puts("EEPROM HEX dump ... [OK].");
            } else {
                log_puts("EEPROM HEX dump ... [NG].");
            }
        }

        // Menu function
        private void MenuOpenFile(object sender, EventArgs e) {
            FlashFileButton_Click(sender, e);
        }

        private void MenuCMDPrompt(object sender, EventArgs e) {
            CMDpromptButton_Click(sender, e);
        }

        private void MenuWriteBoth(object sender, EventArgs e) {
            Both_write_Click(sender, e);
        }

        private void MenuFlashWrite(object sender, EventArgs e) {
            WriteFlashButton_Click(sender, e);
        }

        private void MenuWriteEEPROM(object sender, EventArgs e) {
            WriteEEPROMButton_Click(sender, e);
        }

        private void MenuExit(object sender, EventArgs e) {
            ExitButton_Click(sender, e);
        }

        private void MenuChipRead(object sender, EventArgs e) {
            ReadFuseButton_Click(sender, e);
        }

        private void MenuFuseInfo(object sender, EventArgs e) {
            ChipButton_Click(sender, e);
        }

        private void MenuSetupHIDSPX(object sender, EventArgs e) {
            hidspxSelectButton(sender, e);
        }

        private void MenuFuseCalc(object sender, EventArgs e) {
            FuseViewButton_Click(sender, e);
        }

        private void MenuAVRDocument(object sender, EventArgs e) {
            AVRdocButton_Click(sender, e);
        }

        private void MenuHIDaspx(object sender, EventArgs e) {
            string url = "http://www-ice.yamagata-cit.ac.jp/ken/senshu/sitedev/index.php?AVR%2FHIDaspx";

            // add by senshu
            try {
                log_puts("start " + url);
                System.Diagnostics.Process.Start(url);
            }
            catch {
                log_puts("Web browser Start error.");
            }
        }

        private void MenuHidspxTips(object sender, EventArgs e) {
            string url = "http://www-ice.yamagata-cit.ac.jp/ken/senshu/sitedev/index.php?AVR%2Fhidspx_tips";

            // add by senshu
            try {
                log_puts("start " + url);
                System.Diagnostics.Process.Start(url);
            }
            catch {
                log_puts("Web browser Start error.");
            }
        }

        private void MenuHELP(object sender, EventArgs e) {
            HelpButtonClick(sender, e);
        }

    }
}
