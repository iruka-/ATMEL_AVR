// -*- C++ -*- forwarding header.

#ifndef __NEW_H__
#define __NEW_H__

#include <new>

#ifdef __HONOR_STD
using std::new_handler;
using std::set_new_handler;
#endif

#endif // __NEW_H__
