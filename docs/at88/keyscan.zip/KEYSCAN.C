/*	for Turbo-C or Borland-C */

#include <dos.h>

void tputc(int c)
{
	_AL = c;
	_AH = 0x0e;
	_BX =0;
	__int__(0x10);
}

void tputh1(int c)
{
	c &= 0x0f;
	if(c>=10) c+=7;
	tputc(c + '0');
}

void tputh2(int c)
{
	tputh1(c>>4);
	tputh1(c);
}

void tputs(char *s)
{
	while(*s) {
		tputc(*s++);
	}
}



int get_8042(void)
{
	while ( (inp(0x64) & 1)==0) ;

	return inp(0x60);
}

int put_8042(int data)
{
	while( inp(0x64) & 2 );

	outp(0x60,data);
}

int cmd_8042(int data)
{
	while( inp(0x64) & 2 );

	outp(0x64,0x60);

	while( inp(0x64) & 2 );

	outp(0x60,data);
}

void scan_8042(void)
{
	int c;
	_disable();
	while(1) {
		c = get_8042();
		tputh2(c);
		tputc(' ');
		if(c==0x76) break;	// [ESC]
	}
	_enable();
}

int	main()
{
	tputs("Hello,\r\nWorld.");
	cmd_8042( 0 );	/* select AT-Scan Code. */
	scan_8042();
	return 0;
}

