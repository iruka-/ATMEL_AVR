#ifndef	_utype_h_
#define	_utype_h_

typedef unsigned char   uchar;          // 8-bit
typedef unsigned char   byte;           // 8-bit

typedef unsigned short  ushort;         // 16-bit
typedef unsigned short  word;           // 16-bit

typedef unsigned int    uint;           // 32-bit
typedef unsigned int    dword;          // 32-bit

#endif

