
void	memdump(void *ptr,int len,int off);

