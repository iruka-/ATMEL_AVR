// Sample main.cpp file. Blinks the built-in LED, sends a message out
// USART2, and turns on PWM on pin 2.

#include "wirish.h"

#define PWM_PIN  2

void setup() {
    /* Set up the LED to blink  */
    pinMode(BOARD_LED_PIN, OUTPUT);

    /* Turn on PWM on pin PWM_PIN */
//    pinMode(PWM_PIN, PWM);
//    pwmWrite(PWM_PIN, 0x8000);

    /* Send a message out the usb virtual serial port  */
//    SerialUSB.println("Hello!");
}

void BlinkTask()
{
	static int cnt=0;
	cnt++;
	if(	cnt >= 100000) {
		cnt=0;
	    toggleLED();
	}
}

void loop()
{
	char buf[256];
	int len;

    while (1) {
		len = SerialUSB.available();
		if(len) {
        	SerialUSB.read(buf,len);
	        SerialUSB.write(buf,len);
		}
		BlinkTask();
	}
}

// Force init to be called *first*, i.e. before static object allocation.
// Otherwise, statically allocated objects that need libmaple may fail.
__attribute__((constructor)) void premain() {
    init();
}

int main(void) {
    setup();

    while (true) {
        loop();
    }

    return 0;
}
