#if	0	//ndef	rs232c_h
#define	rs232c_h

int		USB_putdata(	unsigned char *buf , int cnt );
int		USB_put_flush(void);

int		USB_putc(int c);
int		USB_getdata(unsigned char *buf,int cnt);
int		USB_checkdata(void);
int		USB_getc(void);
int		USB_init(int portno,int baudrate);
void	USB_exit(void);
int		USB_printCommInfo(int pr,int port_no);
int		USB_test_target(int portno,int baudrate);
int		USB_printinfo(int port_no,int baudrate,int pr);

void	USB_error_exit(char *msg);

//----------------------------------------------------------
//#define	BAUD_RATE	230400
//#define	BAUD_RATE	460800
//#define	BAUD_RATE	500000
#define	BAUD_RATE	1000000
#endif

