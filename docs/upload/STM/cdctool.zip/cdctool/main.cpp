// Sample main.cpp file. Blinks the built-in LED, sends a message out
// USART2, and turns on PWM on pin 2.

#include "wirish.h"
#include "monitor/monit.h"

#define PWM_PIN  2

void setup() {
    /* Set up the LED to blink  */
    pinMode(BOARD_LED_PIN, OUTPUT);

    /* Turn on PWM on pin PWM_PIN */
//    pinMode(PWM_PIN, PWM);
//    pwmWrite(PWM_PIN, 0x8000);

    /* Send a message out the usb virtual serial port  */
//    SerialUSB.println("Hello!");
}


#if	0

int BlinkPeriod=100000;

//-----------------------------------------------
void BlinkTask()
{
	static int cnt=0;
	cnt++;
	if(	cnt >= BlinkPeriod) {
		cnt=0;
	    toggleLED();
	}
}

//-----------------------------------------------
void  toggle_led()
{
	toggleLED();
}

//-----------------------------------------------
uint32 USBavailable(void)
{
	return SerialUSB.available();
}

//-----------------------------------------------
uint32 USBread(void *buf,int len)
{
	return SerialUSB.read(buf,len);
}

//-----------------------------------------------
void   USBwrite(void *buf,int len)
{
	SerialUSB.write(buf,len);
}

//-----------------------------------------------
int  USBinkey(void)
{
	int len,ch;
	len = SerialUSB.available();
	if(len) {
       	ch = SerialUSB.read();
		return ch;
	}
	return -1;
}

//-----------------------------------------------
int USBgetch(void)
{
	int ch = -1;
	while(1) {
		ch = USBinkey();
		if(ch>=0) break;
		BlinkTask();
	}
	return ch;
}

#endif
//-----------------------------------------------

void loop()
{
    while (1) {
		int ch = USBgetch();
		if(	ch == 0xaa) {
			ch = USBgetch();
			if(	ch == 0x55) {
				USBmonit();
			}
		}
	}
}

// Force init to be called *first*, i.e. before static object allocation.
// Otherwise, statically allocated objects that need libmaple may fail.
__attribute__((constructor)) void premain()
{
    init();			// call wirish/board.cpp 
}

int main(void) {
    setup();

    while (true) {
        loop();
    }

    return 0;
}
