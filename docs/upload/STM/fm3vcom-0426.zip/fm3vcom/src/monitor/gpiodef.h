#ifndef	_gpiodef_h_
#define	_gpiodef_h_

#include "gpio.h"
#include "flash.h"

#endif
