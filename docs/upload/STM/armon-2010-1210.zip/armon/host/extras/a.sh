cp ../../HW/Libraries/CMSIS/CM3/CoreSupport/core_cm3.h .
cp ../../HW/Libraries/CMSIS/CM3/DeviceSupport/ST/STM32F10x/stm32f10x.h .
