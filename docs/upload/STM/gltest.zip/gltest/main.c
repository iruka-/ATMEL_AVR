/*************************************************************************
 *	OpenGL (GLUT) ���C�����[�`��.
 *************************************************************************
 */
#include <windows.h>
#include <math.h>

#include <GL/gl.h>
#include "glut.h"


#include "config.h"
#include "dllcall.h"

//	disp.c �Ɏ���.
void disp( void ) ;		// �\���֐�.
void anim( void ) ;		// �A�j���[�V�����֐�.
void initdisp( void ) ;	// �\���̏�����.
void mouse(int button, int state, int x, int y);
void reshape(int x,int y);
void exit_all(int rc);


/*************************************************************************
 *	[ESC] �������ꂽ��A�A�v���P�[�V�������I��.
 *************************************************************************
 */
void keyboard(unsigned char c, int x, int y)
{
	switch (c) {
	case 27:
		exit_all(0);
		break;
	default:
		break;
	}
}

/*************************************************************************
 *	OpenGL (GLUT) ���C��.
 *************************************************************************
 */
int main(int argc , char ** argv) 
{
	glutInit(&argc , argv);
	glutInitWindowSize(WINDOW_W , WINDOW_H);		// 960 x 640�ō쐬����.
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);

	glutCreateWindow( WINDOW_TITLE );

	initdisp();

	glutDisplayFunc(disp);
	glutKeyboardFunc(keyboard);
	glutReshapeFunc(reshape);
	glutIdleFunc(anim);
	glutMouseFunc(mouse);

	LoadDLL("cdclink.dll");

#if	0
//	glutReshapeWindow(480,320);		//���Ƃ�Window�T�C�Y��ύX����.
	glutReshapeWindow(360,240);		//���Ƃ�Window�T�C�Y��ύX����.
#endif

	glutMainLoop();

	exit_all(0);

	return 0;
}
/*************************************************************************
 *	
 *************************************************************************
 */
void exit_all(int rc)
{
	UnloadDLL();
	exit(0);
}
/*************************************************************************
 *
 *************************************************************************
 */
