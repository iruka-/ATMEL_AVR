#ifndef	_menu_h_
#define	_menu_h_

void	print_xyf(float x,float y, char *str,int font);
void	print_xy(int x,int y, char *str,int font);
void	make_btn(int x,int y, int w,int h,char *help,char *string,char **seltab,int sel,_FUNC func);
void	setColor(int col);
void	disp_frame(WIN_RECT *b,int width,int col1,int col2);
void	disp_btn_rect(MENU_BTN *b);
void	disp_button(MENU_BTN *b);
int		search_button(MENU_BTN *b,int x,int y);
void	disp_buttons(void);
void	search_buttons(int x,int y,int button, int state );
void	disp_menu(void);
void	reshape(int w,int h);
void	mouse(int button, int state, int x, int y);
int		func_stop(int button, int state,void *b);
int		func_start(int button, int state,void *b);
void	btn_trigger(void *ptr,int direction);
int		func_0(int button, int state,void *b);
int		func_start_stop(int button, int state,void *b);
int		func_exit(int button, int state,void *b);
int		func_2(int button, int state,void *b);
int		func_5(int button, int state,void *b);
//void	make_menu_sub(MENU_TAB *m);
void	make_menu(void);

#endif

