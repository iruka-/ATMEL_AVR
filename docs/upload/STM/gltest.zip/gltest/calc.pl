#!/usr/bin/perl

# uS
my @spl=(
	50,100,200,500,1000,2000,5000,10000,20000,50000
);

#   sp = (1/HCLK) * ( (N+1) * M + 1 )

# dot pitch
my $dpl = 776/16;

my $clk = 1000000 / 144;

sub calc()
{
	my ($sp)=@_;
	my $dp  = $sp / $dpl;

#   sp = clk * ( (N+1) * M + 1 )
#   sp = clk * div
#   div = sp / clk
	my ($n,$m,$d,$i,$err);
	my $div = $dp * 144;	# 144

	$i = 3;	# 0=1x,1=4x,2=8x,3=16x,
			# 4=32x,5=64x,6=128x,7=256x
	for($m=16;$m<256;$m *= 2) {
		$d = ($div - 1) / $m;	# 144/16 = 8
		$d = $d - 1;			# 15
		if(($d >= 4) && ($d < 31)) {
			last;
		}
		$i++;
	}
	$n = int($d);

	if($n>31) {$n = 31};
	if($i==3) {
		if($n<12) {$n = 12};
	}

	$err = ($n+1) / ($d+1);

	printf("{%6d,%3d,%3d,%10g},//%3d,%8g,%8g,%8g\n",$sp,$i,$n,$err
								 ,$m,$d,$dp,$div);
}

sub main()
{
	print("//    sp     i    n   err   /   d   m        err    div\n");
	foreach $sp(@spl) {
		&calc($sp);
	}
}


&main();
