/*************************************************************************
 *	CDCLink DLL �̌Ăяo��.
 *************************************************************************
	int LoadDLL(char *dllname);		//	DLL�ǂݍ��݂Ə�����.
	int	UnloadDLL();				//  DLL�J��.
 */

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "config.h"
#include "dllcall.h"

#include "sampling.h"
#include "fifo.h"

#define		VERBOSE_DEBUG	0

extern	int		device_id;


/*************************************************************************
 *
 *************************************************************************
 */

HINSTANCE hDLL = NULL;		// cdclink.dll handle

/*************************************************************************
 *         cdclink.dll �����[�h
 *************************************************************************
 */
int LoadDLL(char *dllname)
{
	//
	//	cdclink.dll��ǂݍ���.
	//
	hDLL = LoadLibrary(dllname);
	if (!hDLL) {
#if 0
		fprintf(stderr, "Error at Load '%s'\n",dllname);
#else
		MessageBox(NULL, "Error at Load DLL", "ERR", MB_OK);
#endif
		return 0;
	}

	//
	// import����֐����ꂼ��̊֐��|�C���^��p�ӂ��āAimport���Ƀ|�C���^���Z�b�g����.
	//
	openDevice  = (_openDevice )GetProcAddress(hDLL, "openDevice");  
	closeDevice = (_closeDevice)GetProcAddress(hDLL, "closeDevice"); 
	sendCommand = (_sendCommand)GetProcAddress(hDLL, "sendCommand"); 	
	getResult 	= (_getResult  )GetProcAddress(hDLL, "getResult"); 	 	
#if	VERBOSE_DEBUG
	printf("openDevice()=%x\n"	,(int) openDevice );
	printf("closeDevice()=%x\n"	,(int) closeDevice );
	printf("sendCommand()=%x\n"	,(int) sendCommand );
	printf("getResult()=%x\n"	,(int) getResult );
#endif
	InitSample();
	return 0;
}


/*************************************************************************
 *         cdclink.dll ���J��
 *************************************************************************
 */
int UnloadDLL(void)
{
	if( hDLL ) {
		//
		//	�X���b�h�g�p���Ȃ��~.
		//
		StopThread();
		//
		//	�f�o�C�X�g�p���Ȃ��~.
		//
		if(	device_id ) {
			closeDevice();
			device_id=0;
		}
		//
		//	DLL���J������.
		//
		FreeLibrary(hDLL);
		hDLL = 0;
	}
	return 0;
}

