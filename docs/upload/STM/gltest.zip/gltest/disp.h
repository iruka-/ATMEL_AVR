#ifndef	_disp_h_
#define	_disp_h_

void	InitWp(WINPOS *wp,int x,int y,int w,int h);
float	Xs(WINPOS *wp,float x);
float	Ys(WINPOS *wp,float y);
float	Xf(WINPOS *wp,float x);
float	Yf(WINPOS *wp,float y);
void	disp_rect(WIN_RECT *b,int col1);
void	set_sweep(int select);
void 	set_channels(int select);
void	set_scale(int select);
void	set_thold(int select);
void	set_inputport(int select);
int		Thhold(int val);
int		Thpoint();
int 	get_data(int count,int multi);
//float	get_value(int t);
void	disp_wave( void );
void	disp_scale( void );
void	initdisp( void ) ;
void	anim( void ) ;

#endif
