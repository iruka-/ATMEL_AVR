/*************************************************************************
 *	���j���[ / �����\��.
 *************************************************************************
 *	void make_menu();
 *	void disp_menu();
 */

#include <windows.h>
#include <math.h>
#include <string.h>
#include <stdio.h>

#include <GL/gl.h>
#include "glut.h"

#include "config.h"
#include "dllcall.h"
#include "sampling.h"
#include "disp.h"
#include "menu.h"

/*************************************************************************
 *	dot���W�n(0..640)����OpenGL 2D���W�n�ւ̕ϊ�����}�N��.
 *************************************************************************
 */
extern float Xs(WINPOS *wp,float x);
extern float Ys(WINPOS *wp,float y);
extern WINPOS	WpTop;		//�E�B���h�E�S��.

#define	_XS(x) Xs(&WpTop,x)
#define	_YS(y) Ys(&WpTop,y)

static	void *bitmap_fonts[7]={		//�t�H���g���.
	GLUT_BITMAP_9_BY_15,			//0
	GLUT_BITMAP_8_BY_13,			//1
	GLUT_BITMAP_TIMES_ROMAN_10,		//2
	GLUT_BITMAP_TIMES_ROMAN_24,     //3
	GLUT_BITMAP_HELVETICA_10,       //4
	GLUT_BITMAP_HELVETICA_12,		//5
	GLUT_BITMAP_HELVETICA_18		//6
};

#define	FONT0	0
#define	FONT1	6

static	MENU_BTN menu_btn[BTN_MAX];
static	int		 btn_max=0;
		int		 device_id =0;
static	int		 window_w = WINDOW_W;
static	int		 window_h = WINDOW_H;
		int		 g_start = 0;

extern	void exit_all(int rc);
extern	SAMPLE_PARAM param;

/*************************************************************************
 *	�������`��. OpenGL��2D���W�n.
 *************************************************************************
 */
void print_xyf(float x,float y, char *str,int font)
{
	int c;
	glRasterPos2f(x, y);
	while (1) {
		c = *str++; if(c==0) break;
		glutBitmapCharacter(bitmap_fonts[font], c);
	}
}

/*************************************************************************
 *	�������`��. �����(0,0)�Ƃ���h�b�g�P�ʂ̍��W�n.
 *************************************************************************
 */
void print_xy(int x,int y, char *str,int font)
{
	print_xyf(_XS(x),_YS(y),str,font);
}
static	int xcount(char **s)
{
	int m=0;
	while(*s) {
		m++;s++;
	}
	return m;
}

/*************************************************************************
 *	���j���[�{�^���𐶐�����.
 *************************************************************************
 */
void make_btn(int x,int y, int w,int h,char *help,char *string,char **seltab,int sel,_FUNC func)
{
	MENU_BTN *b = &menu_btn[btn_max++];

	b->x = x;
	b->y = y;
	b->w = w;
	b->h = h;
	b->help   = help;
	b->string = string;
	b->seltab = seltab;
	b->select = sel;
	b->selmax = xcount(seltab);
	b->func = func;
}

//	�g���̐F.

void setColor(int col)
{
//	float a = ((col>>24)&0xff)/255.0f ;
	float r = ((col>>16)&0xff)/255.0f ;
	float g = ((col>> 8)&0xff)/255.0f ;
	float b = ((col    )&0xff)/255.0f ;
	glColor3f(r,g,b);
}

/*************************************************************************
 *	�S�̘̂g������
 *************************************************************************
 */
void disp_frame(WIN_RECT *b,int width,int col1,int col2)
{
	WINPOS *Wp = &WpTop;
	float x0,y0;
	float x1,y1;
	int t;

	glDisable(GL_LINE_SMOOTH);
	glLineWidth(1);
	// ����������.
	glBegin(GL_LINES);

	for(t=0;t<width;t++) {
		setColor(col1);
		//��`��float���W��(x0,y0) - (x1,y1)
		x0=    Xs(Wp,b->x - t );
		x1=    Xs(Wp,b->x + b->w +t );
		y0=    Ys(Wp,b->y - t);
		y1=    Ys(Wp,b->y + b->h +t);

		glVertex2f(x0 , y0 );	//����.
		glVertex2f(x1 , y0 );

		glVertex2f(x0 , y0 );	//�c��.
		glVertex2f(x0 , y1 );

		setColor(col2);
		glVertex2f(x0 , y1 );
		glVertex2f(x1 , y1 );

		glVertex2f(x1 , y0 );
		glVertex2f(x1 , y1 );
	}
	glEnd();
}

void disp_btn_rect(MENU_BTN *b)
{
	int col2 = 0x606060;
	int col1 = 0xd0d0d0;	//0xe0e0e0;
	disp_frame((WIN_RECT *)b,3,col1,col2);
}


#define	FONT_H	16
#define	FONT_W	12

void disp_button(MENU_BTN *b)
{
	//��`���ォ�當����܂ł̂��炵���W.
	int len = strlen(b->string) * FONT_W;
	int xoff =(b->w - len) / 2;
	int yoff =(b->h + FONT_H ) / 2;

	disp_btn_rect(b);

	setColor(0x202020);
	print_xy(b->x + xoff,b->y + yoff,b->string,FONT1);

	xoff = -10;yoff = - 8;
	setColor(0x204040);
	print_xy(b->x + xoff,b->y + yoff,b->help,FONT0);
}

int	search_button(MENU_BTN *b,int x,int y)
{
	unsigned int px = x - b->x;
	unsigned int py = y - b->y;

	if( (px < b->w) && (py < b->h ) ) {
		return 1;	// hit!
	}
	return 0;
}

void disp_buttons(void)
{
	MENU_BTN *b = &menu_btn[0];
	int i;
	for(i=0;i<btn_max;i++,b++) {
		disp_button(b);
	}
}
void search_buttons(int x,int y,int button, int state )
{
	MENU_BTN *b = &menu_btn[0];
	int i;
	for(i=0;i<btn_max;i++,b++) {
		if( search_button(b,x,y) ) {
			b->hit = 1;
			b->func(button,state,b);
		}else{
			b->hit = 0;
		}
	}
}
/*************************************************************************
 *	���j���[�S�ʂ�`��.
 *************************************************************************
 */
void disp_menu(void)
{
#define	N 18
	WIN_RECT rect = {N,N,WINDOW_W-120-2*N,WINDOW_H-2*N};
	int col1 = 0x606060;
	int col2 = 0xd0d0d0;	//0xe0e0e0;
	disp_frame(&rect,8,col1,col2);

	disp_buttons();
}

/*************************************************************************
 *	��ʃT�C�Y�ύX��callback
 *************************************************************************
 */
void reshape(int w,int h)
{
	window_w = w;
	window_h = h;
//	printf("w,h=%d,%d\n",w,h);

	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0, w, h, 0);
	glMatrixMode(GL_MODELVIEW);
}
/*************************************************************************
 *	�}�E�X�n���h���[.
 *************************************************************************
 */
void mouse(int button, int state, int x, int y)
{
	x = x * WINDOW_W / window_w;
	y = y * WINDOW_H / window_h;

	if (state == GLUT_DOWN) {
		search_buttons(x,y,button,state);
	}

	if (button == GLUT_LEFT_BUTTON) {
		if (state == GLUT_DOWN) {
		} else if (state == GLUT_UP) {
		}
	}
}


/*************************************************************************
 *	
 *************************************************************************
 */
int func_stop(int button, int state,void *b)
{
	StopSample();
	g_start = 0;
	return 0;
}
/*************************************************************************
 *	
 *************************************************************************
 */
int func_start(int button, int state,void *b)
{
	StartSample(&param);
	g_start = 1;
	return 0;
}

/*************************************************************************
 *	
 *************************************************************************
 */
int samp_start()
{
	MENU_BTN *b= &menu_btn[5];	// START
	b->select = 1;	// STOP.
	b->string = b->seltab[b->select];	// "STOP"

	StartSample(&param);
	g_start = 1;
	return 0;
}
/*************************************************************************
 *	
 *************************************************************************
 */
void btn_trigger(void *ptr,int direction)
{
	MENU_BTN *b = ( MENU_BTN *) ptr;
	if(direction==1) {
		b->select++;
		if(	b->select >= b->selmax) {
			b->select = 0;
		}
	}
	if(direction== -1) {
		b->select--;
		if(	b->select < 0 ) {
			b->select = b->selmax - 1;
		}
	}
	b->string = b->seltab[b->select];
}
/*************************************************************************
 *	
 *************************************************************************
 */
int func_0(int button, int state,void *b)
{
	if (state == GLUT_DOWN) {
		if (button == GLUT_LEFT_BUTTON) {
			btn_trigger(b,1);
		}
		if (button == GLUT_RIGHT_BUTTON) {
			btn_trigger(b,-1);
		}
	}
	return 0;
}
void set_sweep(int select);
/*************************************************************************
 *	
 *************************************************************************
 */
int func_start_stop(int button, int state,void *b)
{
	MENU_BTN *btn = ( MENU_BTN *) b;
	int rc = func_0(button,state,b);

	if(btn->select) {
		func_start(button,state,b);
	}else{
		func_stop(button,state,b);
	}
	(void)rc;
	return 0;
}
/*************************************************************************
 *	
 *************************************************************************
 */
int func_exit(int button, int state,void *b)
{
	func_stop(button,state,b);
	exit_all(0);
	return 0;
}

int func_1(int button, int state,void *b)
{	
	MENU_BTN *btn = ( MENU_BTN *) b;
	int rc = func_0(button,state,b);
	
	set_sweep(btn->select);
	samp_start();
	return rc;
}
int func_2(int button, int state,void *b)
{
	MENU_BTN *btn = ( MENU_BTN *) b;
	int rc = func_0(button,state,b);
	
	set_scale(btn->select);
	return rc;
}
int func_3(int button, int state,void *b)
{
	MENU_BTN *btn = ( MENU_BTN *) b;
	int rc = func_0(button,state,b);
	set_channels(btn->select);
	samp_start();
	return rc;
}
int func_4(int button, int state,void *b)
{
	MENU_BTN *btn = ( MENU_BTN *) b;
	int rc = func_0(button,state,b);
	
	set_inputport(btn->select);
	samp_start();
	return rc;
}
int func_5(int button, int state,void *b)
{
	MENU_BTN *btn = ( MENU_BTN *) b;
	int rc = func_0(button,state,b);
	
	set_thold(btn->select);
	samp_start();
	return rc;
}
/*************************************************************************
 *	���j���[�̏�����.
 *************************************************************************
 */
#define	MPOS(y)	WINDOW_W-120,72*(y)+64,100,32

typedef	struct {
	int x,y,w,h;char *help,*string;int select;_FUNC func;
	char **seltab;
} MENU_TAB;
/*************************************************************************
 *	�I�����̃e�[�u��
 *************************************************************************
 */
char *sel_0[]={"ANALOG","DIGITAL",NULL};
char *sel_1[]={"50uS","100uS","200uS","500uS","1mS","2mS","5mS","10mS","20mS","50mS",NULL};
char *sel_2[]={"1x","2x","5x","10x",NULL};
char *sel_3[]={"1ch","2ch","4ch","8ch","16ch",NULL};
//char *sel_4[]={"port 0","port 1","port 2","port 3",NULL};
char *sel_4[]={"AN0-15","AN16-31",NULL};
char *sel_5[]={"free","+10%","+20%","+30%","-10%","-20%","-30%",NULL};
char *sel_6[]={"START","STOP",NULL};
char *sel_7[]={"EXIT",NULL};
/*************************************************************************
 *	���j���[�쐬�p�̃e�[�u��
 *************************************************************************
 */
MENU_TAB menu_tab[]={
//	���W	,HELP	, SELECT,�����l	,callback,sel_table .
	{MPOS(0),"SWEEP/div","",0		,func_1,sel_1},
	{MPOS(1),"GAIN:","",0			,func_2,sel_2},
	{MPOS(2),"CHANNELS:","",0		,func_3,sel_3},
	{MPOS(3),"INPUT SELECT:","",0	,func_4,sel_4},
	{MPOS(4),"TRIGGER:","",0		,func_5,sel_5},
	{MPOS(5),"","START",0			,func_start_stop,sel_6},
	{MPOS(6),"","EXIT",0			,func_exit,sel_7},
	{MPOS(0),NULL,NULL,0,NULL,NULL},	// EOT
};
#if	0
MENU_TAB menu_tab[]={
//	���W	,HELP	, SELECT,�����l	,callback,sel_table .
	{MPOS(0),"ANALOG/DIGITAL:","",0	,func_0,sel_0},
	{MPOS(1),"SWEEP/div","",0		,func_1,sel_1},
	{MPOS(2),"GAIN:","",0			,func_2,sel_2},
	{MPOS(3),"CHANNELS:","",0		,func_3,sel_3},
	{MPOS(4),"DIGITAL INPUT:","",0	,func_4,sel_4},
	{MPOS(5),"TRIGGER:","",0		,func_5,sel_5},
	{MPOS(6),"","START",0		,func_start,sel_6},
	{MPOS(7),"","STOP",0		,func_stop,sel_7},
	{MPOS(0),NULL,NULL,0,NULL,NULL},	// EOT
};
#endif

/*************************************************************************
 *	
 *************************************************************************
 */
void make_menu_sub(MENU_TAB *m)
{
	char *string = m->seltab[m->select];
	make_btn(m->x,m->y,m->w,m->h,m->help,string,m->seltab,m->select,m->func);
	
}
/*************************************************************************
 *	���j���[�̏�����.
 *************************************************************************
 */
void make_menu(void)
{
	MENU_TAB *m=menu_tab;
	while(m->func) {
		make_menu_sub(m++);
	}
}
/*************************************************************************
 *	
 *************************************************************************
 */
