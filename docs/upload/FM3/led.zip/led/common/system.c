#ifdef	__CPU_MB9B500__
#include "system_mb9bf50x_usbfunc.c"
#endif	//#ifdef	__CPU_MB9B500__

#ifdef	__CPU_MB9B618__
#include "system_mb9bf61x.c"
#endif	//#ifdef	__CPU_MB9B618__
