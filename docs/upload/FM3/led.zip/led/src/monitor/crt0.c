/* -=* << crt0.S ���A�Z���u�������ŏ����Ă݂܂��� >> *=- */

#include "crt0.h"

//;
//;		C Runtime Startup for FM3:MB9B618T
//;
EXTERN		_estack			;
//;
//;		���荞�݃x�N�g��:
//;
	__attribute__ ((section(".isr_vector"))) void (*const 
g_Vectors					[])(void) = {
	LPVOID  &_estack	       ,/* Top of Stack */
	DCD     Reset_Handler      ,/* Reset Handler */
	DCD     NMI_Handler        ,/* NMI Handler */
	DCD     HardFault_Handler  ,/* Hard Fault Handler */
	DCD     MemManage_Handler  ,/* MPU Fault Handler */
	DCD     BusFault_Handler   ,/* Bus Fault Handler */
	DCD     UsageFault_Handler ,/* Usage Fault Handler */
	DCD     0                  ,/* Reserved */
	DCD     0                  ,/* Reserved */
	DCD     0                  ,/* Reserved */
	DCD     0                  ,/* Reserved */
	DCD     SVC_Handler        ,/* SVCall Handler */
	DCD     DebugMon_Handler   ,/* Debug Monitor Handler */
	DCD     0                  ,/* Reserved */
	DCD     PendSV_Handler     ,/* PendSV Handler */
	DCD     SysTick_Handler    ,/* SysTick Handler */
	DCD     CSV_Handler        ,/* 0: Clock Super Visor */
	DCD     SWDT_Handler       ,/* 1: Software Watchdog Timer */
	DCD     LVD_Handler        ,/* 2: Low Voltage Detector */
	DCD     MFT_WG_IRQHandler  ,/* 3: Wave Form Generator / DTIF */
	DCD     INT0_7_Handler     ,/* 4: External Interrupt Request ch.0 to ch.7 */
	DCD     INT8_15_Handler    ,/* 5: External Interrupt Request ch.8 to ch.15 */
	DCD     DT_Handler         ,/* 6: Dual Timer / Quad Decoder */
	DCD     MFS0RX_IRQHandler  ,/* 7: MultiFunction Serial ch.0 */
	DCD     MFS0TX_IRQHandler  ,/* 8: MultiFunction Serial ch.0 */
	DCD     MFS1RX_IRQHandler  ,/* 9: MultiFunction Serial ch.1 */
	DCD     MFS1TX_IRQHandler  ,/* 10: MultiFunction Serial ch.1 */
	DCD     MFS2RX_IRQHandler  ,/* 11: MultiFunction Serial ch.2 */
	DCD     MFS2TX_IRQHandler  ,/* 12: MultiFunction Serial ch.2 */
	DCD     MFS3RX_IRQHandler  ,/* 13: MultiFunction Serial ch.3 */
	DCD     MFS3TX_IRQHandler  ,/* 14: MultiFunction Serial ch.3 */
	DCD     MFS4RX_IRQHandler  ,/* 15: MultiFunction Serial ch.4 */
	DCD     MFS4TX_IRQHandler  ,/* 16: MultiFunction Serial ch.4 */
	DCD     MFS5RX_IRQHandler  ,/* 17: MultiFunction Serial ch.5 */
	DCD     MFS5TX_IRQHandler  ,/* 18: MultiFunction Serial ch.5 */
	DCD     MFS6RX_IRQHandler  ,/* 19: MultiFunction Serial ch.6 */
	DCD     MFS6TX_IRQHandler  ,/* 20: MultiFunction Serial ch.6 */
	DCD     MFS7RX_IRQHandler  ,/* 21: MultiFunction Serial ch.7 */
	DCD     MFS7TX_IRQHandler  ,/* 22: MultiFunction Serial ch.7 */
	DCD     PPG_Handler        ,/* 23: PPG */
	DCD     TIM_IRQHandler     ,/* 24: OSC / PLL / Watch Counter */
	DCD     ADC0_IRQHandler    ,/* 25: ADC0 */
	DCD     ADC1_IRQHandler    ,/* 26: ADC1 */
	DCD     ADC2_IRQHandler    ,/* 27: ADC2 */
	DCD     MFT_FRT_IRQHandler ,/* 28: Free-run Timer */
	DCD     MFT_IPC_IRQHandler ,/* 29: Input Capture */
	DCD     MFT_OPC_IRQHandler ,/* 30: Output Compare */
	DCD     BT0_7_IRQHandler   ,/* 31: Base Timer ch.0 to ch.7 */
	DCD     ETHER_MAC0_IRQHandler,/* 32: Ethernet MAC ch.0 */
	DCD     ETHER_MAC1_IRQHandler,/* 33: Ethernet MAC ch.1 */
	DCD     USB0F_Handler      ,/* 34: USB0 Function */
	DCD     USB0_Handler       ,/* 35: USB0 Function / USB0 HOST */
	DCD     USB1F_Handler      ,/* 36: USB1 Function */
	DCD     USB1_Handler       ,/* 37: USB1 Function / USB1 HOST */
	DCD     DMAC0_Handler      ,/* 38: DMAC ch.0 */
	DCD     DMAC1_Handler      ,/* 39: DMAC ch.1 */
	DCD     DMAC2_Handler      ,/* 40: DMAC ch.2 */
	DCD     DMAC3_Handler      ,/* 41: DMAC ch.3 */
	DCD     DMAC4_Handler      ,/* 42: DMAC ch.4 */
	DCD     DMAC5_Handler      ,/* 43: DMAC ch.5 */
	DCD     DMAC6_Handler      ,/* 44: DMAC ch.6 */
	DCD     DMAC7_Handler      ,/* 45: DMAC ch.7 */
	DCD     BT8_15_IRQHandler  ,/* 46: Base Timer ch.8 to ch.15 */
	DCD     DummyHandler       ,/* 47: Reserved */
};


//;
//;	�����J�[�X�N���v�g�E�V���{��:
//;
EXTERN	_sidata	;/* start address for the initialization values of the .data section.*/
EXTERN	_sdata	;/* start address for the .data section.  */
EXTERN	_edata	;/* end address for the .data section.    */
EXTERN	_sbss	;/* start address for the .bss section.   */
EXTERN	_ebss	;/* end address for the .bss section.     */

//;
//;	���Z�b�g����:
//;

void
Reset_Handler			(void) { uint *s,*t;

	s = &_sidata;
	t = &_sdata;

//;
//;	�f�[�^�Z�N�V������RAM�ɃR�s�[����.
//;
	while( t < &_edata ) {
		*t++ = *s++;
	}

//;
//;	bss�Z�N�V�������[���E�N���A����.
//;
	t = &_sbss;
	while( t < &_ebss ) {
		*t++ = 0;
	}

	SystemInit();

	main() ;

//;
//;	�I���� �������[�v.
//;
	while(1) {};
}


//;	�f�t�H���g�E�n���h���[	(�������[�v�ߑ��^)
HANDLER(	NMI_Handler     	)
HANDLER(	HardFault_Handler   )
HANDLER(	MemManage_Handler   )
HANDLER(	BusFault_Handler    )
HANDLER(	UsageFault_Handler  )
HANDLER(	SVCall_Handler      )

HANDLER(	Default_Handler     )

