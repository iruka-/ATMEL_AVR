/*********************************************************************
 *	WIN32: RS232C �̐���.
 *********************************************************************
 * �������E�I��:
int		USB_init(int portno,int baudrate);
void	USB_exit(void);
 * �f�[�^���M:
int		USB_putdata(	unsigned char *buf , int cnt );
 * �f�[�^��M:
int		USB_getdata(unsigned char *buf,int cnt);
 *
 *********************************************************************
 */

#ifndef	_LINUX_
#include <windows.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <time.h>

#ifdef	_MSDOS_
#include "../libusb/include/lusb0_usb.h"
#else
#include <usb.h>
#endif

#include "packet.h"
#include "monit.h"
#include "bulkusb.h"

/*********************************************************************
 *	��`
 *********************************************************************
 */


#if	0
//	obdev (AVRUSB�̏ꍇ)
#define MY_VID 0x04d8
#define MY_PID 0x0204
#else
//	FM3	�̏ꍇ.
#define MY_VID 0x04c5
#define MY_PID 0x4242
#endif


#if	0
/* the device's endpoints */
#define EP_IN  				0x81
#define EP_OUT 				0x01
#else
//	FM3
#define EP_IN  				0x81
#define EP_OUT 				0x03
#endif

#define PACKET_SIZE 		60
#define	VERBOSE				0
#define	REPORT_MATCH_DEVICE	0
#define	REPORT_ALL_DEVICES	0
#define DEBUG_PKTDUMP 	 	0		// �p�P�b�g���_���v����.
#define	TIMEOUT				1000	//(mSec) 5000

void dump_info(  struct usb_device *dev );

/*********************************************************************
 *	USB�f�o�C�X�̃n���h��(libusb)
 *********************************************************************
 */
static  usb_dev_handle *usb_dev = NULL;


/*********************************************************************
 *	USB�f�o�C�X�ɁA�f�[�^�𑗂�.
 *********************************************************************
 */
int	USB_putdata(	unsigned char *buf , int cnt )
{
	int rc;
	rc = usb_bulk_write(usb_dev, EP_OUT, (char*)buf, cnt , TIMEOUT );
#if	DEBUG_PKTDUMP
	printf("WR: rc=%d\n",rc);
	memdump("WR", buf, cnt);
#endif
	return rc;
}
/*********************************************************************
 *	USB�f�o�C�X����A�f�[�^���������.
 *********************************************************************
 */
int	USB_getdata( unsigned char *buf , int cnt )
{
	int rc;
#if	DEBUG_PKTDUMP
	printf("RD: size=%d\n",cnt);
#endif
	rc = usb_bulk_read(usb_dev, EP_IN, (char*)buf , cnt , TIMEOUT );
#if	DEBUG_PKTDUMP
	printf("RD: rc=%d\n",rc);
	memdump("RD", buf, cnt);
#endif
	return rc;
}
/*********************************************************************
 *	USB�f�o�C�X����A��������擾����
 *********************************************************************
 */
static int  usbGetStringAscii(usb_dev_handle *dev, int index, int langid, char *buf, int buflen)
{
	char    buffer[256];
	int     rval, i;

	if((rval = usb_control_msg(dev, USB_ENDPOINT_IN, USB_REQ_GET_DESCRIPTOR, (USB_DT_STRING << 8) + index, langid, buffer, sizeof(buffer), 1000)) < 0)
		return rval;
	if(buffer[1] != USB_DT_STRING)
		return 0;
	if((unsigned char)buffer[0] < rval)
		rval = (unsigned char)buffer[0];
	rval /= 2;
	/* lossy conversion to ISO Latin1 */
	for(i=1; i<rval; i++) {
		if(i > buflen)  /* destination buffer overflow */
			break;
		buf[i-1] = buffer[2 * i];
		if(buffer[2 * i + 1] != 0)  /* outside of ISO Latin1 range */
			buf[i-1] = '?';
	}
	buf[i-1] = 0;
	return i-1;
}

/*********************************************************************
 *	iManufacturer,iProduct ��������`�F�b�N.
 *********************************************************************
 */
int	open_dev_check_string(struct usb_device *dev,usb_dev_handle *handle)
{
	int len1,len2;
	char string1[256];
	char string2[256];

	len1 = usbGetStringAscii(handle, dev->descriptor.iManufacturer,
	                         0x0409, string1, sizeof(string1));
	len2 = usbGetStringAscii(handle, dev->descriptor.iProduct,
	                         0x0409, string2, sizeof(string2));
	if((len1<0)||(len2<0)) return 0;

#if	0
	printf("iManufacturer:%s\n",string1);
	printf("iProduct:%s\n",string2);
#endif

	return 1;	//���v����.
}


/*********************************************************************
 *	�ړ��Ă�USB �J�X�^���f�o�C�X���I�[�v������.
 *********************************************************************
 */
usb_dev_handle *open_dev(void)
{
	struct usb_bus *bus;
	struct usb_device *dev;
	usb_dev_handle *handle;

	for(bus = usb_get_busses(); bus; bus = bus->next) {
		for(dev = bus->devices; dev; dev = dev->next) {

#if	REPORT_ALL_DEVICES
			dump_info(dev);
#endif

			//
			//	VendorID,ProductID �̈�v�`�F�b�N.
			//
			if(dev->descriptor.idVendor  == MY_VID &&
			        dev->descriptor.idProduct == MY_PID) {
#if	REPORT_MATCH_DEVICE
				if( VERBOSE ) {
					dump_info(dev);
				}
#endif
				handle = usb_open(dev);
				if( open_dev_check_string(dev,handle) == 1) {
					return handle;	//��v.
				}
				usb_close(handle);
				handle = NULL;
			}
		}
	}
	return NULL;
}


/*********************************************************************
 *	������
 *********************************************************************
 */
int	USB_init(int portno,int baudrate)
{
	usb_init(); /* initialize the library */
#if	1	//VERBOSE
	usb_set_debug(3);	// =debug level
#endif
	usb_find_busses(); /* find all busses */
	usb_find_devices(); /* find all connected devices */
	usb_dev = open_dev();

	if(	usb_dev == NULL ) {
		printf("error: device not found!\n");
		return 0;
	}

	//�o���N�p�G���h�|�C���g�� set_configuration���Ȃ���
	//�g���Ȃ��悤��.

	if(usb_set_configuration(usb_dev, 1 ) < 0) {
		printf("error: setting config 1 failed\n");
		usb_close(usb_dev);
		return 0;
	}
//	if(usb_claim_interface(usb_dev, 0) < 0) {
	if(usb_claim_interface(usb_dev, 1) < 0) {
		printf("error: claiming interface 1 failed\n");
		usb_close(usb_dev);
		return 0;
	}

#if	0	//def LIBUSB_HAS_DETACH_KERNEL_DRIVER_NP
	if(usb_detach_kernel_driver_np(usb_dev, 0) < 0 ){
		fprintf(stderr, "Warning: could not detach kernel driver: %s\n", usb_strerror());
	}
#endif


	return 1;	// OK.
}
/*********************************************************************
 *	�I��
 *********************************************************************
 */
void USB_exit(void)
{
	if(	usb_dev ) {
		usb_release_interface(usb_dev, 0);
		usb_close(usb_dev);
		usb_dev = NULL;
	}
}


#if	0
//	�ȉ��A�������Ȃ�.
/*********************************************************************
 *
 *********************************************************************
 */
int	USB_put_flush(void)
{
	return 0;
}
/*********************************************************************
 *
 *********************************************************************
 */
int	USB_putc(int c)
{
	return 0;
}
/*********************************************************************
 *
 *********************************************************************
 */
int	USB_checkdata(void)
{
	return 1;
}
/*********************************************************************
 *
 *********************************************************************
 */
int	USB_getc(void)
{
	return 0;
}
#endif
/*********************************************************************
 *
 *********************************************************************
 */
