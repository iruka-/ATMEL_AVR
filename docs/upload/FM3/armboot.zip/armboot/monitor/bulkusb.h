#ifndef	bulkusb_h_
#define	bulkusb_h_

int		USB_putdata(	unsigned char *buf , int cnt );
int		USB_put_flush(void);

int		USB_putc(int c);
int		USB_getdata(unsigned char *buf,int cnt);
int		USB_checkdata(void);
int		USB_getc(void);
int		USB_init(int portno,int baudrate);
void	USB_exit(void);
int		USB_printCommInfo(int pr,int port_no);
int		USB_test_target(int portno,int baudrate);
int		USB_printinfo(int port_no,int baudrate,int pr);

void	USB_error_exit(char *msg);

#endif

