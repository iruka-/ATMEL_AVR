/*********************************************************************
 *	�����u�����������F �A�h���X�� 0x0000 �` 0x00ff
 *	�W�����v�e�[�u���F �A�h���X�� 0x0100 �` 0x01ff
 *********************************************************************
 */


#include "monit.h"


extern  void start();
extern  void sci_putc();
extern  void dummy_handler( void );

#ifdef	_TINY
extern  void sci_handler( void );
#else
extern  void sci_rx_handler( void );
extern  void sci_error_handler( void );
#endif

Interrupt void trap_handler( void )
{
}

Interrupt void nmi_handler( void )
{
}

#define	NULLFUNC  dummy_handler

typedef void (*func)(void);

#ifdef	_TINY

/*********************************************************************
 *	�R�U�X�S�e�F���荞�݃x�N�^�[.
 *********************************************************************
 */

const func IntVector[] __attribute__ ((section (".vectors"))) =
{
    start,			// 0 RESET
	NULLFUNC,		// 1 reserved.
	NULLFUNC,		// 2 reserved.
	NULLFUNC,		// 3 reserved.
	NULLFUNC,		// 4 reserved.
	NULLFUNC,		// 5 reserved.
	NULLFUNC,		// 6 reserved.
	nmi_handler,	// 7 NMI

	trap_handler,	// 8  TRAP#0
	trap_handler,	// 9  TRAP#1
	trap_handler,	// 10 TRAP#2
	trap_handler,	// 11 TRAP#3
	NULLFUNC,		// 12 Address Break
	NULLFUNC,		// 13 CPU Sleep
// External Interrupt:
	NULLFUNC,		// 14 IRQ0(PowerDown)
	NULLFUNC,		// 15 IRQ1

	NULLFUNC,		// 16 IRQ2
	NULLFUNC,		// 17 IRQ3
	NULLFUNC,		// 18 WKP
	NULLFUNC,		// 19 TIMER_A Overflow
	NULLFUNC,		// 20 reserved.
	NULLFUNC,		// 21 TIMER_W
	NULLFUNC,		// 22 TIMER_V
	sci_handler,	// 23 SCI3

	NULLFUNC,		// 24 IIC2
	NULLFUNC,		// 25 A/D
	NULLFUNC,		// 26 
	NULLFUNC,		// 27 
	NULLFUNC,		// 28 
	NULLFUNC,		// 29 
	NULLFUNC,		// 30 
	NULLFUNC,		// 31 

	NULLFUNC,		// 32 
	NULLFUNC,		// 33 
	NULLFUNC,		// 34 
	NULLFUNC,		// 35 
	NULLFUNC,		// 36 
	NULLFUNC,		// 37 
	NULLFUNC,		// 38 
	NULLFUNC,		// 39 

	NULLFUNC,		// 40 
	NULLFUNC,		// 41 
	NULLFUNC,		// 42 
	NULLFUNC,		// 43 
	NULLFUNC,		// 44 
	NULLFUNC,		// 45 
	NULLFUNC,		// 46 
	NULLFUNC,		// 47 

	NULLFUNC,		// 48
	sci_putc,		// 49
	NULLFUNC,		// 50 
	NULLFUNC,		// 51
	NULLFUNC,		// 52
	NULLFUNC,		// 53
	NULLFUNC,		// 54
	NULLFUNC,		// 55

	NULLFUNC,		// 56
	NULLFUNC,		// 57
	NULLFUNC,		// 58
	NULLFUNC,		// 59
	NULLFUNC,		// 60
	NULLFUNC,		// 61
	NULLFUNC,		// 62
	NULLFUNC,		// 63

};
#else


/*********************************************************************
 *	�R�O�S�W�e�F���荞�݃x�N�^�[.
 *********************************************************************
 */
const func IntVector[] __attribute__ ((section (".vectors"))) =
{
    start,			// 0 RESET
	NULLFUNC,		// 1 reserved.
	NULLFUNC,		// 2 reserved.
	NULLFUNC,		// 3 reserved.
	NULLFUNC,		// 4 reserved.
	NULLFUNC,		// 5 reserved.
	NULLFUNC,		// 6 reserved.
	nmi_handler,	// 7 NMI

	trap_handler,	// 8  TRAP#0
	trap_handler,	// 9  TRAP#1
	trap_handler,	// 10 TRAP#2
	trap_handler,	// 11 TRAP#3
// External Interrupt:
	NULLFUNC,		// 12 IRQ0
	NULLFUNC,		// 13 IRQ1
	NULLFUNC,		// 14 IRQ2
	NULLFUNC,		// 15 IRQ3

	NULLFUNC,		// 16 IRQ4
	NULLFUNC,		// 17 IRQ5
	NULLFUNC,		// 18 Reserved
	NULLFUNC,		// 19 Reserved
	NULLFUNC,		// 20 WOVI(WatchDog)
	NULLFUNC,		// 21 CMI(Refresh)
	NULLFUNC,		// 22 Reserved
	NULLFUNC,		// 23 Reserved
	NULLFUNC,		// 24 ITU0 IMIA0
	NULLFUNC,		// 25 ITU0 IMIB0
	NULLFUNC,		// 26 ITU0 OVI0
	NULLFUNC,		// 27 Reserved
	NULLFUNC,		// 28 ITU1 IMIA1
	NULLFUNC,		// 29 ITU1 IMIB1
	NULLFUNC,		// 30 ITU1 OVI1
	NULLFUNC,		// 31 Reserved

	NULLFUNC,		// 32 ITU2 IMIA2
	NULLFUNC,		// 33 ITU2 IMIB2
	NULLFUNC,		// 34 ITU2 OVI2
	NULLFUNC,		// 35 Reserved
	NULLFUNC,		// 36 ITU3 IMIA3
	NULLFUNC,		// 37 ITU3 IMIB3
	NULLFUNC,		// 38 ITU3 OVI3
	NULLFUNC,		// 39 Reserved

	NULLFUNC,		// 40 ITU4 IMIA4
	NULLFUNC,		// 41 ITU4 IMIB4
	NULLFUNC,		// 42 ITU4 OVI4
	NULLFUNC,		// 43 Reserved
	NULLFUNC,		// 44 DMAC DEND0A
	NULLFUNC,		// 45 DMAC DEND0B
	NULLFUNC,		// 46 DMAC DEND1A
	NULLFUNC,		// 47 DMAC DEND1B

	NULLFUNC,		// 48 Reserved
	NULLFUNC,		// 49 Reserved
	NULLFUNC,		// 50 Reserved
	NULLFUNC,		// 51 Reserved
	NULLFUNC,		// 52 SCI0 ERI0
	NULLFUNC,		// 53 SCI0 RXI0
	NULLFUNC,		// 54 SCI0 TXI0
	NULLFUNC,		// 55 SCI0 TEI0

	sci_error_handler,// 56 SCI1 ERI1
	sci_rx_handler,	// 57 SCI1 RXI1
	NULLFUNC,		// 58 SCI1 TXI1
	NULLFUNC,		// 59 SCI1 TEI1
	NULLFUNC,		// 60 ADI
	NULLFUNC,		// 61
	NULLFUNC,		// 62
	NULLFUNC,		// 63

};
#endif
