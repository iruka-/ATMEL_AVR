#include <string.h>

#define BUFMAX 		80
#define	STACK_SIZE	32

/*-------------------------------------------------------------------------*/
char remcomInBuffer[BUFMAX];
//int work_area; /* work area of isr.S */

int stub_stack[STACK_SIZE] __attribute__ ((section (".stack"))) = {0};

int	monitor_main();

int	main()
{
	while(1) {
		monitor_main();
	}
	return 0;
}
