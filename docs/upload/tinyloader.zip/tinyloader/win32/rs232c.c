/*********************************************************************
 *	WIN32: RS232C �̐���.
 *********************************************************************

 * �������E�I��:
int		RS_init(char *portno,int baudrate);
void	RS_exit(void);

 * ���菇�[���̎��s:
void	RS_terminal(char *port_no,int baudrate);

 * �f�[�^���M:
int		RS_putdata(	unsigned char *buf , int cnt );
int		RS_putc(int c);
int		RS_getc(int timeout);
 * �f�[�^��M:
int		RS_checkdata();
int		RS_getdata(unsigned char *buf,int cnt);

 * �L�[�{�[�h����:
int		RS_keyInput(void);

 *
 *********************************************************************
 */

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <signal.h>
#include <usb.h>
#include "loader.h"
#include "rs232c.h"
#include "util.h"

#define	VERBOSE_DEBUG		0

/*********************************************************************
 *	��`
 *********************************************************************
 */
#define	    COM_DEVICENAME  "\\\\.\\COM%s"	
// ���� "\\.\"��t���Ȃ��ꍇ�� COM�|�[�g1�`9�܂ł����Ή��ł��Ȃ�.
//				�t�����ꍇ��1�`99�܂�.

#define		KEY_ESCAPE_CH	0x01

#define	MAX_RESULT_LENGTH	32		//��M�o�b�t�@��.

#define	RESULT_LENGTH_MASK	0x7f	//��M�������̗L���}�X�N�r�b�g.
#define	TXBUF_FULL_MASK		0x80	//���M�o�b�t�@�t���������r�b�g.
/*********************************************************************
 *	�O���[�o��
 *********************************************************************
 */
static char	COM_Device[256];
HANDLE		thread;
DWORD		thid;
HANDLE		comHandle;
OVERLAPPED	ovlrd;
OVERLAPPED	ovlwr;
HANDLE		ovlrd_hEvent;
HANDLE		ovlwr_hEvent;

/*********************************************************************
 *	�q�r�Q�R�Q�b ������f�[�^ �o��.
 *********************************************************************
 */
int	RS_putdata(	unsigned char *buf , int cnt )
{
	DWORD dwWritten=0;
	DWORD wcnt = 0;

	memset(&ovlwr,0,sizeof(OVERLAPPED));
	ovlwr.hEvent = ovlwr_hEvent;

//	buf[cnt]=0; printf("%02x\n",buf[0]);

	int rc = WriteFile(comHandle, buf , cnt , &dwWritten, &ovlwr);
	if (rc == 0) {
		if((rc = GetLastError() ) == ERROR_IO_PENDING) 
		{
//			WaitForSingleObject(ovlwr.hEvent, INFINITE);
			GetOverlappedResult(comHandle,&ovlwr,&wcnt,FALSE);
			//printf("putComPort() data = %x\n",buf[0]);
			return cnt;
		}
	}
	return cnt;
}

/*********************************************************************
 *	�q�r�Q�R�Q�b�����o��.
 *********************************************************************
 */
int	RS_putc(int c)
{
	char buf[16];
	buf[0]=c;
#if	VERBOSE_DEBUG
	printf(">RS_putc(0x%02x)\n",c);
#endif

	RS_putdata(buf,1);
	return 0;
}
/*********************************************************************
 *	�R���\�[������
 *********************************************************************
 */
int	RS_keyInput(void)
{
	if(kbhit())	{
		return getch();
	}
	return 0;
}
/*********************************************************************
 *	COMM�f�o�C�X����P�o�C�g����M����.
 *********************************************************************
 *	�߂�l:
 *		0 ��M�Ȃ�.
 *		1 ��M�n�j.
 *
 *
 */
int	RS_getdata(unsigned char *buf,int cnt)
{
	DWORD	r=0;
	DWORD	rcnt = 0;

	memset(&ovlrd,0,sizeof(OVERLAPPED));
	ovlrd.hEvent = ovlrd_hEvent;

	int	rc = ReadFile( comHandle, buf , cnt , &r , &ovlrd ); 
	if (rc) {
		if(r == cnt) {
		// �����ǂݍ��ݐ���.
			return cnt;	//��M����.
		}
		//printf("RxError1 rc = %d\n",rc);
		return 0;
	}else{

		// �x���ǂݍ��ݒ��E�E�E.
		if(( rc =GetLastError() ) == ERROR_IO_PENDING) {
			WaitForSingleObject(ovlrd.hEvent, INFINITE);
			rc = GetOverlappedResult(comHandle,&ovlrd,&rcnt,FALSE);
			if(rc) {
				if(rcnt == cnt) 
				{
					return cnt;	// ��M�n�j.
				}
			}
			//printf("RxError3 rc = %d\n",rc);
			return 0;
		}
		//printf("RxError4 rc = %d\n",rc);
		return 0;
	}
	return 0;
}
/*********************************************************************
 *	
 *********************************************************************
 */
int	RS_checkdata()
{
	DWORD DErr=0;
	COMSTAT commstat;

	ClearCommError(comHandle,&DErr,&commstat);
	return commstat.cbInQue ;

}

/*********************************************************************
 *	�b�n�l�|�[�g�̏�����
 *********************************************************************
 */
int	RS_init(char *portno,int baudrate)
{
	static	DCB	com_dcb;
	DWORD 		DErr;

	sprintf(COM_Device,COM_DEVICENAME,portno);
	comHandle =	CreateFile(
		COM_Device,									/* �V���A���|�[�g�̕����� */
		GENERIC_READ | GENERIC_WRITE   ,			/* �A�N�Z�X���[�h */
		0,
		NULL,										/* �Z�L�����e�B���� */
		OPEN_EXISTING,								/* �쐬�t���O	*/
//		FILE_ATTRIBUTE_NORMAL|FILE_FLAG_OVERLAPPED, /* ���� */
		0,											/* ���� */
		NULL										/* �e���v���[�g�̃n���h��	*/
	);

	if(comHandle ==	INVALID_HANDLE_VALUE) {
		fprintf(stderr,	"Can't Open COM Port (%s:).\n",COM_Device + strlen("\\\\.\\") );
		exit(1);
	}

	ovlrd_hEvent = CreateEvent(NULL,TRUE,FALSE,NULL);
	ovlwr_hEvent = CreateEvent(NULL,TRUE,TRUE ,NULL);

	{
		ClearCommError(comHandle,&DErr,NULL);
		SetupComm(comHandle,8192,2048);
		PurgeComm(comHandle,PURGE_TXABORT | PURGE_RXABORT |PURGE_TXCLEAR |	PURGE_RXCLEAR);

		memset(&com_dcb,0,sizeof(com_dcb));
		com_dcb.DCBlength = sizeof(DCB);
		GetCommState(comHandle,&com_dcb);

		com_dcb.BaudRate = baudrate;
		com_dcb.ByteSize = 8;
		com_dcb.Parity   = NOPARITY;
		com_dcb.StopBits = ONESTOPBIT;
		SetCommState(comHandle,&com_dcb);

		SetCommMask(comHandle,0);
		SetCommMask(comHandle,EV_RXCHAR);

		EscapeCommFunction(comHandle, CLRBREAK);
		EscapeCommFunction(comHandle, SETDTR);
		EscapeCommFunction(comHandle, SETRTS);
	}
	return 0;
}

/*********************************************************************
 *
 *********************************************************************
 */

void RS_exit(void)
{
	CloseHandle(ovlwr_hEvent);
	CloseHandle(ovlrd_hEvent);
	CloseHandle(comHandle);
}
/*********************************************************************
 *	�G�R�[�o�b�N�E�T�[�o�[.
 *********************************************************************
 *	CTRL+A �ŒE�o����.
 *
 */
void RS_echohost(char *port_no,int baudrate)
{
	int c;
	unsigned char buf[16];
	RS_init(port_no,baudrate);			// 'COMx:' ���I�[�v������.
	printf("Entering EchobackMode: Escape=^%c\n", '@' +	KEY_ESCAPE_CH );

	while(1) {
		c = RS_keyInput();if(c == KEY_ESCAPE_CH) break;	//�E�o.
		if(	RS_checkdata() ) {
			RS_getdata(buf,1);
			c = buf[0];
			RS_putc(c);
			putchar(c);
			if(c == '\r') {
				c = '\n';
				RS_putc(c);
				putchar(c);
			}
		}
	}
	RS_exit();
}
/*********************************************************************
 *	
 *********************************************************************
 */
int		RS_getc(int timeout)
{
	int c;
#if	VERBOSE_DEBUG
	int t0=timeout;
#endif
	unsigned char buf[128];
	while(1) {
		if(	RS_checkdata() ) {
			RS_getdata(buf,1);
			c = buf[0];
#if	VERBOSE_DEBUG
			printf("RS_getc(%d)=0x%02x\n",t0,c);
#endif
			return c;
		}
		if( timeout > 0 ) {
			timeout--;
			if(timeout==0) break;
		}
		Sleep(1);
	}
#if	VERBOSE_DEBUG
			printf("RS_getc(%d)=-1\n",t0);
#endif
	return -1;
}
/*********************************************************************
 *	
 *********************************************************************
 *	CTRL+A �ŒE�o����.
 *
 */
void RS_terminal(char *port_no,int baudrate)
{
	int c;
	unsigned char buf[16];

	RS_init(port_no,baudrate);			// 'COMx:' ���I�[�v������.
	printf("Entering TerminalMode: Escape=^%c\n", '@' +	KEY_ESCAPE_CH );
	signal(SIGINT,SIG_IGN);	// ^C �𖳌��ɂ���.

#if	1
	int adr = 0;

	while(1) {
		c = RS_keyInput();
		if(c) {
			if(c == KEY_ESCAPE_CH) break;	//�E�o.
//			RS_putc(c);
			if(c == 'a') {
				RS_putc(0xff);
				RS_putc(0xff);
				RS_putc('b');
				RS_putc('x');
				RS_putc(0x02);
				RS_putc(adr);
				RS_putc(adr>>8);
				RS_putc(0x00);
				adr += 32;
			}else{
				RS_putc(c);
				printf("\n%04x ",adr);
			}
		}
		if(	RS_checkdata() ) {
			RS_getdata(buf,1);
//			Term_Log(buf[0]);
//			puthexchar(buf[0]);
		}
	}
#endif

	signal(SIGINT,SIG_DFL);
	RS_exit();
}
/*********************************************************************
 *
 *********************************************************************
 */

