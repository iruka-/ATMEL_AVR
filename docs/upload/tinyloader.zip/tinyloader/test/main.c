/**********************************************************************
 *	ATtiny2313 ��p Serial Line Bootloader
 **********************************************************************
 */
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <util/delay.h>
#include <avr/wdt.h>
#include <stdint.h>

#include "delay.h"


#ifndef	F_CPU
#define	F_CPU	8000000		//CPU�N���b�N���g��	8MHz
#endif

/**********************************************************************
 *	
 **********************************************************************
 */
void	led_test(void)
{
	delay_100ms(10);
	PORTB ^= 0b00001100;				// PB2,3=READY,BUSY LED  , DIRECTION
}

/**********************************************************************
 *	���C��
 **********************************************************************
 */

int	main(void)
{
	cli(); // no irqs.
	DDRD  = 0;
	PORTD = 0b00000100;				// PD2 = BOOT JUMPER (LOW close=BOOT) PULLUP
	DDRB  = 0b00001100;				// PB2,3=READY,BUSY LED  , DIRECTION
	PORTB = 0;
	
	PORTB  = 0b00000100;				// PB2,3=READY,BUSY LED  , DIRECTION
	while (1) {
		led_test();
	}
}

/**********************************************************************
 *	
 **********************************************************************
 */
