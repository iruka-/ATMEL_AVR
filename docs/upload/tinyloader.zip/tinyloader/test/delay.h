typedef	unsigned char uchar;


void delay_loop(uchar __count);
void delay_us(uchar us);
void delay_100us(uchar us100);
void delay_ms(uchar ms);
void delay_100ms(uchar ms100);
