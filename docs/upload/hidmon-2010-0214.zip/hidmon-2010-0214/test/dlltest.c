/* dlltest.c */

#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

#include "hidmon.h"

#define	PINB	"pinb"
#define	PORTB	"portb"
#define	DDRB	"ddrb"

#define RAM_IO	0
#define ALL		0

char *check_poke(char *port, int data)
{
	int rc;

	rc = UsbPoke(PortAddress(port), RAM_IO, data, ALL);
	if (rc > 0) {
		return "[OK]";
	} else {
		return "[ERROR]";
	}
}

void test1(int f)
{
#if	1
	printf(" ddrd := 0x%02x, %s\n", f, check_poke("ddrd", f));
	printf("portd := 0x%02x, %s\n", f, check_poke("portd", f));
	printf(" pind := 0x%02x, %s\n", f, check_poke("pind", f));
#endif
}

unsigned char bits[] = {1,2,4,8,16,32,64,128,64,32,16,8,4,2,1};

int main(int argc, char*argv[])
{
	int i, adr, portb, rc;
	char *serial = "*";

	if (argc == 2) {
		serial = argv[1];
	}
	rc = UsbInit(serial);
	if (rc>=0) {
		printf("UsbInit(\"%s\") [OK]\n", serial);
	} else {
		printf("UsbInit(\"%s\") [ERROR], rc = %d\n", serial, rc);
		exit(1);
	}

	printf("%5s = (0x%x)\n", "portb", PortAddress("portb"));

	adr   = PortAddress(PINB);
	portb = PortAddress(PORTB);

	printf("%5s = (0x%x)\n", PINB, adr);

	test1(0);
	test1(20);		// �e�X�g�̂��߂ɁA��O�I�Ȓl����������
	test1(60);		// �e�X�g�̂��߂ɁA��O�I�Ȓl����������
	test1(32);
	test1(0x32);

	UsbPoke(PortAddress("ddrb"), RAM_IO, 0xff, ALL);
	for (i = 0; i < 10; i++) {
		int j;
		for (j = 0; j < sizeof(bits); j++) {
			// PORTB3 ��RED LED
			UsbPoke(portb, RAM_IO, bits[j], ALL);
			Sleep(100);
		}
	}

	for (i = 0; i < 1000; i++) {
		printf("%5s == 0x%02x\r", PINB, UsbPeek(adr, 0));
	}
	printf("\n");

	/* HIDaspx�̕W�����[�h�ɖ߂� */
	UsbPoke(PortAddress("portb"), RAM_IO, 0x38, ALL);
	UsbPoke(PortAddress("portd"), RAM_IO, 0x67, ALL);
	UsbPoke(PortAddress("ddrd"), RAM_IO, 0x20, ALL);

	UsbExit();

	printf("UsbExit\n");

	return 0;
}
