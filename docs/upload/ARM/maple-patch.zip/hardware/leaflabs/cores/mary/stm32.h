/**
 *  @brief General STM32 specific definitions
 */

#ifndef _STM32_H_
#define _STM32_H_

#define PCLK1   36000000U
#define PCLK2   72000000U

#define NR_INTERRUPTS 60

#endif

