#ifndef _comm_h
#define _comm_h

#include "utype.h"

#define	INIT_BAUDRATE	230400

int  uart0_init(int baud);
int  uart0_test(void);
void uart0_put(BYTE);
BYTE uart0_get(void);

#endif

