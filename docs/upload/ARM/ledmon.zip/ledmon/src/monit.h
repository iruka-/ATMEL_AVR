/*********************************************************************
 *	LED�ȈՃ��j�^.
 *********************************************************************
 */
#ifndef	_monit_h_
#define	_monit_h_

#include "utype.h"
#include "interrupt.h"
#include "taskmgr.h"
#include "comm.h"

#endif
