#ifndef	_taskmgr_h_
#define	_taskmgr_h_

void StartTask (DWORD* tobj, void(*task)(void), void* stack);
void DispatchTask (DWORD* tobj);
void Sleep (short tmr);
void TaskTimerproc (void);

#endif

