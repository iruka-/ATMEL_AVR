#ifndef	_utype_h_
#define	_utype_h_

//	�����Ȃ��^�̒�`.
typedef	unsigned char  uchar;
typedef	unsigned short ushort;
typedef	unsigned int   uint;


//	WINDOWS���̌^��`.
typedef	unsigned char  BYTE;
typedef	unsigned short WORD;
typedef	unsigned int   DWORD;


typedef	unsigned int   adrs_t;

#ifndef	NULL
#define	NULL 	0
#endif


#endif

