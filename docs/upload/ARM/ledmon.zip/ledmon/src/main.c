/*********************************************************************
 *	�b�p�t�^�m�w�o-�`�q�l ��p	�k�d�c���j�^.
 *********************************************************************
 */


#include <string.h>
#include "LPC23xx.h"
#include "monit.h"

volatile uint Timer;		/* 1kHz increment timer */

#define TASK_STACK_SIZE 	1024
#define NUM_TASKS 			2

uint	TaskStk[NUM_TASKS][TASK_STACK_SIZE];
uint	TaskContext[NUM_TASKS][16];
void	Monitor_task(void);


/*********************************************************************
 *	�^�C�}�[���荞�݁F�P���r�P��
 *********************************************************************
 */
void Isr_TIMER0(void)
{
	T0IR = 1;	/* Clear irq flag */
	Timer++;

	// �^�X�N�R���e�L�X�g���̋N���J�E���^�����Z����.

	int n;
	for (n = 0; n < NUM_TASKS; n++) {
		WORD w = TaskContext[n][1];
		if (w != 0xFFFF && w-- != 0) TaskContext[n][1] = w;
	}
}



#define PLL_N		2UL
#define PLL_M		72UL
#define CCLK_DIV	4

/*********************************************************************
 *	�h/�n�|�[�g�̏�����.
 *********************************************************************
 */
static	void IoInit (void)
{
	if ( PLLSTAT & (1 << 25) ) {
		PLLCON = 1;				/* Disconnect PLL output if PLL is in use */
		PLLFEED = 0xAA;
		PLLFEED = 0x55;
	}
	PLLCON = 0;				/* Disable PLL */
	PLLFEED = 0xAA;
	PLLFEED = 0x55;
	CLKSRCSEL = 0;			/* Select IRC (4MHz) as the PLL clock input */

	PLLCFG = ((PLL_N - 1) << 16) | (PLL_M - 1);	/* Re-configure PLL */
	PLLFEED = 0xAA;
	PLLFEED = 0x55;
	PLLCON = 1;				/* Enable PLL */
	PLLFEED = 0xAA;
	PLLFEED = 0x55;

	while ((PLLSTAT & (1 << 26)) == 0);	/* Wait for PLL locked */

	CCLKCFG = CCLK_DIV-1;	/* Select CCLK frequency (divide ratio of hclk) */
	PLLCON = 3;				/* Connect PLL output to the sysclk */
	PLLFEED = 0xAA;
	PLLFEED = 0x55;

	MAMCR = 0;				/* Configure MAM for 72MHz operation */
	MAMTIM = 3;
	MAMCR = 2;

	PCLKSEL0 = 0x00000000;	/* Select peripheral clock */
	PCLKSEL1 = 0x00000000;

	ClearVector();

	SCS |= 1;				/* Enable FIO0 and FIO1 */

	FIO1PIN2 = 0x04;		/* -|-|-|-|-|LED|-|- */
	FIO1DIR2 = 0x04;
	PINMODE3 = 0x00000020;

	/* Initialize Timer0 as 1kHz interval timer */
	RegisterVector(TIMER0_INT, Isr_TIMER0, PRI_LOWEST, CLASS_IRQ);
	T0CTCR = 0;
	T0MR0 = 18000 - 1;	/* 18M / 1k = 18000 */
	T0MCR = 0x3;		/* Clear TC and Interrupt on MR0 match */
	T0TCR = 1;

	IrqEnable();

	uart0_init(INIT_BAUDRATE);
}

/*********************************************************************
 *	���̂k�d�c�_�ŏ���.
 *********************************************************************
 */

/* FGPIO�R���g���[���̃��W�X�^ */
#define FGPIO_FIO1DIR	((volatile uint *)(0x3FFFC020))
#define FGPIO_FIO1MASK	((volatile uint *)(0x3FFFC030))
#define FGPIO_FIO1PIN	((volatile uint *)(0x3FFFC034))
#define FGPIO_FIO1CLR	((volatile uint *)(0x3FFFC03C))

/* LED��_�����鏈�� */
static	void LED_ON(void)
{
    *FGPIO_FIO1PIN=0x00000000; /* P1[18] ��'0'�ɁiLED��_����j */
}

/* LED���������鏈�� */
static	void LED_OFF(void)
{
    *FGPIO_FIO1PIN=0x00040000; /* P1[18] ��'1'�ɁiLED�������j   */
}

void LED_flipper(void)
{
    static int ledcnt = 0;

	ledcnt++;
    if(ledcnt & 1)	LED_ON();
    else 			LED_OFF();
}

void LED_task(void)
{
	while(1) {
		LED_flipper();
		Sleep(500);
	}
}
/*********************************************************************
 *	���C��
 *********************************************************************
 */
int main (void)
{
	IoInit();

	/* Start threads */
	StartTask(TaskContext[0], Monitor_task, &TaskStk[0][TASK_STACK_SIZE]);
	StartTask(TaskContext[1], LED_task  ,   &TaskStk[1][TASK_STACK_SIZE]);

	/* Drive threads */
	while(1) {
		DispatchTask(TaskContext[0]);
		DispatchTask(TaskContext[1]);
	}
}
/*********************************************************************
 *	
 *********************************************************************
 */
