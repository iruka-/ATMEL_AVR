//=========================================================
// LPC1114 Project
//=========================================================
// File Name : main.c
// Function  : Main Routine
//---------------------------------------------------------
// Rev.01 2010.08.01 Munetomo Maruyama
//---------------------------------------------------------
// Copyright (C) 2010-2011 Munetomo Maruyama
//=========================================================
// ---- License Information -------------------------------
// Anyone can FREELY use this code fully or partially
// under conditions shown below.
// 1. You may use this code only for individual purpose,
//    and educational purpose.
//    Do not use this code for business even if partially.
// 2. You can copy, modify and distribute this code.
// 3. You should remain this header text in your codes
//   including Copyright credit and License Information.
// 4. Your codes should inherit this license information.
//=========================================================
// ---- Patent Notice -------------------------------------
// I have not cared whether this system (hw + sw) causes
// infringement on the patent, copyright, trademark,
// or trade secret rights of others. You have all
// responsibilities for determining if your designs
// and products infringe on the intellectual property
// rights of others, when you use technical information
// included in this system for your business.
//=========================================================
// ---- Disclaimers ---------------------------------------
// The function and reliability of this system are not
// guaranteed. They may cause any damages to loss of
// properties, data, money, profits, life, or business.
// By adopting this system even partially, you assume
// all responsibility for its use.
//=========================================================

#ifdef __USE_CMSIS
#include "LPC11xx.h"
#endif

#include "systick.h"
#include "integer.h"
#include "uart.h"
#include "gpiodef.h"

//	LED�̃s�������蓖�Ă�.
#define	LED_PIN1	P0_7
#define	LED_PIN2	P1_5


#define	BLINK_INTERVAL	100000


//==================
// LED	Blinker
//==================
void LED_blink()
{
	static int count=0;
	static int led=0;
	count++;
	if(	count >= BLINK_INTERVAL) {
		count = 0;
		led++;
		
		digitalWrite( LED_PIN1 , led    & 1 );
		digitalWrite( LED_PIN2 ,(led+1) & 1 );
	}
}

//==================
// UART EchoBack
//==================
void UART_echo()
{
	int c;
	if( UARTReceive_Check() ) {
		c = UARTReceive_Byte();
		UARTSend_Byte(c);
	}
}

//----------------------------
//	������:�ŏ��ɂP��Ă΂��
//----------------------------
void init()
{
	Init_SysTick();

//===�@BaudRate Setup ===
//	UARTInit(38400);
	UARTInit(115200);
//	UARTInit(230400);
//	UARTInit(460800);
//	UARTInit(500000);
//	UARTInit(1000000);	// 1Mbps

//=== GPIO 0_6 0_8 0_9  R1_0 Function Setup .
    LPC_IOCON->R_PIO1_0 = 0x00000091; // digital , pullup ,GPIO :See LPC111x Users Manual.
    LPC_IOCON->PIO0_6 = 0x00000010; // GPIO, pullup
    LPC_IOCON->PIO0_8 = 0x00000010; // GPIO, pullup
    LPC_IOCON->PIO0_9 = 0x00000010; // GPIO, pullup

	pinMode(LED_PIN1,OUTPUT);
	pinMode(LED_PIN2,OUTPUT);
}

//----------------------------
//	���[�v�ɂ�薈��Ă΂��
//----------------------------
void loop(void)
{
	LED_blink();	// LED��_�ł�����.
	UART_echo();	// UART�̕������G�R�[�o�b�N����.
}


//-----------------------
// Main Routine
//-----------------------
int main(void)
{
	init();

    while(1) {
		loop();
    }

    return 0;
}

//=========================================================
// End of Program
//=========================================================
