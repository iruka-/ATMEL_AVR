/********************************************************************
 *	FLASH ��������
 ********************************************************************
 */
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <malloc.h>

#include "platform_config.h"
#include "stm32f10x.h"
#include "usb_lib.h"
#include "usb_istr.h"
#include "stm32_eval.h"
#include "hidcmd.h"
#include "monit.h"

//	CPU�N���b�N.
#define	CLOCK_KHz	72000

//	FLASH �̃y�[�W�T�C�Y.
#define	PAGE_SIZE			4096
#define	PAGE_OFFSET_MASK	(PAGE_SIZE-1)
#define	PAGE_SHIFT			12

//	�R�}���h�ԍ�.
#define	IAP_PREPARE			50
#define	IAP_RAM2FLASH		51
#define	IAP_ERASE			52

//	�������݃o�b�t�@.
#define		SRC_SIZE	PAGE_SIZE
int	 srcbuf[SRC_SIZE/sizeof(int)];



typedef void (*IAP)(uint32_t [], uint32_t []);

IAP iap_entry = (IAP)0x1fff1ff1;
uint32_t command[5], result[4];

/********************************************************************
 *	BOOT-ROM �̃G���g���[�|�C���g���Ăяo��.
 ********************************************************************
 */
static	int	call_IAP(int cmd,int arg1,int arg2,int arg3,int arg4)
{
	/* Send Reinvoke ISP command to ISP entry point*/
	command[0] = cmd;
	command[1] = arg1;
	command[2] = arg2;
	command[3] = arg3;
	command[4] = arg4;

	/* Set stack pointer to ROM value (reset default) This must be the last
	   piece of code executed before calling ISP, because most C expressions
	   and function returns will fail after the stack pointer is changed. */
	// __set_MSP(*((uint32_t *)0x1FFF0000)); /* inline asm function */

	/* Enter ISP. We call "iap_entry" to enter ISP because the ISP entry is done
	   through the same command interface as IAP. */
	iap_entry(command, result);

	return result[0];
}

/********************************************************************
 *	PAGE buffer [] 4kB �� 0xff�Ŗ��߂�.
 ********************************************************************
 */
static	void erase_buf(void)
{
	int i;
	//
	for(i=0; i< (PAGE_SIZE/sizeof(int) ); i++) {
		srcbuf[i]=(-1);
	}
}

/********************************************************************
 *	FLASH ����
 ********************************************************************
 */
static	void flash_erase(int page)
{
	int rc;
	rc = call_IAP(IAP_PREPARE,page,page	  ,CLOCK_KHz,0);
//	hex_print("prepare=",rc);

	rc = call_IAP(IAP_ERASE  ,page,page	  ,CLOCK_KHz,0);
//	hex_print("erase=",rc);
}

/********************************************************************
 *	4K�y�[�W�S��������.
 ********************************************************************
 *	�������݌�: srcbuf[]
 *	�������ݐ�: page (0..7)  4kB/page
 */
static	void flash_write(int page)
{
	int dst = page * PAGE_SIZE;
	int bytes = PAGE_SIZE;
	int rc;
	rc = call_IAP(IAP_PREPARE,page,page	  ,CLOCK_KHz,0);
//	hex_print("prepare=",rc);

	rc = call_IAP(IAP_RAM2FLASH ,dst,(int) srcbuf , bytes ,CLOCK_KHz);
//	hex_print("write=",rc);
}

/********************************************************************
 *	
 ********************************************************************
 */
#if	0
void erase_test(void)
{
	int rc,i;
	int bytes = SRC_SIZE;
	int dst = 0x7000;

	for(i=0; i<1024/4; i++) {
		srcbuf[i]=(-1);
	}
	srcbuf[0]=0x55aa;
	srcbuf[255]=0xaa55;

	rc = call_IAP(IAP_PREPARE,PAGE,PAGE	  ,CLOCK_KHz,0);
	hex_print("prepare=",rc);

	rc = call_IAP(IAP_ERASE  ,PAGE,PAGE	  ,CLOCK_KHz,0);
	hex_print("erase=",rc);

	rc = call_IAP(IAP_PREPARE,PAGE,PAGE	  ,CLOCK_KHz,0);
	hex_print("prepare=",rc);

	rc = call_IAP(IAP_RAM2FLASH  ,dst,(int) srcbuf , bytes ,CLOCK_KHz);
	hex_print("write=",rc);
}
#endif

/********************************************************************
 *	
 ********************************************************************
 */
void FLASH_ProgramWord(int adr,int data)
{
	int off = adr & PAGE_OFFSET_MASK;

	srcbuf[off/sizeof(int)] = data;
}

/********************************************************************
 *	
 ********************************************************************
 */
void FLASH_ProgramPage(int adr)
{
	int page;
	page = adr >> PAGE_SHIFT;
	flash_write(page);
	erase_buf();
}

/********************************************************************
 *	
 ********************************************************************
 */
void FLASH_ErasePage(int adr)
{
	int page;
	if((adr & PAGE_OFFSET_MASK )== 0) {
		page = adr >> PAGE_SHIFT;
		flash_erase(page);
		erase_buf();
	}
}

/********************************************************************
 *	D U M M Y
 ********************************************************************
 */
void FLASH_Lock(void)
{}
void FLASH_Unlock(void)
{}

int	_sdata[1];

/********************************************************************
 *	
 ********************************************************************
 */
