#ifndef	usb_istr_h_
#define	usb_istr_h_

/*
 */

void	FLASH_ProgramWord(int adr,int data);
void	FLASH_ProgramPage(int adr);
void	FLASH_ErasePage(int adr);

void 	FLASH_Lock(void);
void 	FLASH_Unlock(void);

void 	SetEPTxValid(int ep);
void 	SetEPRxStatus(int ep,int st);

#endif

