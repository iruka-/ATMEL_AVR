#!/usr/bin/perl

#
# Convert: stm32f10x.h  to  portadrs.h
#
use strict;

my $stm32_hdr = '../../HW/Libraries/CMSIS/CM3/DeviceSupport/ST/STM32F10x/stm32f10x.h';
my $core_hdr  = '../../HW/Libraries/CMSIS/CM3/CoreSupport/core_cm3.h';

# ../../HW/Libraries/CMSIS/CM3/DeviceSupport/ST/STM32F10x/stm32f10x.h
# ../../HW/Libraries/CMSIS/CM3/CoreSupport/core_cm3.h

my @buf;
my @hdr;

my %hash;
my @labels;

# =====================================================
#      
# =====================================================
sub loadfile()
{
	my ($file)=@_;
	my @buf;
	open(FILE,$file) || die("Can't open file $file");
	@buf = <FILE>;
	close(FILE);
	return @buf;
}

# =====================================================
#      
# =====================================================
sub push_hdr()
{
	my $line;
	foreach $line (@buf) {
		$line =~ s/\n//;
		$line =~ s/\r//;
		push @hdr,$line;
	}
}

# =====================================================
#      
# =====================================================
sub sub1()
{
	my $line;
	my $value;
	my $label;

	foreach $line(keys %hash) {
		$value = $line;
		$label = '"' . $hash{$value} . '"';
#		printf("	{%-16s,%s,0	},\n",$label , $value );
		push @labels,"$value,$label";
	}

	my @label = sort(@labels);
	foreach $line(@label) {
		($value,$label)=split(/,/,$line);
		printf("	{%-16s,%s,0	},\n",$label , $value );
	}

}
sub pr_struct()
{
	my $line;
	my $s=0;
	foreach $line (@hdr) {
		if($line =~ /^typedef.*struct/) {
			print "\n------------------------------\n";
			$s=1;
		}
		if($s) 
		{
			print $line . "\n";
		}
		if($line =~ /^}/) {$s=0;}
	}
}
# =====================================================
#      
# =====================================================
sub main()
{
	@buf = &loadfile($core_hdr);
	&push_hdr();
	@buf = &loadfile($stm32_hdr);
	&push_hdr();

	&pr_struct();
}

# =====================================================
#      
# =====================================================

&main();

