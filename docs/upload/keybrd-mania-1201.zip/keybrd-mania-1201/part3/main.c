/**********************************************************************
 *	PS2 Keyboard Library : Sample Main
 **********************************************************************
 */
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <util/delay.h>

#include "config.h"
#include "task.h"
#include "taskdef.h"
#include "timer.h"
#include "sound.h"
#include "ps2keyb.h"
#include "morse.h"


#define	ESCAPE	0x1b		// [ESC]

#define	BACKGROUND_BEEP	0	//�펞�A�w�i����炷(����m�F�p).

/**********************************************************************
 *	
 **********************************************************************
 */
void quit();				// bootloader�ɖ߂�.

/**********************************************************************
 *	
 **********************************************************************
 */
uchar keyon_f;				// �Ō���=true

/**********************************************************************
 *	
 **********************************************************************
 */
void keyon(uchar c)
{
	keyon_f = c;
}

/**********************************************************************
 *	
 **********************************************************************
 */
void main_task(void)
{
	uchar c ;
	if(morse_stat()) {		//�Ō��^�X�N���������Ȃ�A�������Ȃ�.
		sleep_tsk(20);		//20tick �҂�.
		return;
	}

	c = kbd_getchar();		//PS2 keyboard���� ASCII�R�[�h���擾����.
	if( c == 0 ) {			//�L�[���͖���.
		sleep_tsk(20);		//20tick �҂�.
		return;
	}
	if( c == ESCAPE) {		// [ESC]�������ꂽ.
		quit();				// bootloader �ɖ߂�.
	}
	// [ESC] �ȊO�̃L�[���͂�������.
	morse_send(c);			// ���[���X�����𔭐M����.(c=ASCII CODE)
	sleep_tsk(20);		//20tick �҂�.
}


/**********************************************************************
 *	
 **********************************************************************
 */
#define	PITCH  10
#define	PITCH2 8

static uchar cnt =0x80;
static uchar cnt2=0x80;

/**********************************************************************
 *	���U����炷.
 **********************************************************************
 */
void beep_task_2(void)
{
	static  char add=PITCH2 ;
	cnt2 += add;
	if(add>0) {
		if(	cnt2 >= 0xe0) {
			add = -PITCH2 ;
		}
	}else{
		if(	cnt2 <= 0x20) {
			add =  PITCH2 ;
		}
	}
}

/**********************************************************************
 *	
 **********************************************************************
 */
void beep_task(void)
{
#if	BACKGROUND_BEEP
	static  char add=PITCH ;
	cnt += add;
	if(add>0) {
		if(	cnt >= 0xe0) {
			add = -PITCH ;
		}
	}else{
		if(	cnt <= 0x20) {
			add =  PITCH ;
		}
	}
#endif

	if(keyon_f)
		beep_task_2();

	int x = (cnt>>5) + cnt2;
	x>>=1;
	OCR0A = x;
}


/**********************************************************************
 *	���C��
 **********************************************************************
 */
int	main(void)
{
	init_tsk();
	kbd_init();
	sound_init();
	morse_init();
	timer_init(360-1);	// 20��S(50kHz)�����Ŋ��荞��.
	sei();

	reg_tsk(ID_main,main_task);
	reg_tsk(ID_beep1,beep_task);
	reg_tsk(ID_beep2,morse_task);

	while(1) {
		timer_wait();
		dispatch_tsk();
	}
	return 0;
}

/**********************************************************************
 *	
 **********************************************************************
 */
