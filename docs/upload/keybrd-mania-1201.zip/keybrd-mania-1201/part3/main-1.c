/**********************************************************************
 *	PS2 Keyboard Library : Sample Main
 **********************************************************************
 */
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <util/delay.h>

#include "config.h"
#include "task.h"
#include "taskdef.h"
#include "timer.h"
#include "sound.h"
#include "ps2keyb.h"

void quit();

uchar keyon_f;

void keyon(uchar c)
{
	keyon_f = c;
}

void beep_init()
{
	SPK_OUT_PORT &= ~SPK_OUT_BIT_MASK;	// PD6��0.
	SPK_OUT_DDR  |= SPK_OUT_BIT_MASK;	// PD6��out.
}

void beep_flip()
{
	SPK_OUT_PIN  = SPK_OUT_BIT_MASK;	// PD6��flip.
}

void beep_task1(void)
{
	beep_flip();
	sleep_tsk(32);
}

void beep_task2(void)
{
//	beep_flip();
	sleep_tsk(24);
}

void beep_task3(void)
{
//	beep_flip();
	sleep_tsk(22);
}

void main_task(void)
{
	uchar c;
	c = kbd_getchar();
	if( c == 'q') {
		quit();
	}
#if	0
	static int timeout = 0;
	timeout++;
	if(timeout==0) {
//		quit();
	}
#endif
	sleep_tsk(20);
}


/**********************************************************************
 *	
 **********************************************************************
p tccr0a 0100_0010  # COM0A=01 : ��r��v��OC0A�g�O��.
                    # WGM210 = 010 : ��r��v�^�C�}�[�A�J�E���^�N���A.
p tccr0b 0000_0011  # fclk 1/64 ����.
p ddrb.2 1			# PB2���o��.
p ocr0a f1			#  TIMER0 �̎�����ݒ肷��.
 **********************************************************************
 */
void sound1_init(void)
{
	SPK_OUT_DDR |= SPK_OUT_BIT_MASK;	// PD6��out.
	TCCR0A = 0b11000011;
	TCCR0B = 0b00000001;
	OCR0A = 128;
}

/**********************************************************************
 *	
 **********************************************************************
 */
void sound1_beep(uchar pitch)
{
	if(pitch) {
		OCR0A = pitch;
		SPK_OUT_DDR |= SPK_OUT_BIT_MASK;	// PD6��out.
	}else{
		SPK_OUT_DDR &= ~SPK_OUT_BIT_MASK;	// PD6��in.
	}
}

#define	PITCH  12
#define	PITCH2 10

static uchar cnt =0x80;
static uchar cnt2=0x80;

void beep_task_2(void)
{
	static  char add=PITCH2 ;
	cnt2 += add;
	if(add>0) {
		if(	cnt2 >= 0xe0) {
			add = -PITCH2 ;
		}
	}else{
		if(	cnt2 <= 0x20) {
			add =  PITCH2 ;
		}
	}
}

void beep_task(void)
{
	static  char add=PITCH ;
	cnt += add;
	if(add>0) {
		if(	cnt >= 0xe0) {
			add = -PITCH ;
		}
	}else{
		if(	cnt <= 0x20) {
			add =  PITCH ;
		}
	}
	beep_task_2();
	int x = cnt + cnt2;
	x>>=1;
	OCR0A = x;
}


int	main(void)
{
	init_tsk();
	kbd_init();
	beep_init();
	timer_init(360-1);	// 20��S(50kHz)�����Ŋ��荞��.
	sound1_init();
	sei();

	reg_tsk(ID_main,main_task);
	reg_tsk(ID_beep1,beep_task);

//	reg_tsk(ID_beep1,beep_task1);
//	reg_tsk(ID_beep2,beep_task2);
//	reg_tsk(ID_beep3,beep_task3);

	while(1) {
		timer_wait();
		dispatch_tsk();
	}
	return 0;
}

