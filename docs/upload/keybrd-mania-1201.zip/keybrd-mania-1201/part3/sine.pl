#!/usr/bin/perl


#
# sine table 
#
my $center = 0;
my $scale  = 128-8;

#my $center = 128/4;
#my $scale  = (128/4 - 4);

my $twopi  = 64;

#
# ���ϗ����Ktable �𐶐�.
#
sub tone12()
{
	$m = 128.0;
	$r = 2 ** (1/12);
	for($i=0;$i<12;$i++) {
		printf("%x\n",$m);
		$m = $m * $r;
	}
}

#
# sine table �𐶐�.
#
sub sinewave()
{
	for($i=0;$i<=$twopi;$i++) {
		$rad = $i * 3.1415926535 * 2.0 / $twopi;
		$sine = int( sin($rad) * $scale + $center );
		$shex = $sine & 0xff;
		printf("	0x%x,	/* %2d: %3d */\n",$shex,$i,$sine - $center);
	}
}

sub main()
{
	&sinewave();
}


&main();

