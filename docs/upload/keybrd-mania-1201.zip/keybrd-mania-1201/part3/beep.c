/**********************************************************************
 *	Beep Sound Driver
 **********************************************************************
 *
 *	sound_init()			�|�[�g������.
 *	sound_beep(pitch)		BEEP�� ����.
 */
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>


#include "config.h"
#include "task.h"

/**********************************************************************
 *	
 **********************************************************************
p tccr0a 0100_0010  # COM0A=01 : ��r��v��OC0A�g�O��.
                    # WGM210 = 010 : ��r��v�^�C�}�[�A�J�E���^�N���A.
p tccr0b 0000_0011  # fclk 1/64 ����.
p ddrb.2 1			# PB2���o��.
p ocr0a f1			#  TIMER0 �̎�����ݒ肷��.
 **********************************************************************
 */
void sound_init(void)
{
	SPK_OUT_DDR |= SPK_OUT_BIT_MASK;	// PD6��out.
	TCCR0A = 0b01000010;
	TCCR0B = 0b00000011;
}

/**********************************************************************
 *	
 **********************************************************************
 */
void sound_beep(uchar pitch)
{
	if(pitch) {
		OCR0A = pitch;
		SPK_OUT_DDR |= SPK_OUT_BIT_MASK;	// PD6��out.
	}else{
		SPK_OUT_DDR &= ~SPK_OUT_BIT_MASK;	// PD6��in.
	}
}


#if	0
void beep_init()
{
	SPK_OUT_PORT &= ~SPK_OUT_BIT_MASK;	// PD6��0.
	SPK_OUT_DDR  |= SPK_OUT_BIT_MASK;	// PD6��out.
}

void beep_flip()
{
	SPK_OUT_PIN  = SPK_OUT_BIT_MASK;	// PD6��flip.
}

void beep_task1(void)
{
	beep_flip();
	sleep_tsk(32);
}

void beep_task2(void)
{
//	beep_flip();
	sleep_tsk(24);
}

void beep_task3(void)
{
//	beep_flip();
	sleep_tsk(22);
}
/**********************************************************************
 *	
 **********************************************************************
p tccr0a 0100_0010  # COM0A=01 : ��r��v��OC0A�g�O��.
                    # WGM210 = 010 : ��r��v�^�C�}�[�A�J�E���^�N���A.
p tccr0b 0000_0011  # fclk 1/64 ����.
p ddrb.2 1			# PB2���o��.
p ocr0a f1			#  TIMER0 �̎�����ݒ肷��.
 **********************************************************************
 */
void sound1_init(void)
{
	SPK_OUT_DDR |= SPK_OUT_BIT_MASK;	// PD6��out.
	TCCR0A = 0b11000011;
	TCCR0B = 0b00000001;
	OCR0A = 128;
}

/**********************************************************************
 *	
 **********************************************************************
 */
void sound1_beep(uchar pitch)
{
	if(pitch) {
		OCR0A = pitch;
		SPK_OUT_DDR |= SPK_OUT_BIT_MASK;	// PD6��out.
	}else{
		SPK_OUT_DDR &= ~SPK_OUT_BIT_MASK;	// PD6��in.
	}
}

#endif
/**********************************************************************
 *	
 **********************************************************************
 */
