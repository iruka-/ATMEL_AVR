/**********************************************************************
 *	Tiny Task Controler
 **********************************************************************
 *	�^�X�NID�������Ō��߂Ă悢.
 *	task.h ::MAX_TASKS �ȏ��ID�͋֎~.
 */

#ifndef	_taskdef_h_
#define	_taskdef_h_

#define	ID_main		0
#define	ID_kbd		1
#define	ID_beep1	2
#define	ID_beep2	3
#define	ID_beep3	4




#endif	//_taskdef_h_
