﻿namespace hidspxGUI
{
    partial class MainForm
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ExtFuse = new System.Windows.Forms.Label();
            this.ChipButton = new System.Windows.Forms.Button();
            this.WriteFuseButton = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.EFuseTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.LFuseTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.HFuseTextBox = new System.Windows.Forms.TextBox();
            this.ExitButton = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.hidspxButton = new System.Windows.Forms.Button();
            this.hidspxTextBox = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.HexDumpFlashMButton = new System.Windows.Forms.Button();
            this.ProgramFlashButton = new System.Windows.Forms.Button();
            this.VerifyFlashButton = new System.Windows.Forms.Button();
            this.ReadFlashButton = new System.Windows.Forms.Button();
            this.FlashFileButton = new System.Windows.Forms.Button();
            this.FlashFileTextBox = new System.Windows.Forms.TextBox();
            this.WriteFlashButton = new System.Windows.Forms.Button();
            this.CMDpromptButton = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.HexDumpEEPROMButton = new System.Windows.Forms.Button();
            this.VerifyEEPROMButton = new System.Windows.Forms.Button();
            this.WriteEEPROMButton = new System.Windows.Forms.Button();
            this.ReadEEPROMButton = new System.Windows.Forms.Button();
            this.EEPROMFileButton = new System.Windows.Forms.Button();
            this.EEPROMFileTextBox = new System.Windows.Forms.TextBox();
            this.Both_write = new System.Windows.Forms.Button();
            this.ProgressBar = new System.Windows.Forms.ProgressBar();
            this.OpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.SaveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.CommandLineOptionTextBox = new System.Windows.Forms.TextBox();
            this.FuseViewButton = new System.Windows.Forms.Button();
            this.Help = new System.Windows.Forms.Button();
            this.ChipEraseButton = new System.Windows.Forms.Button();
            this.LockBitTextBox = new System.Windows.Forms.TextBox();
            this.WriteLockBitButton = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.LogTextBox = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.EnterButton = new System.Windows.Forms.Button();
            this.ParmTextBox = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.AVRdocButton = new System.Windows.Forms.Button();
            this.LogClearButton = new System.Windows.Forms.Button();
            this.SimpleModeCheckBox = new System.Windows.Forms.CheckBox();
            this.DeviceName = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ExtFuse);
            this.groupBox2.Controls.Add(this.ChipButton);
            this.groupBox2.Controls.Add(this.WriteFuseButton);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.EFuseTextBox);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.LFuseTextBox);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.HFuseTextBox);
            this.groupBox2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(138, 0);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Size = new System.Drawing.Size(364, 48);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Fuse (HEX)";
            // 
            // ExtFuse
            // 
            this.ExtFuse.AutoSize = true;
            this.ExtFuse.Location = new System.Drawing.Point(263, 22);
            this.ExtFuse.Name = "ExtFuse";
            this.ExtFuse.Size = new System.Drawing.Size(16, 16);
            this.ExtFuse.TabIndex = 9;
            this.ExtFuse.Text = "--";
            // 
            // ChipButton
            // 
            this.ChipButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ChipButton.BackgroundImage")));
            this.ChipButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ChipButton.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChipButton.Location = new System.Drawing.Point(9, 17);
            this.ChipButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ChipButton.Name = "ChipButton";
            this.ChipButton.Size = new System.Drawing.Size(69, 24);
            this.ChipButton.TabIndex = 0;
            this.ChipButton.Text = " Read";
            this.ChipButton.UseVisualStyleBackColor = true;
            this.ChipButton.Click += new System.EventHandler(this.ChipButton_Click);
            // 
            // WriteFuseButton
            // 
            this.WriteFuseButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.WriteFuseButton.Location = new System.Drawing.Point(288, 17);
            this.WriteFuseButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.WriteFuseButton.Name = "WriteFuseButton";
            this.WriteFuseButton.Size = new System.Drawing.Size(69, 24);
            this.WriteFuseButton.TabIndex = 4;
            this.WriteFuseButton.Text = "Write";
            this.WriteFuseButton.UseVisualStyleBackColor = true;
            this.WriteFuseButton.Click += new System.EventHandler(this.WriteFuseButton_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(201, 21);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(24, 16);
            this.label6.TabIndex = 8;
            this.label6.Text = "Ex";
            // 
            // EFuseTextBox
            // 
            this.EFuseTextBox.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.EFuseTextBox.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.EFuseTextBox.Location = new System.Drawing.Point(231, 19);
            this.EFuseTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.EFuseTextBox.MaxLength = 2;
            this.EFuseTextBox.Name = "EFuseTextBox";
            this.EFuseTextBox.Size = new System.Drawing.Size(26, 22);
            this.EFuseTextBox.TabIndex = 3;
            this.EFuseTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(83, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(22, 16);
            this.label4.TabIndex = 5;
            this.label4.Text = "Lo";
            // 
            // LFuseTextBox
            // 
            this.LFuseTextBox.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.LFuseTextBox.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.LFuseTextBox.Location = new System.Drawing.Point(111, 19);
            this.LFuseTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.LFuseTextBox.MaxLength = 2;
            this.LFuseTextBox.Name = "LFuseTextBox";
            this.LFuseTextBox.Size = new System.Drawing.Size(26, 22);
            this.LFuseTextBox.TabIndex = 1;
            this.LFuseTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(143, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Hi";
            // 
            // HFuseTextBox
            // 
            this.HFuseTextBox.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.HFuseTextBox.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.HFuseTextBox.Location = new System.Drawing.Point(169, 19);
            this.HFuseTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.HFuseTextBox.MaxLength = 2;
            this.HFuseTextBox.Name = "HFuseTextBox";
            this.HFuseTextBox.Size = new System.Drawing.Size(26, 22);
            this.HFuseTextBox.TabIndex = 2;
            this.HFuseTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ExitButton
            // 
            this.ExitButton.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitButton.Location = new System.Drawing.Point(511, 67);
            this.ExitButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(73, 24);
            this.ExitButton.TabIndex = 4;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.hidspxButton);
            this.groupBox4.Controls.Add(this.hidspxTextBox);
            this.groupBox4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(5, 364);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox4.Size = new System.Drawing.Size(184, 52);
            this.groupBox4.TabIndex = 8;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "hidspx.exe File";
            // 
            // hidspxButton
            // 
            this.hidspxButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("hidspxButton.BackgroundImage")));
            this.hidspxButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.hidspxButton.Location = new System.Drawing.Point(162, 23);
            this.hidspxButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.hidspxButton.Name = "hidspxButton";
            this.hidspxButton.Size = new System.Drawing.Size(16, 16);
            this.hidspxButton.TabIndex = 1;
            this.hidspxButton.UseVisualStyleBackColor = true;
            this.hidspxButton.Click += new System.EventHandler(this.hidspxButton_Click);
            // 
            // hidspxTextBox
            // 
            this.hidspxTextBox.Location = new System.Drawing.Point(8, 20);
            this.hidspxTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.hidspxTextBox.MaxLength = 0;
            this.hidspxTextBox.Name = "hidspxTextBox";
            this.hidspxTextBox.Size = new System.Drawing.Size(148, 22);
            this.hidspxTextBox.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.HexDumpFlashMButton);
            this.groupBox5.Controls.Add(this.ProgramFlashButton);
            this.groupBox5.Controls.Add(this.VerifyFlashButton);
            this.groupBox5.Controls.Add(this.ReadFlashButton);
            this.groupBox5.Controls.Add(this.FlashFileButton);
            this.groupBox5.Controls.Add(this.FlashFileTextBox);
            this.groupBox5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(195, 282);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox5.Size = new System.Drawing.Size(395, 81);
            this.groupBox5.TabIndex = 9;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Flash";
            // 
            // HexDumpFlashMButton
            // 
            this.HexDumpFlashMButton.Location = new System.Drawing.Point(104, 47);
            this.HexDumpFlashMButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.HexDumpFlashMButton.Name = "HexDumpFlashMButton";
            this.HexDumpFlashMButton.Size = new System.Drawing.Size(88, 24);
            this.HexDumpFlashMButton.TabIndex = 4;
            this.HexDumpFlashMButton.Text = "HEX dump";
            this.HexDumpFlashMButton.UseVisualStyleBackColor = true;
            this.HexDumpFlashMButton.Click += new System.EventHandler(this.HexDumpFlashButton_Click);
            // 
            // ProgramFlashButton
            // 
            this.ProgramFlashButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ProgramFlashButton.BackgroundImage")));
            this.ProgramFlashButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ProgramFlashButton.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProgramFlashButton.Location = new System.Drawing.Point(300, 47);
            this.ProgramFlashButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProgramFlashButton.Name = "ProgramFlashButton";
            this.ProgramFlashButton.Size = new System.Drawing.Size(88, 24);
            this.ProgramFlashButton.TabIndex = 5;
            this.ProgramFlashButton.Text = "Write";
            this.ProgramFlashButton.UseVisualStyleBackColor = true;
            this.ProgramFlashButton.Click += new System.EventHandler(this.ProgramFlashButton_Click);
            // 
            // VerifyFlashButton
            // 
            this.VerifyFlashButton.Location = new System.Drawing.Point(202, 47);
            this.VerifyFlashButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.VerifyFlashButton.Name = "VerifyFlashButton";
            this.VerifyFlashButton.Size = new System.Drawing.Size(88, 24);
            this.VerifyFlashButton.TabIndex = 4;
            this.VerifyFlashButton.Text = "Verify";
            this.VerifyFlashButton.UseVisualStyleBackColor = true;
            this.VerifyFlashButton.Click += new System.EventHandler(this.VerifyFlashButton_Click);
            // 
            // ReadFlashButton
            // 
            this.ReadFlashButton.Location = new System.Drawing.Point(6, 47);
            this.ReadFlashButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ReadFlashButton.Name = "ReadFlashButton";
            this.ReadFlashButton.Size = new System.Drawing.Size(88, 24);
            this.ReadFlashButton.TabIndex = 3;
            this.ReadFlashButton.Text = "Save";
            this.ReadFlashButton.UseVisualStyleBackColor = true;
            this.ReadFlashButton.Click += new System.EventHandler(this.ReadFlashButton_Click);
            // 
            // FlashFileButton
            // 
            this.FlashFileButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("FlashFileButton.BackgroundImage")));
            this.FlashFileButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.FlashFileButton.Location = new System.Drawing.Point(371, 19);
            this.FlashFileButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.FlashFileButton.Name = "FlashFileButton";
            this.FlashFileButton.Size = new System.Drawing.Size(16, 16);
            this.FlashFileButton.TabIndex = 2;
            this.FlashFileButton.UseVisualStyleBackColor = true;
            this.FlashFileButton.Click += new System.EventHandler(this.FlashFileButton_Click);
            // 
            // FlashFileTextBox
            // 
            this.FlashFileTextBox.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FlashFileTextBox.Location = new System.Drawing.Point(4, 18);
            this.FlashFileTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.FlashFileTextBox.Name = "FlashFileTextBox";
            this.FlashFileTextBox.Size = new System.Drawing.Size(361, 20);
            this.FlashFileTextBox.TabIndex = 1;
            this.FlashFileTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // WriteFlashButton
            // 
            this.WriteFlashButton.Location = new System.Drawing.Point(13, 22);
            this.WriteFlashButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.WriteFlashButton.Name = "WriteFlashButton";
            this.WriteFlashButton.Size = new System.Drawing.Size(89, 24);
            this.WriteFlashButton.TabIndex = 0;
            this.WriteFlashButton.Text = "Fast Write";
            this.WriteFlashButton.UseVisualStyleBackColor = true;
            this.WriteFlashButton.Click += new System.EventHandler(this.WriteFlashButton_Click);
            // 
            // CMDpromptButton
            // 
            this.CMDpromptButton.Location = new System.Drawing.Point(112, 22);
            this.CMDpromptButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CMDpromptButton.Name = "CMDpromptButton";
            this.CMDpromptButton.Size = new System.Drawing.Size(89, 24);
            this.CMDpromptButton.TabIndex = 1;
            this.CMDpromptButton.Text = "CMD prompt";
            this.CMDpromptButton.UseVisualStyleBackColor = true;
            this.CMDpromptButton.Click += new System.EventHandler(this.CMDpromptButton_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.HexDumpEEPROMButton);
            this.groupBox6.Controls.Add(this.VerifyEEPROMButton);
            this.groupBox6.Controls.Add(this.WriteEEPROMButton);
            this.groupBox6.Controls.Add(this.ReadEEPROMButton);
            this.groupBox6.Controls.Add(this.EEPROMFileButton);
            this.groupBox6.Controls.Add(this.EEPROMFileTextBox);
            this.groupBox6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(195, 364);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox6.Size = new System.Drawing.Size(395, 81);
            this.groupBox6.TabIndex = 10;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "EEPROM";
            // 
            // HexDumpEEPROMButton
            // 
            this.HexDumpEEPROMButton.Location = new System.Drawing.Point(104, 45);
            this.HexDumpEEPROMButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.HexDumpEEPROMButton.Name = "HexDumpEEPROMButton";
            this.HexDumpEEPROMButton.Size = new System.Drawing.Size(89, 24);
            this.HexDumpEEPROMButton.TabIndex = 3;
            this.HexDumpEEPROMButton.Text = "HEX dump";
            this.HexDumpEEPROMButton.UseVisualStyleBackColor = true;
            this.HexDumpEEPROMButton.Click += new System.EventHandler(this.HexDumpEEPROMButton_Click);
            // 
            // VerifyEEPROMButton
            // 
            this.VerifyEEPROMButton.Location = new System.Drawing.Point(202, 45);
            this.VerifyEEPROMButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.VerifyEEPROMButton.Name = "VerifyEEPROMButton";
            this.VerifyEEPROMButton.Size = new System.Drawing.Size(89, 24);
            this.VerifyEEPROMButton.TabIndex = 4;
            this.VerifyEEPROMButton.Text = "Verify";
            this.VerifyEEPROMButton.UseVisualStyleBackColor = true;
            this.VerifyEEPROMButton.Click += new System.EventHandler(this.VerifyEEPROMButton_Click);
            // 
            // WriteEEPROMButton
            // 
            this.WriteEEPROMButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("WriteEEPROMButton.BackgroundImage")));
            this.WriteEEPROMButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.WriteEEPROMButton.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WriteEEPROMButton.Location = new System.Drawing.Point(300, 45);
            this.WriteEEPROMButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.WriteEEPROMButton.Name = "WriteEEPROMButton";
            this.WriteEEPROMButton.Size = new System.Drawing.Size(89, 24);
            this.WriteEEPROMButton.TabIndex = 5;
            this.WriteEEPROMButton.Text = "Write";
            this.WriteEEPROMButton.UseVisualStyleBackColor = true;
            this.WriteEEPROMButton.Click += new System.EventHandler(this.WriteEEPROMButton_Click);
            // 
            // ReadEEPROMButton
            // 
            this.ReadEEPROMButton.Location = new System.Drawing.Point(6, 44);
            this.ReadEEPROMButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ReadEEPROMButton.Name = "ReadEEPROMButton";
            this.ReadEEPROMButton.Size = new System.Drawing.Size(89, 24);
            this.ReadEEPROMButton.TabIndex = 2;
            this.ReadEEPROMButton.Text = "Save";
            this.ReadEEPROMButton.UseVisualStyleBackColor = true;
            this.ReadEEPROMButton.Click += new System.EventHandler(this.ReadEEPROMButton_Click);
            // 
            // EEPROMFileButton
            // 
            this.EEPROMFileButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("EEPROMFileButton.BackgroundImage")));
            this.EEPROMFileButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.EEPROMFileButton.Location = new System.Drawing.Point(371, 20);
            this.EEPROMFileButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.EEPROMFileButton.Name = "EEPROMFileButton";
            this.EEPROMFileButton.Size = new System.Drawing.Size(16, 16);
            this.EEPROMFileButton.TabIndex = 1;
            this.EEPROMFileButton.UseVisualStyleBackColor = true;
            this.EEPROMFileButton.Click += new System.EventHandler(this.EEPROMFileButton_Click);
            // 
            // EEPROMFileTextBox
            // 
            this.EEPROMFileTextBox.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EEPROMFileTextBox.Location = new System.Drawing.Point(4, 16);
            this.EEPROMFileTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.EEPROMFileTextBox.Name = "EEPROMFileTextBox";
            this.EEPROMFileTextBox.Size = new System.Drawing.Size(361, 20);
            this.EEPROMFileTextBox.TabIndex = 0;
            this.EEPROMFileTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Both_write
            // 
            this.Both_write.Location = new System.Drawing.Point(210, 22);
            this.Both_write.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Both_write.Name = "Both_write";
            this.Both_write.Size = new System.Drawing.Size(89, 24);
            this.Both_write.TabIndex = 2;
            this.Both_write.Text = "Write(Both)";
            this.Both_write.UseVisualStyleBackColor = true;
            this.Both_write.Click += new System.EventHandler(this.Both_write_Click);
            // 
            // ProgressBar
            // 
            this.ProgressBar.Location = new System.Drawing.Point(5, 267);
            this.ProgressBar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProgressBar.Name = "ProgressBar";
            this.ProgressBar.Size = new System.Drawing.Size(585, 12);
            this.ProgressBar.TabIndex = 0;
            // 
            // OpenFileDialog
            // 
            this.OpenFileDialog.FileName = "openFileDialog1";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.CommandLineOptionTextBox);
            this.groupBox9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.Location = new System.Drawing.Point(7, 49);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(194, 52);
            this.groupBox9.TabIndex = 2;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Command line Option";
            // 
            // CommandLineOptionTextBox
            // 
            this.CommandLineOptionTextBox.Location = new System.Drawing.Point(6, 20);
            this.CommandLineOptionTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CommandLineOptionTextBox.Name = "CommandLineOptionTextBox";
            this.CommandLineOptionTextBox.Size = new System.Drawing.Size(176, 22);
            this.CommandLineOptionTextBox.TabIndex = 0;
            // 
            // FuseViewButton
            // 
            this.FuseViewButton.Location = new System.Drawing.Point(8, 22);
            this.FuseViewButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.FuseViewButton.Name = "FuseViewButton";
            this.FuseViewButton.Size = new System.Drawing.Size(78, 24);
            this.FuseViewButton.TabIndex = 0;
            this.FuseViewButton.Text = "FuseCalc";
            this.FuseViewButton.UseVisualStyleBackColor = true;
            this.FuseViewButton.Click += new System.EventHandler(this.FuseViewButton_Click);
            // 
            // Help
            // 
            this.Help.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Help.BackgroundImage")));
            this.Help.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Help.Location = new System.Drawing.Point(184, 22);
            this.Help.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Help.Name = "Help";
            this.Help.Size = new System.Drawing.Size(78, 24);
            this.Help.TabIndex = 2;
            this.Help.Text = "News";
            this.Help.UseVisualStyleBackColor = true;
            this.Help.Click += new System.EventHandler(this.Help_Click_1);
            // 
            // ChipEraseButton
            // 
            this.ChipEraseButton.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChipEraseButton.Location = new System.Drawing.Point(99, 283);
            this.ChipEraseButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ChipEraseButton.Name = "ChipEraseButton";
            this.ChipEraseButton.Size = new System.Drawing.Size(84, 24);
            this.ChipEraseButton.TabIndex = 6;
            this.ChipEraseButton.Text = "ChipErase";
            this.ChipEraseButton.UseVisualStyleBackColor = true;
            this.ChipEraseButton.Click += new System.EventHandler(this.ChipEraseButton_Click);
            // 
            // LockBitTextBox
            // 
            this.LockBitTextBox.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.LockBitTextBox.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.LockBitTextBox.Location = new System.Drawing.Point(57, 18);
            this.LockBitTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.LockBitTextBox.MaxLength = 2;
            this.LockBitTextBox.Name = "LockBitTextBox";
            this.LockBitTextBox.Size = new System.Drawing.Size(26, 22);
            this.LockBitTextBox.TabIndex = 0;
            this.LockBitTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // WriteLockBitButton
            // 
            this.WriteLockBitButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.WriteLockBitButton.Location = new System.Drawing.Point(94, 16);
            this.WriteLockBitButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.WriteLockBitButton.Name = "WriteLockBitButton";
            this.WriteLockBitButton.Size = new System.Drawing.Size(84, 24);
            this.WriteLockBitButton.TabIndex = 1;
            this.WriteLockBitButton.Text = "Write";
            this.WriteLockBitButton.UseVisualStyleBackColor = true;
            this.WriteLockBitButton.Click += new System.EventHandler(this.WriteLockBitButton_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label2);
            this.groupBox7.Controls.Add(this.WriteLockBitButton);
            this.groupBox7.Controls.Add(this.LockBitTextBox);
            this.groupBox7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.Location = new System.Drawing.Point(5, 314);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox7.Size = new System.Drawing.Size(184, 48);
            this.groupBox7.TabIndex = 7;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Lock Bit (HEX)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Image = ((System.Drawing.Image)(resources.GetObject("label2.Image")));
            this.label2.Location = new System.Drawing.Point(8, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(20, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "   ";
            // 
            // LogTextBox
            // 
            this.LogTextBox.BackColor = System.Drawing.SystemColors.InfoText;
            this.LogTextBox.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogTextBox.ForeColor = System.Drawing.SystemColors.Info;
            this.LogTextBox.Location = new System.Drawing.Point(7, 105);
            this.LogTextBox.MaxLength = 0;
            this.LogTextBox.Multiline = true;
            this.LogTextBox.Name = "LogTextBox";
            this.LogTextBox.ReadOnly = true;
            this.LogTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.LogTextBox.Size = new System.Drawing.Size(581, 161);
            this.LogTextBox.TabIndex = 0;
            this.LogTextBox.TabStop = false;
            this.LogTextBox.WordWrap = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.EnterButton);
            this.groupBox1.Controls.Add(this.ParmTextBox);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(207, 49);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(295, 52);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Command Execute (for Expart)";
            // 
            // EnterButton
            // 
            this.EnterButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.EnterButton.Location = new System.Drawing.Point(235, 19);
            this.EnterButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.EnterButton.Name = "EnterButton";
            this.EnterButton.Size = new System.Drawing.Size(53, 24);
            this.EnterButton.TabIndex = 1;
            this.EnterButton.Text = "Enter";
            this.EnterButton.UseVisualStyleBackColor = true;
            this.EnterButton.Click += new System.EventHandler(this.EnterButton_Click);
            // 
            // ParmTextBox
            // 
            this.ParmTextBox.AcceptsReturn = true;
            this.ParmTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.ParmTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.ParmTextBox.Location = new System.Drawing.Point(8, 20);
            this.ParmTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ParmTextBox.Name = "ParmTextBox";
            this.ParmTextBox.Size = new System.Drawing.Size(221, 22);
            this.ParmTextBox.TabIndex = 0;
            this.ParmTextBox.WordWrap = false;
            this.ParmTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Enter_KeyDown);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.AVRdocButton);
            this.groupBox3.Controls.Add(this.Help);
            this.groupBox3.Controls.Add(this.FuseViewButton);
            this.groupBox3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(5, 448);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(270, 59);
            this.groupBox3.TabIndex = 11;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Web Browser";
            // 
            // AVRdocButton
            // 
            this.AVRdocButton.Location = new System.Drawing.Point(96, 22);
            this.AVRdocButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.AVRdocButton.Name = "AVRdocButton";
            this.AVRdocButton.Size = new System.Drawing.Size(78, 24);
            this.AVRdocButton.TabIndex = 1;
            this.AVRdocButton.Text = "AVRdocs";
            this.AVRdocButton.UseVisualStyleBackColor = true;
            this.AVRdocButton.Click += new System.EventHandler(this.AVRdocButton_Click);
            // 
            // LogClearButton
            // 
            this.LogClearButton.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogClearButton.Location = new System.Drawing.Point(5, 283);
            this.LogClearButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.LogClearButton.Name = "LogClearButton";
            this.LogClearButton.Size = new System.Drawing.Size(84, 24);
            this.LogClearButton.TabIndex = 5;
            this.LogClearButton.Text = "Log CLR";
            this.LogClearButton.UseVisualStyleBackColor = true;
            this.LogClearButton.Click += new System.EventHandler(this.LogClearButton_Click);
            // 
            // SimpleModeCheckBox
            // 
            this.SimpleModeCheckBox.AutoSize = true;
            this.SimpleModeCheckBox.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SimpleModeCheckBox.Location = new System.Drawing.Point(508, 18);
            this.SimpleModeCheckBox.Name = "SimpleModeCheckBox";
            this.SimpleModeCheckBox.Size = new System.Drawing.Size(67, 20);
            this.SimpleModeCheckBox.TabIndex = 0;
            this.SimpleModeCheckBox.TabStop = false;
            this.SimpleModeCheckBox.Text = "Simple";
            this.SimpleModeCheckBox.UseVisualStyleBackColor = true;
            this.SimpleModeCheckBox.CheckedChanged += new System.EventHandler(this.ModeChange);
            // 
            // DeviceName
            // 
            this.DeviceName.AutoSize = true;
            this.DeviceName.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.DeviceName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.DeviceName.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeviceName.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.DeviceName.Location = new System.Drawing.Point(13, 18);
            this.DeviceName.Name = "DeviceName";
            this.DeviceName.Size = new System.Drawing.Size(107, 21);
            this.DeviceName.TabIndex = 32;
            this.DeviceName.Text = "DeviceName";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.Both_write);
            this.groupBox8.Controls.Add(this.WriteFlashButton);
            this.groupBox8.Controls.Add(this.CMDpromptButton);
            this.groupBox8.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(286, 448);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(304, 59);
            this.groupBox8.TabIndex = 12;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Special";
            // 
            // MainForm
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(594, 515);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.DeviceName);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.LogTextBox);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.SimpleModeCheckBox);
            this.Controls.Add(this.LogClearButton);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.ChipEraseButton);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.ProgressBar);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Text = "hidspx-GUI [ver ";
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.MainForm_DragDrop);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.DragEnter += new System.Windows.Forms.DragEventHandler(this.MainForm_DragEnter);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox EFuseTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox LFuseTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox HFuseTextBox;
        private System.Windows.Forms.Button WriteFuseButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox hidspxTextBox;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button WriteFlashButton;
        private System.Windows.Forms.Button ReadFlashButton;
        private System.Windows.Forms.Button FlashFileButton;
        private System.Windows.Forms.TextBox FlashFileTextBox;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button WriteEEPROMButton;
        private System.Windows.Forms.Button ReadEEPROMButton;
        private System.Windows.Forms.Button EEPROMFileButton;
        private System.Windows.Forms.TextBox EEPROMFileTextBox;
        private System.Windows.Forms.ProgressBar ProgressBar;
        private System.Windows.Forms.Button ProgramFlashButton;
        private System.Windows.Forms.Button VerifyFlashButton;
        private System.Windows.Forms.OpenFileDialog OpenFileDialog;
        private System.Windows.Forms.Button hidspxButton;
        private System.Windows.Forms.Button CMDpromptButton;
        private System.Windows.Forms.SaveFileDialog SaveFileDialog;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox CommandLineOptionTextBox;
        private System.Windows.Forms.Button FuseViewButton;
        private System.Windows.Forms.Button Help;
        private System.Windows.Forms.Button ChipEraseButton;
        private System.Windows.Forms.TextBox LockBitTextBox;
        private System.Windows.Forms.Button WriteLockBitButton;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button Both_write;
        private System.Windows.Forms.Button VerifyEEPROMButton;
        private System.Windows.Forms.TextBox LogTextBox;
        private System.Windows.Forms.Button ChipButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button EnterButton;
        private System.Windows.Forms.TextBox ParmTextBox;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button AVRdocButton;
        private System.Windows.Forms.Button LogClearButton;
        private System.Windows.Forms.CheckBox SimpleModeCheckBox;
        private System.Windows.Forms.Button HexDumpFlashMButton;
        private System.Windows.Forms.Label DeviceName;
        private System.Windows.Forms.Button HexDumpEEPROMButton;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label ExtFuse;
        private System.Windows.Forms.Label label2;
    }
}

