/*
 * Name: hardware.h
 * Project: AVR-Doper
 * Author: Christian Starkjohann <cs@obdev.at>
 * Creation Date: 2006-07-05
 * Tabsize: 4
 * Copyright: (c) 2006 by Christian Starkjohann, all rights reserved.
 * License: GNU GPL v2 (see License.txt) or proprietary (CommercialLicense.txt)
 * Revision: $Id: hardware.h 566 2008-04-26 14:21:47Z cs $
 */

/*
General Description:
This module defines hardware properties and configuration choices.
*/

#ifndef __hardware_h_included__
#define __hardware_h_included__

#define ENABLE_HID_INTERFACE    1
/* If this option is defined to 1, the device implements a custom HID type
 * interface to send and receive STK500 serial data. If both, the CDC-ACM and
 * HID interface are enabled, a jumper selects which one is used.
 */
#ifndef F_CPU
#error "F_CPU must be defined in compiler command line!"
/* #define F_CPU                   12000000 */
/* Our CPU frequency.
 */
#endif


/*
Port        | Function                | dir | value
------------+-------------------------+-----+-------
PORT B
  0         | HVSP Supply               [O]    1
  1 OC1A    | SMPS                      [O]    0
  2         | HVSP RESETHV / LEDHV      [O]    0
  3 OC2     | HVSP SCI / ISP target clk [O]    0
  4         | ISP driver enable         [O]    0
  5         | LED Prog active           [O]    1
  6 XTAL1   | XTAL
  7 XTAL2   | XTAL
PORT C (ADC)
  0         | SMPS feedback             [i]    0
  1         | ISP voltage sense         [i]    0
  2         | ISP SCK                   [O]    0
  3         | ISP MISO                  [I]    1
  4         | ISP MOSI                  [O]    0
  5         | ISP RESET / HVSP RESET    [O]    0
  6 RESET   | Reset
  7 n/a     | *
PORT D
  0 RxD     | ISP TxD                   [I]    1
  1 TxD     | ISP RxD                   [I]    1
  2 Int0    | USB D+                    [i]    0
  3 Int1    | USB D-                    [i]    0
  4 T0      | JUMPER Low Speed          [I]    1
  5 T1      | HVSP SII (PPD1)           [I]    1
  6 AIN0    | HVSP SDI (PPD0)           [I]    1
  7 AIN1    | HVSP SDO (PPD2)           [I]    1
*/
#define HWPIN_USB_DPLUS     D, 2
#define HWPIN_USB_DMINUS    D, 3

#endif /* __hardware_h_included__ */
