
typedef	unsigned char  Uchar;
typedef	unsigned short Ushort;

typedef	struct _packet {
	int	adrs;	// bindata �� ��Ƭ���ɥ쥹 (16bit).
	int size;	// bindata ��ͭ��������(bytes)
	int off;	// �����ɤ߼�����.
	Uchar bindata[256];
} Packet;

int		Read_IntelHex(Packet *p , char *linebuf);
int		Read_Srecord(Packet *p , char *linebuf);


void	Inst_init(void);
void	ToLowers(char *s);
int		Disasm_Line(char *buf,Uchar *bin,int addr,int debugf);
void	Disasm_Hex(char *hexbuf,Uchar *bin,int off,int opsize);

//	mode mask bit.
enum {
	MODE_DEBUG_INFO = 0x01,	//
	MODE_HEX_SUFFIX = 0x02,	// ex. '1234h'
};

