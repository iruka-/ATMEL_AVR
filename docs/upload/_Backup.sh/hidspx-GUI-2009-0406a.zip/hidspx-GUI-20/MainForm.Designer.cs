﻿namespace hidspxGUI
{
    partial class MainForm
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.DeviceTextBox = new System.Windows.Forms.TextBox();
            this.ReadFuseButton = new System.Windows.Forms.Button();
            this.WriteFuseButton = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.EFuseTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.LFuseTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.HFuseTextBox = new System.Windows.Forms.TextBox();
            this.ExitButton = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.hidspxButton = new System.Windows.Forms.Button();
            this.hidspxTextBox = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.ProgramFlashButton = new System.Windows.Forms.Button();
            this.VerifyFlashButton = new System.Windows.Forms.Button();
            this.WriteFlashButton = new System.Windows.Forms.Button();
            this.ReadFlashButton = new System.Windows.Forms.Button();
            this.FlashFileButton = new System.Windows.Forms.Button();
            this.TerminalButton = new System.Windows.Forms.Button();
            this.FlashFileTextBox = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.VerifyEEPROMButton = new System.Windows.Forms.Button();
            this.Both_write = new System.Windows.Forms.Button();
            this.WriteEEPROMButton = new System.Windows.Forms.Button();
            this.ReadEEPROMButton = new System.Windows.Forms.Button();
            this.EEPROMFileButton = new System.Windows.Forms.Button();
            this.EEPROMFileTextBox = new System.Windows.Forms.TextBox();
            this.ProgressBar = new System.Windows.Forms.ProgressBar();
            this.OpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.WindowCheckBox = new System.Windows.Forms.CheckBox();
            this.SaveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.CommandLineOptionTextBox = new System.Windows.Forms.TextBox();
            this.FuseViewButton = new System.Windows.Forms.Button();
            this.Help = new System.Windows.Forms.Button();
            this.ChipEraseButton = new System.Windows.Forms.Button();
            this.LockBitTextBox = new System.Windows.Forms.TextBox();
            this.WriteLockBitButton = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.DeviceTextBox);
            this.groupBox2.Controls.Add(this.ReadFuseButton);
            this.groupBox2.Controls.Add(this.WriteFuseButton);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.EFuseTextBox);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.LFuseTextBox);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.HFuseTextBox);
            this.groupBox2.Location = new System.Drawing.Point(1, 126);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Size = new System.Drawing.Size(184, 177);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Fuse";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 16);
            this.label2.TabIndex = 10;
            this.label2.Text = "detect Device";
            // 
            // DeviceTextBox
            // 
            this.DeviceTextBox.Location = new System.Drawing.Point(6, 45);
            this.DeviceTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DeviceTextBox.Name = "DeviceTextBox";
            this.DeviceTextBox.ReadOnly = true;
            this.DeviceTextBox.Size = new System.Drawing.Size(163, 22);
            this.DeviceTextBox.TabIndex = 9;
            // 
            // ReadFuseButton
            // 
            this.ReadFuseButton.Location = new System.Drawing.Point(107, 83);
            this.ReadFuseButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ReadFuseButton.Name = "ReadFuseButton";
            this.ReadFuseButton.Size = new System.Drawing.Size(62, 28);
            this.ReadFuseButton.TabIndex = 3;
            this.ReadFuseButton.Text = "Read";
            this.ReadFuseButton.UseVisualStyleBackColor = true;
            this.ReadFuseButton.Click += new System.EventHandler(this.ReadFuseButton_Click);
            // 
            // WriteFuseButton
            // 
            this.WriteFuseButton.Location = new System.Drawing.Point(107, 136);
            this.WriteFuseButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.WriteFuseButton.Name = "WriteFuseButton";
            this.WriteFuseButton.Size = new System.Drawing.Size(62, 28);
            this.WriteFuseButton.TabIndex = 4;
            this.WriteFuseButton.Text = "Write";
            this.WriteFuseButton.UseVisualStyleBackColor = true;
            this.WriteFuseButton.Click += new System.EventHandler(this.WriteFuseButton_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 143);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 16);
            this.label6.TabIndex = 8;
            this.label6.Text = "Ext";
            // 
            // EFuseTextBox
            // 
            this.EFuseTextBox.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.EFuseTextBox.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.EFuseTextBox.Location = new System.Drawing.Point(64, 141);
            this.EFuseTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.EFuseTextBox.MaxLength = 2;
            this.EFuseTextBox.Name = "EFuseTextBox";
            this.EFuseTextBox.Size = new System.Drawing.Size(26, 22);
            this.EFuseTextBox.TabIndex = 2;
            this.EFuseTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 85);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 16);
            this.label4.TabIndex = 5;
            this.label4.Text = "Low";
            // 
            // LFuseTextBox
            // 
            this.LFuseTextBox.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.LFuseTextBox.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.LFuseTextBox.Location = new System.Drawing.Point(64, 83);
            this.LFuseTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.LFuseTextBox.MaxLength = 2;
            this.LFuseTextBox.Name = "LFuseTextBox";
            this.LFuseTextBox.Size = new System.Drawing.Size(26, 22);
            this.LFuseTextBox.TabIndex = 1;
            this.LFuseTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 114);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "High";
            // 
            // HFuseTextBox
            // 
            this.HFuseTextBox.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.HFuseTextBox.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.HFuseTextBox.Location = new System.Drawing.Point(64, 111);
            this.HFuseTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.HFuseTextBox.MaxLength = 2;
            this.HFuseTextBox.Name = "HFuseTextBox";
            this.HFuseTextBox.Size = new System.Drawing.Size(26, 22);
            this.HFuseTextBox.TabIndex = 0;
            this.HFuseTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(521, 339);
            this.ExitButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(53, 28);
            this.ExitButton.TabIndex = 12;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.hidspxButton);
            this.groupBox4.Controls.Add(this.hidspxTextBox);
            this.groupBox4.Location = new System.Drawing.Point(1, 3);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox4.Size = new System.Drawing.Size(587, 51);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "hidspx.exe File";
            // 
            // hidspxButton
            // 
            this.hidspxButton.Location = new System.Drawing.Point(551, 21);
            this.hidspxButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.hidspxButton.Name = "hidspxButton";
            this.hidspxButton.Size = new System.Drawing.Size(30, 25);
            this.hidspxButton.TabIndex = 1;
            this.hidspxButton.Text = "...";
            this.hidspxButton.UseVisualStyleBackColor = true;
            this.hidspxButton.Click += new System.EventHandler(this.hidspxButton_Click);
            // 
            // hidspxTextBox
            // 
            this.hidspxTextBox.Location = new System.Drawing.Point(6, 22);
            this.hidspxTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.hidspxTextBox.MaxLength = 32;
            this.hidspxTextBox.Name = "hidspxTextBox";
            this.hidspxTextBox.Size = new System.Drawing.Size(539, 22);
            this.hidspxTextBox.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.ProgramFlashButton);
            this.groupBox5.Controls.Add(this.VerifyFlashButton);
            this.groupBox5.Controls.Add(this.WriteFlashButton);
            this.groupBox5.Controls.Add(this.ReadFlashButton);
            this.groupBox5.Controls.Add(this.FlashFileButton);
            this.groupBox5.Controls.Add(this.TerminalButton);
            this.groupBox5.Controls.Add(this.FlashFileTextBox);
            this.groupBox5.Location = new System.Drawing.Point(191, 126);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox5.Size = new System.Drawing.Size(395, 112);
            this.groupBox5.TabIndex = 7;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Flash";
            // 
            // ProgramFlashButton
            // 
            this.ProgramFlashButton.Location = new System.Drawing.Point(172, 77);
            this.ProgramFlashButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProgramFlashButton.Name = "ProgramFlashButton";
            this.ProgramFlashButton.Size = new System.Drawing.Size(211, 28);
            this.ProgramFlashButton.TabIndex = 5;
            this.ProgramFlashButton.Text = "Erase - Write - Verify";
            this.ProgramFlashButton.UseVisualStyleBackColor = true;
            this.ProgramFlashButton.Click += new System.EventHandler(this.ProgramFlashButton_Click);
            // 
            // VerifyFlashButton
            // 
            this.VerifyFlashButton.Location = new System.Drawing.Point(6, 76);
            this.VerifyFlashButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.VerifyFlashButton.Name = "VerifyFlashButton";
            this.VerifyFlashButton.Size = new System.Drawing.Size(148, 28);
            this.VerifyFlashButton.TabIndex = 4;
            this.VerifyFlashButton.Text = "Verify";
            this.VerifyFlashButton.UseVisualStyleBackColor = true;
            this.VerifyFlashButton.Click += new System.EventHandler(this.VerifyFlashButton_Click);
            // 
            // WriteFlashButton
            // 
            this.WriteFlashButton.Location = new System.Drawing.Point(172, 45);
            this.WriteFlashButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.WriteFlashButton.Name = "WriteFlashButton";
            this.WriteFlashButton.Size = new System.Drawing.Size(83, 28);
            this.WriteFlashButton.TabIndex = 3;
            this.WriteFlashButton.Text = "Write";
            this.WriteFlashButton.UseVisualStyleBackColor = true;
            this.WriteFlashButton.Click += new System.EventHandler(this.WriteFlashButton_Click);
            // 
            // ReadFlashButton
            // 
            this.ReadFlashButton.Location = new System.Drawing.Point(6, 45);
            this.ReadFlashButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ReadFlashButton.Name = "ReadFlashButton";
            this.ReadFlashButton.Size = new System.Drawing.Size(148, 28);
            this.ReadFlashButton.TabIndex = 2;
            this.ReadFlashButton.Text = "Read";
            this.ReadFlashButton.UseVisualStyleBackColor = true;
            this.ReadFlashButton.Click += new System.EventHandler(this.ReadFlashButton_Click);
            // 
            // FlashFileButton
            // 
            this.FlashFileButton.Location = new System.Drawing.Point(359, 17);
            this.FlashFileButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.FlashFileButton.Name = "FlashFileButton";
            this.FlashFileButton.Size = new System.Drawing.Size(30, 25);
            this.FlashFileButton.TabIndex = 1;
            this.FlashFileButton.Text = "...";
            this.FlashFileButton.UseVisualStyleBackColor = true;
            this.FlashFileButton.Click += new System.EventHandler(this.FlashFileButton_Click);
            // 
            // TerminalButton
            // 
            this.TerminalButton.Location = new System.Drawing.Point(274, 45);
            this.TerminalButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TerminalButton.Name = "TerminalButton";
            this.TerminalButton.Size = new System.Drawing.Size(109, 28);
            this.TerminalButton.TabIndex = 11;
            this.TerminalButton.Text = "CMD prompt";
            this.TerminalButton.UseVisualStyleBackColor = true;
            this.TerminalButton.Click += new System.EventHandler(this.TerminalButton_Click);
            // 
            // FlashFileTextBox
            // 
            this.FlashFileTextBox.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FlashFileTextBox.Location = new System.Drawing.Point(4, 18);
            this.FlashFileTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.FlashFileTextBox.Name = "FlashFileTextBox";
            this.FlashFileTextBox.Size = new System.Drawing.Size(349, 20);
            this.FlashFileTextBox.TabIndex = 0;
            this.FlashFileTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.VerifyEEPROMButton);
            this.groupBox6.Controls.Add(this.Both_write);
            this.groupBox6.Controls.Add(this.WriteEEPROMButton);
            this.groupBox6.Controls.Add(this.ReadEEPROMButton);
            this.groupBox6.Controls.Add(this.EEPROMFileButton);
            this.groupBox6.Controls.Add(this.EEPROMFileTextBox);
            this.groupBox6.Location = new System.Drawing.Point(191, 246);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox6.Size = new System.Drawing.Size(395, 81);
            this.groupBox6.TabIndex = 9;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "EEPROM";
            // 
            // VerifyEEPROMButton
            // 
            this.VerifyEEPROMButton.Location = new System.Drawing.Point(96, 44);
            this.VerifyEEPROMButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.VerifyEEPROMButton.Name = "VerifyEEPROMButton";
            this.VerifyEEPROMButton.Size = new System.Drawing.Size(80, 28);
            this.VerifyEEPROMButton.TabIndex = 5;
            this.VerifyEEPROMButton.Text = "Verify";
            this.VerifyEEPROMButton.UseVisualStyleBackColor = true;
            this.VerifyEEPROMButton.Click += new System.EventHandler(this.VerifyEEPROMButton_Click);
            // 
            // Both_write
            // 
            this.Both_write.Location = new System.Drawing.Point(274, 44);
            this.Both_write.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Both_write.Name = "Both_write";
            this.Both_write.Size = new System.Drawing.Size(109, 28);
            this.Both_write.TabIndex = 4;
            this.Both_write.Text = "Write(Both)";
            this.Both_write.UseVisualStyleBackColor = true;
            this.Both_write.Click += new System.EventHandler(this.Both_write_Click);
            // 
            // WriteEEPROMButton
            // 
            this.WriteEEPROMButton.Location = new System.Drawing.Point(185, 44);
            this.WriteEEPROMButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.WriteEEPROMButton.Name = "WriteEEPROMButton";
            this.WriteEEPROMButton.Size = new System.Drawing.Size(80, 28);
            this.WriteEEPROMButton.TabIndex = 3;
            this.WriteEEPROMButton.Text = "Write";
            this.WriteEEPROMButton.UseVisualStyleBackColor = true;
            this.WriteEEPROMButton.Click += new System.EventHandler(this.WriteEEPROMButton_Click);
            // 
            // ReadEEPROMButton
            // 
            this.ReadEEPROMButton.Location = new System.Drawing.Point(6, 44);
            this.ReadEEPROMButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ReadEEPROMButton.Name = "ReadEEPROMButton";
            this.ReadEEPROMButton.Size = new System.Drawing.Size(80, 28);
            this.ReadEEPROMButton.TabIndex = 2;
            this.ReadEEPROMButton.Text = "Read";
            this.ReadEEPROMButton.UseVisualStyleBackColor = true;
            this.ReadEEPROMButton.Click += new System.EventHandler(this.ReadEEPROMButton_Click);
            // 
            // EEPROMFileButton
            // 
            this.EEPROMFileButton.Location = new System.Drawing.Point(359, 16);
            this.EEPROMFileButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.EEPROMFileButton.Name = "EEPROMFileButton";
            this.EEPROMFileButton.Size = new System.Drawing.Size(30, 22);
            this.EEPROMFileButton.TabIndex = 1;
            this.EEPROMFileButton.Text = "...";
            this.EEPROMFileButton.UseVisualStyleBackColor = true;
            this.EEPROMFileButton.Click += new System.EventHandler(this.EEPROMFileButton_Click);
            // 
            // EEPROMFileTextBox
            // 
            this.EEPROMFileTextBox.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EEPROMFileTextBox.Location = new System.Drawing.Point(4, 16);
            this.EEPROMFileTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.EEPROMFileTextBox.Name = "EEPROMFileTextBox";
            this.EEPROMFileTextBox.Size = new System.Drawing.Size(349, 20);
            this.EEPROMFileTextBox.TabIndex = 0;
            this.EEPROMFileTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // ProgressBar
            // 
            this.ProgressBar.Location = new System.Drawing.Point(7, 383);
            this.ProgressBar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ProgressBar.Name = "ProgressBar";
            this.ProgressBar.Size = new System.Drawing.Size(573, 19);
            this.ProgressBar.TabIndex = 9;
            // 
            // OpenFileDialog
            // 
            this.OpenFileDialog.FileName = "openFileDialog1";
            // 
            // WindowCheckBox
            // 
            this.WindowCheckBox.AutoSize = true;
            this.WindowCheckBox.Location = new System.Drawing.Point(440, 79);
            this.WindowCheckBox.Name = "WindowCheckBox";
            this.WindowCheckBox.Size = new System.Drawing.Size(120, 36);
            this.WindowCheckBox.TabIndex = 2;
            this.WindowCheckBox.Text = "Display Window\r\n(for debug)";
            this.WindowCheckBox.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.CommandLineOptionTextBox);
            this.groupBox9.Location = new System.Drawing.Point(1, 61);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(429, 57);
            this.groupBox9.TabIndex = 5;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Command line Option";
            // 
            // CommandLineOptionTextBox
            // 
            this.CommandLineOptionTextBox.Location = new System.Drawing.Point(6, 24);
            this.CommandLineOptionTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CommandLineOptionTextBox.Name = "CommandLineOptionTextBox";
            this.CommandLineOptionTextBox.Size = new System.Drawing.Size(417, 22);
            this.CommandLineOptionTextBox.TabIndex = 0;
            // 
            // FuseViewButton
            // 
            this.FuseViewButton.Location = new System.Drawing.Point(293, 339);
            this.FuseViewButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.FuseViewButton.Name = "FuseViewButton";
            this.FuseViewButton.Size = new System.Drawing.Size(102, 28);
            this.FuseViewButton.TabIndex = 14;
            this.FuseViewButton.Text = "FuseCalc";
            this.FuseViewButton.UseVisualStyleBackColor = true;
            this.FuseViewButton.Click += new System.EventHandler(this.FuseViewButton_Click);
            // 
            // Help
            // 
            this.Help.Location = new System.Drawing.Point(410, 339);
            this.Help.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Help.Name = "Help";
            this.Help.Size = new System.Drawing.Size(96, 28);
            this.Help.TabIndex = 15;
            this.Help.Text = "Help(web)";
            this.Help.UseVisualStyleBackColor = true;
            this.Help.Click += new System.EventHandler(this.Help_Click_1);
            // 
            // ChipEraseButton
            // 
            this.ChipEraseButton.Location = new System.Drawing.Point(197, 339);
            this.ChipEraseButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ChipEraseButton.Name = "ChipEraseButton";
            this.ChipEraseButton.Size = new System.Drawing.Size(80, 28);
            this.ChipEraseButton.TabIndex = 10;
            this.ChipEraseButton.Text = "ChipErase";
            this.ChipEraseButton.UseVisualStyleBackColor = true;
            this.ChipEraseButton.Click += new System.EventHandler(this.ChipEraseButton_Click);
            // 
            // LockBitTextBox
            // 
            this.LockBitTextBox.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.LockBitTextBox.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.LockBitTextBox.Location = new System.Drawing.Point(64, 28);
            this.LockBitTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.LockBitTextBox.MaxLength = 2;
            this.LockBitTextBox.Name = "LockBitTextBox";
            this.LockBitTextBox.Size = new System.Drawing.Size(26, 22);
            this.LockBitTextBox.TabIndex = 0;
            this.LockBitTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // WriteLockBitButton
            // 
            this.WriteLockBitButton.Location = new System.Drawing.Point(107, 28);
            this.WriteLockBitButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.WriteLockBitButton.Name = "WriteLockBitButton";
            this.WriteLockBitButton.Size = new System.Drawing.Size(62, 28);
            this.WriteLockBitButton.TabIndex = 2;
            this.WriteLockBitButton.Text = "Write";
            this.WriteLockBitButton.UseVisualStyleBackColor = true;
            this.WriteLockBitButton.Click += new System.EventHandler(this.WriteLockBitButton_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label3);
            this.groupBox7.Controls.Add(this.WriteLockBitButton);
            this.groupBox7.Controls.Add(this.LockBitTextBox);
            this.groupBox7.Location = new System.Drawing.Point(1, 311);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox7.Size = new System.Drawing.Size(186, 64);
            this.groupBox7.TabIndex = 8;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Lock Bit";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(22, 16);
            this.label3.TabIndex = 9;
            this.label3.Text = "0x";
            // 
            // MainForm
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(586, 407);
            this.Controls.Add(this.Help);
            this.Controls.Add(this.FuseViewButton);
            this.Controls.Add(this.ChipEraseButton);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.WindowCheckBox);
            this.Controls.Add(this.ProgressBar);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.groupBox2);
            this.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Text = "hidspx-GUI [Version ";
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.MainForm_DragDrop);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.DragEnter += new System.Windows.Forms.DragEventHandler(this.MainForm_DragEnter);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox EFuseTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox LFuseTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox HFuseTextBox;
        private System.Windows.Forms.Button WriteFuseButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Button ReadFuseButton;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox hidspxTextBox;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button WriteFlashButton;
        private System.Windows.Forms.Button ReadFlashButton;
        private System.Windows.Forms.Button FlashFileButton;
        private System.Windows.Forms.TextBox FlashFileTextBox;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button WriteEEPROMButton;
        private System.Windows.Forms.Button ReadEEPROMButton;
        private System.Windows.Forms.Button EEPROMFileButton;
        private System.Windows.Forms.TextBox EEPROMFileTextBox;
        private System.Windows.Forms.ProgressBar ProgressBar;
        private System.Windows.Forms.Button ProgramFlashButton;
        private System.Windows.Forms.Button VerifyFlashButton;
        private System.Windows.Forms.OpenFileDialog OpenFileDialog;
        private System.Windows.Forms.Button hidspxButton;
        private System.Windows.Forms.Button TerminalButton;
        private System.Windows.Forms.CheckBox WindowCheckBox;
        private System.Windows.Forms.SaveFileDialog SaveFileDialog;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox CommandLineOptionTextBox;
        private System.Windows.Forms.Button FuseViewButton;
        private System.Windows.Forms.Button Help;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox DeviceTextBox;
        private System.Windows.Forms.Button ChipEraseButton;
        private System.Windows.Forms.TextBox LockBitTextBox;
        private System.Windows.Forms.Button WriteLockBitButton;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Both_write;
        private System.Windows.Forms.Button VerifyEEPROMButton;
    }
}

