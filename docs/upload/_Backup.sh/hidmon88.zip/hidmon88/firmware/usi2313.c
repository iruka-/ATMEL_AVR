//	for ATtiny2313

//
//	wait:
//		0 =  2clk    3 MHz
//		1 =  4clk  1.5 MHz
//		2 =  9clk  666 kHz
//		3 = 21clk  285 kHz
//		4 = 33clk  181 kHz
//	   10 =129clk   46 kHz
//	   20 =249clk   23 kHz
//	   50 =609clk  9.8 kHz
//
//		2�ȏ�� 9 + (12 * wait) clk
//
static uint8_t usi_trans(uint8_t data){
	USIDR=data;
	USISR=(1<<USIOIF);
	if(wait==0) {
		uchar CR0=(1<<USIWM0)|(1<<USICS1)|(1<<USITC);
		USICR=CR0;
		uchar CR1=(1<<USIWM0)|(1<<USICS1)|(1<<USITC)|(1<<USICLK);
								USICR=CR1;	asm("nop");
		USICR=CR0;	asm("nop");	USICR=CR1;	asm("nop");
		USICR=CR0;	asm("nop");	USICR=CR1;	asm("nop");
		USICR=CR0;	asm("nop");	USICR=CR1;	asm("nop");
		USICR=CR0;	asm("nop");	USICR=CR1;	asm("nop");
		USICR=CR0;	asm("nop");	USICR=CR1;	asm("nop");
		USICR=CR0;	asm("nop");	USICR=CR1;	asm("nop");
		USICR=CR0;	asm("nop");	USICR=CR1;
	}else if(wait==1) {
		do{
			USICR=(1<<USIWM0)|(1<<USICS1)|(1<<USICLK)|(1<<USITC);
		} while(!(USISR&(1<<USIOIF)));
	}else{
		uchar d=wait;		// 12clk * (wait-2)
		do {
			while(d != 2) {		// 1 loop = 12clk
				asm("rjmp .+0");
				asm("rjmp .+0");
				asm("rjmp .+0");
				asm("rjmp .+0");
				d--;
			}
			USICR=(1<<USIWM0)|(1<<USICS1)|(1<<USICLK)|(1<<USITC);
		} while(!(USISR&(1<<USIOIF)));
	}
	return USIDR;
}
