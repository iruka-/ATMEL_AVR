/* Name: main.c
 * Project: AVR bootloader HID
 * Author: Christian Starkjohann
 * Creation Date: 2007-03-19
 * Tabsize: 4
 * Copyright: (c) 2007 by OBJECTIVE DEVELOPMENT Software GmbH
 * License: Proprietary, free under certain conditions. See Documentation.
 * This Revision: $Id: main.c 373 2007-07-04 08:59:36Z cs $
BOOLEAN __stdcall   HidD_GetSerialNumberString(IN HANDLE device, OUT void *buffer, IN ULONG bufferLen);
 */

#define DEBUG 0

#include <stdio.h>
#include <windows.h>
//#include <string.h>
//#include <stdlib.h>
//#include <errno.h>
#include "usbcalls.h"

#define IDENT_VENDOR_NUM        0x1C40
#define IDENT_VENDOR_STRING     "MYDenshi"
#define IDENT_PRODUCT_NUM       0x0BBF
#define IDENT_PRODUCT_STRING    "HIDsph0"

/* ------------------------------------------------------------------------- */

usbDevice_t *dev = NULL;
static int startAddress, endAddress;

/* ------------------------------------------------------------------------- */

#define HID_R_FEATURE  USB_HID_REPORT_TYPE_FEATURE

static unsigned char resbuf[7];
static unsigned char cbuf[4];

typedef struct deviceInfo {
	char reportId;
	char pageSize[2];
	char flashSize[4];
} deviceInfo_t;

static union {
	unsigned char byt[1];
	deviceInfo_t info;
} buf;


int hidasp_init() {
    int len, err;

    err = usbOpenDevice(&dev, IDENT_VENDOR_NUM, IDENT_VENDOR_STRING,
                            IDENT_PRODUCT_NUM, IDENT_PRODUCT_STRING, 1);
    if(err) {
        fprintf(stderr, "ERROR: fail to usbOpenDevice()\n");
        return err;
    }
    Sleep(100);

#if DEBUG
    printf("HIDspx0 Connection check!");
#endif
    buf.byt[0] = 1;
    buf.byt[1] = 1; // Connection test
    buf.byt[2] = 0;
    while(buf.byt[2] < 4) {
        err = usbSetReport(dev, HID_R_FEATURE, buf.byt, sizeof(buf.info));
        if(err) {
            fprintf(stderr, "\nERROR: fail to write()\n");
            return err;
        }
        Sleep(10);
        buf.byt[2]++;
    }

    len = sizeof(resbuf);
    err = usbGetReport(dev, HID_R_FEATURE, 1, resbuf, &len);
    if(err) return err;
    if(len < sizeof(resbuf)) err = -1;
    if(!err && (resbuf[1] != 3)) err = -2;
    if(err) {
        fprintf(stderr, "\nERROR: fail to read()\n");
        return err;
    }
    Sleep(10);
#if DEBUG
    printf(" OK.\n");
#endif
    return 0;
}


int hidasp_cmd(const unsigned char cmd[4], unsigned char res[4])
{
	int len, err;

	memcpy(buf.byt + 2, cmd, 4);
	buf.byt[0] = 1;
	buf.byt[1] = 16;			// SPI
	err = usbSetReport(dev, HID_R_FEATURE, buf.byt, sizeof(buf.info));
	if (err)
		return err;
#if DEBUG
//	fprintf(stderr,"hidasp_cmd %d cmd: %02x %02x %02x %02x ",buf[1],cmd[0],cmd[1],cmd[2],cmd[3]);
#endif

	if (res) {
		len = sizeof(resbuf);
		err = usbGetReport(dev, HID_R_FEATURE, 1, resbuf, &len);
		if (err)
			return err;
		if (len < sizeof(resbuf)) {
			fprintf(stderr, "ERROR: fail to command()\n");
			return -1;
		}
		memcpy(res, resbuf + 1, 4);
#if DEBUG
		fprintf(stderr,"  res: %02x %02x %02x %02x\n",res[0],res[1],res[2],res[3]);
#endif
	}
#if DEBUG
	fprintf(stderr,"\n");
#endif
	return 0;
}

int hidasp_program_enable(int delay)
{
	int err, i;

#if DEBUG
	fprintf(stderr, "hidasp_program_enable()\n");
#endif


	// �G���[���ɂ̓��g���C����悤�ɏC�� by senshu(2008-9-16)
	for (i=0; i<3; i++) {
		Sleep(2);
		buf.byt[0] = 1;
		buf.byt[1] = 2;
		buf.byt[2] = 0x02;			// LED off
		buf.byt[3] = 0x10;			// ~RESET HI
		err = usbSetReport(dev, HID_R_FEATURE, buf.byt, sizeof(buf.info));
		Sleep(150);
		if (err)
			return err;

		buf.byt[0] = 1;
		buf.byt[1] = 2;
		buf.byt[2] = 0x00;			// LED on
		buf.byt[3] = 0x00;			// ~RESET LOW
		err = usbSetReport(dev, HID_R_FEATURE, buf.byt, sizeof(buf.info));
		if (err)
			return err;

		buf.byt[0] = 1;
		buf.byt[1] = 18;			// SET_DELAY
		buf.byt[2] = delay;			// *3inst. delay (min 6 : 1.5uSec.)
		buf.byt[3] = 0;
		err = usbSetReport(dev, HID_R_FEATURE, buf.byt, sizeof(buf.info));
		if (err)
			return err;

		Sleep(60);
		cbuf[0] = 0xAC;
		cbuf[1] = 0x53;
		cbuf[2] = 0x00;
		cbuf[3] = 0x00;
		err = hidasp_cmd(cbuf, resbuf);
		if (err) {
			return err;
		}
		if (resbuf[2] == 0x53) {
			return 0;
		}
		Sleep(50);
	}
	fprintf(stderr, "ERROR: no response from target device\n");
	return -3;
}

void hidasp_close()
{
	if (dev) {
		cbuf[0] = 0x00;
		cbuf[1] = 0x00;
		cbuf[2] = 0x00;
		cbuf[3] = 0x00;
		hidasp_cmd(cbuf, NULL);	// AVOID BUG!
		buf.byt[0] = 1;
		buf.byt[1] = 2;
		buf.byt[2] = 0x02;		// LED off
		buf.byt[3] = 0x10;		// ~RESET HI
		usbSetReport(dev, HID_R_FEATURE, buf.byt, sizeof(buf.info));
	}
	if (dev != NULL)
		usbCloseDevice(dev);
}

/* ------------------------------------------------------------------------- */

char *usbErrorMessage(int errCode)
{
	static char buffer[80];

	switch (errCode) {
	case USB_ERROR_ACCESS:
		return "Access to device denied";
	case USB_ERROR_NOTFOUND:
		return "The specified device was not found";
	case USB_ERROR_BUSY:
		return "The device is used by another application";
	case USB_ERROR_IO:
		return "Communication error with device";
	default:
		sprintf(buffer, "Unknown USB error %d", errCode);
		return buffer;
	}
	return NULL;				/* not reached */
}

#define InputReportByteLength  6
#define OutputReportByteLength 6
// char ttt=0;

int hidasp_page_write(long addr, const unsigned char *wd, int pagesize)
{
	int err, n, l;

	// set page
	buf.byt[0] = 1;
	buf.byt[1] = 20;			// Set Page mode
	buf.byt[2] = addr & 1 ? 0x48 : 0x40;	// Flash
	buf.byt[3] = (unsigned char) ((addr >> 9) & 0xFF);
	buf.byt[4] = (unsigned char) ((addr >> 1) & 0xFF);
	err = usbSetReport(dev, HID_R_FEATURE, buf.byt, sizeof(buf.info));
	if (err) {
		fprintf(stderr, "Error setup page address: %s\n", usbErrorMessage(err));
		return err;
	}
	// Load the page data into page buffer
	n = 0;
	while (n < pagesize) {
		l = OutputReportByteLength - 1;	// MAX
		if (pagesize - n < l)
			l = pagesize - n;
		buf.byt[0] = 1;
		buf.byt[1] = 0x40 | l;	// PageBuf
		memcpy(buf.byt + 2, wd + n, l);
//      Sleep(2);
#if 0
		if(!ttt++) {
            fprintf(stderr,"  p: %02x %02x %02x %02x %02x\n",buf.byt[2],buf.byt[3],
                                          buf.byt[4],buf.byt[5],buf.byt[6]);}
#endif
		err = usbSetReport(dev, HID_R_FEATURE, buf.byt, sizeof(buf.info));
		if (err) {
			fprintf(stderr, "Error uploading data block: %s\n",	 usbErrorMessage(err));
			return err;
		}
#if 0
		fprintf(stderr,"  p: %02x %02x %02x %02x\n",buf[1],buf[2],buf[3],buf[4]);
#endif
		n += l;
	}
	return 0;
}

int hidasp_page_read(long addr, unsigned char *wd, int pagesize)
{
	int err, n, l, len;

	// set page
	if (addr >= 0) {
		buf.byt[0] = 1;
		buf.byt[1] = 20;		// Set Page mode
		buf.byt[2] = addr & 1 ? 0x28 : 0x20;	// Flash read
		buf.byt[3] = (unsigned char) ((addr >> 9) & 0xFF);
		buf.byt[4] = (unsigned char) ((addr >> 1) & 0xFF);
		err = usbSetReport(dev, HID_R_FEATURE, buf.byt, sizeof(buf.info));
		if (err) {
			fprintf(stderr, "Error setup page address: %s\n", usbErrorMessage(err));
			return err;
		}
	}
	// Load the page data into page buffer
	n = 0;
	while (n < pagesize) {
		l = OutputReportByteLength - 1;	// MAX
		if (pagesize - n < l)
			l = pagesize - n;
		buf.byt[0] = 1;
		buf.byt[1] = 0x40 | l;	// PageBuf
		memset(buf.byt + 2, 0, l);
//      Sleep(2);
		err = usbSetReport(dev, HID_R_FEATURE, buf.byt, sizeof(buf.info));
		if (err) {
			fprintf(stderr, "Error reading data block(command): %s\n", usbErrorMessage(err));
			return err;
		}
		len = sizeof(resbuf);
		err = usbGetReport(dev, HID_R_FEATURE, 1, resbuf, &len);
		if (!err && (len < sizeof(resbuf)))
			err = -1;
		if (err) {
			fprintf(stderr, "Error reading data block: %s\n", usbErrorMessage(err));
			return err;
		}
		memcpy(wd + n, resbuf + 1, l);
#if 1
		report_update(l);
#endif

#if 0
		fprintf(stderr,"  p: %02x %02x %02x %02x\n",buf[1],buf[2],buf[3],buf[4]);
#endif
		n += l;
	}
	return 0;
}

/* --------------------- */
