/* hidasp.c
 */

#define DEBUG 0

#include <windows.h>
#include <stdio.h>
#include "usbhid.h"
#include "hidasp.h"

#pragma comment(lib, "setupapi.lib")

// HID API (from w2k DDK)
_HidD_GetAttributes HidD_GetAttributes;
_HidD_GetHidGuid HidD_GetHidGuid;
_HidD_GetPreparsedData HidD_GetPreparsedData;
_HidD_FreePreparsedData HidD_FreePreparsedData;
_HidP_GetCaps HidP_GetCaps;
_HidP_GetValueCaps HidP_GetValueCaps;

HINSTANCE hHID_DLL = NULL;		// hid.dll handle
HANDLE hHID = NULL;				// USB-IO dev handle
HIDP_CAPS Caps;


////////////////////////////////////////////////////////////////////////
//             hid.dll �����[�h
static int LoadHidDLL()
{
	hHID_DLL = LoadLibrary("hid.dll");
	if (!hHID_DLL) {
#if 1
		fprintf(stderr, "Error at Load 'hid.dll'\n");
#else
		MessageBox(NULL, "Error at Load 'hid.dll'", "ERRR", MB_OK);
#endif
		return 0;
	}
	HidD_GetAttributes =
		(_HidD_GetAttributes) GetProcAddress(hHID_DLL,
											 "HidD_GetAttributes");
	if (!HidD_GetAttributes) {
#if 1
		fprintf(stderr, "Error at HidD_GetAttributes\n");
#else
		MessageBox(NULL, "Error at HidD_GetAttributes", "ERR", MB_OK);
#endif
		return 0;
	}
	HidD_GetHidGuid =
		(_HidD_GetHidGuid) GetProcAddress(hHID_DLL, "HidD_GetHidGuid");
	if (!HidD_GetHidGuid) {
#if 1
		fprintf(stderr, "Error at HidD_GetHidGuid\n");
#else
		MessageBox(NULL, "Error at HidD_GetHidGuid", "ERR", MB_OK);
#endif
		return 0;
	}
	HidD_GetPreparsedData = (_HidD_GetPreparsedData) GetProcAddress(hHID_DLL, "HidD_GetPreparsedData");
	HidD_FreePreparsedData = (_HidD_FreePreparsedData) GetProcAddress(hHID_DLL, "HidD_FreePreparsedData");
	HidP_GetCaps = (_HidP_GetCaps) GetProcAddress(hHID_DLL, "HidP_GetCaps");
	HidP_GetValueCaps = (_HidP_GetValueCaps) GetProcAddress(hHID_DLL, "HidP_GetValueCaps");
	return 1;
}

////////////////////////////////////////////////////////////////////////
// �f�B�o�C�X�̏����擾
static void GetDevCaps()
{
	PHIDP_PREPARSED_DATA PreparsedData;
	HIDP_VALUE_CAPS *VCaps;
	char buf[1024];

	VCaps = (HIDP_VALUE_CAPS *) (&buf);

	HidD_GetPreparsedData(hHID, &PreparsedData);
	HidP_GetCaps(PreparsedData, &Caps);
	HidP_GetValueCaps(HidP_Input, VCaps,  &Caps.NumberInputValueCaps, PreparsedData);
	HidD_FreePreparsedData(PreparsedData);
}

////////////////////////////////////////////////////////////////////////
// HID�f�B�o�C�X�ꗗ����USBIO������
static int OpenTheHid()
{
	int f = 0;
	int i = 0;
	ULONG Needed, l;
	GUID HidGuid;
	HDEVINFO DeviceInfoSet;
	HIDD_ATTRIBUTES DeviceAttributes;
	SP_DEVICE_INTERFACE_DATA DevData;
	PSP_INTERFACE_DEVICE_DETAIL_DATA DevDetail;
	//SP_DEVICE_INTERFACE_DETAIL_DATA *MyDeviceInterfaceDetailData;

	DeviceAttributes.Size = sizeof(HIDD_ATTRIBUTES);
	DevData.cbSize = sizeof(SP_DEVICE_INTERFACE_DATA);

	HidD_GetHidGuid(&HidGuid);
#if 1							/* For vista */
	DeviceInfoSet =
		SetupDiGetClassDevs(&HidGuid, NULL, NULL, DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);
#else
	DeviceInfoSet =
		SetupDiGetClassDevs(&HidGuid, "", NULL,	DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);
#endif

	while (SetupDiEnumDeviceInterfaces(DeviceInfoSet, 0, &HidGuid, i++, &DevData)) {
		SetupDiGetDeviceInterfaceDetail(DeviceInfoSet, &DevData, NULL, 0, &Needed, 0);
		l = Needed;
		DevDetail =
			(SP_DEVICE_INTERFACE_DETAIL_DATA *) GlobalAlloc(GPTR, l + 4);
		DevDetail->cbSize = sizeof(SP_INTERFACE_DEVICE_DETAIL_DATA);
		SetupDiGetDeviceInterfaceDetail(DeviceInfoSet, &DevData, DevDetail, l, &Needed, 0);

		hHID = CreateFile(DevDetail->DevicePath,
						  GENERIC_READ | GENERIC_WRITE,
						  FILE_SHARE_READ | FILE_SHARE_WRITE,
						  NULL, OPEN_EXISTING,
						  FILE_FLAG_WRITE_THROUGH | FILE_FLAG_NO_BUFFERING,
						  NULL);
		GlobalFree(DevDetail);

		if (hHID == INVALID_HANDLE_VALUE)	// Can't open a device
			continue;
		HidD_GetAttributes(hHID, &DeviceAttributes);
		// USB-IO���ǂ������ׂ�
		if (DeviceAttributes.VendorID == 5824 && DeviceAttributes.ProductID == 1500) {
			f = 1;
			break;
		} else {
			// ����������
			CloseHandle(hHID);
			hHID = NULL;
		}
	}
	SetupDiDestroyDeviceInfoList(DeviceInfoSet);
	return f;
}


int hidasp_init(char *string)
{
	ULONG sz;
	char wr_data[128], rd_data[128];
	int i, r;

#define CHECK_COUNT 4

	LoadHidDLL();
	if (OpenTheHid() == 0) {
#if DEBUG
		fprintf(stderr, "ERROR: fail to OpenTheHid()\n");
#endif
		return 1;
	}

	GetDevCaps();
	Sleep(100);

#if DEBUG
	fprintf(stderr, "HIDASP Connection check!\n");
#endif

	wr_data[0] = 0;
	wr_data[1] = 1;					// Connection test
	wr_data[2] = 0;
	wr_data[3] = 0;

	for (i=0; i<CHECK_COUNT; i++) {
		wr_data[2] = i;
#if DEBUG
		fprintf(stderr, "HIDasp write %2d.\n", i);
#endif
		r = WriteFile(hHID, wr_data, Caps.OutputReportByteLength, &sz, NULL);
//		Sleep(10);	/* wait */

		r = ReadFile(hHID, rd_data, Caps.InputReportByteLength, &sz, NULL);
#if DEBUG
		fprintf(stderr, "HIDasp read  %2d. %d\n", i, rd_data[1]);
#endif
		if (r == 0) {
			fprintf(stderr, "ERR. fail to Read().\n");
			return 1;
		}
		if (rd_data[1] == i) {
			Sleep(10);	/* wait */
		} else {
			return 1;
		}
	}
#if DEBUG
	fprintf(stderr, "OK.\n");
#endif
	return 0;
}

int hidasp_program_enable(int delay)
{
	unsigned char buf[128];
	unsigned char res[4];
	ULONG sz;
	int i;

	// �G���[���ɂ̓��g���C����悤�ɏC�� by senshu(2008-9-16)
	for (i=0; i<3; i++) {
		Sleep(2);
		buf[0] = 0;
		buf[1] = 2;					// LED CONT
		buf[2] = 2;					// BUSY LED OFF
		buf[3] = 0x10;				// RESET HIGH
		WriteFile(hHID, buf, Caps.OutputReportByteLength, &sz, NULL);
		Sleep(100);					// 10 => 100

		buf[0] = 0;
		buf[1] = 2;					// LED CONT
		buf[2] = 0;					// BUSY LED ON
		buf[3] = 0x00;				// RESET LOW
		WriteFile(hHID, buf, Caps.OutputReportByteLength, &sz, NULL);

		buf[0] = 0;
		buf[1] = 60;				// SET_DELAY
		buf[2] = delay;				// delay value
		buf[3] = 0x00;
		WriteFile(hHID, buf, Caps.OutputReportByteLength, &sz, NULL);
		Sleep(30);					// 30

		buf[0] = 0xAC;
		buf[1] = 0x53;
		buf[2] = 0x00;
		buf[3] = 0x00;
		hidasp_cmd(buf, res);

		if (res[2] == 0x53) {
#if DEBUG
			fprintf(stderr, "hidasp_program_enable() == OK\n");
#endif
			return 0;
		} else {
#if DEBUG
			fprintf(stderr, "hidasp_program_enable() == NG\n");
#endif
			Sleep(200);
		}
	}
	return 1;
}


void hidasp_close()
{
	if (hHID) {
		ULONG sz;
		unsigned char buf[128];

		buf[0] = 0x00;
		buf[1] = 0x00;
		buf[2] = 0x00;
		buf[3] = 0x00;
		hidasp_cmd(buf, NULL);	// AVOID BUG!

		buf[0] = 0;
		buf[1] = 2;
		buf[2] = 2;				// LED
		buf[3] = 0x10;			// RESET HI
		WriteFile(hHID, buf, Caps.OutputReportByteLength, &sz, NULL);
		CloseHandle(hHID);
	}
	if (hHID_DLL)
		FreeLibrary(hHID_DLL);
	hHID = NULL;
	hHID_DLL = NULL;
}

int hidasp_cmd(const unsigned char cmd[4], unsigned char res[4])
{
	ULONG sz = 0;
	char buf[128];
	int r;

	buf[0] = 0;
	if (res != NULL) {
		buf[1] = 0x11;
	} else {
		buf[1] = 0x10;
	}

#if 0
	Sleep(2);
	if(cmd[0]==0x38 && cmd[2]==0)  { // BUG!
		buf[8]=0;
		buf[9]=123; // dummy
		WriteFile(hHID, buf+8, Caps.OutputReportByteLength,&sz,NULL);
		Sleep(2);
	}
#endif
	Sleep(2);	// !!!
	memcpy(buf + 2, cmd, 4);
	r = WriteFile(hHID, buf, Caps.OutputReportByteLength, &sz, NULL);
#if DEBUG
	fprintf(stderr, "hidasp_cmd %02X, cmd: %02X %02X %02X %02X ", buf[1], cmd[0],cmd[1],cmd[2],cmd[3]);
#endif

	if (res != NULL) {
		r = ReadFile(hHID, buf, Caps.InputReportByteLength, &sz, NULL);
		memcpy(res, buf + 1, 4);
#if DEBUG
	  	fprintf(stderr, " --> res: %02X %02X %02X %02X\n", res[0],res[1],res[2],res[3]);
#endif
	}

	return 1;
}

int hidasp_page_write(long addr, const unsigned char *wd, int pagesize)
{
	int n, l;
	ULONG sz = 0;
	char buf[128];

	// set page
	buf[0] = 0x00;
	buf[1] = 20;				// Set Page mode
	buf[2] = 0x40;				// Flash
	buf[3] = 0x00;
	buf[4] = (char) (addr & 0xFF);
	WriteFile(hHID, buf, Caps.OutputReportByteLength, &sz, NULL);

	// Load the page data into page buffer
	n = 0;
	while (n < pagesize) {
		l = Caps.OutputReportByteLength - 3;	// MAX
		if (pagesize - n < l)
			l = pagesize - n;
		buf[0] = 0x00;
		buf[1] = 22;			// PageBuf
		buf[2] = l;				// Len
		memcpy(buf + 3, wd + n, l);
#if DEBUG
		Sleep(2);
#endif
		WriteFile(hHID, buf, Caps.OutputReportByteLength, &sz, NULL);
#if DEBUG
		fprintf(stderr, "  p: %02x %02x %02x %02x\n",
			buf[1] & 0xff, buf[2] & 0xff, buf[3] & 0xff, buf[4] & 0xff);
#endif
		n += l;
	}

	return 0;
}

int hidasp_page_read(long addr, unsigned char *wd, int pagesize)
{
	int n, l;
	ULONG sz = 0;
	char buf[128];

	// set page
	buf[0] = 0x00;
	buf[1] = 20;				// Set Page mode
	buf[2] = 0x20;				// FlashRead
	buf[3] = 0x00;
	if (addr >= 0)
		WriteFile(hHID, buf, Caps.OutputReportByteLength, &sz, NULL);

	// Load the page data into page buffer
	n = 0;
	while (n < pagesize) {
		l = Caps.InputReportByteLength - 1;	// MAX
		if (pagesize - n < l)
			l = pagesize - n;
		buf[0] = 0x00;
		buf[1] = 23;			// PageRead
		buf[2] = l;				// Len
		memset(buf + 3, 0, l);
#if DEBUG
		Sleep(2);
#endif
		WriteFile(hHID, buf, Caps.OutputReportByteLength, &sz, NULL);
		ReadFile(hHID, buf, Caps.InputReportByteLength, &sz, NULL);
		memcpy(wd + n, buf + 1, l);

#if 1
		report_update(l);
#else
		if (n % 1024 == 0) {
			report_update(1024);
		}
#endif

#if DEBUG
		fprintf(stderr, "  p: %02x %02x %02x %02x\n",
			buf[1] & 0xff, buf[2] & 0xff, buf[3] & 0xff, buf[4] & 0xff);
#endif
		n += l;
	}

	return 0;
}
