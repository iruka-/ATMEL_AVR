/* Name: main.c
 * Project: AVR bootloader HID
 * Author: Christian Starkjohann
 * Creation Date: 2007-03-19
 * Tabsize: 4
 * Copyright: (c) 2007 by OBJECTIVE DEVELOPMENT Software GmbH
 * License: GNU GPL v2 (see License.txt)
 * This Revision: $Id: main.c 378 2007-07-07 20:47:21Z cs $
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/wdt.h>
#include <avr/boot.h>
#include <string.h>

volatile void (*func)(void);

int	subr()
{
	func();
}

int main(void)
{
#if	0
	while(1) {
		// nothing.
	}
#endif
	func = 0x1800/2;
	subr();
}

#define	NOP1	\
	asm("nop");	asm("nop");	asm("nop");	asm("nop");	\
	asm("nop");	asm("nop");	asm("nop");	asm("nop");

#define	NOP2	NOP1 NOP1 NOP1 NOP1 NOP1 NOP1 NOP1 NOP1 NOP1 NOP1 

int	sub(void)
{
	NOP2	NOP2	NOP2	NOP2	NOP2	NOP2	NOP2	NOP2
	NOP2	NOP2	NOP2	NOP2	NOP2	NOP2	NOP2	NOP2
	NOP2	NOP2	NOP2	NOP2	NOP2	NOP2	NOP2	NOP2
	NOP2	NOP2	NOP2	NOP2	NOP2	NOP2	NOP2	NOP2
	NOP2	NOP2	NOP2	NOP2	
	NOP2	
//	NOP1 NOP1 NOP1 
}

