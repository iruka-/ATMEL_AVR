#!/usr/bin/perl

sub main()
{
	$m = 128.0;
	$r = 2 ** (1/12);
	for($i=0;$i<12;$i++) {
		printf("%x\n",$m);
		$m = $m * $r;
	}
}

&main();

