//	====================================================
//	�b����:�ȈՃO���t�B�b�N���C�u����(Win32��) ������
//	====================================================

#include "gr.h"

//	====================================================
//	���[�J����`.
//	====================================================
#define	u_short	unsigned short
#define	u_int	unsigned int
#define SWAP(x,y)  {int t; t=(x); (x)=(y); (y)=t; }

typedef	struct {
	int	width;
	int	height;
	
} gr_context;

gr_context gr;
//	====================================================
//	�O���[�o���ϐ�.
//	====================================================
int destroy_flag ;
int hitanykey_flag;
int	esc_flag;
int	end_flag;
int	close_flag;
ATOM wndclsatom ;

HBITMAP bitmap = NULL;
HWND hwMain=NULL;
HINSTANCE instance = NULL;
HANDLE thread = NULL;

HANDLE esc_event = NULL;
HANDLE hitanykey_event = NULL;
HANDLE cw_event = NULL;
HANDLE paint_event = NULL;
RECT client_rect = { 32,32, 640, 480 };

LPBYTE lpBuf,lpBMP;
LPBITMAPINFO lpDIB;
HDC hdcWin,hdcMem;
HBITMAP hBMP;

int *pixbuf;
static u_int gr_height;
static u_int gr_width;

int	mouse_x;
int	mouse_y;

static	char	g_menuname[256]="HIDmon";

//	====================================================
//	���[�J���ϐ�.
//	====================================================
int	gr_settitle(char *name)
{
//	char *s=get_filebody(name);
	strcpy(g_menuname,name);
//	printf("%s\n",s);
	return 0;
}

//	====================================================
//	�֐�.
//	====================================================
void redraw(HDC hdc, LPRECT prc)
{
	BitBlt(hdc, prc->left, prc->top,
	       prc->right - prc->left,
	       prc->bottom - prc->top,
	       hdcMem, prc->left, prc->top, SRCCOPY);

#if	0
	HDC hdcmem;
	hdcmem = CreateCompatibleDC(hdc);
	SelectObject(hdcmem, bitmap);
	BitBlt(hdc, prc->left, prc->top,
	       prc->right - prc->left,
	       prc->bottom - prc->top,
	       hdcmem, prc->left, prc->top, SRCCOPY);
	DeleteDC(hdcmem);
#endif
}

//	====================================================
//	
//	====================================================
int *gr_point(int x,int y)
{
	if( ((u_int)x < gr_width) && ((u_int)y < gr_height) ) {
		return &pixbuf[ y * gr_width + x ];
	}
	return 0;
}

//	====================================================
//	
//	====================================================
void gr_pset(int x,int y,int color)
{
	if(hBMP==NULL) return;

	if( ((u_int)x < gr_width) && ((u_int)y < gr_height) ) {
		pixbuf[ y * gr_width + x ]=color;
	}
}

#define GR_PSET(x,y,color)	pixbuf[(y)*gr_width+(x)]=color

//	====================================================
//	
//	====================================================
void gr_line(int x1,int y1,int x2,int y2,int c)
{
	int px,py;		/* �łׂ��_ */
	int r;			/* �덷���W�X�^ */
	int dx,dy,dir,count;

	if(x1 > x2) {SWAP(x1,x2);SWAP(y1,y2);}

	px=x1;py=y1;	/* �J�n�_ */
	dx=x2-x1;	/* �f���^ */
	dy=y2-y1;dir=1;
	if(dy<0) {dy=-dy;dir=-1;} /* ���̌X�� */

	if(dx<dy) {	/* �f���^���̕����傫���ꍇ */
		count=dy+1;
		r=dy/2;
		do {
			gr_pset(px,py,c);py+=dir;
			r+=dx;if(r>=dy) {r-=dy;px++;}
		} while(--count);
	} else {	/* �f���^���̕����傫���ꍇ */
		count=dx+1;
		r=dx/2;
		do {
			gr_pset(px,py,c);px++;
			r+=dy;if(r>=dx) {r-=dx;py+=dir;}
		} while(--count);
	}
}

//	====================================================
//	�~(cx,cy),���ar,�Fc ��`��
//	====================================================
void gr_circle( int cx,int cy,int r,int c)
{
	int  x,y;
	int  xr,yr;

	if(r==0) return;
	x=r * r;y=0;
	do {
		xr= x / r;
		yr= y / r;
		gr_pset(cx+xr,cy+yr,c);
		gr_pset(cx-xr,cy+yr,c);
		gr_pset(cx-xr,cy-yr,c);
		gr_pset(cx+xr,cy-yr,c);

		gr_pset(cx+yr,cy+xr,c);
		gr_pset(cx-yr,cy+xr,c);
		gr_pset(cx-yr,cy-xr,c);
		gr_pset(cx+yr,cy-xr,c);

		x += yr;
		y -= xr;
	}while( x>= (-y) );
}

//	====================================================
//	�������C��(x1,y1)�������ׂ̃T�u���[�`��
//	====================================================
static	void hline_sub(int x1,int y1,int xlen,int c)
{
	int *p = gr_point(x1,y1);
	while(xlen) {
		*p++ = c;xlen--;
	}
}

//	====================================================
//	�������C��(x1,y1)�������ׂ̃T�u���[�`��
//	====================================================
static	void vline_sub(int x1,int y1,int ylen,int stride,int c)
{
	int *p = gr_point(x1,y1);
	while(ylen) {
		*p = c;p += stride;
		ylen--;
	}
}

//	====================================================
//	�������C��(x1,y1) - (x2,y2) �������@�iy2�͖����j
//	====================================================
void gr_hline(int x1,int y1,int x2,int y2,int c)
{
	unsigned int  xlen;
	
	if(x2<x1) SWAP(x1,x2);
	if( ((u_int)x1 < gr_width) && ((u_int)y1 < gr_height) ) {
		xlen= x2 - x1 + 1;		/* ���̒��� */
		hline_sub(x1,y1,xlen,c);
	}
}

//	====================================================
//	�������C��(x1,y1) - (x2,y2) �������@�iy2�͖����j
//	====================================================
void gr_vline(int x1,int y1,int x2,int y2,int c)
{
	unsigned int  ylen;
	if(hBMP==NULL) return;

	if(y2<y1) SWAP(y1,y2);
	if( ((u_int)y1 < gr_height) && ((u_int)x1 < gr_width) ) {
		ylen= y2 - y1 + 1;		/* ���̒��� */
		vline_sub(x1,y1,ylen,gr_width,c);
	}
}

//	====================================================
//	�a�n�w�e�h�k�k(x1,y1) - (x2,y2),c
//	====================================================
void gr_boxfill(int x1,int y1,int x2,int y2,int c)
{
	int xlen,ylen;
	if(y2<y1) SWAP(y1,y2);
	if(x2<x1) SWAP(x1,x2);

	ylen = y2 - y1 + 1;
	xlen = x2 - x1 + 1;		/* ���̒��� */

	while(ylen) {
		hline_sub(x1,y1,xlen,c);y1++;ylen--;
	}
}


//	====================================================
//	�a�n�w(x1,y1) - (x2,y2),c
//	====================================================
void gr_box(int x1,int y1,int x2,int y2,int c)
{
	gr_hline(x1,y1,x2,y1,c);
	gr_hline(x1,y2,x2,y2,c);
	gr_vline(x1,y1,x1,y2,c);
	gr_vline(x2,y1,x2,y2,c);
}
//	====================================================
//	
//	====================================================
void gr_cls(int color)
{
	int i;
	int size = gr_width * gr_height;
	int *p=pixbuf;
	for(i=0;i<size;i++) *p++ = color;
}
//	====================================================
//	
//	====================================================
void gr_puts(int x,int y,char *s,int color)
{
	RECT r;
	r.left=x; /* �r�b�g�}�b�v�̗̈�w�� */ 
	r.top=y;
	r.right=gr_width;
	r.bottom=gr_height;

	/* GDI �ŕ�����`�� */
//	SetTextColor(hdcMem,RGB(240,240,240));
	SetTextColor(hdcMem,color);
	SetBkMode(hdcMem,TRANSPARENT);
	DrawText(hdcMem,s,lstrlen(s),&r,DT_SINGLELINE);
}

//	====================================================
//	
//	====================================================
void gr_textout(int x,int y,char *s)
{
	RECT r;
	r.left=x; /* �r�b�g�}�b�v�̗̈�w�� */ 
	r.top=y;
	r.right=gr_width;
	r.bottom=gr_height;

	/* GDI �ŕ�����`�� */
	SetTextColor(hdcMem,RGB(240,240,240));
	SetBkMode(hdcMem,TRANSPARENT);
//	DrawText(hdcMem,s,lstrlen(s),&r,DT_SINGLELINE);
	TextOut(hdcMem,x,y,s,lstrlen(s));
}

//	====================================================
//	
//	====================================================
LRESULT CALLBACK mainwnd_proc(HWND hwnd, UINT msgid, WPARAM wparam, LPARAM lparam)
{
	PAINTSTRUCT ps;
	HDC hdc;
	LPRECT prc;
	RECT r;
	switch(msgid) {

	case WM_MOUSEMOVE: /* �}�E�X�J�[�\���ړ� */
		mouse_x=LOWORD(lparam); /* �}�E�X�J�[�\���̈ʒu�擾 */
		mouse_y=HIWORD(lparam);
		return 0;

	case WM_CREATE:
		return 0;
	case WM_SIZE:
		InvalidateRect(hwnd,NULL,FALSE);
		UpdateWindow (hwnd);             // �ĕ`��
//		SetWindowPos(hwMain, NULL, 0, 0,
//			     client_rect.right - client_rect.left,
//			     client_rect.bottom - client_rect.top,
//			     SWP_NOCOPYBITS | SWP_NOMOVE | SWP_NOZORDER);
		return 0;
	case WM_SIZING:
		prc = (LPRECT) lparam;
		switch(wparam) {
		case WMSZ_TOP:
		case WMSZ_TOPLEFT:
		case WMSZ_TOPRIGHT:
		case WMSZ_BOTTOMLEFT:
		case WMSZ_LEFT:
			prc->left = prc->right - (client_rect.right
						  - client_rect.left);
			prc->top = prc->bottom - (client_rect.bottom
						  - client_rect.top);
			break;
		case WMSZ_BOTTOM:
		case WMSZ_BOTTOMRIGHT:
		case WMSZ_RIGHT:
			prc->right = prc->left + (client_rect.right
						  - client_rect.left);
			prc->bottom = prc->top + (client_rect.bottom
						  - client_rect.top);
			break;
		}
		return 0;
	case WM_PAINT:
#if	1
		{ int x,y;
			GetClientRect(hwnd,&r); /* �N���C�A���g�̈�擾 */
			x=(r.right -gr_width) /2; /* �r�b�g�}�b�v�̕\���ʒu�v�Z */
			y=(r.bottom-gr_height)/2;

			hdc=BeginPaint(hwMain,&ps);

			BitBlt(hdc,x,y,gr_width,gr_height,hdcMem,0,0,SRCCOPY);

			EndPaint(hwMain,&ps);
		}
		SetEvent(paint_event);
		return 0;
#else
		hdc = BeginPaint(hwMain, &ps);
		redraw(hdc, &ps.rcPaint);
		EndPaint(hwMain, &ps);
#endif
		return 0;
	case WM_KEYDOWN:
		if(wparam == VK_ESCAPE) {
			esc_flag = 1;
			end_flag = 1;
			SetEvent(esc_event);
		}
		if(lparam & (1 << 30))
			return 0;
		if(wparam == VK_F5) {
			hdc = GetDC(hwMain);
			redraw(hdc, &client_rect);
			ReleaseDC(hwMain, hdc);
			return 0;
		}
	case WM_LBUTTONDOWN:
	case WM_RBUTTONDOWN:
	case WM_MBUTTONDOWN:
		SetEvent(hitanykey_event);
		return 0;
	case WM_DESTROY:
	if(lpBuf) {
		GlobalFree(lpBuf); /* ����������� */
		lpBuf = NULL;
	}
		DeleteDC(hdcMem); /* �f�o�C�X�R���e�L�X�g�J�� */
		DeleteObject(hBMP); /* �r�b�g�}�b�v�J�� */
		PostQuitMessage(0);
		hdcMem=NULL;
		hBMP=NULL;
			end_flag = 1;
		return 0;
	}
	return DefWindowProc(hwnd, msgid, wparam, lparam);
}

//	====================================================
//	
//	====================================================
void init_window(void)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(wcex);
	wcex.style = CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc = mainwnd_proc;
	wcex.cbClsExtra = wcex.cbWndExtra = 0;
	wcex.hInstance = instance = GetModuleHandle(NULL);
	wcex.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
	wcex.lpszMenuName = NULL;
	wcex.lpszClassName = "graphics";
	wcex.hIconSm = wcex.hIcon;
	wndclsatom = RegisterClassEx(&wcex);
	if(wndclsatom == 0) {
		fprintf(stderr, "Can't register class.\n");
		exit(1);
	}

	AdjustWindowRectEx(
		&client_rect,
		WS_OVERLAPPEDWINDOW,
		FALSE,
		WS_EX_OVERLAPPEDWINDOW);

	hwMain = CreateWindowEx(
		WS_EX_OVERLAPPEDWINDOW,
		"graphics",
		g_menuname,
		WS_OVERLAPPEDWINDOW ,
		CW_USEDEFAULT, CW_USEDEFAULT,
		client_rect.right  - client_rect.left,
		client_rect.bottom - client_rect.top,
		NULL, NULL, instance, NULL);

	if(hwMain == NULL) {
		fprintf(stderr, "Can't create window.\n");
		UnregisterClass("graphics", instance);
		exit(1);
	}


	ShowWindow(hwMain, SW_NORMAL);
	UpdateWindow(hwMain);

//	SetActiveWindow(hwMain);

}

//	====================================================
//	
//	====================================================
void init_bitmap(int bpp)
{
	lpBuf=GlobalAlloc(GPTR,sizeof(BITMAPINFO));
	lpDIB=(LPBITMAPINFO)lpBuf;
	lpDIB->bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
	lpDIB->bmiHeader.biWidth =  gr_width;
	lpDIB->bmiHeader.biHeight= -gr_height;	//�オy=0��bitmap
	lpDIB->bmiHeader.biPlanes=1;
	lpDIB->bmiHeader.biBitCount=bpp;	//16;
	lpDIB->bmiHeader.biCompression=BI_RGB;
	lpDIB->bmiHeader.biSizeImage=0;
	lpDIB->bmiHeader.biXPelsPerMeter=0;
	lpDIB->bmiHeader.biYPelsPerMeter=0;
	lpDIB->bmiHeader.biClrUsed=0;
	lpDIB->bmiHeader.biClrImportant=0;

	hdcWin=GetDC(hwMain); /* �E�C���h�E��DC ���擾 */

	/* DIB �ƃE�C���h�E��DC ����DIBSection ���쐬 */
	hBMP=CreateDIBSection(hdcWin,lpDIB,DIB_RGB_COLORS,(void *)&lpBMP,NULL,0);

	hdcMem=CreateCompatibleDC(hdcWin); /* ������DC ���쐬 */

	SelectObject(hdcMem,hBMP); /* ������DC �Ƀr�b�g�}�b�v��I�� */

	ReleaseDC(hwMain,hdcWin);
	
	pixbuf = (int*)lpBMP;
}

//	====================================================
//	
//	====================================================
DWORD WINAPI xmain(LPVOID param)
{
	MSG msg;

	init_window();

	SetEvent(cw_event);

	destroy_flag = 0;
	while(GetMessage(&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
		if(destroy_flag) {
			DestroyWindow(hwMain);
			hwMain=NULL;
		}
	}

	hitanykey_flag = 0;
	end_flag = 0;
	esc_flag = 0;
//	DeleteObject(bitmap);

	return msg.wParam;
}

//	====================================================
//	
//	====================================================
int	gr_flip(int flag)
{
	ResetEvent(paint_event);
	InvalidateRect(hwMain,NULL,FALSE);
	WaitForSingleObject(paint_event, INFINITE);

	return end_flag;
}

//	====================================================
//	
//	====================================================
int	gr_break(void)
{
	if(hwMain!= NULL) {
//	ResetEvent(paint_event);
	InvalidateRect(hwMain,NULL,FALSE);
//	WaitForSingleObject(paint_event, INFINITE);
	}
	return end_flag;
}

//	====================================================
//	
//	====================================================
int hitanykey(void)
{
	char fnbuf[MAX_PATH];
	
	gr_flip(0);
	
	GetWindowsDirectory(fnbuf, MAX_PATH);
	ResetEvent(hitanykey_event);
	WaitForSingleObject(hitanykey_event, INFINITE);

	return esc_flag;
}


//	====================================================
//	
//	====================================================
void gr_close(void)
{
	DWORD exitcode;

	if(close_flag) return;

	GetExitCodeThread(thread, &exitcode);
	if(exitcode == STILL_ACTIVE) {
		destroy_flag = 1;
		while(exitcode == STILL_ACTIVE) {
			GetExitCodeThread(thread, &exitcode);
		}
	}
	if(wndclsatom != 0) {
		UnregisterClass("graphics", instance);
	}
	CloseHandle(esc_event);
	CloseHandle(hitanykey_event);
	CloseHandle(cw_event);
	CloseHandle(paint_event);

	if(lpBuf) {
		GlobalFree(lpBuf);
		lpBuf = NULL;
	}
	close_flag = 1;
}


//	====================================================
//	�O���t�B�b�N������.
//	====================================================
void gr_init(int width,int height,int bpp,int color)
{
	//static 
	int first = 1;

	width = (width + 3) & (-4);	//�S�̔{���ɂ���.

	gr_width  = width;
	gr_height = height;

	client_rect.left  = 32;
	client_rect.top   = 32;

	client_rect.right  = client_rect.left + width;
	client_rect.bottom = client_rect.top  + height;

	if(first) {
		DWORD thid;

		atexit(gr_close);
		first = 0;
		close_flag = 0;

		esc_event       = CreateEvent(NULL, FALSE, TRUE, NULL);
		hitanykey_event = CreateEvent(NULL, FALSE, TRUE, NULL);
		cw_event        = CreateEvent(NULL, FALSE, FALSE, NULL);
		paint_event     = CreateEvent(NULL, FALSE, FALSE, NULL);
		thread = CreateThread(NULL, 0, xmain, NULL, 0, &thid);
		if(thread == NULL) {
			fprintf(stderr, "Can't create thread.\n");
			exit(1);
		}
		WaitForSingleObject(cw_event, INFINITE);
	}
	init_bitmap(bpp);
}
