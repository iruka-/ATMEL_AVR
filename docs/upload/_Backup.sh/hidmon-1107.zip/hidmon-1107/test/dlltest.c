#include <stdio.h>

#include "hidmon.h"


#define	NAME	"pinb"


void	test1(f)
{
#if	1
	UsbPoke( PortAddress("ddrd"), 0,f,0);
	UsbPoke( PortAddress("portd"),0,f,0);
	UsbPoke( PortAddress("pind"), 0,f,0);
#endif
}


int main()
{
	int i,adr;
	UsbInit("*");

	printf("%s(%x)\n","portb", PortAddress( "portb" ) );

	adr = PortAddress( NAME );
	printf("%s(%x)\n",NAME, adr );

	test1(0);

	for(i=0;i<1000;i++) {
		printf("%s = 0x%02x\r",NAME,UsbPeek(adr,0) );
	}
	test1(0xff);

	UsbExit();
	return 0;
}
