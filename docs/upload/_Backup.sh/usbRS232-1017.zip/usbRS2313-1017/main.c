/*******************************************************************************
 *			usbRS2313 :	  USB to RS232C	serial port	for	ATtiny2313
 *******************************************************************************
 *������:
 *
 *
 *
 *
 *
 *
 *
 *******************************************************************************
 */
#include "hardware.h"
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/wdt.h>
#include <util/delay.h>
#include <string.h>
#include "usbdrv.h"


/*******************************************************************************
 *	Switches
 *******************************************************************************
 */
#define	OPTIMIZE_SIZE	(1)		// Enable global register assignment
#define	ECHOBACK_TEST	(0)		// Enable Echoback Test
#define	SEQENCE_TEST	(0)		// Enable Sequence Test
#define	USE_LED_CONTROL	(1)		// BUSY LED CONTROL



#if	OPTIMIZE_SIZE	
#define	REGISTER	register
#define	ASM( reg )	asm( reg )
#else
#define	REGISTER
#define	ASM( reg )
#endif

/*******************************************************************************
 *	deviceDescriptor / configDescriptor for CDC Device.
 *******************************************************************************
 */
#include "usbdesc.h"


/*******************************************************************************
 *	Static Work
 *******************************************************************************
 */
static   uchar	modeBuffer[7];
// =	{0x80, 0x25, 0,	0, 0, 0, 8};  /* default: 9600 bps,	8n1	*/

REGISTER uchar	requestType     ASM("r3");
REGISTER uchar  sendEmptyFrame	ASM("r4");	// = 1;

#if	USE_DCD_REPORTING
REGISTER uchar	intr3Status     ASM("r5");
#endif

#if	ECHOBACK_TEST
REGISTER uchar  etestcnt        ASM("r6");
static   char   etestbuf[8];	//�o���N�ǂݏo��(��M�f�[�^�]��)�̃o�b�t�@.
#endif

//	����:	register r8 �ȍ~�� usart.h ���Ŏg�p����.
//	*****************************************************************************


/*******************************************************************************
 *	Serial Port Control
 *******************************************************************************
 */
#include "usart.h"


//	����!! ����memCopy�� (char)len <= 0 �Ȃ牽�����Ȃ�.
void memCopy(uchar *d,uchar *s,uchar len);		// SRAM to SRAM copy


/* CDC class requests: */
enum {
	SEND_ENCAPSULATED_COMMAND =	0,
	GET_ENCAPSULATED_RESPONSE,
	SET_COMM_FEATURE,
	GET_COMM_FEATURE,
	CLEAR_COMM_FEATURE,
	SET_LINE_CODING	= 0x20,
	GET_LINE_CODING,
	SET_CONTROL_LINE_STATE,
	SEND_BREAK
};

/* defines for 'requestType' */
#define	REQUEST_TYPE_LINE_CODING	0	/* CDC GET/SET_LINE_CODING */
#define	REQUEST_TYPE_VENDOR			4	/* vendor request for get/set debug	data */

/* ------------------------------------------------------------------------- */


/* ------------------------------------------------------------------------- */
/* ----------------------------- USB interface ----------------------------- */
/* ------------------------------------------------------------------------- */

/******************************************************************
 *	�f�t�H���g�ȊO�̃R���g���[���]���������ɌĂяo�����G���g���[.
 ******************************************************************
 *	�x���_���N�G�X�g�������̓N���X���N�G�X�g�ɉ�������.
 *	����   :usbRequset_t *rq;      ���N�G�X�g�p�P�b�g�\����.
 *          �ڍׂ� usbdrv.h ���Q��.
 *			����rq->bRequest �ɃR�}���h�ԍ������邱�Ƃ�����.
 *	�߂�l :uchar         replyLen 
 *			�o�C�g����Ԃ����ꍇ�� usbMsgPtr�ɃA�h���X�����Ă���.
 *			0xff ��Ԃ����ꍇ�� usbFunctionRead()���Ăяo�����.
 *
 */
uchar usbFunctionSetup(uchar data[8])
{
	usbRequest_t	*rq	= (void	*)data;
	uchar			rqType = rq->bmRequestType & USBRQ_TYPE_MASK;

	if(rqType == USBRQ_TYPE_CLASS){	   /* class	request	type */
		if(rq->bRequest	== GET_LINE_CODING){
//			usbMsgPtr = modeBuffer;
//			return 7;
			requestType	= REQUEST_TYPE_LINE_CODING;
			return 0xff;
		}
		if(rq->bRequest == SET_LINE_CODING){
			requestType	= REQUEST_TYPE_LINE_CODING;
			return 0xff;
		}

#	if USE_DCD_REPORTING
		if(rq->bRequest	== SET_CONTROL_LINE_STATE){
			/* Report serial state (carrier	detect). On	several	Unix platforms,
			 * tty devices can only	be opened when carrier detect is set.
			 */
			intr3Status	= 2;
		}
#	endif

#if	1
		/*  Prepare bulk-in endpoint to respond to early termination   */
		if((rq->bmRequestType & USBRQ_DIR_MASK) == USBRQ_DIR_HOST_TO_DEVICE) {
			sendEmptyFrame  = 1;
		}
#endif
	}
	return 0;
}

#if	1
/*******************************************************************************
 *	Control-In ���s���ɌĂ΂��.
 ******************************************************************
 *	�߂�l�́A�z�X�g�ɓ]������o�C�g��.(<= 8)
 *				0xff�̎���stall
 *	���ꂪ�Ăт������ɂ́A�܂� usbFunctionSetup() �̕Ԃ�l�� 
 *  0xff�łȂ���΂Ȃ�Ȃ�.
 */
uchar usbFunctionRead(uchar	*data, uchar len)
{
	if(requestType == REQUEST_TYPE_LINE_CODING){
		/* return the "virtual"	configuration */
		memCopy(data, modeBuffer, 7);
		return 7;
	}
	return 0;	/* error ->	terminate transfer */
}
#endif

/*******************************************************************************
 *	Control-Out ���s���ɌĂ΂��.
 *******************************************************************************
 */
uchar usbFunctionWrite(uchar *data,	uchar len)
{
	if(requestType == REQUEST_TYPE_LINE_CODING){
		/* Don't know why data toggling	is reset when line coding is changed, but it is... */
		USB_SET_DATATOKEN1(USBPID_DATA1);	/* enforce DATA0 token for next	transfer */
		/* store the line configuration	so that	we can return it on	request	*/
		memCopy(modeBuffer, data, 7);
		USART_Init( *((int*)modeBuffer) , modeBuffer[2] );
//		return 1;
	}
	return 1;	/* error ->	accept everything until	end	*/
}

#if	ECHOBACK_TEST
/*******************************************************************************
 *	HOST->DEVICE:(Bulk-out) ���s���ɌĂ΂��.
 *******************************************************************************
 */
void usbFunctionWriteOut(uchar *data, uchar	len)
{
	memCopy( etestbuf, data, 8 );
	etestcnt = len;
}
#else
/*******************************************************************************
 *	HOST->DEVICE:(Bulk-out) ���s���ɌĂ΂��.
 *******************************************************************************
 */
void usbFunctionWriteOut(uchar *data, uchar	len)
{
#if	0
	// �����M�f�[�^������Ȃ�A�����őS�����M����܂ő҂�.
	while( rsptr < TXBUF_SIZE ) {
		USART_RecvTask();
		USART_SendTask();
	}
#endif
	// ���M�o�b�t�@�ɗ��߂�.
	rsptr = 8 - len;
	memCopy(rsbuf+rsptr,data,len);
	USART_SendTask();
	if( rsptr < TXBUF_SIZE ) {
		usbDisableAllRequests();
	}
#if	0
//	AVR-Doper:
	do{	/* len must	be at least	1 character, the driver	discards zero sized	packets	*/
		stkSetRxChar(*data++);
	}while(--len);
#endif
}
#endif


#if	ECHOBACK_TEST
/*******************************************************************************
 *	usbSetInterrupt :
 *******************************************************************************
 */
static	void setInterrupt_xfer(void)
{
	if( etestcnt || sendEmptyFrame ) {
		usbSetInterrupt((uchar *)etestbuf, etestcnt);
		/* send an empty block after last data block to indicate transfer end */
		if(etestcnt==8) {sendEmptyFrame=1;}
		else			{sendEmptyFrame=0;}
		etestcnt    = 0;
	}
}

#else

/*******************************************************************************
 *	usbSetInterrupt :	�q�r�Q�R�Q��M�f�[�^���z�X�g�o�b�ɑ���.
 *******************************************************************************
 */
static	void setInterrupt_xfer(void)
{
	static uchar buffer[HW_CDC_PACKET_SIZE];
	uchar rxcnt = USART_rxptr;		//��M������.

	if((rxcnt > 0) || sendEmptyFrame){
		if(rxcnt >= 8) rxcnt = 8;	//�P��̓]���͂W�o�C�g�܂�.

		// ��M�σf�[�^��buffer�ɃR�s�[.
		memCopy(buffer,USART_rxbuf,rxcnt);

		// ��M�σf�[�^(max 8byte) ��USART_rxbuf[]����폜.
		USART_rxptr -= rxcnt;
		memCopy(USART_rxbuf,USART_rxbuf+8,USART_rxptr);	//�o�b�t�@���炵.

#if		SEQENCE_TEST
		static char seq='0';
		uchar i;
		for(i=0;i<8;i++) buffer[i]=seq;
		seq++;if(seq>=0x7f) seq ='0';
		rxcnt = 8;
		usbSetInterrupt(buffer,rxcnt);
		sendEmptyFrame=0;
		if(rxcnt==8) {sendEmptyFrame=1;}

#else
		/* send	an empty block after last data block to	indicate transfer end */
		usbSetInterrupt(buffer,rxcnt);
//		sendEmptyFrame=rxcnt;
		sendEmptyFrame=0;
		if(rxcnt==8) {sendEmptyFrame=1;}

#endif
	}

#if	0
// AVR-Doper:
//	static uchar sendEmptyFrame	= 1;
	static uchar buffer[HW_CDC_PACKET_SIZE];
	/* start with empty	frame because the host eats	the	first packet --	don't know why... */
	uchar c;
	uchar i	= 0;
	while(i	< HW_CDC_PACKET_SIZE &&	(c = stkGetTxByte()) !=	0){
		buffer[i++]	= c;
	}
	if(i > 0 ||	sendEmptyFrame){
		sendEmptyFrame = i;		/* send	an empty block after last data block to	indicate transfer end */
		usbSetInterrupt(buffer,	i);
	}
#endif
}

#endif

/*******************************************************************************
 *	usbSetInterrupt3 :
 *******************************************************************************
 */
static	void setInterrupt3(void)
{
#if	USE_DCD_REPORTING
	/* We need to report rx	and	tx carrier after open attempt */
	if(intr3Status != 0	&& usbInterruptIsReady3()){
		static uchar serialStateNotification[8]	= {0xa1, 0x20, 0, 0, 0,	0, 2, 0};
		static uchar serialStateData[2]	= {3, 0};
		if(intr3Status == 2){
			usbSetInterrupt3(serialStateNotification, 8);
		}else{
			usbSetInterrupt3(serialStateData, 2);
		}
		intr3Status--;
	}
#endif
}

static void LED_Control()
{
#if	USE_LED_CONTROL
	if(USART_rxptr) {
		PORTB &= ~(1<<LED_PIN);
	}else{
		PORTB |=  (1<<LED_PIN);
	}
#endif
}
/*******************************************************************************
 *	
 *******************************************************************************
 */
static	void hardwareInit()
{
	PORTD = 1;				// RxD Pullup
	DDRD = ~USBMASK;        /* all outputs except USB data */
	DDRB = 0x0f;			/* PB7-4=in PB3-0=out*/

	sendEmptyFrame	= 1;

#if	USE_DCD_REPORTING
	intr3Status = 0;
#endif

#if	ECHOBACK_TEST
	etestcnt    = 0;
#endif

}

/*
 *	*******************************************************************
 * 	��H�}�́A�g�h�c�������i���j�A�g�h�c�������̂��̂Ƌ��ʂł��B


         ATtiny2313
         ___    ___
RESET   [1  |__| 20] Vcc
PD0(RxD)[2       19] PB7(SCK)
PD1(TxD)[3       18] PB6(MISO)
XTAL2   [4       17] PB5(MOSI)
XTAL1   [5       16] PB4(NC)
PD2     [6       15] PB3(PWR LED)
PD3(D+) [7       14] PB2(ACC LED)
PD4(D-) [8       13] PB1(NC)
PD5     [9       12] PB0(NC)
GND     [10      11] PD6(NC)
         ~~~~~~~~~~~

   ---------------------------------------
   SPI:     PB7-5
   USB:     PD4   ===> USB D-
            PD3   ===> USB D+
   XTAL:    XTAL1,2 => Crystal 12MHz
   ---------------------------------------
 *	*******************************************************************
 */

/*******************************************************************************
 *	main Loop
 *******************************************************************************
 */
int	main(void)
{
	hardwareInit();
	usbInit();
#if	0
	USB_SET_DATATOKEN1(USBPID_DATA1);
	USB_SET_DATATOKEN3(USBPID_DATA1);
#endif
	USART_Init(USART_default_baud);

	sei();
	for(;;){	/* main	event loop */
		usbPoll();
		USART_RecvTask();
		LED_Control();
#if	1
		USART_SendTask();
#else
		if( USART_SendTask()!=0 ) {		// ���M�o�b�t�@�c��.
			usbDisableAllRequests();	// ���M��t��~.
		}else{
			usbEnableAllRequests();		// ���M�o�b�t�@�͋�.
		}
#endif

		if(	usbInterruptIsReady() ) {
			setInterrupt_xfer();		// ��M�f�[�^���z�X�g�o�b�ɓ]��.
		}
		setInterrupt3();				// EndPoint3: DCD_REPORTING
	}
	return 0;
}

