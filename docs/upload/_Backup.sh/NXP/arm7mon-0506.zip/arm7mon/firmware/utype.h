#ifndef _utype_h_
#define _utype_h_

//
//	unsigned types
//

typedef unsigned char		uchar;	
typedef unsigned short 		ushort;	
typedef unsigned int		uint;	

typedef unsigned char		uint8_t;
typedef unsigned short 		uint16_t;
typedef unsigned int		uint32_t;

#endif 

