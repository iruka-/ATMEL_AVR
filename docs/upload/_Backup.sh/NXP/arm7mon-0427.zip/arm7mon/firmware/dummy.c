
#include "type.h"
#include "usbdebug.h"

#include "console.h"
#include "usbapi.h"
#include "startup.h"

#include "hwlib/led.h"
#include "utype.h"

#ifdef	LPC214x
#include "hwlib/LPC214x.h"
#else
#include "hwlib/LPC23xx.h"
#endif

#define	GPIOC		0
#define GPIO_Pin_6	6

static int led_cnt=0;

// dummy
void GPIO_SetBits(int a,int b)		{}
void GPIO_ResetBits(int a,int b)	{}

void led_blink()
{
	led_cnt++;led_cnt &= 1;
	if(led_cnt) {
	    GPIO_SetBits(GPIOC, GPIO_Pin_6);
	}else{
    	GPIO_ResetBits(GPIOC, GPIO_Pin_6);
	}
}

void led_on()
{
	GPIO_SetBits(GPIOC, GPIO_Pin_6);
	led_cnt=1;
}
void led_off()
{
	GPIO_ResetBits(GPIOC, GPIO_Pin_6);
	led_cnt=0;
}
void Delay(uint32_t nCount)
{
  for(; nCount!= 0;nCount--);
}
void wait_ms(int ms)
{
	Delay(ms*1000);
}

void GetEPTxAddr(){}
void SetEPTxValid(){}
void UserToPMABufferCopy(){}
void USB_SIL_Read(){}
void SetEPRxStatus(){}

