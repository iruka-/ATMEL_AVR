/*********************************************************************
 *	WIN32: RS232C �̐���.
 *********************************************************************

 * �������E�I��:
int		RS_init(char *portno,int baudrate);
void	RS_exit(void);

 * ���菇�[���̎��s:
void	RS_terminal(char *port_no,int baudrate);

 * �f�[�^���M:
int		RS_putdata(	unsigned char *buf , int cnt );
int		RS_putc(int c);
 * �f�[�^��M:
int		RS_checkdata();
int		RS_getdata(unsigned char *buf,int cnt);

 * �L�[�{�[�h����:
int		RS_keyInput(void);

void	memdump(void *ptr,int len,int off);
int		UsbInit(int verbose,int enable_bulk);	
int		UsbExit(void);
void 	UsbBench(int cnt,int psize);
void	UsbDump(int adr,int arena,int size);
void 	UsbPoke(int adr,int arena,int data0,int data1);
int 	UsbPeek(int adr,int arena);
int 	UsbRead(int adr,int arena,uchar *buf,int size);
void 	UsbBench2(int cnt,int psize);
void 	UsbSetBaudRate(int ubrr,int bits);
 *
 *********************************************************************
 */

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <signal.h>
#include <usb.h>
#include "w32term.h"
#include "rs232c.h"
#include "util.h"
/*********************************************************************
 *	��`
 *********************************************************************
 */
#define	    COM_DEVICENAME  "\\\\.\\COM%s"	
// ���� "\\.\"��t���Ȃ��ꍇ�� COM�|�[�g1�`9�܂ł����Ή��ł��Ȃ�.
//				�t�����ꍇ��1�`99�܂�.

#define		KEY_ESCAPE_CH	0x01
/*********************************************************************
 *	�O���[�o��
 *********************************************************************
 */
static char	COM_Device[256];
HANDLE		thread;
DWORD		thid;
HANDLE		comHandle;
OVERLAPPED	ovlrd;
OVERLAPPED	ovlwr;
HANDLE		ovlrd_hEvent;
HANDLE		ovlwr_hEvent;

void	Term_Log(int c);
usb_dev_handle *usb_dev; /* the device handle */
/*********************************************************************
 *	�q�r�Q�R�Q�b ������f�[�^ �o��.
 *********************************************************************
 */
int	RS_putdata(	unsigned char *buf , int cnt )
{
	DWORD dwWritten=0;
	DWORD wcnt = 0;

	memset(&ovlwr,0,sizeof(OVERLAPPED));
	ovlwr.hEvent = ovlwr_hEvent;

//	buf[cnt]=0; printf("%02x\n",buf[0]);

	int rc = WriteFile(comHandle, buf , cnt , &dwWritten, &ovlwr);
	if (rc == 0) {
		if((rc = GetLastError() ) == ERROR_IO_PENDING) 
		{
//			WaitForSingleObject(ovlwr.hEvent, INFINITE);
			GetOverlappedResult(comHandle,&ovlwr,&wcnt,FALSE);
			//printf("putComPort() data = %x\n",buf[0]);
			return cnt;
		}
	}
	return cnt;
}

/*********************************************************************
 *	�q�r�Q�R�Q�b�����o��.
 *********************************************************************
 */
int	RS_putc(int c)
{
	char buf[16];
	buf[0]=c;
	RS_putdata(buf,1);
	Term_Log(c);
	return 0;
}
/*********************************************************************
 *	�R���\�[������
 *********************************************************************
 */
int	RS_keyInput(void)
{
	if(kbhit())	{
		return getch();
	}
	return 0;
}
/*********************************************************************
 *	COMM�f�o�C�X����P�o�C�g����M����.
 *********************************************************************
 *	�߂�l:
 *		0 ��M�Ȃ�.
 *		1 ��M�n�j.
 *
 *
 */
int	RS_getdata(unsigned char *buf,int cnt)
{
	DWORD	r=0;
	DWORD	rcnt = 0;

	memset(&ovlrd,0,sizeof(OVERLAPPED));
	ovlrd.hEvent = ovlrd_hEvent;

	int	rc = ReadFile( comHandle, buf , cnt , &r , &ovlrd ); 
	if (rc) {
		if(r == cnt) {
		// �����ǂݍ��ݐ���.
			return cnt;	//��M����.
		}
		//printf("RxError1 rc = %d\n",rc);
		return 0;
	}else{

		// �x���ǂݍ��ݒ��E�E�E.
		if(( rc =GetLastError() ) == ERROR_IO_PENDING) {
			WaitForSingleObject(ovlrd.hEvent, INFINITE);
			rc = GetOverlappedResult(comHandle,&ovlrd,&rcnt,FALSE);
			if(rc) {
				if(rcnt == cnt) 
				{
					return cnt;	// ��M�n�j.
				}
			}
			//printf("RxError3 rc = %d\n",rc);
			return 0;
		}
		//printf("RxError4 rc = %d\n",rc);
		return 0;
	}
	return 0;
}
/*********************************************************************
 *	
 *********************************************************************
 */
int	RS_checkdata()
{
	DWORD DErr=0;
	COMSTAT commstat;

	ClearCommError(comHandle,&DErr,&commstat);
	return commstat.cbInQue ;

}

/*********************************************************************
 *	�b�n�l�|�[�g�̏�����
 *********************************************************************
 */
int	RS_init(char *portno,int baudrate)
{
	static	DCB	com_dcb;
	DWORD 		DErr;

	sprintf(COM_Device,COM_DEVICENAME,portno);
	comHandle =	CreateFile(
		COM_Device,									/* �V���A���|�[�g�̕����� */
		GENERIC_READ | GENERIC_WRITE   ,			/* �A�N�Z�X���[�h */
		0,
		NULL,										/* �Z�L�����e�B���� */
		OPEN_EXISTING,								/* �쐬�t���O	*/
//		FILE_ATTRIBUTE_NORMAL|FILE_FLAG_OVERLAPPED, /* ���� */
		0,											/* ���� */
		NULL										/* �e���v���[�g�̃n���h��	*/
	);

	if(comHandle ==	INVALID_HANDLE_VALUE) {
		fprintf(stderr,	"Can't Open COM Port (%s:).\n",COM_Device + strlen("\\\\.\\") );
		exit(1);
	}

	ovlrd_hEvent = CreateEvent(NULL,TRUE,FALSE,NULL);
	ovlwr_hEvent = CreateEvent(NULL,TRUE,TRUE ,NULL);

	{
		ClearCommError(comHandle,&DErr,NULL);
		SetupComm(comHandle,8192,2048);
		PurgeComm(comHandle,PURGE_TXABORT | PURGE_RXABORT |PURGE_TXCLEAR |	PURGE_RXCLEAR);

		memset(&com_dcb,0,sizeof(com_dcb));
		com_dcb.DCBlength = sizeof(DCB);
		GetCommState(comHandle,&com_dcb);

		com_dcb.BaudRate = baudrate;
		com_dcb.ByteSize = 8;
		com_dcb.Parity   = NOPARITY;
		com_dcb.StopBits = ONESTOPBIT;
		SetCommState(comHandle,&com_dcb);

		SetCommMask(comHandle,0);
		SetCommMask(comHandle,EV_RXCHAR);

		EscapeCommFunction(comHandle, CLRBREAK);
		EscapeCommFunction(comHandle, SETDTR);
		EscapeCommFunction(comHandle, SETRTS);
	}
	return 0;
}

/*********************************************************************
 *
 *********************************************************************
 */

void RS_exit(void)
{
	CloseHandle(ovlwr_hEvent);
	CloseHandle(ovlrd_hEvent);
	CloseHandle(comHandle);
}
/*********************************************************************
 *	�G�R�[�o�b�N�E�T�[�o�[.
 *********************************************************************
 *	CTRL+A �ŒE�o����.
 *
 */
void RS_echohost(char *port_no,int baudrate)
{
	int c;
	unsigned char buf[16];
	RS_init(port_no,baudrate);			// 'COMx:' ���I�[�v������.
	printf("Entering EchobackMode: Escape=^%c\n", '@' +	KEY_ESCAPE_CH );

	while(1) {
		c = RS_keyInput();if(c == KEY_ESCAPE_CH) break;	//�E�o.
		if(	RS_checkdata() ) {
			RS_getdata(buf,1);
			c = buf[0];
			RS_putc(c);
			putchar(c);
			if(c == '\r') {
				c = '\n';
				RS_putc(c);
				putchar(c);
			}
		}
	}
	RS_exit();
}
/*********************************************************************
 *
 *********************************************************************
 */
void H8_stage1_00(void)
{
}
void H8_stage2_AA(void)
{
}
void H8_stage3_SIZE(void)
{
}
void H8_stage4_BOOTCODE(void)
{
}
void H8_stage5_FLASH(void)
{
}

/*********************************************************************
 *	
 *********************************************************************
 *	CTRL+A �ŒE�o����.
 *
 */
void RS_emulate(char *port_no,int baudrate)
{
	RS_init(port_no,baudrate);			// 'COMx:' ���I�[�v������.

	printf("Entering EmulateMode: Escape=^%c\n", '@' +	KEY_ESCAPE_CH );

	H8_stage1_00();
	H8_stage2_AA();
	H8_stage3_SIZE();
	H8_stage4_BOOTCODE();
	H8_stage5_FLASH();

	RS_exit();
}
/*********************************************************************
 *	
 *********************************************************************
 */
/*********************************************************************
 *	���M�f�[�^���Z�b�g���Ă`�u�q�ƒʐM����.
 *********************************************************************
 *	���ʂ�result_buf[8] �ɓ����.
 */
static int AVR_TxRx(int key_count,unsigned char *key_buffer,unsigned char *result_buf)
{
	RxBuf cmd;
	memset(&cmd,0,sizeof(RxBuf));
	memset(result_buf,0,8);

	cmd.bmRequestType = USB_TYPE_VENDOR | USB_RECIP_DEVICE |USB_ENDPOINT_IN;
	cmd.cmd   = key_count;
	cmd.adr   = key_buffer[0]|( key_buffer[1]<<8 );
	cmd.data0 = key_buffer[2];
	cmd.data1 = key_buffer[3];
	QueryAVR(usb_dev,&cmd,result_buf);

	return result_buf[0];
}
/*********************************************************************
 *	
 *********************************************************************
 *	CTRL+A �ŒE�o����.
 *
 */
void RS_usbhost(char *port_no,int baudrate)
{
	int c,rcnt;
	int key_count=0;
	int key_inhibit=0;
	unsigned char tbuf[16];
	unsigned char rbuf[16];
	static unsigned char key_buffer[16];
	if( UsbInit(0,0) == 0 ) return;	
	RS_init(port_no,baudrate);			// 'COMx:' ���I�[�v������.

	printf("Entering UsbHost Mode: Escape=^%c\n", '@' +	KEY_ESCAPE_CH );

	while(1) {
		//�G�X�P�[�v�L�[�E�o.
		c = RS_keyInput();if(c == KEY_ESCAPE_CH) break;

		//���M�����ۂ��ĂȂ���΁ARS232C���當�����󂯕t����.
		if(key_inhibit == 0) {
			key_count = RS_checkdata();
			if(	key_count > 0) {
				if(key_count >=4 ) key_count = 4;
				RS_getdata(tbuf,key_count);
				memcpy( key_buffer + (4-key_count),tbuf , key_count );
			}
		}
		
		//�`�u�q�ƌ�M����.
		rcnt = AVR_TxRx(key_count,key_buffer,rbuf);	

		//�`�u�q����͂���������RS232C���ɑ��M����.
		key_inhibit = rcnt & 0x80;					// TxBuffer FULL ?
		if(rcnt & 7) {
			RS_putdata(rbuf + 1 , rcnt & 7);		// AVR 7byte --> RS232c
		}
	}

	RS_exit();
	UsbExit();
}
/*********************************************************************
 *	
 *********************************************************************
 *	CTRL+A �ŒE�o����.
 *
 */
void RS_terminal(char *port_no,int baudrate)
{
	int c;
	unsigned char buf[16];
	RS_init(port_no,baudrate);			// 'COMx:' ���I�[�v������.
	printf("Entering TerminalMode: Escape=^%c\n", '@' +	KEY_ESCAPE_CH );
	signal(SIGINT,SIG_IGN);	// ^C �𖳌��ɂ���.

	while(1) {
		c = RS_keyInput();
		if(c) {
			if(c == KEY_ESCAPE_CH) break;	//�E�o.
			RS_putc(c);
		}
		if(	RS_checkdata() ) {
			RS_getdata(buf,1);
			putchar(buf[0]);
		}
	}
	signal(SIGINT,SIG_DFL);
	RS_exit();
}
/*********************************************************************
 *
 *********************************************************************
 */

