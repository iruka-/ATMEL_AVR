/**********************************************************************
 *	PS2 Keyboard Library : Sample Main
 **********************************************************************
 */
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <string.h>

#include "task.h"
#include "sound.h"
#include "ps2keyb.h"

uchar buffer[256];
uchar ptr=0;

void put_ch(uchar c)
{
	buffer[ptr++]=c;
}

void quit(void);

int	main(void)
{
	uchar key;

	kbd_init();
	sound_init();
	sound_beep(128);
	sei();

	while(ptr<16) {
		key=kbd_getchar();
		if(key) {
			put_ch(key);
			sound_beep(key);
		}
	}
	sound_beep(128);
	
	quit();
	return 0;
}

