#include <stdio.h>

#include "hidmon.h"


#define	NAME	"pinb"

int main()
{
	int i,adr;
	UsbInit("*");

	printf("%s(%x)\n","portb", PortAddress( "portb" ) );

	adr = PortAddress( NAME );
	printf("%s(%x)\n",NAME, adr );

	for(i=0;i<1000;i++) {
		printf("%s = 0x%02x\r",NAME,UsbPeek(adr,0) );
	}

	UsbExit();
	return 0;
}
