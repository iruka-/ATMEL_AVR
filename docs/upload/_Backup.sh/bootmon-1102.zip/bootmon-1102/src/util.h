
void	memdump(void *ptr,int len,int off);
int		UsbInit(int verbose,int enable_bulk);	
int		UsbExit(void);
void 	UsbBench(int cnt,int psize);
void	UsbDump(int adr,int arena,int size);
void 	UsbPoke(int adr,int arena,int data,int mask);
void 	UsbPoke_b(int adr,int arena,int bit,int mask);
int 	UsbPeek(int adr,int arena);
int 	UsbRead(int adr,int arena,uchar *buf,int size);
int 	UsbBootTarget(int adr,int boot);

