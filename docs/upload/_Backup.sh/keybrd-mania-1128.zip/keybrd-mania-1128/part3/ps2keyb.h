#ifndef _ps2keyb_h_
#define _ps2keyb_h_

void  kbd_init(void);
uchar kbd_getchar(void);

#endif	//_ps2keyb_h_
