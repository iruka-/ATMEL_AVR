#include <stdio.h>

#define	PROGMEM	

#include "scancodes.h"

int nor[128];
int sft[128];

void npr(char *buf,int i)
{
	if( (i>=0x20)&&(i<0x7e)&&(i!=0x27) ){
		sprintf(buf," '%c'",i);
	}else{
		sprintf(buf,"0x%02x",i);
	}
}

int init()
{
	int i=0;
	for(i=0;i<128;i++) nor[i]=sft[i]=0;
	int key,chr;
	int n=0;
	while(1) {
		key = unshifted[n][0];
		chr = unshifted[n][1];

		nor[key]=chr;

		key = shifted[n][0];
		chr = shifted[n][1];

		sft[key]=chr;

		if(key==0) break;
		n++;
	}
}

int main1()
{
	int i;
	char buf1[128];
	char buf2[128];

	for(i=0;i<128;i++) {
		npr(buf1,nor[i]);
		npr(buf2,sft[i]);

		printf("	%s,%s,	/* %02x */\n"
			,buf1,buf2,i
		);
	}
}


void spr(char *buf,int i)
{
	if(isalnum(i) ){
		sprintf(buf,"%c",toupper(i));
	}else{
		sprintf(buf,"%02x",i);
	}
}

void tpr(char *buf,int i)
{
	if( (i>=0x20)&&(i<0x7e)&&(i!=0x27) ){
		sprintf(buf,"%c",i);
	}else{
		sprintf(buf,"%02x",i);
	}
}

int main2()
{
	char buf1[128];
	char buf2[128];

	int i=0;
	for(i=0;i<128;i++) nor[i]=sft[i]=0;
	int key,chr;
	int n=0;
	while(1) {
		key = unshifted[n][0];
		chr = unshifted[n][1];

		nor[key]=chr;

		spr(buf1,chr);
		tpr(buf2,chr);
		printf("#define SKEY_%-14s	0x%02x	/* %s */\n"
			,buf1,key,buf2
		);

		if(key==0) break;
		n++;
	}
}

int main()
{
	init();
//	main1();
	main2();
}

#if	0
/****************************************************************************
 *
 *      Direct keyboard scan codes
 *
 ****************************************************************************/
#define DK_ESCAPE          0x01
#define DK_1               0x02
#define DK_2               0x03
#define DK_3               0x04
#define DK_4               0x05
#define DK_5               0x06
#define DK_6               0x07
#define DK_7               0x08
#define DK_8               0x09
#define DK_9               0x0A
#define DK_0               0x0B
#define DK_MINUS           0x0C    /* - on main keyboard */
#define DK_EQUALS          0x0D
#define DK_BACK            0x0E    /* backspace */
#define DK_TAB             0x0F
#define DK_Q               0x10
#define DK_W               0x11
#define DK_E               0x12
#define DK_R               0x13
#define DK_T               0x14
#define DK_Y               0x15
#define DK_U               0x16
#define DK_I               0x17
#define DK_O               0x18
#define DK_P               0x19
#define DK_LBRACKET        0x1A
#define DK_RBRACKET        0x1B
#define DK_RETURN          0x1C    /* Enter on main keyboard */
#define DK_LCONTROL        0x1D
#define DK_A               0x1E
#define DK_S               0x1F
#define DK_D               0x20
#define DK_F               0x21
#define DK_G               0x22
#define DK_H               0x23
#define DK_J               0x24
#define DK_K               0x25
#define DK_L               0x26
#define DK_SEMICOLON       0x27
#define DK_APOSTROPHE      0x28
#define DK_GRAVE           0x29    /* accent grave */
#define DK_LSHIFT          0x2A
#define DK_BACKSLASH       0x2B
#define DK_Z               0x2C
#define DK_X               0x2D
#define DK_C               0x2E
#define DK_V               0x2F
#define DK_B               0x30
#define DK_N               0x31
#define DK_M               0x32
#define DK_COMMA           0x33
#define DK_PERIOD          0x34    /* . on main keyboard */
#define DK_SLASH           0x35    /* / on main keyboard */
#define DK_RSHIFT          0x36
#define DK_MULTIPLY        0x37    /* * on numeric keypad */
#define DK_LMENU           0x38    /* left Alt */
#define DK_SPACE           0x39
#define DK_CAPITAL         0x3A
#define DK_F1              0x3B
#define DK_F2              0x3C
#define DK_F3              0x3D
#define DK_F4              0x3E
#define DK_F5              0x3F
#define DK_F6              0x40
#define DK_F7              0x41
#define DK_F8              0x42
#define DK_F9              0x43
#define DK_F10             0x44
#define DK_NUMLOCK         0x45
#define DK_SCROLL          0x46    /* Scroll Lock */
#define DK_NUMPAD7         0x47
#define DK_NUMPAD8         0x48
#define DK_NUMPAD9         0x49
#define DK_SUBTRACT        0x4A    /* - on numeric keypad */
#define DK_NUMPAD4         0x4B
#define DK_NUMPAD5         0x4C
#define DK_NUMPAD6         0x4D
#define DK_ADD             0x4E    /* + on numeric keypad */
#define DK_NUMPAD1         0x4F
#define DK_NUMPAD2         0x50
#define DK_NUMPAD3         0x51
#define DK_NUMPAD0         0x52
#define DK_DECIMAL         0x53    /* . on numeric keypad */
#define DK_OEM_102         0x56    /* <> or \| on RT 102-key keyboard (Non-U.S.) */
#define DK_F11             0x57
#define DK_F12             0x58
#define DK_F13             0x64    /*                     (NEC PC98) */
#define DK_F14             0x65    /*                     (NEC PC98) */
#define DK_F15             0x66    /*                     (NEC PC98) */
#define DK_KANA            0x70    /* (Japanese keyboard)            */
#define DK_ABNT_C1         0x73    /* /? on Brazilian keyboard */
#define DK_CONVERT         0x79    /* (Japanese keyboard)            */
#define DK_NOCONVERT       0x7B    /* (Japanese keyboard)            */
#define DK_YEN             0x7D    /* (Japanese keyboard)            */
#define DK_ABNT_C2         0x7E    /* Numpad . on Brazilian keyboard */
#define DK_NUMPADEQUALS    0x8D    /* = on numeric keypad (NEC PC98) */
#define DK_PREVTRACK       0x90    /* Previous Track (DIK_CIRCUMFLEX on Japanese keyboard) */
#define DK_AT              0x91    /*                     (NEC PC98) */
#define DK_COLON           0x92    /*                     (NEC PC98) */
#define DK_UNDERLINE       0x93    /*                     (NEC PC98) */
#define DK_KANJI           0x94    /* (Japanese keyboard)            */
#define DK_STOP            0x95    /*                     (NEC PC98) */
#define DK_AX              0x96    /*                     (Japan AX) */
#define DK_UNLABELED       0x97    /*                        (J3100) */
#define DK_NEXTTRACK       0x99    /* Next Track */
#define DK_NUMPADENTER     0x9C    /* Enter on numeric keypad */
#define DK_RCONTROL        0x9D
#define DK_MUTE            0xA0    /* Mute */
#define DK_CALCULATOR      0xA1    /* Calculator */
#define DK_PLAYPAUSE       0xA2    /* Play / Pause */
#define DK_MEDIASTOP       0xA4    /* Media Stop */
#define DK_VOLUMEDOWN      0xAE    /* Volume - */
#define DK_VOLUMEUP        0xB0    /* Volume + */
#define DK_WEBHOME         0xB2    /* Web home */
#define DK_NUMPADCOMMA     0xB3    /* , on numeric keypad (NEC PC98) */
#define DK_DIVIDE          0xB5    /* / on numeric keypad */
#define DK_SYSRQ           0xB7
#define DK_RMENU           0xB8    /* right Alt */
#define DK_PAUSE           0xC5    /* Pause */
#define DK_HOME            0xC7    /* Home on arrow keypad */
#define DK_UP              0xC8    /* UpArrow on arrow keypad */
#define DK_PRIOR           0xC9    /* PgUp on arrow keypad */
#define DK_LEFT            0xCB    /* LeftArrow on arrow keypad */
#define DK_RIGHT           0xCD    /* RightArrow on arrow keypad */
#define DK_END             0xCF    /* End on arrow keypad */
#define DK_DOWN            0xD0    /* DownArrow on arrow keypad */
#define DK_NEXT            0xD1    /* PgDn on arrow keypad */
#define DK_INSERT          0xD2    /* Insert on arrow keypad */
#define DK_DELETE          0xD3    /* Delete on arrow keypad */
#define DK_LWIN            0xDB    /* Left Windows key */
#define DK_RWIN            0xDC    /* Right Windows key */
#define DK_APPS            0xDD    /* AppMenu key */
#define DK_POWER           0xDE    /* System Power */
#define DK_SLEEP           0xDF    /* System Sleep */
#define DK_WAKE            0xE3    /* System Wake */
#define DK_WEBSEARCH       0xE5    /* Web Search */
#define DK_WEBFAVORITES    0xE6    /* Web Favorites */
#define DK_WEBREFRESH      0xE7    /* Web Refresh */
#define DK_WEBSTOP         0xE8    /* Web Stop */
#define DK_WEBFORWARD      0xE9    /* Web Forward */
#define DK_WEBBACK         0xEA    /* Web Back */
#define DK_MYCOMPUTER      0xEB    /* My Computer */
#define DK_MAIL            0xEC    /* Mail */
#define DK_MEDIASELECT     0xED    /* Media Select */

/*
 *  Alternate names for keys, to facilitate transition from DOS.
 */
#define DK_BACKSPACE       DK_BACK            /* backspace */
#define DK_NUMPADSTAR      DK_MULTIPLY        /* * on numeric keypad */
#define DK_LALT            DK_LMENU           /* left Alt */
#define DK_CAPSLOCK        DK_CAPITAL         /* CapsLock */
#define DK_NUMPADMINUS     DK_SUBTRACT        /* - on numeric keypad */
#define DK_NUMPADPLUS      DK_ADD             /* + on numeric keypad */
#define DK_NUMPADPERIOD    DK_DECIMAL         /* . on numeric keypad */
#define DK_NUMPADSLASH     DK_DIVIDE          /* / on numeric keypad */
#define DK_RALT            DK_RMENU           /* right Alt */
#define DK_UPARROW         DK_UP              /* UpArrow on arrow keypad */
#define DK_PGUP            DK_PRIOR           /* PgUp on arrow keypad */
#define DK_LEFTARROW       DK_LEFT            /* LeftArrow on arrow keypad */
#define DK_RIGHTARROW      DK_RIGHT           /* RightArrow on arrow keypad */
#define DK_DOWNARROW       DK_DOWN            /* DownArrow on arrow keypad */
#define DK_PGDN            DK_NEXT            /* PgDn on arrow keypad */

#endif
