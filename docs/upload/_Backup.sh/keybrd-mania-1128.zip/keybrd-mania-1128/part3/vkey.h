//
//	���̃X�L�����R�[�h�́A101-AT Keyboard�����肵�Ă���.
//

#define SKEY_ESCAPE       	0x76	/* ESCAPE */
#define SKEY_BS            	0x66	/* BACKSPACE */
#define SKEY_TAB          	0x0d	/* TAB */
#define SKEY_RETURN       	0x5a	/* ENTER */
#define SKEY_SPACE        	0x29	/* SPACE */
#define SKEY_COMMA	     	0x41	/* , */
#define SKEY_PERIOD        	0x49	/* . */
#define SKEY_SLASH          0x4a	/* / */
#define SKEY_SEMICOLON     	0x4c	/* SEMICOLON */
#define SKEY_MINUS         	0x4e	/* + */
#define SKEY_BACKSLASH      0x5d	/* \ */
#define SKEY_APOSTROPHE   	0x52	/* APOSTROPHE */
#define SKEY_3c            	0x61	/* < */
#define SKEY_EQUAL	    	0x55	/* = */
#define SKEY_GRAVE		   	0x0e	/* ~ */
#define SKEY_LBRACKET     	0x54	/* e5 */
#define SKEY_RBRACKET      	0x5b	/* a8 */

#define SKEY_LSHIFT      	0x12	/* [SHIFT] */
#define SKEY_RSHIFT      	0x59	/* [SHIFT] */
#define SKEY_CTRL 	     	0x14	/* [CTRL] */
#define SKEY_ALT 	     	0x11	/* [ALT] */
#define SKEY_CAPS 	     	0x58	/* [CAPS] */


#define SKEY_NUMPAD0        0x70	/* 0 */
#define SKEY_NUMPAD1        0x69	/* 1 */
#define SKEY_NUMPAD2        0x72	/* 2 */
#define SKEY_NUMPAD3        0x7a	/* 3 */
#define SKEY_NUMPAD4        0x6b	/* 4 */
#define SKEY_NUMPAD5        0x73	/* 5 */
#define SKEY_NUMPAD6        0x74	/* 6 */
#define SKEY_NUMPAD7        0x6c	/* 7 */
#define SKEY_NUMPAD8        0x75	/* 8 */
#define SKEY_NUMPAD9        0x7d	/* 9 */
#define SKEY_NUMPADMINUS    0x7b	/* - */
#define SKEY_NUMPADCOMMA    0x71	/* , */
#define SKEY_NUMPADPLUS     0x79	/* + */
#define SKEY_NUMPADSTAR    	0x7c	/* * */

#define SKEY_0             	0x45	/* 0 */
#define SKEY_1             	0x16	/* 1 */
#define SKEY_2             	0x1e	/* 2 */
#define SKEY_3             	0x26	/* 3 */
#define SKEY_4             	0x25	/* 4 */
#define SKEY_5             	0x2e	/* 5 */
#define SKEY_6             	0x36	/* 6 */
#define SKEY_7             	0x3d	/* 7 */
#define SKEY_8             	0x3e	/* 8 */
#define SKEY_9             	0x46	/* 9 */

#define SKEY_A             	0x1c	/* a */
#define SKEY_B             	0x32	/* b */
#define SKEY_C             	0x21	/* c */
#define SKEY_D             	0x23	/* d */
#define SKEY_E             	0x24	/* e */
#define SKEY_F             	0x2b	/* f */
#define SKEY_G             	0x34	/* g */
#define SKEY_H             	0x33	/* h */
#define SKEY_I             	0x43	/* i */
#define SKEY_J             	0x3b	/* j */
#define SKEY_K             	0x42	/* k */
#define SKEY_L             	0x4b	/* l */
#define SKEY_M             	0x3a	/* m */
#define SKEY_N             	0x31	/* n */
#define SKEY_O             	0x44	/* o */
#define SKEY_P             	0x4d	/* p */
#define SKEY_Q             	0x15	/* q */
#define SKEY_R             	0x2d	/* r */
#define SKEY_S             	0x1b	/* s */
#define SKEY_T             	0x2c	/* t */
#define SKEY_U             	0x3c	/* u */
#define SKEY_V             	0x2a	/* v */
#define SKEY_W             	0x1d	/* w */
#define SKEY_X             	0x22	/* x */
#define SKEY_Y             	0x35	/* y */
#define SKEY_Z             	0x1a	/* z */
