/**********************************************************************
 *	PS2 Keyboard Library : Sample Main
 **********************************************************************
 */
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <string.h>

#include "task.h"
#include "sound.h"
#include "ps2keyb.h"


uchar buffer[256];
uchar ptr=2;

void buf_init(void)
{
	uchar i;
	for(i=0;i<250;i++) buffer[i]=0xff;
}

void put_ch(uchar c)
{
	buffer[ptr++]=c;
}

void quit(void);

int	main(void)
{
	uchar key;

	kbd_init();
	sound_init();
	sound_beep(128);
	buf_init();
	sei();

	while(ptr<20) {
#if	1
		key=kbd_getchar();
#else
		key=kbd_getcode();
#endif
		if(key) {
			put_ch(key);
			sound_beep(key);
		}
	}
	sound_beep(128);
	
	quit();
	return 0;
}

