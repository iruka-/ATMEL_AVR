□　Linux用のhidspxについて

　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　2009年1月27日

　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　千秋広幸

□　これは何か

 これは、Linux用のHIDaspx用の書き込みツール(hidspx)のソースです。瓶詰堂さんが
公開されて いるソースを元に、Linux用に編成しました。

□　インストール方法
make
sudo make install

でインストールできます。インストール先は、/usr/local/bin となっています。
変更したい場合は、Makefileを修正してください。hidspxのコマンド名も変更可能
です。HIDSPXの定義に注目してください。

fuse.txtは現在はUTF8となっていますが、文字コードが異なる場合には、利用している
環境に合わせて、コード変換を行ってください。コード変換には、iconvやnkfコマンドが
利用できます。

□　特徴

 Windows版のhidspxに似た使い方が可能ですが、初期のソースを採用している関係で、
Windows版 よりも機能は限られます。しかし、基本的な機能は備えており、AVRマイコ
ンのプログラマとして利用する限り、困ることはないと思います。

□　改良点
 HIDSPXという環境変数に /usr/local/bin （あるいは hidspx.ini, fuse.txt の設置
場所）を 指定すれば、そのファイルを参照し、各種の設定を行うことができます。

□　HIDaspxのファームウェアについて
 2008年11月27日〜2009年1月21日までのファームウェアでは、このソフトウェアは機能
しません。 最新版のソースでお使いください。

□　確認済みの点（改良が望まれる点）

* hidspxを接続する度に、以下のメッセージがlogに出力されます。
実害はありませんので、このままお使いください。なお、これが気になる方は、HIDaspx
のファームウェアをmain_libusb.hexに変更し、-phu を指定すれば1 のメッセージは
回避できますが、この変更を実施するとWindowsでは使えなくなります。できるだけ
「main-12.hex」ファームでご利用ください。

※ 2009-0123版では、実験的に-phu というHIDaspxのlibusb対応オプションを追加しました。

usb 1-2: configuration #1 chosen from 1 choice
/build/buildd/linux-2.6.24/drivers/hid/usbhid/hid-core.c: \
　couldn't find an input interrupt endpoint

□　お願い
 独自の改良を行われた方は、ぜひご一報ください。

□　改訂履歴

2009-0122 初版リリース
2009-0123 make install 時の権限を修正、libusbモードへの対応を追加
2009-0124 以下のメッセージ出力を抑止（谷岡さんの作成したパッチを元にしています）
　「usb 1-2: usbfs: process 9811 (hidspx) did not claim interface 0 before use」

2009-0126 Linux版でも、-ri, -rd, -rF, -rl, --new-mode, --show-options を追加
 利用するWebブラウザは、ターミナルからの使用を想定し、URLを標準出力に
 表示します。w3m, lynx などに渡すことでブラウザで表示可能です。
 gnome端末を利用している場合には、右クリックで「URLを開く」を選ぶことで、
 firefoxなどを利用することができます。

2009-0127 特権モードでの実行を必要な部分に限定する修正を実施

