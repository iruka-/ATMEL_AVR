/*----------------------------------------------------------------------------
 *      U S B  -  K e r n e l
 *----------------------------------------------------------------------------
 * Name:    usbuser.c
 *      Purpose: USB Custom User Module
 * Version: V1.20
 *----------------------------------------------------------------------------
 *      This software is supplied "AS IS" without any warranties, express,
 *      implied or statutory, including but not limited to the implied
 *      warranties of fitness for purpose, satisfactory quality and
 *      noninfringement. Keil extends you a royalty-free right to reproduce
 *      and distribute executable files created using this software for use
 *      on NXP Semiconductors LPC microcontroller devices only. Nothing else
 *      gives you the right to use this software.
 *
 * Copyright (c) 2009 Keil - An ARM Company. All rights reserved.
 *----------------------------------------------------------------------------
 *
void USB_Power_Event (uint32_t  power);
void USB_Reset_Event (void);
void USB_Suspend_Event (void);
void USB_Resume_Event (void);
void USB_WakeUp_Event (void);
void USB_SOF_Event (void);
void USB_Error_Event (uint32_t error);
void USB_Configure_Event (void);
void USB_Interface_Event (void);
void USB_Feature_Event (void);
void USB_EndPoint1 (uint32_t event);
void USB_EndPoint2 (uint32_t event);
void USB_EndPoint3 (uint32_t event);
 */

#include <string.h>
#include "type.h"
#include "utype.h"

#include "usb.h"
#include "usbcfg.h"
#include "usbhw.h"
#include "usbcore.h"
#include "usbuser.h"

#include "demo.h"
#include "monit.h"

/********************************************************************
 *	
 ********************************************************************
 */

void led_set(int f);
void ProcessIO(void);
void HID_OutReport(void);

extern	Packet PacketFromPC;			//���̓p�P�b�g 64byte
//extern	Packet PacketToPC;				//�o�̓p�P�b�g 64byte

/********************************************************************
 *	
 ********************************************************************
 */

/* CDC Data In/Out Endpoint Address */
#define HID_INTR_IN       0x81
#define HID_INTR_OUT      0x01

/*
 *  USB Power Event Callback
 *   Called automatically on USB Power Event
 *    Parameter:       power: On(TRUE)/Off(FALSE)
 */

#if USB_POWER_EVENT
void USB_Power_Event (uint32_t  power)
{
}
#endif


/*
 *  USB Reset Event Callback
 *   Called automatically on USB Reset Event
 */

#if USB_RESET_EVENT
void USB_Reset_Event (void)
{
	USB_ResetCore();
}
#endif


/*
 *  USB Suspend Event Callback
 *   Called automatically on USB Suspend Event
 */

#if USB_SUSPEND_EVENT
void USB_Suspend_Event (void)
{
}
#endif


/*
 *  USB Resume Event Callback
 *   Called automatically on USB Resume Event
 */

#if USB_RESUME_EVENT
void USB_Resume_Event (void)
{
}
#endif


/*
 *  USB Remote Wakeup Event Callback
 *   Called automatically on USB Remote Wakeup Event
 */

#if USB_WAKEUP_EVENT
void USB_WakeUp_Event (void)
{
}
#endif


/*
 *  USB Start of Frame Event Callback
 *   Called automatically on USB Start of Frame Event
 */

#if USB_SOF_EVENT
void USB_SOF_Event (void)
{
}
#endif


/*
 *  USB Error Event Callback
 *   Called automatically on USB Error Event
 *    Parameter:       error: Error Code
 */

#if USB_ERROR_EVENT
void USB_Error_Event (uint32_t error)
{
}
#endif


/*
 *  USB Set Configuration Event Callback
 *   Called automatically on USB Set Configuration Request
 */

#if USB_CONFIGURE_EVENT
void USB_Configure_Event (void)
{
	if (USB_Configuration) {                  /* Check if USB is configured */
		GetInReport();
		USB_WriteEP(0x81, &InReport, sizeof(InReport));
	}
}
#endif


/*
 *  USB Set Interface Event Callback
 *   Called automatically on USB Set Interface Request
 */

#if USB_INTERFACE_EVENT
void USB_Interface_Event (void)
{
}
#endif


/*
 *  USB Set/Clear Feature Event Callback
 *   Called automatically on USB Set/Clear Feature Request
 */

#if USB_FEATURE_EVENT
void USB_Feature_Event (void)
{
}
#endif


#define P_EP(n) ((USB_EP_EVENT & (1 << (n))) ? USB_EndPoint##n : NULL)

/* USB Endpoint Events Callback Pointers */
void (* const USB_P_EP[USB_LOGIC_EP_NUM]) (uint32_t event) = {
	P_EP(0),
	P_EP(1),
	P_EP(2),
	P_EP(3),
};


/********************************************************************
 *	
 ********************************************************************
 */
/*
 *  USB Endpoint 1 Event Callback
 *   Called automatically on USB Endpoint 1 Event
 *    Parameter:       event
 */
void USB_EndPoint1 (uint32_t event)
{
	switch (event) {
	case USB_EVT_OUT:	/* data received from Host */
		HID_OutReport();
		break;
//	case USB_EVT_IN:	/* data expected from Host */
//		HID_InReport();
//		break;
	}
}


/*
 *  USB Endpoint 2 Event Callback
 *   Called automatically on USB Endpoint 2 Event
 *    Parameter:       event
 */

void USB_EndPoint2 (uint32_t event)
{
	event = event;		/* get rid of warning */
}


/*
 *  USB Endpoint 3 Event Callback
 *   Called automatically on USB Endpoint 3 Event
 *    Parameter:       event
 */

void USB_EndPoint3 (uint32_t event)
{
	event = event;
}


/********************************************************************
 *	MONITOR INTERFACE
 ********************************************************************
 */
/*----------------------------------------------------------------------------
  CDC_BulkOut call on DataOut Request
  Parameters:   none
  Return Value: none
 *---------------------------------------------------------------------------*/
void HID_OutReport(void)
{
	// HostPC����f�o�C�X�ւ̏�������.
	int numBytesRead;

	// get data from USB into intermediate buffer
	numBytesRead = USB_ReadEP(HID_INTR_OUT, PacketFromPC.raw);
//	if(numBytesRead) 
	{
		ProcessIO();
	}
}

void UserToPMABufferCopy(uchar *src,uchar *dst,int size)
{
	// �f�o�C�X���� HostPC �ւ̃f�[�^�̕ԋp.
	USB_WriteEP(HID_INTR_IN, src , size);
	(void)dst;
}


/********************************************************************
 *	D U M M Y
 ********************************************************************
 */
void usbModuleDisable(void)
{
#if	0
	PowerOff();					// Disconnect USB.
	USB_Cable_Config(DISABLE);
#endif
}

uchar *GetEPTxAddr(int n)
{
	return 0;
}

int USB_SIL_Read(int bEpAddr, uchar *p)
{
	(void)bEpAddr;
	(void)p;
	return 0;
}

void SetEPTxValid(int ep)
{}
void SetEPRxStatus(int ep,int st)
{}

void GetInReport ()		{}
void SetOutReport ()	{}

/********************************************************************
 *	
 ********************************************************************
 */

