/********************************************************************
 *	���C������
 ********************************************************************
 */
#include <string.h>
//#include "lpc13xx.h"                        /* LPC13xx definitions */
#include "stm32f10x.h"

#include "usb.h"
#include "usbcfg.h"
#include "usbhw.h"
#include "usbcore.h"
#include "gpio.h"
#include "demo.h"
#include "config.h"

#include "monit.h"


/********************************************************************
 *	
 ********************************************************************
 */
#define     EN_TIMER32_1    (1<<10)
#define     EN_IOCON        (1<<16)
#define     EN_USBREG       (1<<14)

#define	led_on()	led_set(1)
#define	led_off()	led_set(0)

void led_set(int f)
{
	GPIOSetValue(OUTPUT0_PORT, OUTPUT0_BIT, f);
}

/********************************************************************
 *
 ********************************************************************
 */
void led_blink(int interval)
{
	static int led_cnt=0;
	int mask = 1<<interval;

	led_cnt++;
	if(led_cnt & mask) {
		led_on();
	} else {
		led_off();
	}
}
/********************************************************************
 *	
 ********************************************************************
 */
int main (void)
{
	/* Initialize output port pins */
	GPIOSetDir( OUTPUT0_PORT, OUTPUT0_BIT, 1 );
	led_set(1);	// on
	Init_Monitor();


#if	APPLICATION_MODE
	SCB->VTOR = _ROMADRS;	// Vector Table Offset Reg.
#endif

	/* Enable Timer32_1, IOCON, and USB blocks */
	LPC_SYSCON->SYSAHBCLKCTRL |= (EN_TIMER32_1 | EN_IOCON | EN_USBREG);

	/* PLL and pin init function */
	USBIOClkConfig();

	/* USB Initialization */
	USB_Init();

	/* USB Connect (if SoftConnect switch implemented) */
	USB_Connect(1);

	while(1) {
		USBtask();
#if	APPLICATION_MODE
		wait_ms(1);
		led_blink(8);
#endif
	}

//	while(1) {
//		__WFI();
//	}
}

