
//#define	DLL_int	__declspec(dllexport) int __cdecl //__stdcall
#define	DLL_int	__declspec(dllexport) int __stdcall

DLL_int	UsbInit(const char *string);
DLL_int	UsbExit(void);
DLL_int	UsbPoke(int adr,int arena,int data,int mask);
DLL_int	UsbPeek(int adr,int arena);
DLL_int	PortAddress(const char *string);

DLL_int UsbSetPoll(int adr,int arena);
DLL_int	UsbPoll(void);


