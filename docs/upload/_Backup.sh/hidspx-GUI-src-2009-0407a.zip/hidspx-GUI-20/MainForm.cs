/* MainForm.cs */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;


namespace hidspxGUI {
    
    public partial class MainForm : Form {

        private void SetFilename(string fullpath)
        {
            string ext;

#if false
            MessageBox.Show(fullpath, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
#endif
            if (File.Exists(fullpath))
            {
                ext = System.IO.Path.GetExtension(fullpath);

                if (ext.ToLower() == ".hex")
                {
                    FlashFileTextBox.Text = fullpath;
                }
                else if (ext.ToLower() == ".eep")
                {
                    EEPROMFileTextBox.Text = fullpath;
                }
                else if (ext.ToLower() == ".exe")
                {
                    if (System.IO.Path.GetFileName(fullpath).ToLower() == "hidspx.exe")
                    {
                        hidspxTextBox.Text = fullpath;
                    }
                }
            }
        }

        private void MainForm_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                // ドラッグ中のファイルやディレクトリの取得
                string[] drags = (string[])e.Data.GetData(DataFormats.FileDrop);

                foreach (string d in drags)
                {
                    if (!System.IO.File.Exists(d))
                    {
                        // ファイル以外であればイベント・ハンドラを抜ける
                        return;
                    }
                }
                e.Effect = DragDropEffects.Copy;
            }
        }

        private void MainForm_DragDrop(object sender, DragEventArgs e)
        {
            // ドラッグ＆ドロップされたファイル
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            for (int i = 0; i < files.Length; i++)
            {
                SetFilename(files[i]);
            }
        }

        /// <summary>
        /// hidspx.exe ファイル選択ボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void hidspxButton_Click(object sender, EventArgs e) {

            OpenFileDialog.CheckFileExists = true;
            OpenFileDialog.Filter = "hidspx.exe|*spx.exe";
            OpenFileDialog.FileName = "";
            OpenFileDialog.Title = "Select hidspx.exe File";
            OpenFileDialog.ShowDialog();
            if (OpenFileDialog.FileName.Length > 0) {
                hidspxTextBox.Text = OpenFileDialog.FileName;
                hidspxInfo();  // コンボボックス設定
            }
        }

        /// <summary>
        /// チップ消去ボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChipEraseButton_Click(object sender, EventArgs e) {

            if (MessageBox.Show("All the settings and data in the device are deleted. Is it good ?", this.Text,
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
                == DialogResult.Yes) {
                ExecCommand("-e", 50, false);
            }
        }

        /// <summary>
        /// CMD prompt 起動ボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TerminalButton_Click(object sender, EventArgs e) {
            string dir;

            if (FlashFileTextBox.Text.Length != 0)
            {
                dir = Path.GetDirectoryName(FlashFileTextBox.Text);
            }
            else if (EEPROMFileTextBox.Text.Length != 0)
            {
                dir = Path.GetDirectoryName(EEPROMFileTextBox.Text);
            }
            else
            {
                MessageBox.Show("Select Hex File", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                hidspxButton.Focus();
                return;
            }

            System.Diagnostics.Process prc = null;
            System.Diagnostics.ProcessStartInfo psi = new System.Diagnostics.ProcessStartInfo();
            psi.FileName = System.Environment.GetEnvironmentVariable("comspec");
            psi.Arguments = " /f:on /K \"cd /d" + dir + "\" ";
            prc = System.Diagnostics.Process.Start(psi);
            prc.WaitForExit();
        }

        /// <summary>
        /// ヒューズ読み込みボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ReadFuseButton_Click(object sender, EventArgs e) {
            string fuse;
            string temp;

            HFuseTextBox.Text = "";
            LFuseTextBox.Text = "";
            EFuseTextBox.Text = "";

            fuse = "_fuse_.txt";
            temp = Environment.GetEnvironmentVariable("temp") + "\\";
            File.Delete(temp + fuse);
            /*
            ---- 「-rl」では、以下の形式の一行でFUSE情報を得ることができる ----
             device  Low:MSK   Hi:MSK  EXT:MSK LOCK
            attiny26 E4:FF     F7:17   --:--     FF
             [0]     [1][2]    [3][4]  [5][6]    [7]
             */

            if (ExecCommand("-d10 -rl -o" + temp + fuse, 0, false) == 0)
            {
                // fuse読み込み
                if (File.Exists(temp + fuse))
                {
                    char[] delimiterChars = { ' ', ':' };
                    string data;
                    StreamReader sr = new StreamReader(temp + fuse);
                    data = sr.ReadLine();
                    sr.Close();
                    DeviceTextBox.Text = "";
                    LFuseTextBox.Text = "";
                    HFuseTextBox.Text = "";
                    EFuseTextBox.Text = "";
                    LockBitTextBox.Text = "";
                    if (data.Length > 10)
                    {
                        string[] fuses = data.Split(delimiterChars);
                        if (fuses[0] != "--")
                        {
                            DeviceTextBox.Text = fuses[0];
                        }

                        if (fuses[1] != "--")
                        {
                            LFuseTextBox.Text = fuses[1];
                        }

                        if (fuses[3] != "--")
                        {
                            HFuseTextBox.Text = fuses[3];
                        }

                        if (fuses[5] != "--")
                        {
                            EFuseTextBox.Text = fuses[5];
                        }

                        if (fuses[7] != "--")
                        {
                            LockBitTextBox.Text = fuses[7];
                        }
                    }

                }

                File.Delete(temp + fuse);
            }
        }

        /// <summary>
        /// ヒューズ書き込みボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WriteFuseButton_Click(object sender, EventArgs e) {

            Regex reg = new Regex("^[0-9A-Fa-f]{2}$");

            if ((HFuseTextBox.Text.Length > 0) && (reg.Match(HFuseTextBox.Text).Success == false)) {
                MessageBox.Show("Please Set hfuse by the hexadecimal number of 2 charactors. ",
                    this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                HFuseTextBox.Focus();
                return;
            }
            if ((LFuseTextBox.Text.Length > 0) && (reg.Match(LFuseTextBox.Text).Success == false)) {
                MessageBox.Show("Please Set lfuse by the hexadecimal number of 2 charactors. ",
                    this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                LFuseTextBox.Focus();
                return;
            }
            if ((EFuseTextBox.Text.Length > 0) && (reg.Match(EFuseTextBox.Text).Success == false)) {
                MessageBox.Show("Please Set efuse by the hexadecimal number of 2 charactors. ",
                    this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                EFuseTextBox.Focus();
                return;
            }
            if ((HFuseTextBox.Text.Length == 0) && (LFuseTextBox.Text.Length == 0) && (EFuseTextBox.Text.Length == 0)) {
                MessageBox.Show("Please Set hfuse, lfuse or efuse.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            if (MessageBox.Show("Fuses is ReWritten. Is it good ?",
                this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
                != DialogResult.Yes)
            {
                return;
            }

            string arg = "-d10";
            if (LFuseTextBox.Text.Length > 0)
            {
                arg += " -fL0x" + LFuseTextBox.Text;
            }
            if (HFuseTextBox.Text.Length > 0)
            {
                arg += " -fH0x" + HFuseTextBox.Text;
            }
            if (EFuseTextBox.Text.Length > 0) {
                arg += " -fX0x" + EFuseTextBox.Text;
            }
#if true
            MessageBox.Show(arg, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            ExecCommand(arg, 0, true);
#endif
            MessageBox.Show("Wrote FUSE byte(s).", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>
        /// ロックビット書き込みボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WriteLockBitButton_Click(object sender, EventArgs e) {

            Regex reg = new Regex("^[0-9A-Fa-f]{2}$");

            if (LockBitTextBox.Text.Length == 0) {
                MessageBox.Show("Please Set Lock bit.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            if (reg.Match(LockBitTextBox.Text).Success == false) {
                MessageBox.Show("Please Set Lock bit by the hexadecimal number of 2 charactors. ",
                    this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                LockBitTextBox.Focus();
                return;
            }

            if (MessageBox.Show("Lock bit is ReWritten. Is it good ?",
                this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
                != DialogResult.Yes)
            {
                return;
            }

#if true
            MessageBox.Show("-l0x" + LockBitTextBox.Text, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            ExecCommand("-l0x" + LockBitTextBox.Text, 0, false);
#endif
        }

        /// <summary>
        /// Flash ファイル選択ボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FlashFileButton_Click(object sender, EventArgs e) {

            OpenFileDialog.CheckFileExists = false;
            OpenFileDialog.AddExtension = true;
            OpenFileDialog.DefaultExt = "hex";
            OpenFileDialog.Filter = "Intel Hex File(*.hex)|*.hex|All File(*.*)|*.*";
            OpenFileDialog.FileName = "";
            OpenFileDialog.ShowDialog();
            if (OpenFileDialog.FileName.Length > 0) {
                FlashFileTextBox.Text = OpenFileDialog.FileName;
            }
        }

        /// <summary>
        /// Flash 読み込みボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ReadFlashButton_Click(object sender, EventArgs e) {

            SaveFileDialog.AddExtension = true;
            SaveFileDialog.DefaultExt = "hex";
            SaveFileDialog.FileName = "";
            SaveFileDialog.Filter = "Hex File (*.hex)|*.hex|All File (*.*)|*.*";
            SaveFileDialog.OverwritePrompt = true;
            SaveFileDialog.Title = "Save Flash data";
            SaveFileDialog.ValidateNames = true;
            if (SaveFileDialog.ShowDialog() == DialogResult.OK) {
                this.Refresh();
                ExecCommand("-rp -o\"" + SaveFileDialog.FileName + "\"", 50, false);
            }
        }

        /// <summary>
        /// Flash 書き込みボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WriteFlashButton_Click(object sender, EventArgs e) {

            if (FlashFileTextBox.Text.Length == 0) {
                MessageBox.Show("Select Flash file", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                FlashFileButton.Focus();
                return;
            }
            if (!File.Exists(FlashFileTextBox.Text)) {
                MessageBox.Show("File not found", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                FlashFileButton.Focus();
                return;
            }

            ExecCommand("-v- \"" + FlashFileTextBox.Text + "\"", 50, false);
        }

        /// <summary>
        /// Flash Verifyボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void VerifyFlashButton_Click(object sender, EventArgs e) {

            if (FlashFileTextBox.Text.Length == 0) {
                MessageBox.Show("Select Flash file", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                FlashFileButton.Focus();
                return;
            }
            if (!File.Exists(FlashFileTextBox.Text)) {
                MessageBox.Show("File not found", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                FlashFileButton.Focus();
                return;
            }

            if (ExecCommand("-v \"" + FlashFileTextBox.Text + "\"", 50, false)==0)
            {
                MessageBox.Show("Flash Verify OK", this.Text, MessageBoxButtons.OK);
            }

        }

        /// <summary>
        /// Flash Erase - Write - Verify ボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ProgramFlashButton_Click(object sender, EventArgs e) {

            if (FlashFileTextBox.Text.Length == 0) {
                MessageBox.Show("Select Flash file", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                FlashFileButton.Focus();
                return;
            }
            if (!File.Exists(FlashFileTextBox.Text)) {
                MessageBox.Show("File not found", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                FlashFileButton.Focus();
                return;
            }

            ExecCommand("\"" + FlashFileTextBox.Text + "\"", 100, false);
        }

        /// <summary>
        /// EEPROM ファイル選択ボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EEPROMFileButton_Click(object sender, EventArgs e) {

            OpenFileDialog.CheckFileExists = false;
            OpenFileDialog.AddExtension = true;
            OpenFileDialog.DefaultExt = "eep";
            OpenFileDialog.Filter = "EEPROM File(*.eep)|*.eep|All File(*.*)|*.*";
            OpenFileDialog.FileName = "";
            OpenFileDialog.ShowDialog();
            if (OpenFileDialog.FileName.Length > 0) {
                EEPROMFileTextBox.Text = OpenFileDialog.FileName;
            }
        }

        /// <summary>
        /// EEPROM 読み込みボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ReadEEPROMButton_Click(object sender, EventArgs e) {

            SaveFileDialog.AddExtension = true;
            SaveFileDialog.DefaultExt = "eep";
            SaveFileDialog.FileName = "";
            SaveFileDialog.Filter = "EEPROM File (*.eep)|*.eep|All File (*.*)|*.*";
            SaveFileDialog.OverwritePrompt = true;
            SaveFileDialog.Title = "Save EEPROM data";
            SaveFileDialog.ValidateNames = true;
            if (SaveFileDialog.ShowDialog() == DialogResult.OK) {
                this.Refresh();
                ExecCommand("-re -o\"" + SaveFileDialog.FileName + "\"", 50, false);
            }
        }

        /// <summary>
        /// EEPROM 書き込みボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WriteEEPROMButton_Click(object sender, EventArgs e) {

            if (EEPROMFileTextBox.Text.Length == 0) {
                MessageBox.Show("Select EEPROM file", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                EEPROMFileButton.Focus();
                return;
            }
            if (!File.Exists(EEPROMFileTextBox.Text)) {
                MessageBox.Show("File not found", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                EEPROMFileButton.Focus();
                return;
            }

            ExecCommand("\"" + EEPROMFileTextBox.Text + "\"", 50, false);
        }


        private void VerifyEEPROMButton_Click(object sender, EventArgs e)
        {
            if (EEPROMFileTextBox.Text.Length == 0)
            {
                MessageBox.Show("Select EEPROM file", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                EEPROMFileButton.Focus();
                return;
            }
            if (!File.Exists(EEPROMFileTextBox.Text))
            {
                MessageBox.Show("File not found", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                EEPROMFileButton.Focus();
                return;
            }

            if (ExecCommand("-v \"" + EEPROMFileTextBox.Text + "\"", 50, false) == 0)
            {
                MessageBox.Show("EEPROM Verify OK", this.Text, MessageBoxButtons.OK);
            }

        }

        private void Both_write_Click(object sender, EventArgs e)
        {
            if (File.Exists(FlashFileTextBox.Text))
            {
                ProgramFlashButton_Click(sender, e);
            }
            if (File.Exists(EEPROMFileTextBox.Text))
            {
                WriteEEPROMButton_Click(sender, e);
            }
        }
        
        /// <summary>
        /// 終了ボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ExitButton_Click(object sender, EventArgs e) {
            Application.Exit();
        }

        /// <summary>
        /// メインフォームコンストラクタ
        /// </summary>
        /// ==== Form LOAD ====
         public MainForm(string[] args)
         {
            InitializeComponent();

            for (int i=0; i<args.Length; i++) 
            {
                string fullpath, fname;

                fname = args[i];

                fullpath = System.IO.Path.GetFullPath(fname);

                SetFilename(fullpath);

            }
            // ユーザ設定復元
            hidspxTextBox.Text = hidspxGUI.Default.hidspx;
            if (hidspxTextBox.Text.Length == 0) {
                if (File.Exists("hidspx.exe")) {
                    hidspxTextBox.Text = "hidspx.exe";
                }
            }
            if (hidspxTextBox.Text.Length > 0) {
                hidspxInfo();
            }
            WindowCheckBox.Checked = hidspxGUI.Default.DisplayWindow;
            CommandLineOptionTextBox.Text = hidspxGUI.Default.CommandLineOption;

            // add by senshu
            if (args.Length == 0)
            {
                FlashFileTextBox.Text = hidspxGUI.Default.FlashFile;
                EEPROMFileTextBox.Text = hidspxGUI.Default.EEPROMFile;
            }

            // タイトルバー文字列
            this.Text += Application.ProductVersion;
            this.Text = this.Text.Substring(0, this.Text.LastIndexOf('.')); // バージョン番号末尾削除
            this.Text += "]";

            // add by senshu
            this.ActiveControl = this.ReadFuseButton;

        }

        /// <summary>
        /// Form Closed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainForm_FormClosed(object sender, FormClosedEventArgs e) {

            // ユーザ設定保存
            hidspxGUI.Default.hidspx = hidspxTextBox.Text;
            hidspxGUI.Default.DisplayWindow = WindowCheckBox.Checked;
            hidspxGUI.Default.CommandLineOption = CommandLineOptionTextBox.Text;
            hidspxGUI.Default.FlashFile = FlashFileTextBox.Text;
            hidspxGUI.Default.EEPROMFile = EEPROMFileTextBox.Text;
            hidspxGUI.Default.Save();
        }

        /// <summary>
        /// hidspx.exeのヘルプ出力からプログラマ・デバイス名取得
        /// 各コンボボックスの選択
        /// </summary>
        /// <returns></returns>
        private void hidspxInfo() {
        }


        /// <summary>
        /// hidspx プログラマにオプション文字列を追加する
        /// </summary>
        /// <returns></returns>
        private string GetArg(){
            string arg = "";

            // コマンドラインの追加パラメータ 
            if (CommandLineOptionTextBox.Text.Length > 0) {
                arg += " " + CommandLineOptionTextBox.Text + " ";
            }

            return arg;
        }

        /// <summary>
        /// hidspx.exe 実行開始
        /// </summary>
        /// <param name="arg">実行時の引数</param>
        /// <returns>Processオブジェクト</returns>
        private System.Diagnostics.Process hidspx(string arg) {

            if (hidspxTextBox.Text.Length == 0) return null;

            System.Diagnostics.Process prc;
            try {
                System.Diagnostics.ProcessStartInfo psi = new System.Diagnostics.ProcessStartInfo();
                psi.FileName = hidspxTextBox.Text;
                psi.RedirectStandardOutput = true;   // 標準出力を取り込む
                psi.RedirectStandardError = true;   // 標準エラー出力を取り込む
                psi.CreateNoWindow = true;          // ウインドウ表示しない
                psi.UseShellExecute = false;        // 必須
                psi.Arguments = arg;                // 引数
                prc = System.Diagnostics.Process.Start(psi);
            } catch {
                prc = null;
            }
            return prc;
        }

        /// <summary>
        /// hidspx コマンド実行
        /// </summary>
        /// <param name="arg">hidspxの引数</param>
        /// <param name="maxProgress">hidspxの出力文字列中の # の数(=プログレスバーの最大値)</param>
        /// <param name="ignoreError">== true : エラーが発生してもエラーダイアログを表示しない</param>
        /// <returns>hidspxの戻り値</returns>
        private int ExecCommand(string arg, int maxProgress, bool ignoreError) {

            if (hidspxTextBox.Text.Length == 0)
            {
                MessageBox.Show("Select hidspx.exe File", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                hidspxButton.Focus();
                return 0;
            }

            System.Windows.Forms.Cursor cur = System.Windows.Forms.Cursor.Current;

            try {
                System.Windows.Forms.Cursor.Current = Cursors.WaitCursor;   // 砂時計カーソル

                System.Diagnostics.ProcessStartInfo psi = new System.Diagnostics.ProcessStartInfo();
                psi.Arguments = "";
                if (WindowCheckBox.Checked == true)
                {
                    // cmd.exe窓動作モード。エラー発生時に困るので自動終了しない
                    psi.FileName = System.Environment.GetEnvironmentVariable("comspec");
                    psi.Arguments = "/K \"\"" + hidspxTextBox.Text + "\" ";
                } else {
                    // 通常モード
                    psi.FileName = hidspxTextBox.Text;
                }
                if (WindowCheckBox.Checked == false) {
                    // Window表示なし
                    psi.Arguments += GetArg() + arg;   // 終了時のヒューズ設定確認を省略
                    psi.CreateNoWindow = true;          // Window表示しない
                    psi.RedirectStandardError = true;   // 標準エラー出力を取り込む
                    psi.UseShellExecute = false;        // 必須
                } else {
                    // Windows表示(DOS窓実行)あり
                    psi.Arguments += GetArg() + " " + arg;      // 終了時のヒューズ設定確認はあり
                    psi.Arguments = psi.Arguments + "\"";    // add by senshu
#if false
                    MessageBox.Show(psi.Arguments, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
#endif
                }
                psi.WorkingDirectory = Environment.GetEnvironmentVariable("temp");  // テンポラリ
                
                // hidspx起動
#if false
                MessageBox.Show(psi.Arguments, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                ProgressBar.Value = 0;
                return 0;
#else

                System.Diagnostics.Process prc = System.Diagnostics.Process.Start(psi);

                StringBuilder sb = new StringBuilder();
                if (WindowCheckBox.Checked == false) {
                    ProgressBar.Maximum = maxProgress;
                    ProgressBar.Value = 0;
                    while (!prc.StandardError.EndOfStream) {
                        int c;
                        c = prc.StandardError.Read();
                        // # が出力されたらプログレスバーを進める
                        if ((c == (int)'#') && (ProgressBar.Value < ProgressBar.Maximum)) {
                            ProgressBar.Value += 1;
                        }
                        sb.Append((char)c); // 出力メッセージをとっておく
                    }
                }
                prc.WaitForExit();  // 終了待ち

                System.Windows.Forms.Cursor.Current = cur;  // カーソルを戻す

                if ((WindowCheckBox.Checked == false) && (prc.ExitCode != 0) && (ignoreError == false))
                {
                    // エラーが発生したので出力メッセージを表示する
                    System.Media.SystemSounds.Asterisk.Play();  // チャイム音？
                    Form md = new ErrorMessageForm();
                    md.Text = this.Text + " Error";
                    md.Controls["MessageTextBox"].Text = sb.ToString();
                    md.ShowDialog();
                    ProgressBar.Value = 0;
                    return 1;
                } else {
                    // 正常終了
                    /*
                    MessageBox.Show("hidspx.exe done. Thank you.",
                         MessageBoxButtons.OK, MessageBoxIcon.Information);
                     */
                    ProgressBar.Value = 0;

                    return 0;
                }

#endif
            }
            catch
            {
                System.Windows.Forms.Cursor.Current = cur;  // カーソルを戻す
                ProgressBar.Value = 0;
                return 1;
            }
        }

        /* add by senshu */
        private void FuseViewButton_Click(object sender, EventArgs e)
        {
            string url;
 
            ReadFuseButton_Click(sender, e);
            if (LFuseTextBox.Text != "")
            {
                if (HFuseTextBox.Text == "")
                {
                    url = "http://www.engbedded.com/cgi-bin/fc.cgi/?P="
                        + DeviceTextBox.Text
                        + "&V_LOW=" + LFuseTextBox.Text
                        + "&O_HEX=Apply+user+values";
                }
                else
                {
                    url = "http://www.engbedded.com/cgi-bin/fc.cgi/?P="
                        + DeviceTextBox.Text
                        + "&V_LOW=" + LFuseTextBox.Text
                        + "&V_HIGH=" + HFuseTextBox.Text
                        + "&V_EXTENDED=" + EFuseTextBox.Text
                        + "&O_HEX=Apply+user+values";
                }
#if true
                System.Diagnostics.Process.Start(url);
#else   // for DEBUG
                MessageBox.Show(url, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
#endif
            }
        }


        private void Help_Click_1(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(
                "http://www-ice.yamagata-cit.ac.jp/ken/senshu/sitedev/index.php?AVR%2FHIDaspx00");
        }


    }
}