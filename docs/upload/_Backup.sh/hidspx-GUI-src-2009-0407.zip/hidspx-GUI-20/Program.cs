﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Windows.Forms;

namespace hidspxGUI
{
    /// <summary>
    /// アプリケーションのメイン エントリ ポイントです。
    /// </summary>
    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    static class Program
    {
        /*
         * Win32APIをP/Invokeで使用するための宣言
         */
        [System.Runtime.InteropServices.DllImport("User32.dll")]
        private static extern int ShowWindow(IntPtr hWnd, int nCmdShow);

        [System.Runtime.InteropServices.DllImport("User32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        private const int SW_SHOWNORMAL = 1;

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            /* 現在のプロセスを取得 */
            Process currentProcess = Process.GetCurrentProcess();

            /* 現在のプロセスと同名のプロセスを取得 */
            Process[] processes = Process.GetProcessesByName(currentProcess.ProcessName);

            foreach (Process p in processes)
            {
                /* 同名の他のプロセスがあれば... */
                if (p.Id != currentProcess.Id)
                {
                    /* ウィンドウを全面に表示する */
                    ShowWindow(p.MainWindowHandle, SW_SHOWNORMAL);
                    SetForegroundWindow(p.MainWindowHandle);
                    return;
                }
            }

            /* 同名の他のプロセスがなければ起動 */
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm(args));
        }
    }
}
