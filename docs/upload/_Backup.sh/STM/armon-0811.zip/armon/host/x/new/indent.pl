#! /usr/bin/perl

sub usage() {
	print << 'USAGI';
usage is:
 $  indent.pl infile.pl outfile.pl
USAGI
}

#
# 	indent fix.
#

	my @source;
	my @out;
    my @lev;
	my $level=0;
	my $updnf;
	my ($infile,$outfile);
	&main();
	exit;


sub getfile() {
	my $file = $_[0];
	open(FILE,$file) or die "Can not open file $file\n";
	@source = <FILE>;
	close(FILE);
}

sub putfile() {
	my $file = $_[0];
	open(FILE,">$file") or die "Can not create file $file\n";
	foreach(@out) {
		print FILE $_;
	}
	close(FILE);
}

sub levchk() {
	my ($line) = @_;
	my $i;
	my $lv = 0;
	my $c;
	my $q="";
	my $len = length($line);
    my $dnf = 0;

    $updnf = 0;

	for($i=0;$i<$len;$i++) {
		$c = substr($line,$i,1) ;

		if($q eq "") {
			if($c eq "\x22") {$q = $c;}
			elsif($c eq "'") {$q = $c;}
			elsif($c eq "{") {$lv ++;$dnf++;}
			elsif($c eq "}") {$lv --;$dnf--;
				if($updnf > $dnf) {$updnf = $dnf;};
			}
		}else{
			if($c eq $q) {$q = "";}
		}
	}
	$lv;
}

sub	tabs() {
	my $lv = $_[0];
	my $i;
	my $buf = "";
	for($i=0;$i<$lv;$i++) {
		$buf .= "\t";
	}
	$buf;
}

sub stripqt() {
	my $s = $_[0];
	my $l = length($s);
	if( substr($s,0,1) eq "\x22") {
		$s = substr($s,1,$l-2);
	}elsif( substr($s,0,1) eq "'") {
		$s = substr($s,1,$l-2);
	}
	$s;
}

sub indent() {
	undef @out;
	my $line;
	my $updn;
	my $lv;
	my $here_document = "";
	foreach $line (@source) {
		if( $line =~ /^[ \t]*#/ ) {	# comment;
			push @out,$line;
		}elsif( $line =~ m|^[ \t]*//| ) {	# comment;
			push @out,$line;
		}else{
			$updn = &levchk($line);
			$lv = $level;
			if($updnf) {$lv = $level + $updnf;}

			if($here_document ne "") {
				push @out,$line;
			}else{
				$line =~ s/^[ \t]*// ;
				push @out, &tabs($lv) . $line;
				$level = $level + $updn;
				if($level < 0) {$level = 0;}
			}
		}
		if($here_document ne "") {
			$line =~ s/\r//;
			$line =~ s/\n//;
			if($line eq $here_document) {
				$here_document = "";
			}
		}elsif( $line =~ /<<.*;[ ]*$/ ) {
			$here_document = $line;
			$here_document =~ s/\r// ;
			$here_document =~ s/\n// ;
			$here_document =~ s/.*<<//;
			$here_document =~ s/[ \t]*//;
			$here_document =~ s/[ \t]*;[ \t]*//;
			$here_document = &stripqt($here_document);
			#print "here_document = ($here_document)\n";
		}
	}
}

sub main() {
	my $argc = scalar @ARGV;

#	if(		$argc==1) {$infile = @ARGV[0];$outfile = STDOUT;}

	if(		$argc==1) {$infile = @ARGV[0];$outfile = @ARGV[0];}
	elsif(	$argc==2) {$infile = @ARGV[0];$outfile = @ARGV[1];}
	else{ &usage();exit; }

	&getfile($infile);
	&indent();
	&putfile($outfile);
}
