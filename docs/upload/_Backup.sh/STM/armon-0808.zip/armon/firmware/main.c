/********************************************************************
 *	���C������
 ********************************************************************
 */
#include <stdio.h>
#include <string.h>


#include "platform_config.h"
#include "stm32f10x.h"
#include "usb_lib.h"
#include "usb_istr.h"
#include "stm32_eval.h"
#include "hw_config.h"
#include "hidcmd.h"
#include "monit.h"

#define	LED_PORT	GPIOA
#define	LED_PIN		GPIO_Pin_8



#if	APPLICATION_MODE

/* by default stdout issues to the USART */
//FILE *stdout = _H_USER;

/********************************************************************
 *	��`
 ********************************************************************
 */
/********************************************************************
 *	�f�[�^
 ********************************************************************
 */
//#pragma udata access accessram
//#pragma udata

#define	PUTBUF_SIZE	(64-4)

uchar puts_buf[PUTBUF_SIZE];
uchar puts_ptr;

//#pragma code

/********************************************************************
 *	
 ********************************************************************
 */
int _user_putc(char c)
{
	uchar flush = 0;
	if( c == 0x0a) { flush = 1; }
	if( puts_ptr >= PUTBUF_SIZE ) {flush = 1;}

	if( flush ) {
		while(puts_ptr) {
			wait_ms(1);
		}
	}

	if(	puts_ptr < PUTBUF_SIZE ) {
		puts_buf[puts_ptr++]=c;
	}

	return 1;
}
/********************************************************************
 *	
 ********************************************************************
 */

#if	0
void led_config()
{
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
}
#endif


/********************************************************************
 *	
 ********************************************************************
 */
void led_on()
{
	GPIO_SetBits(LED_PORT,LED_PIN);
}

/********************************************************************
 *	
 ********************************************************************
 */
void led_off()
{
	GPIO_ResetBits(LED_PORT,LED_PIN);
}

/********************************************************************
 *	
 ********************************************************************
 */
void led_blink(int interval)
{
	static int led_cnt=0;
	int mask = 1<<interval;

	led_cnt++;
	if(led_cnt & mask) {
		led_on();
	}else{
		led_off();
	}
}
/********************************************************************
 *	
 ********************************************************************
 */
void *memcpy(void *dst,const void *src,size_t size)
{
	char *t = (char*)dst;
	char *s = (char*)src;
	while(size--) {*t++=*s++;}
	return t;
}

#endif	//APPLICATION_MODE


volatile void wait_us(int us);
volatile void wait_ms(int ms);
/********************************************************************
 *	
 ********************************************************************
 */
volatile void wait_ms(int ms)
{
	int i;
	for(i=0;i<ms;i++) {
		wait_us(1000*8);
	}
}

/********************************************************************
 *	
 ********************************************************************
 */
volatile void wait_us(int us)
{
	int i;
	for(i=0;i<us;i++) {
		asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
	}
}



/********************************************************************
 *	
 ********************************************************************
 */
int main(void)
{
	Set_System();
	USB_Interrupts_Config();
	Set_USBClock();
	USB_Init();

	while(1) {
		USBtask();
#if	APPLICATION_MODE
		wait_ms(1);
		led_blink(8);
#endif
	}
}

/********************************************************************
 *	
 ********************************************************************
 */
