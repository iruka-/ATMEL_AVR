/********************************************************************
 *	���[�U�[��`�֐��̎��s
 ********************************************************************
 */
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <malloc.h>

#include "platform_config.h"
#include "stm32f10x.h"
#include "usb_lib.h"
#include "usb_istr.h"
#include "stm32_eval.h"
#include "hidcmd.h"
#include "monit.h"

#define	PRINTF_TEST	(0)		// printf()�̓���e�X�g.



#if	APPLICATION_MODE

//	#undef	putc
//	#undef	fputs
//	#define	putc(c,fp)  _user_putc(c)
//	#define	fputs(s,fp) _user_puts(s)


int _user_putc(char c);

int _user_puts(char *s)
{
	while(*s) {
		_user_putc(*s++);
	}
	return 0;
}


/********************************************************************
 *	��`
 ********************************************************************
 */
/********************************************************************
 *	�f�[�^
 ********************************************************************
 */
/********************************************************************
 *	
 ********************************************************************
 */
void memdump(char *mesg,void *src , int len )
{
	char buf[16];
	uchar *s=(uchar*)src;
	int i;

	_user_puts(mesg);

	for(i=0;i<len;i++) {
		sprintf(buf,"%02x ",*s);s++;
		_user_puts(buf);
	}
	_user_puts("\n");
}


#if	PRINTF_TEST		// printf()�̓���e�X�g.
/********************************************************************
 *	
 ********************************************************************
 */
void user_cmd(int arg)
{
	char buf[64];

#if	0
	//
	//	malloc()�e�X�g�̎��s.
	//
	int *t;
	t=malloc(1);
	sprintf(buf,"t=%x\n",(int) t );
	fputs(buf,stdout);

	t=malloc(16);
	sprintf(buf,"t=%x\n",(int) t );
	fputs(buf,stdout);

	t=malloc(16);
	sprintf(buf,"t=%x\n",(int) t );
	fputs(buf,stdout);
#endif

	//
	//	printf()�e�X�g�̎��s.
	//
	printf("Hello World\n");
	printf("Pi=%16.10g\n",atan(1.0)*4.0 );

#if	1
	//
	//	fputs()�e�X�g�̎��s.
	//
	ushort i,j;
	for(j=0;j<16;j++) {
//		printf("Hello :");
		fputs("Hello :",stdout);
		for(i=0;i<50;i++) {
			putc( i + ' ' ,stdout );
//			USBtask();
//			LED1_blink();
		}
//		printf("\n");
		fputs("\n",stdout);
	}
#endif

#if	0
	//
	//	double �^�̃������[�_���v�e�X�g.
	//
	double a = 3.14;
	double b = 2.0;
	double c;
	double d;

	c = a*b;
	d = atan(1.0)*4.0;
	memdump( "a=" , &a , 8 );
	memdump( "b=" , &b , 8 );
	memdump( "c=" , &c , 8 );
	memdump( "d=" , &d , 8 );
#endif
}

#else	//PRINTF_TEST	printf()�̓���e�X�g.


/********************************************************************
 *	_user_putc()  _user_puts()�e�X�g�̎��s.
 ********************************************************************
 */
void user_cmd(int arg)
{
	char buf[64];
	_user_puts("Hello World\n");
	ushort i,j;
	for(j=0;j<16;j++) {
		_user_puts("Hello :");
		for(i=0;i<50;i++) {
			_user_putc( i + ' ' );
		}
		_user_puts("\n");
	}
}


#endif	//PRINTF_TEST	printf()�̓���e�X�g.
/********************************************************************
 *	
 ********************************************************************
 */
#endif
