/* avrdude wrapper for Windows
 Programed by Kimio Kosaka 2009.05.01

 Modified by senshu 2009.09.23
 Modified by senshu 2009.09.28 (For hidspx.exe)
 Modified by senshu 2009.10.11 (For avrdude_orig.exe)
 Modified by senshu 2010.03.18 (For avrdude_orig.exe)

 License: GPL

*/

/*
���̃v���O�����́Aavrdude.exe�����b�v���A-chidspx���w�肷�邱�ƂŁA
avrdude�R�}���h�o�R�� hidspx�̗��p���\�ɂ��邽�߂̃R�}���h�ł��B

����avrdude.exe���R�s�[����O�ɁA���O�ɃI���W�i���� avrdude.exe��
 avrdude_orig.exe �ɉ������A����avrdude.exe�𓯂��ꏊ�ɃR�s�[���܂��B

 */

/*
Usage: avrdude [options]
Options:
�d�v
  -p <partno>                Required. Specify AVR device.
  -C <config-file>           Specify location of configuration file.
  -c <programmer>            Specify programmer type.
  -D                         Disable auto erase for flash memory
  -P <port>                  Specify connection port.
  -e                         Perform a chip erase.
  -U <memtype>:r|w|v:<filename>[:format]
                             Memory operation specification.
                             Multiple -U options are allowed, each request
                             is performed in the order specified.
  -u                         Disable safemode, default when running from a script.
  -v                         Verbose output. -v -v for more.
  -q                         Quell progress output. -q -q for less.

  -b <baudrate>              Override RS-232 baud rate.
  -B <bitclock>              Specify JTAG/STK500v2 bit clock period (us).
  -i <delay>                 ISP Clock Delay [in microseconds]
  -F                         Override invalid signature check.
  -O                         Perform RC oscillator calibration (see AVR053).
  -n                         Do not write anything to the device.
  -V                         Do not verify.
  -s                         Silent safemode operation, will not ask you if
                             fuses should be changed back.

  -t                         Enter terminal mode.
  -E <exitspec>[,<exitspec>] List programmer exit specifications.
  -x <extended_param>        Pass <extended_param> to programmer.
  -y                         Count # erase cycles in EEPROM.
  -Y <number>                Initialize erase cycle # in EEPROM.
  -?                         Display this usage.

avrdude project: <URL:http://savannah.nongnu.org/projects/avrdude>

 */

#ifdef WIN32
#include <windows.h>
#elif defined(__linux__)
#include <unistd.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef WIN32
#include <io.h>
#include <dir.h>
#endif
#include <dirent.h>

#define VERSION "0.8"
#define DEBUG  0

#ifndef _MAX_PATH
#define _MAX_PATH (256)
#endif

#if defined(WIN32)
  #define AVRDUDE_IMG "avrdude.exe"
  #define HIDSPX_IMG "hidspx.exe"
  #define HIDSPX "c:\\bin\\hidspx.exe"
#elif defined(MACOS)
  #define AVRDUDE_IMG "/Applications/Arduino.app/Contents/Resources/Java/hardware/tools/avr/bin/avrdude.org"
  #define HIDSPX_IMG "/opt/local/bin/hidspx"
#elif defined(__linux__)
  #define AVRDUDE_IMG "/usr/local/bin/avrdude"
  #define HIDSPX_IMG "/usr/local/bin/hidspx"
#endif

#define MAX_BUFF_SIZE (_MAX_PATH + 16)
#define MAX_CMD_SIZE (2047)
#define check_cmd_buff(len, opt_len) (MAX_CMD_SIZE - (len) - (opt_len))

//replace strings
int str_rpl(char *buf, char *old, char *new)
{
	char *mituke;
	size_t old_len, new_len;

	old_len = strlen(old);
	new_len = strlen(new);
	if (old_len == 0 || (mituke = strstr(buf, old)) == NULL) {
		return 0;
	}
	memmove(mituke + new_len, mituke + old_len,
			strlen(buf) - (mituke + old_len - buf) + 1);
	memcpy(mituke, new, new_len);

	return 1;
}

char *q_fname(int mode, char *fname)	/* mode==1�́A������:i���Ƃ� */
{
	static char buff[MAX_BUFF_SIZE];
	int len;

	strcpy(buff, fname);

	if (strchr(buff, ' ') != NULL) {
		len = sprintf(buff, "\"%s", fname);
		if (mode) {
			if (buff[len - 2] == ':') {
				buff[len - 2] = '\"';
				buff[len - 1] = '\0';
			} else {
				buff[len] = '\"';
				buff[len + 1] = '\0';
			}
		} else {
			buff[len] = '\"';
			buff[len + 1] = '\0';
		}
	} else {
		if (mode) {
			len = strlen(buff);
			if (buff[len - 2] == ':') {
				buff[len - 2] = '\0';
			}
		}
	}

	/* �������ނׂ��t�@�C���w�肪�����inull�j */
	if (strcmp(buff, "null")==0) {
		return NULL;
	} else if (strstr(buff, "\\null\"") != NULL) {
		return NULL;
	} else {
		return buff;
	}
}


int main(int argc, char *argv[])
{
	int ret, i, found, len, opt_len;
	char cmd[MAX_CMD_SIZE] = "";
	char exe_fname[MAX_BUFF_SIZE];
	char hidspx_image[MAX_BUFF_SIZE];
	char hidspx_short_image[MAX_BUFF_SIZE];
	char option[MAX_BUFF_SIZE];
	char *p;
#if DEBUG
	char cur_dir[MAX_BUFF_SIZE];
#endif

#if defined(WIN32)
	GetModuleFileName(NULL, exe_fname, _MAX_PATH);

	p = getenv("HIDSPX_EXE");
	if (p == NULL) {
		/* avrdude.exe �̂���ꏊ�� hidspx.exe������΁A����𗘗p���� */
		strcpy(hidspx_image, exe_fname);
		str_rpl(hidspx_image, AVRDUDE_IMG, HIDSPX_IMG);
		if (access(hidspx_image, 0) < 0) {
			strcpy(hidspx_image, HIDSPX);
		}
	} else {
		/* ���ϐ��Ŏw�肪����΁A����𗘗p���� */
		strcpy(hidspx_image, p);
	}
#elif defined(MACOS)
	p = getenv("HIDSPX_EXE");
	if (p != NULL) {
		/* ���ϐ��Ŏw�肪����΁A����𗘗p���� */
		strcpy(hidspx_image, p);
	} else {
		strcpy(hidspx_image, HIDSPX_IMG);
	}
#endif

	strcpy(exe_fname, AVRDUDE_IMG);
	if (argc == 2) {
		if (strcmp(argv[1], "--version") == 0) {
			fprintf(stderr, "avrdude wrapper version %s, (%s)\n", VERSION,
					__DATE__);
#ifdef WIN32
			str_rpl(exe_fname, ".exe", "_orig.exe");
#endif
			fprintf(stderr, "avrdude -> %s\n", exe_fname);
			fprintf(stderr, "hidspx  -> %s\n", hidspx_image);
			return 0;
		}
	}

#if DEBUG
	getcwd(cur_dir, _MAX_PATH);
	fprintf(stderr, "cur_dir   = %s\n", cur_dir);
	fprintf(stderr, "exe_fname = %s\n", exe_fname);
	for (i = 0; i < argc; i++) {
		fprintf(stderr, "argv[%2d] |%s|\n", i, argv[i]);
	}
#endif

	len = found = 0;
	for (i = 1; i < argc; i++) {
		strcpy(option, argv[i]);
		if ((strcmp(argv[i], "-c") == 0)) {
			i++;
			strcat(option, argv[i]);
		}
		if (strncmp(option, "-chidspx", 8) == 0) {
			found++;
		}
	}
	if (found) {
#ifdef WIN32
		if (GetShortPathName(hidspx_image, hidspx_short_image, MAX_BUFF_SIZE) != 0) {
			len = sprintf(cmd, "%s --show-options", hidspx_short_image);
		} else {
			len = sprintf(cmd, "\"%s\" --show-options", hidspx_image);
		}
#else
		len = sprintf(cmd, "\"%s\" --show-options", hidspx_image);
#endif
		for (i = 1; i < argc; i++) {
			/*
			   hidspx �ɓn���K�v�̖����o�����[�^�Q���`�F�b�N����B
			   -D ... Erase�����ŏ������ށi��������j
			   -v ... Verbose�i��������j
			   -q ... Quiet�i��������j
			   -V ... Verify�ihidspx�ł͏ȗ��ł��̃��[�h�j
			   -e ... �Ώۃf�o�C�X������������
			   -C ... avrdude.conf �t�@�C���̎w��
			 */

			if (argv[i][0] == '-') {
				opt_len = strlen(argv[i]);

				if (opt_len > sizeof(option) + 4)
					goto BUFF_ERROR;
				strcpy(option, argv[i]);
				/*
				   �y�A�Ŏw�肷��o�����[�^�Q���`�F�b�N����B

				   -p ... �������ݑΏۂ�Part��
				   -P ... Port����
				   -U ... Update�Ώ�
				 */
				if ((strcmp(argv[i], "-p") == 0)
					|| (strcmp(argv[i], "-P") == 0)
					|| (strcmp(argv[i], "-U") == 0)) {
					i++;
					strcat(option, argv[i]);
				}

				/* hidspx�ɓn���I�v�V����������𐶐� */
				if (strncmp(option, "-chidspx", 8) == 0) {
					char *p;

					p = option + 8;
					while (*p) {
						if (*p == ',' || *p == '_') {
							cmd[len] = ' ';
						} else {
							cmd[len] = *p;
						}
						p++;
						len++;
					}

				} else if (strcmp(option, "-e") == 0) {
					len += sprintf(cmd + len, " -e");
				}
				/* Read/Write AVR chip */
				else if (strncmp(option, "-Ueeprom:w:", 11) == 0) {
					p = q_fname(1, option + 11);
					if (p == NULL)
						continue;
					if (check_cmd_buff(len, opt_len) < 0)
						goto BUFF_ERROR;
					len += sprintf(cmd + len, " %s", p);

				} else if (strncmp(option, "-Uflash:w:", 10) == 0) {
					p = q_fname(1, option + 10);
					if (p == NULL)
						continue;
					if (check_cmd_buff(len, opt_len) < 0)
						goto BUFF_ERROR;
					len += sprintf(cmd + len, " %s", q_fname(1, option + 10));

				} else if (strncmp(option, "-Uflash:r:", 10) == 0) {
					p = q_fname(1, option + 10);
					if (p == NULL)
						continue;

					if (check_cmd_buff(len, opt_len) < 0)
						goto BUFF_ERROR;

					if (strstr(option, "flash:r:-:i")) {
						len += sprintf(cmd + len, " -rp");
					} else {
						len +=	sprintf(cmd + len, " -rp -o%s", q_fname(1, option + 10));
					}
				} else if (strncmp(option, "-Ueeprom:r:", 11) == 0) {
					p = q_fname(1, option + 11);
					if (p == NULL)
						continue;

					if (check_cmd_buff(len, opt_len) < 0)
						goto BUFF_ERROR;

					if (strstr(option, ":r:-:i")) {
						len += sprintf(cmd + len, " -rp");
					} else {
						len += sprintf(cmd + len, " -rp -o%s",	q_fname(1, option + 11));
					}
				}
				/* Fuse and Lock bit */
				else if (strncmp(option, "-Ulock:w:", 9) == 0) {
					p = q_fname(1, option + 9);
					if (p == NULL)
						continue;

					if (check_cmd_buff(len, opt_len) < 0)
						goto BUFF_ERROR;

					len += sprintf(cmd + len, " -l%s", option + 9);
					if (cmd[len - 2] == ':') {
						len -= 2;
						cmd[len] = '\0';
					}
				} else if (strncmp(option, "-Ufuse:w:", 9) == 0) {
					p = q_fname(1, option + 9);
					if (p == NULL)
						continue;

					if (check_cmd_buff(len, opt_len) < 0)
						goto BUFF_ERROR;

					len += sprintf(cmd + len, " -fL%s", option + 9);
					if (cmd[len - 2] == ':') {
						len -= 2;
						cmd[len] = '\0';
					}
				} else if (strncmp(option, "-Ulfuse:w:", 10) == 0) {
					p = q_fname(1, option + 10);
					if (p == NULL)
						continue;

					if (check_cmd_buff(len, opt_len) < 0)
						goto BUFF_ERROR;

					len += sprintf(cmd + len, " -fL%s", option + 10);
					if (cmd[len - 2] == ':') {
						len -= 2;
						cmd[len] = '\0';
					}
				} else if (strncmp(option, "-Uhfuse:w:", 10) == 0) {
					p = q_fname(1, option + 10);
					if (p == NULL)
						continue;

					if (check_cmd_buff(len, opt_len) < 0)
						goto BUFF_ERROR;

					len += sprintf(cmd + len, " -fH%s", option + 10);
					if (cmd[len - 2] == ':') {
						len -= 2;
						cmd[len] = '\0';
					}
				} else if (strncmp(option, "-Uefuse:w:", 10) == 0) {
					p = q_fname(1, option + 10);
					if (p == NULL)
						continue;

					if (check_cmd_buff(len, opt_len) < 0)
						goto BUFF_ERROR;

					len += sprintf(cmd + len, " -fX%s", option + 10);
					if (cmd[len - 2] == ':') {
						len -= 2;
						cmd[len] = '\0';
					}
				}
			}
		}
	} else {
		len = 0;
		opt_len = strlen(exe_fname);
		if (check_cmd_buff(len, opt_len) < 0)
			goto BUFF_ERROR;

		strcpy(cmd,exe_fname);

#ifdef WIN32
		if (GetShortPathName(exe_fname, cmd, MAX_CMD_SIZE) == 0) {
			fprintf(stderr, "avrdude (wrapper) : GetShortPathName(\"%s\") Error\n", exe_fname);
			return 1;
		}
		str_rpl(cmd, ".exe", "_orig.exe");
		if (access(cmd, 0) < 0) {
			fprintf(stderr, "avrdude: %s isn't found.\n", cmd);
			exit(1);
		}
#else
		if (access(cmd, 0) < 0) {
			fprintf(stderr, "avrdude: %s isn't found.\n", cmd);
			exit(1);
		}
#endif
		strcat(cmd, " ");
		len = strlen(cmd);

		for (i = 1; i < argc; i++) {
			opt_len = strlen(argv[i]);
			if (check_cmd_buff(len, opt_len) < 0)
				goto BUFF_ERROR;

			len += sprintf(cmd + len, " %s", q_fname(0, argv[i]));
		}
#if	DEBUG
		fprintf(stderr, "\navrdude-wrapper:\n%s\n", cmd);
#endif
	}

	ret = system(cmd);
#if DEBUG
	ret = 0;
#endif

	return ret;

  BUFF_ERROR:;

	fprintf(stderr, "BUFF_ERROR: CMD strings OVER(%d)\n", len);
	return 1;
}
