/**********************************************************************
 *	PWM Sound Driver
 **********************************************************************
 * TIMER0�ɂ�鍂���o�v�l�i8bit D/A�j�o��
 *
 *	void sound_init(void)	PWM ������.
 *	void sound_mix(void)	�~�L�V���O.
 *
 *
 *
 */
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>

#include "config.h"
#include "task.h"
#include "sound.h"
#include "sinewave.h"

#define	CH_MAX	4

uint  waveptr[CH_MAX];		// sine table�̓ǂݏo��pointer.
uint  wavepitch[CH_MAX];	// waveptr �ɉ��Z���釙�l.
uchar wavevol[CH_MAX];		// ����.

static	uchar keyon_f;				// �Ō���=true
static	uint  pp = 0;

/**********************************************************************
 *	������
 **********************************************************************
 */
void sound_init(void)
{
	uchar i;

	SPK_OUT_DDR |= SPK_OUT_BIT_MASK;	// PD6��out.
	TCCR0A = 0b11000011;
	TCCR0B = 0b00000001;
	OCR0A  = 128;

	for(i=0;i<CH_MAX;i++) {
		wavepitch[i]=0;
		waveptr[i]=0;
	}
}

/**********************************************************************
 *	8bit D/A�o��.
 **********************************************************************
 */
static	void sound_out(uchar x)
{
	OCR0A = x;
}

/**********************************************************************
 *	�`���l���~�L�V���O.
 **********************************************************************
 */
static	void sound_mix(void)
{
	uchar i,p;
	char  out=0;
	char  c;
	int   v;
	for(i=0;i<CH_MAX;i++) {
		waveptr[i] += wavepitch[i];		//�s�b�`���W�X�^�����Z.
		p = (waveptr[i] >> 8) & 0x3f;	//sine wave table�̓ǂݏo���|�C���^.
		c = __LPM( &sinewave[p] );
		v = ((c * wavevol[i]) >> 8);	//���ʂ���Z.
		c = v ;
		out += c;						//�~�L�V���O.
	}
	sound_out(out + 0x80);
}

/**********************************************************************
 *	���U����炷.
 **********************************************************************
 */
/**********************************************************************
 *	interface
 **********************************************************************
 */
void keyon(uchar c)
{
	uchar i;
	keyon_f = c;
	if(keyon_f) {
		wavepitch[0]=0x200;	//pp>>6;
		wavepitch[1]=0x203;
//		wavepitch[2]=pp>>8;
//		wavepitch[3]=pp>>5;
//		for(i=0;i<CH_MAX;i++) {
			wavevol[0]=0x7f;
			wavevol[1]=0x3f;
//		}
	}else{
		for(i=0;i<CH_MAX;i++) {
			wavepitch[i]=0;
			wavevol[i]=0;
		}
	}
}

void sound_task(void)
{
	sound_mix();
#if	0
	uchar c,i;
	pp++;
	c = (pp>>9) & 0x3f;
	for(i=0;i<CH_MAX;i++) {
		wavevol[i]=c;
	}
#endif
}


/**********************************************************************
 *	
 **********************************************************************
 */
