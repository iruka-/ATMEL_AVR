/**********************************************************************
 *	PS2 Keyboard Library : Sample Main
 **********************************************************************
 */
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <util/delay.h>

#include "config.h"
#include "task.h"
#include "taskdef.h"
#include "timer.h"
#include "sound.h"
#include "ps2keyb.h"
#include "morse.h"


/**********************************************************************
 *	define
 **********************************************************************
 */
#define	ESCAPE	0x1b		// [ESC]

void quit();				// bootloader�ɖ߂�.

/**********************************************************************
 *	task
 **********************************************************************
 */
void main_task(void)
{
	if(morse_stat()==0) {		// �Ō��^�X�N����.
		uchar c = kbd_getchar();// PS2 keyboard���� ASCII�R�[�h���擾����.
		if( c == ESCAPE) {		// [ESC]�������ꂽ.
			quit();				// bootloader �ɖ߂�.
		}
		if( c ) {				// [ESC] �ȊO�̃L�[���͂�������.
			morse_send(c);		// ���[���X�����𔭐M����.(c=ASCII CODE)
		}
	}
	sleep_tsk(20);		//20tick �҂�.
}

/**********************************************************************
 *	���C��
 **********************************************************************
 */
int	main(void)
{
	init_tsk();
	kbd_init();
	sound_init();
	morse_init();
	timer_init(360-1);	// 30��S(33.3kHz)�����Ŋ��荞��.
//	timer_init(240-1);	// 20��S(50kHz)�����Ŋ��荞��.
	sei();

	reg_tsk(ID_main,main_task);
	reg_tsk(ID_sound,sound_task);
	reg_tsk(ID_morse,morse_task);

	while(1) {
		timer_wait();
		dispatch_tsk();
	}
	return 0;
}

/**********************************************************************
 *	
 **********************************************************************
 */
