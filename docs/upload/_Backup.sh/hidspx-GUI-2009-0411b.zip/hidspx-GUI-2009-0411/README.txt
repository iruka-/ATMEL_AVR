avrdude-GUI for Windows

License : BSD (New BSD License)

Please read http://yuki-lab.jp/hw/avrdude-GUI/ (Japanese)

Required :
 .NET Framework 2.0
 avrdude.exe  http://www.bsdhome.com/avrdude/
 libusb-win32 http://sourceforge.net/project/showfiles.php?group_id=78138

Copyright(C) 2007-2009  KAWAKAMI Yukio
