/* util.h */
//#define	DLL_int	__declspec(dllexport) int __cdecl //__stdcall
#define	DLL_int	__declspec(dllexport) int __stdcall

/* util.c */
DLL_int PortAddress (const char *string);
DLL_int UsbExit (void);
DLL_int UsbInit (const char *string);
DLL_int UsbPeek (int adr, int arena);
DLL_int UsbPoke (int adr, int arena, int data, int mask);
DLL_int UsbPoll (void);
DLL_int UsbSetPoll (int adr, int arena);
int QueryAVR (cmdBuf *cmd, uchar *buf, int reply_len);
int UsbPoll_slow (void);
int UsbRead (int adr, int arena, uchar *buf, int size);
int UsbSetPoll_slow (int adr, int arena);
int dumpmem (int adr, int arena, int size, unsigned char *buf);
int hid_ping (int i);
int pokemem (int adr, int arena, int data0, int data1);
void UsbBench (int cnt, int psize);
void UsbCheckPollCmd (void);
void UsbDump (int adr, int arena, int cnt);
void UsbPoke_b (int adr, int arena, int bit, int mask);
void memdump_print (void *ptr, int len, int off);
