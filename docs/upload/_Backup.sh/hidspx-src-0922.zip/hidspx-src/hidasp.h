
int hidasp_init(char *string);
void hidasp_close();
int hidasp_program_enable(int delay);
int hidasp_cmd(const unsigned char cmd[4],unsigned char res[4]);
int hidasp_page_write(long addr,const unsigned char *wd,int pagesize);
int hidasp_page_read(long addr,unsigned char *wd,int pagesize);

//
int	hidWriteFile(HANDLE hHID, char *buf, int Length, ULONG *sz, void *cb);
int hidReadFile( HANDLE hHID, char *buf, int Length, ULONG *sz, void *cb);

