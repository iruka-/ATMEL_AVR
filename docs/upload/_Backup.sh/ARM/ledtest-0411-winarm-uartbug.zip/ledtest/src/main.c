/* 
   "Epsilon"
   LPC2378 Demo by Martin Thomas, Kaiserslautern, Germany
   http://www.siwawi.arubi.uni-kl.de/avr_projects/arm_projects

   Target:   LPC2378
   Board:    Olimex LPC-2378-STK
   Compiler: GNU arm-elf or arm-eabi toolchain 
             (tested with WinARM 5/07-beta)
   
   Partly based on drivers from the NXP LPC23xx & 24xx 
   example-collection available from www.nxp.com.
*/

#define VERSION_STRING "0.5 beta^2 mthomas, KL, .de"

#include "LPC23xx.h"
#include "type.h"
#include "irq.h"
#include "swi.h"
#include "target.h"
#include "timer.h"

#include "fio.h"
#include "uart.h"

#if	0
// LED1 (MCIPWR on Olimex LPC-2378-STK has an indicator LED)
#define LED1_FIOPIN  FIO0PIN
#define LED1_FIOSET  FIO0SET
#define LED1_FIOCLR  FIO0CLR
#define LED1_MASK    (1UL<<21)
#else
// LED1 CQ-FRK-NXP
#define LED1_FIOPIN  FIO1PIN
#define LED1_FIOSET  FIO1SET
#define LED1_FIOCLR  FIO1CLR
#define LED1_MASK    (1UL<<18)	//0x00040000; P1[18]
#endif

#define INBUF_SIZE   0x80

#define UART_NUM     1
#define NEXTLINE     "\r\n"
#define ENTERKEY     '\r'
static const char welcome[] = NEXTLINE "Welcome to the WinARM LPC2378 Demo#1 \"Epsilon\"" NEXTLINE;
static const char version[] = "Version "VERSION_STRING NEXTLINE;

static void time_waste( DWORD dv )
{
	volatile DWORD cnt;
	
	for ( cnt=0; cnt<dv ; cnt++ ) { ; }
}

static int my_strlen(const char* str)
{
   int n = 0;
   const char* s = str;

   while(*s++) {
      n++;
   }
   
   return n;
}

static void my_uart_puts( const char *str )
{
	UARTSend( UART_NUM, (const BYTE*)str, my_strlen(str) );
}

static void prompt(void)
{
	static const char s[] = NEXTLINE "Command>";
	my_uart_puts(s);
}

static int process_input( const char* cmdstr, DWORD cmdcnt )
{
	static const char info1[] = NEXTLINE "About to process : ";
	static const char todo[] = NEXTLINE "HOHO" NEXTLINE;
	my_uart_puts( info1 );
	my_uart_puts( cmdstr );
	
	// TODO: parse cmdstr and process here
	my_uart_puts( todo );
	LED1_FIOPIN ^= LED1_MASK;
	
	prompt();
	
	return 0;
}

int main (void)
{
	BYTE incoming_buf[INBUF_SIZE];
	DWORD incoming_cnt, i, process_flag;
	BYTE c;
#ifdef GPIO_WITH_SET_CLR
	int flip = 0;
#endif
	
	// already called in startup-code: TargetResetInit();

#if	0
// �g���Z��.
/* FGPIO�R���g���[���̃��W�X�^ */
#define FGPIO_FIO1DIR	((volatile unsigned int *)(0x3FFFC020))
#define FGPIO_FIO1MASK	((volatile unsigned int *)(0x3FFFC030))
#define FGPIO_FIO1PIN	((volatile unsigned int *)(0x3FFFC034))
#define FGPIO_FIO1CLR	((volatile unsigned int *)(0x3FFFC03C))
    *FGPIO_FIO1DIR =0x00040000;	/* P1[18] ���o�͒[�q�ɂ���       */
    *FGPIO_FIO1MASK=0x00000000;	/* P1�ɂ͈�؃}�X�N�������Ȃ�    */
#else
	GPIOInit( 1, FAST_PORT, DIR_OUT, LED1_MASK );
#endif
	// do some "alive" blinks
	for ( i=0; i<10; i++ ) {
		LED1_FIOPIN ^= LED1_MASK;
		time_waste( 0x00090000 );
	}
	
	init_timer( TIME_INTERVAL );
	enable_timer( 0 );
	
	/* mt: enable IRQ-Exceptions on core-level thru SWI-call */
	IntEnable();
	
#ifdef UART_NUM
	UARTInit( UART_NUM, 115200 );
	UARTSend( UART_NUM, (const BYTE*)welcome, my_strlen(welcome) );
	my_uart_puts(version);
	prompt();
#endif
	
	incoming_cnt = 0;
	process_flag = 0;
	
	while ( 1 ) {
		if ( timer_counter >= 0x20 ) {
#ifdef GPIO_WITH_SET_CLR
			if ( flip ) {
				LED1_FIOCLR = LED1_MASK;
				flip = 0;
			}
			else {
				LED1_FIOSET = LED1_MASK;
				flip = 1;
			}
#else
			LED1_FIOPIN ^= LED1_MASK;
#endif
			timer_counter = 0;
		}

#ifdef UART_NUM
#if ( UART_NUM==1 )
		// This is all but a good inplementation.
		// A ring-buffer should be used but this does the job for now.
		if ( UART1Count != 0 ) {
			U1IER = IER_THRE | IER_RLS;   /* Disable RBR - buffer-read "atomic" */
			for ( i = 0; i < UART1Count; i++ ) {
				c = UART1Buffer[i];
				if ( c == ENTERKEY ) {
					process_flag = 1;
					c='\0';
				};
				if ( incoming_cnt < INBUF_SIZE ) {
					incoming_buf[incoming_cnt] = c;
					incoming_cnt++;
				}
				else {
					incoming_cnt = 0;
				}
			}
			UART1Count = 0;
			U1IER = IER_THRE | IER_RLS | IER_RBR;   /* Re-enable RBR */
#else
#error "Sorry, currently only UART1 supported"
#endif
	
			if ( process_flag ) {
				process_input( (char*)incoming_buf, incoming_cnt-1 );
				process_flag = 0;
				incoming_cnt = 0;
			}
		}
#endif

	} // main-loop
	
	return 0;
}
