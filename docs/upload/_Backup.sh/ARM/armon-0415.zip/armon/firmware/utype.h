#ifndef	_utype_h_
#define	_utype_h_

typedef unsigned char   byte;           // 8-bit
typedef unsigned char   uchar;          // 8-bit

typedef unsigned short  ushort;         // 16-bit
typedef unsigned int    word;           // 16-bit

typedef unsigned long   dword;          // 32-bit

#endif

