#ifndef __intrinsics_H
#define __intrinsics_H

//#include "LPC23xx.h"

#include "interrupt.h"


#define	__enable_interrupt()	IrqEnable()

#endif

