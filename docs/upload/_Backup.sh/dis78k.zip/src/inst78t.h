//
//	nec78k instruction table
//
//
//
//	�\����
//		L �̓����N�p�̃|�C���^�u����.
//		b �͖��߂̏��v�o�C�g��.
//		opc1�`opc4 �� ����8bit �����߃R�[�h���̂��́A���8bit�͏C���q.
//		�j���j�b�N��NULL�|�C���^�Ȃ�e�[�u�������.
//	
//	�C���q�̎��.
//		___			�g��Ȃ�.	�I�[�ƍl���Ă��悢.
//		_r_210		���W�X�^�ԍ�0�`7     �� bit[2:0] ��or����.
//		_rp_21		���W�X�^�y�A�ԍ�0�`3 �� bit[2:1] ��or����.
//		_b_654		�r�b�g�ԍ�0�`7		 �� bit[6:4] ��or����.
//		_rb_53		���W�X�^�o���N�ԍ�0�`3��bit[5,3] ��or����.
//		_fa_765		callf �̏��3bit	 �� bit[6:4] ��or����.
//		_ta_54321	callt �̃e�[�u���ԍ� �� bit[5:1] ��or����.
//		_Cbyte		#�萔.
//		_jdisp		����f�B�X�v���C�X�����g.
//		_Saddr		8bit�I�t�Z�b�g.
//		_Sfr		8bit�I�t�Z�b�g.
//		_Lowaddr	���ʃA�h���X.
//		_Hiaddr		��ʃA�h���X.
//		_Lowbyte	���ʒ萔.
//		_Hibyte		��ʒ萔.
//
//	���̑�����.
//		���̃e�[�u����S��������͖̂��ʂȂ̂ŁAopc1 �̉��ʂW�r�b�g���L�[�ɂ���
//		���炩���߃C���f�N�X���쐬���Ă���.
//
//		�������Aopc1�����������A�قȂ镡���̖��߂����݂���.
//		����āA�C���f�N�X�̃G���g���[�͂P�ł͂Ȃ��P�������X�g�ɂ���.
//		L �� next pointer�ɂȂ�.
//
// -----------------------------------------------------------------------------
// mne  ,opr1       ,opr2        L b opc1       ,opc2       ,opc3       ,opc4
// -----------------------------------------------------------------------------
//MOV:
{"MOV"  ,"r"        ,"#byte"    ,0,2,0xa0|_r_210,_Cbyte     , ___       , ___ },
{"MOV"  ,"saddr"    ,"#byte"    ,0,3,0x11       ,_Saddr     ,_Cbyte     , ___ },
{"MOV"  ,"sfr"      ,"#byte"    ,0,3,0x13       ,_Sfr       ,_Cbyte     , ___ },
{"MOV"  ,"A"        ,"r"        ,0,1,0x60|_r_210, ___       , ___       , ___ },
{"MOV"  ,"r"        ,"A"        ,0,1,0x70|_r_210, ___       , ___       , ___ },
{"MOV"  ,"A"        ,"saddr"    ,0,2,0xf0       ,_Saddr     , ___       , ___ },
{"MOV"  ,"saddr"    ,"A"        ,0,2,0xf2       ,_Saddr     , ___       , ___ },
{"MOV"  ,"A"        ,"sfr"      ,0,2,0xf4       ,_Sfr       , ___       , ___ },
{"MOV"  ,"sfr"      ,"A"        ,0,2,0xf6       ,_Sfr       , ___       , ___ },
{"MOV"  ,"A"        ,"!addr16"  ,0,3,0x8e       ,_Lowaddr   ,_Hiaddr    , ___ },
{"MOV"  ,"!addr16"  ,"A"        ,0,3,0x9e       ,_Lowaddr   ,_Hiaddr    , ___ },
{"MOV"  ,"PSW"      ,"#byte"    ,0,3,0x11       ,0x1e       ,_Cbyte     , ___ },
{"MOV"  ,"A"        ,"PSW"      ,0,2,0xf0       ,0x1e       , ___       , ___ },
{"MOV"  ,"PSW"      ,"A"        ,0,2,0xf2       ,0x1e       , ___       , ___ },
{"MOV"  ,"A"        ,"[DE]"     ,0,1,0x85       , ___       , ___       , ___ },
{"MOV"  ,"[DE]"     ,"A"        ,0,1,0x95       , ___       , ___       , ___ },
{"MOV"  ,"A"        ,"[HL]"     ,0,1,0x87       , ___       , ___       , ___ },
{"MOV"  ,"[HL]"     ,"A"        ,0,1,0x97       , ___       , ___       , ___ },
{"MOV"  ,"A"        ,"[HL+byte]",0,2,0xae       ,_Byte      , ___       , ___ },
{"MOV"  ,"[HL+byte]","A"        ,0,2,0xbe       ,_Byte      , ___       , ___ },
{"MOV"  ,"A"        ,"[HL+B]"   ,0,1,0xab       , ___       , ___       , ___ },
{"MOV"  ,"[HL+B]"   ,"A"        ,0,1,0xbb       , ___       , ___       , ___ },
{"MOV"  ,"A"        ,"[HL+C]"   ,0,1,0xaa       , ___       , ___       , ___ },
{"MOV"  ,"[HL+C]"   ,"A"        ,0,1,0xba       , ___       , ___       , ___ },
//XCH:
{"XCH"  ,"A"        ,"r"        ,0,1,0x30|_r_210, ___       , ___       , ___ },
{"XCH"  ,"A"        ,"saddr"    ,0,2,0x83       ,_Saddr     , ___       , ___ },
{"XCH"  ,"A"        ,"sfr"      ,0,2,0x93       ,_Sfr       , ___       , ___ },
{"XCH"  ,"A"        ,"!addr16"  ,0,3,0xce       ,_Lowaddr   ,_Hiaddr    , ___ },
{"XCH"  ,"A"        ,"[DE]"     ,0,1,0x05       , ___       , ___       , ___ },
{"XCH"  ,"A"        ,"[HL]"     ,0,1,0x07       , ___       , ___       , ___ },
{"XCH"  ,"A"        ,"[HL+byte]",0,2,0xde       ,_Byte      , ___       , ___ },
{"XCH"  ,"A"        ,"[HL+B]"   ,0,2,0x31       ,0x8b       , ___       , ___ },
{"XCH"  ,"A"        ,"[HL+C]"   ,0,2,0x31       ,0x8a       , ___       , ___ },
//:
// ��  r=A�������B
// 
//MOVW:
{"MOVW" ,"rp"       ,"#word"    ,0,3,0x10|_rp_21,_Lowbyte   ,_Hibyte    , ___ },
{"MOVW" ,"saddr"    ,"#word"    ,0,4,0xee       ,_Saddr     ,_Lowbyte   ,_Hibyte },
{"MOVW" ,"sfr"      ,"#word"    ,0,3,0xfe       ,_Lowbyte   ,_Hibyte    , ___ },
{"MOVW" ,"AX"       ,"saddr"    ,0,2,0x89       ,_Saddr     , ___       , ___ },
{"MOVW" ,"saddr"    ,"AX"       ,0,2,0x99       ,_Saddr     , ___       , ___ },
{"MOVW" ,"AX"       ,"sfr"      ,0,2,0xa9       ,_Sfr       , ___       , ___ },
{"MOVW" ,"sfr"      ,"AX"       ,0,2,0xb9       ,_Sfr       , ___       , ___ },
{"MOVW" ,"AX"       ,"rp"       ,0,1,0xc0|_rp_21, ___       , ___       , ___ },
{"MOVW" ,"rp"       ,"AX"       ,0,1,0xd0|_rp_21, ___       , ___       , ___ },
{"MOVW" ,"AX"       ,"!addr16"  ,0,3,0x02       ,_Lowaddr   ,_Hiaddr    , ___ },
{"MOVW" ,"!addr16"  ,"AX"       ,0,3,0x03       ,_Lowaddr   ,_Hiaddr    , ___ },
//:
// 
//XCHW:
{"XCHW" ,"AX"       ,"rp"       ,0,1,0xe0|_rp_21, ___       , ___       , ___ },
//ADD:
{"ADD"  ,"A"        ,"#byte"    ,0,2,0x0d       ,_Cbyte     , ___       , ___ },
{"ADD"  ,"saddr"    ,"#byte"    ,0,3,0x88       ,_Saddr     ,_Cbyte     , ___ },
{"ADD"  ,"A"        ,"r"        ,0,2,0x61       ,0x08|_r_210, ___       , ___ },
{"ADD"  ,"r"        ,"A"        ,0,2,0x61       ,0x00|_r_210, ___       , ___ },
{"ADD"  ,"A"        ,"saddr"    ,0,2,0x0e       ,_Saddr     , ___       , ___ },
{"ADD"  ,"A"        ,"!addr16"  ,0,3,0x08       ,_Lowaddr   ,_Hiaddr    , ___ },
{"ADD"  ,"A"        ,"[HL]"     ,0,1,0x0f       , ___       , ___       , ___ },
{"ADD"  ,"A"        ,"[HL+byte]",0,2,0x09       ,_Byte      , ___       , ___ },
{"ADD"  ,"A"        ,"[HL+B]"   ,0,2,0x31       ,0x0b       , ___       , ___ },
{"ADD"  ,"A"        ,"[HL+C]"   ,0,2,0x31       ,0x0a       , ___       , ___ },
//ADC:
{"ADC"  ,"A"        ,"#byte"    ,0,2,0x2d       ,_Cbyte     , ___       , ___ },
{"ADC"  ,"saddr"    ,"#byte"    ,0,3,0xa8       ,_Saddr     ,_Cbyte     , ___ },
{"ADC"  ,"A"        ,"r"        ,0,2,0x61       ,0x28|_r_210, ___       , ___ },
{"ADC"  ,"r"        ,"A"        ,0,2,0x61       ,0x20|_r_210, ___       , ___ },
{"ADC"  ,"A"        ,"saddr"    ,0,2,0x2e       ,_Saddr     , ___       , ___ },
{"ADC"  ,"A"        ,"!addr16"  ,0,3,0x28       ,_Lowaddr   ,_Hiaddr    , ___ },
{"ADC"  ,"A"        ,"[HL]"     ,0,1,0x2f       , ___       , ___       , ___ },
{"ADC"  ,"A"        ,"[HL+byte]",0,2,0x29       ,_Byte       , ___       , ___ },
{"ADC"  ,"A"        ,"[HL+B]"   ,0,2,0x31       ,0x2b       , ___       , ___ },
{"ADC"  ,"A"        ,"[HL+C]"   ,0,2,0x31       ,0x2a       , ___       , ___ },
//:
//                  
// ��1�Drp=BC,DE,HL�̂Ƃ��̂݁B   �Q�Dr=A�������B
// 
//SUB:
{"SUB"  ,"A"        ,"#byte"    ,0,2,0x1d       ,_Cbyte     , ___       , ___ },
{"SUB"  ,"saddr"    ,"#byte"    ,0,3,0x98       ,_Saddr     ,_Cbyte     , ___ },
{"SUB"  ,"A"        ,"r"        ,0,2,0x61       ,0x18|_r_210, ___       , ___ },
{"SUB"  ,"r"        ,"A"        ,0,2,0x61       ,0x10|_r_210, ___       , ___ },
{"SUB"  ,"A"        ,"saddr"    ,0,2,0x1e       ,_Saddr     , ___       , ___ },
{"SUB"  ,"A"        ,"!addr16"  ,0,3,0x18       ,_Lowaddr   ,_Hiaddr    , ___ },
{"SUB"  ,"A"        ,"[HL]"     ,0,1,0x1f       , ___       , ___       , ___ },
{"SUB"  ,"A"        ,"[HL+byte]",0,2,0x19       ,_Byte      , ___       , ___ },
{"SUB"  ,"A"        ,"[HL+B]"   ,0,2,0x31       ,0x1b       , ___       , ___ },
{"SUB"  ,"A"        ,"[HL+C]"   ,0,2,0x31       ,0x1a       , ___       , ___ },
// 
// 
//SUBC:
{"SUBC" ,"A"        ,"#byte"    ,0,2,0x3d       ,_Cbyte     , ___       , ___ },
{"SUBC" ,"saddr"    ,"#byte"    ,0,3,0xb8       ,_Saddr     ,_Cbyte     , ___ },
{"SUBC" ,"A"        ,"r"        ,0,2,0x61       ,0x38|_r_210, ___       , ___ },
{"SUBC" ,"r"        ,"A"        ,0,2,0x61       ,0x30|_r_210, ___       , ___ },
{"SUBC" ,"A"        ,"saddr"    ,0,2,0x3e       ,_Saddr     , ___       , ___ },
{"SUBC" ,"A"        ,"!addr16"  ,0,3,0x38       ,_Lowaddr   ,_Hiaddr    , ___ },
{"SUBC" ,"A"        ,"[HL]"     ,0,1,0x3f       , ___       , ___       , ___ },
{"SUBC" ,"A"        ,"[HL+byte]",0,1,0x39       , ___       , ___       , ___ },
{"SUBC" ,"A"        ,"[HL+B]"   ,0,2,0x31       ,0x3b       , ___       , ___ },
{"SUBC" ,"A"        ,"[HL+C]"   ,0,2,0x31       ,0x3a       , ___       , ___ },
// 
// 
// 
//AND:
{"AND"  ,"A"        ,"#byte"    ,0,2,0x5d       ,_Cbyte     , ___       , ___ },
{"AND"  ,"saddr"    ,"#byte"    ,0,3,0xd8       ,_Saddr     ,_Cbyte     , ___ },
{"AND"  ,"A"        ,"r"        ,0,2,0x61       ,0x58|_r_210, ___       , ___ },
{"AND"  ,"r"        ,"A"        ,0,2,0x61       ,0x50|_r_210, ___       , ___ },
{"AND"  ,"A"        ,"saddr"    ,0,2,0x5e       ,_Saddr     , ___       , ___ },
{"AND"  ,"A"        ,"!addr16"  ,0,3,0x58       ,_Lowaddr   ,_Hiaddr    , ___ },
{"AND"  ,"A"        ,"[HL]"     ,0,1,0x5f       , ___       , ___       , ___ },
{"AND"  ,"A"        ,"[HL+byte]",0,2,0x59       ,_Byte      , ___       , ___ },
{"AND"  ,"A"        ,"[HL+B]"   ,0,2,0x31       ,0x5b       , ___       , ___ },
{"AND"  ,"A"        ,"[HL+C]"   ,0,2,0x31       ,0x5a       , ___       , ___ },
// 
// 
// ��  r=A�������B
// 
// 
//OR:
{"OR"   ,"A"        ,"#byte"    ,0,2,0x6d       ,_Cbyte     , ___       , ___ },
{"OR"   ,"saddr"    ,"#byte"    ,0,3,0xe8       ,_Saddr     ,_Cbyte     , ___ },
{"OR"   ,"A"        ,"r"        ,0,2,0x61       ,0x68|_r_210, ___       , ___ },
{"OR"   ,"r"        ,"A"        ,0,2,0x61       ,0x60|_r_210, ___       , ___ },
{"OR"   ,"A"        ,"saddr"    ,0,2,0x6e       ,_Saddr     , ___       , ___ },
{"OR"   ,"A"        ,"!addr16"  ,0,3,0x68       ,_Lowaddr   ,_Hiaddr    , ___ },
{"OR"   ,"A"        ,"[HL]"     ,0,1,0x6f       , ___       , ___       , ___ },
{"OR"   ,"A"        ,"[HL+byte]",0,2,0x69       ,_Byte      , ___       , ___ },
{"OR"   ,"A"        ,"[HL+B]"   ,0,2,0x31       ,0x6b       , ___       , ___ },
{"OR"   ,"A"        ,"[HL+C]"   ,0,2,0x31       ,0x6a       , ___       , ___ },
// 
//XOR:
{"XOR"  ,"A"        ,"#byte"    ,0,2,0x7d       ,_Cbyte     , ___       , ___ },
{"XOR"  ,"saddr"    ,"#byte"    ,0,3,0xf8       ,_Saddr     ,_Cbyte     , ___ },
{"XOR"  ,"A"        ,"r"        ,0,2,0x61       ,0x78|_r_210, ___       , ___ },
{"XOR"  ,"r"        ,"A"        ,0,2,0x61       ,0x70|_r_210, ___       , ___ },
{"XOR"  ,"A"        ,"saddr"    ,0,2,0x7e       ,_Saddr     , ___       , ___ },
{"XOR"  ,"A"        ,"!addr16"  ,0,3,0x78       ,_Lowaddr   ,_Hiaddr    , ___ },
{"XOR"  ,"A"        ,"[HL]"     ,0,1,0x7f       , ___       , ___       , ___ },
{"XOR"  ,"A"        ,"[HL+byte]",0,2,0x79       ,_Byte      , ___       , ___ },
{"XOR"  ,"A"        ,"[HL+B]"   ,0,2,0x31       ,0x7b       , ___       , ___ },
{"XOR"  ,"A"        ,"[HL+C]"   ,0,2,0x31       ,0x7a       , ___       , ___ },
// 
//CMP:
{"CMP"  ,"A"        ,"#byte"    ,0,2,0x4d       ,_Cbyte     , ___       , ___ },
{"CMP"  ,"saddr"    ,"#byte"    ,0,3,0xc8       ,_Saddr     ,_Cbyte     , ___ },
{"CMP"  ,"A"        ,"r"        ,0,2,0x61       ,0x48|_r_210, ___       , ___ },
{"CMP"  ,"r"        ,"A"        ,0,2,0x61       ,0x40|_r_210, ___       , ___ },
{"CMP"  ,"A"        ,"saddr"    ,0,2,0x4e       ,_Saddr     , ___       , ___ },
{"CMP"  ,"A"        ,"!addr16"  ,0,3,0x48       ,_Lowaddr   ,_Hiaddr    , ___ },
{"CMP"  ,"A"        ,"[HL]"     ,0,1,0x4f       , ___       , ___       , ___ },
{"CMP"  ,"A"        ,"[HL+byte]",0,2,0x49       ,_Byte      , ___       , ___ },
{"CMP"  ,"A"        ,"[HL+B]"   ,0,2,0x31       ,0x4b       , ___       , ___ },
{"CMP"  ,"A"        ,"[HL+C]"   ,0,2,0x31       ,0x4a       , ___       , ___ },
// 
// ��  r=A�������B
// 
//ADDW:
{"ADDW" ,"AX"       ,"#word"    ,0,3,0xca       ,_Lowbyte   ,_Hibyte    , ___ },
//SUBW:
{"SUBW" ,"AX"       ,"#word"    ,0,3,0xda       ,_Lowbyte   ,_Hibyte    , ___ },
//CMPW:
{"CMPW" ,"AX"       ,"#word"    ,0,3,0xea       ,_Lowbyte   ,_Hibyte    , ___ },
//MULU:
{"MULU" ,"X"        ,NULL       ,0,2,0x31       ,0x88       , ___       , ___ },
//DIVUW:
{"DIVUW","C"        ,NULL       ,0,2,0x31       ,0x82       , ___       , ___ },
//INC:
{"INC"  ,"r"        ,NULL       ,0,1,0x40|_r_210, ___       , ___       , ___ },
{"INC"  ,"saddr"    ,NULL       ,0,2,0x81       ,_Saddr     , ___       , ___ },
//DEC:
{"DEC"  ,"r"        ,NULL       ,0,1,0x50|_r_210, ___       , ___       , ___ },
{"DEC"  ,"saddr"    ,NULL       ,0,2,0x91       ,_Saddr     , ___       , ___ },
//INCW:
{"INCW" ,"rp"       ,NULL       ,0,1,0x80|_rp_21, ___       , ___       , ___ },
//DECW:
{"DECW" ,"rp"       ,NULL       ,0,1,0x90|_rp_21, ___       , ___       , ___ },
//ROR:
{"ROR"  ,"A"        ,"1"        ,0,1,0x24       , ___       , ___       , ___ },
//ROL:
{"ROL"  ,"A"        ,"1"        ,0,1,0x26       , ___       , ___       , ___ },
//RORC:
{"RORC" ,"A"        ,"1"        ,0,1,0x25       , ___       , ___       , ___ },
//ROLC:
{"ROLC" ,"A"        ,"1"        ,0,1,0x27       , ___       , ___       , ___ },
//ROR4:
{"ROR4" ,"[HL]"     ,NULL       ,0,2,0x31       ,0x90       , ___       , ___ },
//ROL4:
{"ROL4" ,"[HL]"     ,NULL       ,0,2,0x31       ,0x80       , ___       , ___ },
//ADJBA:
{"ADJBA",NULL       ,NULL       ,0,2,0x61       ,0x80       , ___       , ___ },
//ADJBS:
{"ADJBS",NULL       ,NULL       ,0,2,0x61       ,0x90       , ___       , ___ },
// 
//MOV1:
{"MOV1" ,"CY"       ,"saddr.bit",0,3,0x71       ,0x04|_b_654,_Saddr     , ___ },
{"MOV1" ,"CY"       ,"sfr.bit"  ,0,3,0x71       ,0x0c|_b_654,_Sfr       , ___ },
{"MOV1" ,"CY"       ,"A.bit"    ,0,2,0x61       ,0x8c|_b_654, ___       , ___ },
{"MOV1" ,"CY"       ,"PSW.bit"  ,0,3,0x71       ,0x04|_b_654,0x1e       , ___ },
{"MOV1" ,"CY"       ,"[HL].bit" ,0,2,0x71       ,0x84|_b_654, ___       , ___ },
//
{"MOV1" ,"saddr.bit","CY"       ,0,3,0x71       ,0x01|_b_654,_Saddr     , ___ },
{"MOV1" ,"sfr.bit"  ,"CY"       ,0,3,0x71       ,0x09|_b_654,_Sfr       , ___ },
{"MOV1" ,"A.bit"    ,"CY"       ,0,2,0x61       ,0x89|_b_654, ___       , ___ },
{"MOV1" ,"PSW.bit"  ,"CY"       ,0,3,0x71       ,0x01|_b_654,0x1e       , ___ },
{"MOV1" ,"[HL].bit" ,"CY"       ,0,2,0x71       ,0x81|_b_654, ___       , ___ },
//AND1:
{"AND1" ,"CY"       ,"saddr.bit",0,3,0x71       ,0x05|_b_654,_Saddr     , ___ },
{"AND1" ,"CY"       ,"sfr.bit"  ,0,3,0x71       ,0x0d|_b_654,_Sfr       , ___ },
{"AND1" ,"CY"       ,"A.bit"    ,0,2,0x61       ,0x8d|_b_654, ___       , ___ },
{"AND1" ,"CY"       ,"PSW.bit"  ,0,3,0x71       ,0x05|_b_654,0x1e       , ___ },
{"AND1" ,"CY"       ,"[HL].bit" ,0,2,0x71       ,0x85|_b_654, ___       , ___ },
//OR1:
{"OR1"  ,"CY"       ,"saddr.bit",0,3,0x71       ,0x06|_b_654,_Saddr     , ___ },
{"OR1"  ,"CY"       ,"sfr.bit"  ,0,3,0x71       ,0x0e|_b_654,_Sfr       , ___ },
{"OR1"  ,"CY"       ,"A.bit"    ,0,2,0x61       ,0x8e|_b_654, ___       , ___ },
{"OR1"  ,"CY"       ,"PSW.bit"  ,0,3,0x71       ,0x06|_b_654,0x1e       , ___ },
{"OR1"  ,"CY"       ,"[HL].bit" ,0,2,0x71       ,0x86|_b_654, ___       , ___ },
//XOR1:
{"XOR1" ,"CY"       ,"saddr.bit",0,3,0x71       ,0x07|_b_654,_Saddr     , ___ },
{"XOR1" ,"CY"       ,"sfr.bit"  ,0,3,0x71       ,0x0f|_b_654,_Sfr       , ___ },
{"XOR1" ,"CY"       ,"A.bit"    ,0,2,0x61       ,0x8f|_b_654, ___       , ___ },
{"XOR1" ,"CY"       ,"PSW.bit"  ,0,3,0x71       ,0x07|_b_654,0x1e       , ___ },
{"XOR1" ,"CY"       ,"[HL].bit" ,0,2,0x71       ,0x87|_b_654, ___       , ___ },
//SET1:
{"SET1" ,"saddr.bit",NULL       ,0,2,0x0a|_b_654,_Saddr     , ___       , ___ },
{"SET1" ,"sfr.bit"  ,NULL       ,0,3,0x71       ,0x0a|_b_654,_Sfr      , ___ },
{"SET1" ,"A.bit"    ,NULL       ,0,2,0x61       ,0x8a|_b_654, ___       , ___ },
{"SET1" ,"PSW.bit"  ,NULL       ,0,2,0x0a|_b_654,0x1e       , ___       , ___ },
{"SET1" ,"[HL].bit" ,NULL       ,0,2,0x71       ,0x82|_b_654, ___       , ___ },
//CLR1:
{"CLR1" ,"saddr.bit",NULL       ,0,2,0x0b|_b_654,_Saddr     , ___       , ___ },
{"CLR1" ,"sfr.bit"  ,NULL       ,0,3,0x71       ,0x0b|_b_654,_Sfr       , ___ },
{"CLR1" ,"A.bit"    ,NULL       ,0,2,0x61       ,0x8b|_b_654, ___       , ___ },
{"CLR1" ,"PSW.bit"  ,NULL       ,0,2,0x0b|_b_654,0x1e       , ___       , ___ },
{"CLR1" ,"[HL].bit" ,NULL       ,0,2,0x71       ,0x83|_b_654, ___       , ___ },
//SET1:
{"SET1" ,"CY"       ,NULL       ,0,1,0x20       , ___       , ___       , ___ },
//CLR1:
{"CLR1" ,"CY"       ,NULL       ,0,1,0x21       , ___       , ___       , ___ },
//NOT1:
{"NOT1" ,"CY"       ,NULL       ,0,1,0x01       , ___       , ___       , ___ },
//CALL:
{"CALL" ,"!addr16"  ,NULL       ,0,3,0x9a       ,_Lowaddr   ,_Hiaddr    , ___ },
//CALLF:
{"CALLF","!addr11"  ,NULL       ,0,2,0x0c|_fa_765,_fa_low   , ___       , ___ },
//CALLT:
{"CALLT","[addr5]"  ,NULL       ,0,1,0xc1|_ta_54321, ___    , ___       , ___ },
//BRK:
{"BRK"  ,NULL       ,NULL       ,0,1,0xbf       , ___       , ___       , ___ },
//RET:
{"RET"  ,NULL       ,NULL       ,0,1,0xaf       , ___       , ___       , ___ },
//RETB:
{"RETB" ,NULL       ,NULL       ,0,1,0x9f       , ___       , ___       , ___ },
//RETI:
{"RETI" ,NULL       ,NULL       ,0,1,0x8f       , ___       , ___       , ___ },
//PUSH:
{"PUSH" ,"PSW"      ,NULL       ,0,1,0x22       , ___       , ___       , ___ },
{"PUSH" ,"rp"       ,NULL       ,0,1,0xb1|_rp_21, ___       , ___       , ___ },
//POP:
{"POP"  ,"PSW"      ,NULL       ,0,1,0x23       , ___       , ___       , ___ },
{"POP"  ,"rp"       ,NULL       ,0,1,0xb0|_rp_21, ___       , ___       , ___ },
//MOVW:
{"MOVW" ,"SP"       ,"#word"    ,0,4,0xee       ,0x1c       ,_Lowbyte   ,_Hibyte },
{"MOVW" ,"SP"       ,"AX"       ,0,2,0x99       ,0x1c       , ___       , ___ },
{"MOVW" ,"AX"       ,"SP"       ,0,2,0x89       ,0x1c       , ___       , ___ },
//BR:
{"BR"   ,"!addr16"  ,NULL       ,0,3,0x9b       ,_Lowaddr   ,_Hiaddr    , ___ },
{"BR"   ,"$addr16"  ,NULL       ,0,2,0xfa       ,_jdisp     , ___       , ___ },
{"BR"   ,"AX"       ,NULL       ,0,2,0x31       ,0x98       , ___       , ___ },
//BC:
{"BC"   ,"$addr16"  ,NULL       ,0,2,0x8d       ,_jdisp     , ___       , ___ },
//BNC:
{"BNC"  ,"$addr16"  ,NULL       ,0,2,0x9d       ,_jdisp     , ___       , ___ },
//BZ:
{"BZ"   ,"$addr16"  ,NULL       ,0,2,0xad       ,_jdisp     , ___       , ___ },
//BNZ:
{"BNZ"  ,"$addr16"  ,NULL       ,0,2,0xbd       ,_jdisp     , ___       , ___ },
//BT:
{"BT"   ,"saddr.bit","$addr16"  ,0,3,0x8c|_b_654,_Saddr     ,_jdisp     , ___ },
{"BT"   ,"sfr.bit"  ,"$addr16"  ,0,4,0x31       ,0x06|_b_654,_Sfr       ,_jdisp },
{"BT"   ,"A.bit"    ,"$addr16"  ,0,3,0x31       ,0x0e|_b_654,_jdisp     , ___ },
{"BT"   ,"PSW.bit"  ,"$addr16"  ,0,3,0x8c|_b_654,0x1e       ,_jdisp     , ___ },
{"BT"   ,"[HL].bit" ,"$addr16"  ,0,3,0x31       ,0x86|_b_654,_jdisp     , ___ },
//BF:
{"BF"   ,"saddr.bit","$addr16"  ,0,4,0x31       ,0x03|_b_654,_Saddr     ,_jdisp },
{"BF"   ,"sfr.bit"  ,"$addr16"  ,0,4,0x31       ,0x07|_b_654,_Sfr       ,_jdisp },
{"BF"   ,"A.bit"    ,"$addr16"  ,0,3,0x31       ,0x0f|_b_654,_jdisp     , ___ },
{"BF"   ,"PSW.bit"  ,"$addr16"  ,0,4,0x31       ,0x03|_b_654,0x1e       ,_jdisp },
{"BF"   ,"[HL].bit" ,"$addr16"  ,0,3,0x31       ,0x87|_b_654,_jdisp     , ___ },
//BTCLR:
{"BTCLR","saddr.bit","$addr16"  ,0,4,0x31       ,0x01|_b_654,_Saddr     ,_jdisp },
{"BTCLR","sfr.bit"  ,"$addr16"  ,0,4,0x31       ,0x05|_b_654,_Sfr       ,_jdisp },
{"BTCLR","A.bit"    ,"$addr16"  ,0,3,0x31       ,0x0d|_b_654,_jdisp     , ___ },
{"BTCLR","PSW.bit"  ,"$addr16"  ,0,4,0x31       ,0x01|_b_654,0x1e       ,_jdisp },
{"BTCLR","[HL].bit" ,"$addr16"  ,0,3,0x31       ,0x85|_b_654,_jdisp     , ___ },
//DBNZ:
{"DBNZ" ,"$addr16"  ,NULL       ,0,2,0x8b       ,_jdisp     , ___       , ___ },
{"DBNZ" ,"C"        ,"$addr16"  ,0,2,0x8a       ,_jdisp     , ___       , ___ },
{"DBNZ" ,"saddr"    ,"$addr16"  ,0,3,0x04       ,_Saddr     ,_jdisp     , ___ },
//SEL:
{"SEL"  ,"RBn"      ,NULL       ,0,2,0x61       ,0xd0|_rb_53, ___       , ___ },
//NOP:
{"NOP"  ,NULL       ,NULL       ,0,1,0x00       , ___       , ___       , ___ },
//EI:
{"EI"   ,NULL       ,NULL       ,0,2,0x7a       ,0x1e       , ___       , ___ },
//DI:
{"DI"   ,NULL       ,NULL       ,0,2,0x7b       ,0x1e       , ___       , ___ },
//HALT:
{"HALT" ,NULL       ,NULL       ,0,2,0x71       ,0x10       , ___       , ___ },
//STOP:
{"STOP" ,NULL       ,NULL       ,0,2,0x71       ,0x00       , ___       , ___ },
//:

// End of Table:
{NULL   ,NULL       ,NULL       ,0,0, ___       , ___       , ___       , ___ },

// -----------------------------------------------------------------------------
// mne  opr1     ,opr2      ;opc1       ,opc2       ,opc3       ,opc4
// -----------------------------------------------------------------------------
// 
