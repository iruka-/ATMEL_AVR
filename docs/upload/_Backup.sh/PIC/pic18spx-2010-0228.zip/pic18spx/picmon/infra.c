/*********************************************************************
 *	�ԊO�������R���p���X����͂��ĕ\������.
 *********************************************************************
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <conio.h>		// getch() kbhit()

#include "monit.h"
#include "hidasp.h"
#include "util.h"

#define	DATA_BIT	0x01

#define	T1			4		//
#define	MARK_0		4		//
#define	SPACE_0		4		//
#define	SPACE_1		12		//

#define	MARK_HD		36		//
#define	SPACE_HD	18		//

#define	MAX_BIT		1024
uchar bit_buf[MAX_BIT];
int	  bit_ptr;

void add_bit(int b)
{
	if(	bit_ptr < MAX_BIT) {
		bit_buf[bit_ptr++]=b;
	}
}

void print_infra_1(int mark,int space)
{
	static int bits=0;
	if( space >= (MARK_HD + SPACE_HD)*2 ) {
		printf(".\n");
	}

	if( (mark + space) >= (MARK_HD + SPACE_HD - 10) ) {
		printf(" HDR:");
		bits=0;
		bit_ptr=0;
	}else{
		if( ( mark >= 2 ) && ( mark <= (MARK_0 + 3) ) ) {
			if(space < SPACE_0 * 2) {
				printf("0");add_bit(0);
			}else{
				printf("1");add_bit(1);
			}
		}else{
			printf("?");add_bit(0);
		}
		bits++;
		if(	bits>=8 ) {
			bits=0;
			printf("_");
		}
	}
}

void print_infra(int c,int len)
{
	static int mark_len=0;
	if(c) {
		mark_len = len;
	}else{
		print_infra_1(mark_len,len);
		mark_len = 0;
	}
}

void print_hex_code(uchar *s,int len)
{
	int i,byte=0,m=0x80;
	printf(" HEX:");

	for(i=0;i<len;i++) {
		if((i&7)==0) {
			m=0x80;
			byte=0;
		}
		if(s[i]) {
			byte|=m;
		}
		m>>=1;
		if((i&7)==7) {
			printf("%02x ",byte);
		}
	}
	printf("\n");
}

/*********************************************************************
 *	�ԊO�������R���p���X����͂��ĕ\������.
 *********************************************************************
 *	����
 *	 buf[] : 10kHz�T���v�����ꂽ porta �̃��W�A�i�f�[�^. (LSB�̂ݎg�p)
 *	 cnt   : �L���T���v����.
 */
void analize_infra(uchar *buf,int cnt)
{
	int i,c,len,f;

	len = 0;	//�A����.
	f = buf[0] & DATA_BIT;	//���O�̒l.
	for(i=0;i<cnt;i++) {
		c = buf[i] & DATA_BIT;
		if( c != f ) {
#if	0
			if(f) {
				printf("*H:%3d\n",len);
			}else{
				printf("*L:%3d\n",len);
			}
#endif
			print_infra(c,len);
			f = c;
			len=0;
		}else{
			len++;
		}
	}
	print_hex_code(bit_buf,bit_ptr);
}


/*********************************************************************
 *
 *********************************************************************
 */

