/********************************************************************
 *	�ȈՃ��j�^
 ********************************************************************
 */
#include "usb/typedefs.h"
#include "usb/usb.h"
#include "io_cfg.h"
#include "monit.h"
#include "hidcmd.h"

/********************************************************************
 *	
 ********************************************************************
 */
#define	PACKET_SIZE		64
#define	INCLUDE_ISP_CMD	1
#define	INCLUDE_FUSION	1

/********************************************************************
 *	
 ********************************************************************
 */
typedef union {
	uchar raw[PACKET_SIZE];

	struct{
		uchar  cmd;
		uchar  size;
		ushort adrs;
		uchar  data[PACKET_SIZE - 4];
	};
} Packet;

/********************************************************************
 *	
 ********************************************************************
 */
#pragma udata SomeSectionName1
uchar ToPcRdy = 0;


#pragma udata SomeSectionName2
Packet PacketFromPC;

#pragma udata SomeSectionName3
Packet PacketToPC;

static uchar currentPosition;
static uchar bytesRemaining; // Receive Data Pointer
static uchar page_mode;
static uchar page_addr;
static uchar page_addr_h;
static uchar wait;
static uchar programmer_mode;


void  UserInit(void);
uchar usi_trans(uchar data);
void  usi_init(void);


#pragma code

#include "usi_pic18.h"


static void isp_command(uchar *data) {
	uchar i;
	for (i=0;i<4;i++) {
		PacketToPC.raw[i]=usi_trans(data[i]);
	}
}

/********************************************************************
 *	������.
 ********************************************************************
 */
void UserInit(void)
{
    mInitAllLEDs();		//Init them off.
	timer2_interval(5);	// '-d5'
	ToPcRdy = 0;
}
/********************************************************************
 *	���j�^�R�}���h��M�Ǝ��s.
 ********************************************************************
 */
void ProcessIO(void)
{
	uchar i,size,area,data0;
	uchar *p;
	
	if( ToPcRdy == 0 )
	if(!mHIDRxIsBusy()) {	//��M�f�[�^������΁A��M�f�[�^���󂯎��.
		HIDRxReport((char *)&PacketFromPC, 64);
		PacketToPC.raw[0]=PacketFromPC.raw[0];		// CMD ECHOBACK

		switch(PacketFromPC.cmd) {
		 case HIDASP_TEST:
			PacketToPC.raw[1]=0x25;					// PIC25
			PacketToPC.raw[2]=0x1;					// version.L
			PacketToPC.raw[3]=0x1;					// version.H
			PacketToPC.raw[4]=PacketFromPC.raw[1];	// ECHOBACK
			ToPcRdy = 1;
			break;

		 case HIDASP_PEEK:
		 	size      = PacketFromPC.size;
			area = size & 0xc0;
			size = size & 0x3f;
		 	p = (uchar*)PacketFromPC.adrs;

			if(area) {
				PacketFromPC.data[0]=0;	// TBLPTRU���[���N���A.
				TBLPTR = (unsigned short long)PacketFromPC.adrs;
				
				for(i=0;i<size;i++) {
    					_asm
						tblrdpostinc
						_endasm
					PacketToPC.raw[i]=TABLAT;
				}
			}else{
				for(i=0;i<size;i++) {
					PacketToPC.raw[i]=*p++;
				}
			}
			ToPcRdy = 1;
			break;

		 case HIDASP_POKE:
		 	area = PacketFromPC.size;
		 	p = (uchar*)PacketFromPC.adrs;

#define	Mask1	PacketFromPC.data[1]
#define	Data0	PacketFromPC.data[0]

			if( Mask1 ) {	//�}�X�N��������.
				*p = (*p & Mask1) | Data0;
			}else{			//�ʏ폑������.
				*p = Data0;
			}
			break;
			
#if	INCLUDE_ISP_CMD
		 case HIDASP_SET_STATUS:	// PORT�ւ̏o�͐���
		/* ISP�p�̃s����Hi-Z���� */
		/* ISP�ڍs�̎菇���A�t�@�[�����Ŏ��� */
			if(PacketFromPC.raw[2] & 0x10) {// RST�����̏ꍇ
				ispDisconnect();
			}else{
				if(PacketFromPC.raw[2] & 0x80) {// RST��Ԃ�SCK H�� SCK�p���X�v��
					ispSckPulse();
				} else {
					ispConnect();
				}
			}
			PacketToPC.raw[0] = 0xaa;	/* �R�}���h���s������HOST�ɒm�点��. */
			ToPcRdy = 1;
			break;
#endif	/* INCLUDE_ISP_CMD */

		 case HIDASP_CMD_TX:	// PORT�ւ̏o�͐���(�ԓ��s�v)
		 case HIDASP_CMD_TX_1:	// PORT�ւ̏o�͐���
			isp_command( &PacketFromPC.raw[1]);
			ToPcRdy = PacketFromPC.cmd & 1;	// LSB��On�Ȃ�ԓ����K�v.
			break;

		 case HIDASP_SET_PAGE:  // Page set
			page_mode = PacketFromPC.raw[1];
			page_addr = PacketFromPC.raw[2];
			page_addr_h = PacketFromPC.raw[3];

			break;


#if	INCLUDE_FUSION
		 case HIDASP_PAGE_TX:
		 case HIDASP_PAGE_TX+1:
		 case HIDASP_PAGE_TX+2:
		 case HIDASP_PAGE_TX+3:
		 case HIDASP_PAGE_TX+4:
		 case HIDASP_PAGE_TX+5:
		 case HIDASP_PAGE_TX+6:
		 case HIDASP_PAGE_TX+7:

		//
		//	page_write�J�n����page_addr��data[1]�ŏ�����.
		//
		if(PacketFromPC.cmd & (HIDASP_PAGE_TX_START & MODE_MASK)) {
			page_mode = 0x40;
			page_addr = 0;
			page_addr_h = 0;
		}
		//
		//	page_write (�܂���page_read) �̎��s.
		//
		for(i=0;i<PacketFromPC.size;i++) {
			usi_trans(page_mode);
			usi_trans(page_addr_h);
			usi_trans(page_addr);
			PacketToPC.raw[i]=usi_trans(PacketFromPC.raw[i+2]);
			if (page_mode & 0x88) { // EEPROM or FlashH
				page_addr++;
				if(page_addr==0) {page_addr_h++;}
				page_mode&=~0x08;
			} else {
				page_mode|=0x08;
			}
		}
		//
		//	isp_command(Flash��������)�̎��s.
		//
		if(PacketFromPC.cmd & (HIDASP_PAGE_TX_FLUSH & MODE_MASK)) {
			isp_command( &PacketFromPC.raw[PacketFromPC.size+2]);
		}
			ToPcRdy = PacketFromPC.cmd & 1;	// LSB��On�Ȃ�ԓ����K�v.
		 	break;
#endif	/* INCLUDE_FUSION */

		 case HIDASP_SET_DELAY:
			timer2_interval(PacketFromPC.raw[1]);	// '-dN'
		 	break;
		 default:
		 	break;
		}
	}

	if( ToPcRdy ) {
		if(!mHIDTxIsBusy()) {
			HIDTxReport((char *)&PacketToPC, 64);
			ToPcRdy = 0;
		}
	}
}
/********************************************************************
 *	
 ********************************************************************
 */
