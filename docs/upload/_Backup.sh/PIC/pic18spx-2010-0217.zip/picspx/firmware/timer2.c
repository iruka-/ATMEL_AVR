/********************************************************************
 *	�^�C�}�[�Q (SPI�N���b�N����)
 ********************************************************************
 */
#include "usb/typedefs.h" 
#include "usb/usb.h"      
#include "io_cfg.h"       

#include <timers.h>       

/**********************************************************************
 *	������.
 **********************************************************************
 *
	prescale:
			0=  1/1
			1=  1/4
			2= 1/16
	period: n (1�`255)
			 1/n


 */
void timer2_init(uchar prescale,uchar period)
{
    OpenTimer2(prescale);
	PR2 = period;
}


/*------------------------------------------------------------------------
	SPI���䃌�W�X�^���}�X�^�[���[�h�ŏ���������.
    -d0 | fOSC/4  ... 3MHz
    -d1 | fOSC/8  ... 1.5MHz
    -d2 | fOSC/16 ... 750kHz
    -d3 | fOSC/32 ... 375kHz
    -d4 | fOSC/64 ... 187kHz
    -d5 | fOSC/64 ... 187kHz
    -d6 | fOSC/128...  93kHz
 *------------------------------------------------------------------------
 */
void timer2_interval(uchar spi_delay)
{
	if	   (spi_delay==0) {timer2_init(0,4-1);}		// -d0 | fOSC/4  ...   3MHz
	else if(spi_delay==1) {timer2_init(0,8-1);}		// -d1 | fOSC/8  ... 1.5MHz
	else if(spi_delay==2) {timer2_init(1,4-1);}		// -d2 | fOSC/16 ... 750kHz
	else if(spi_delay==3) {timer2_init(1,8-1);}		// -d3 | fOSC/32 ... 375kHz
	else if(spi_delay==4) {timer2_init(2,4-1);}		// -d4 | fOSC/64 ... 187kHz
	else if(spi_delay>=5) {
		timer2_init(2,spi_delay);					// -d5�`| fOSC/128 ... 93kHz
	}
}
/**********************************************************************
 *	
 **********************************************************************
 */


