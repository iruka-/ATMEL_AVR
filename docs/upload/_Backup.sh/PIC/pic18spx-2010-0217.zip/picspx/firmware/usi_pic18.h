/*------------------------------------------------------------------------
 *		PIC18F�p usi_trans()�֐�.
 *------------------------------------------------------------------------
�֐��ꗗ:

 void  portInit(void)			�N����Port������;
 void  ispConnect()             SPI�ڑ�;
 void  ispDisconnect()          SPI�J��;
 uchar usi_trans(char cData)	SPI�]��1�o�C�g���s;
 
 *------------------------------------------------------------------------
25:RC6=TX  = Rset
33:RB0=SDI = MISO
34:RB1=SCK = SCK
26:RC7=SDO = MOSI
 */

//	PORTB PIN Setting
//#define	ISP_DDR		DDRB
//#define	ISP_OUT		PORTB

//	PORTB PIN ASSIGN

//	�o�̓f�[�^.
#define	ISP_SCK		LATBbits.LATB1			/* Target SCK */
#define	ISP_MISO	LATBbits.LATB0			/* Target MISO */
#define	ISP_MOSI	LATCbits.LATC7			/* Target MOSI */
#define	ISP_RST		LATCbits.LATC6			/* Target RESET */

//	0=�o��
#define	DDR_SCK		TRISBbits.TRISB1			/* Target SCK */
#define	DDR_MISO	TRISBbits.TRISB0			/* Target MISO */
#define	DDR_MOSI	TRISCbits.TRISC7			/* Target MOSI */
#define	DDR_RST		TRISCbits.TRISC6			/* Target RESET */

//	�ǂݍ���.
#define	PORT_SCK	PORTBbits.PORTB1			/* Target SCK */
#define	PORT_MISO	PORTBbits.PORTB0			/* Target MISO */
#define	PORT_MOSI	PORTCbits.PORTC7			/* Target MOSI */
#define	PORT_RST	TRISCbits.PORTC6			/* Target RESET */

//LATCbits.LATC0
//#define mInitAllLEDs()      LATC &= 0xFC; TRISC &= 0xFC;


/*------------------------------------------------------------------------
	SPI���䃌�W�X�^���}�X�^�[���[�h�ŏ���������.
    -d0 | fOSC/4  ... 3MHz
    -d1 | fOSC/8  ... 1.5MHz
    -d2 | fOSC/16 ... 750kHz
    -d3 | fOSC/32 ... 375kHz
    -d4 | fOSC/64 ... 187kHz
    -d5 | fOSC/64 ... 187kHz
    -d6 | fOSC/128...  93kHz

    -d7�ȍ~��-d6�Ɠ����ł�.  
    -d4��d5������������ɂȂ��Ă��܂����A�n�[�h�E�F�A�̎d�l�ł�.
    -d255 �́A8bit�̃I�[�o�t���[���ɂ��A6MHz�ݒ�ɂȂ�܂�.
 *------------------------------------------------------------------------
 */
extern void timer2_init(uchar prescale,uchar period);


void SPI_MasterInit(void)
{
	SSPSTAT=0b01000000;	// SMP=0 , CKE=1;
//	SSPCON1=0b00000000;	// SCK=12MHz/1 , CKP(Clock Polarity)=0
//	SSPCON1=0b00000001;	// SCK=12MHz/16
//	SSPCON1=0b00000010;	// SCK=12MHz/64
	SSPCON1=0b00000011;	// SCK=TMR2/2

	DDR_SCK=1;			// Hi-Z
	SSPCON1bits.SSPEN=1;// Enable SSP
	DDR_SCK=0;			// OUT
}

void SPI_MasterExit(void)
{
	SSPCON1bits.SSPEN=0;// Disable SSP
}

//------------------------------------------------------------------------
//uchar SPI_MasterTransmit(char cData)
//	SPI�]�����P�o�C�g�����s����.
uchar usi_trans(uchar data)
{
	SSPBUF = data;
	while(!SSPSTATbits.BF) {};  // BF = SSP Buffer Full . 1=Full 0=Empty
	return SSPBUF;
}


//------------------------------------------------------------------------
void ispDelay()
{
	uchar i;
	for(i=0;i<100;i++) ;
//	delay_10us(1);
}
//------------------------------------------------------------------------
void ispConnect() {
  /* all ISP pins are inputs before */

  /* reset device */
//  ISP_OUT &= ~(1 << ISP_RST);   /* RST low */
//  ISP_OUT &= ~(1 << ISP_SCK);   /* SCK low */
	ISP_RST=0;
	ISP_SCK=0;

  /* now set output pins */
//  ISP_DDR |= (1 << ISP_RST) | (1 << ISP_SCK) | (1 << ISP_MOSI);
	DDR_RST=0;
	DDR_SCK=0;
	DDR_MOSI=0;
	DDR_MISO=1;


  	SPI_MasterInit();

  /* positive reset pulse > 2 SCK (target) */
  	ispDelay();	// ISP_OUT |= (1 << ISP_RST);    /* RST high */
	ISP_RST = 1;
  	ispDelay();	// ISP_OUT &= ~(1 << ISP_RST);   /* RST low */
	ISP_RST = 0;
}

//------------------------------------------------------------------------
static void ispDisconnect() {
  
  /* set all ISP pins inputs */
//  ISP_DDR &= ~((1 << ISP_RST) | (1 << ISP_SCK) | (1 << ISP_MOSI));
	DDR_RST=1;
	DDR_SCK=1;
	DDR_MOSI=1;
  /* switch pullups off */
//  ISP_OUT &= ~((1 << ISP_RST) | (1 << ISP_SCK) | (1 << ISP_MOSI));
	ISP_RST=0;
	ISP_SCK=0;
	ISP_MOSI=0;

  /* disable hardware SPI */
//  SPCR = 0;
  SPI_MasterExit();
}

static	void ispSckPulse(void)
{
//	ISP_DDR=(1<<ISP_MOSI)|(1<<ISP_SCK);  /*MOSI,SCK=�o�́A���͓��͂ɐݒ� */
  /* disable hardware SPI */
//  SPCR = 0;
  	SPI_MasterExit();

//	ISP_OUT |= (1 << ISP_SCK);		/* SCK high */
	ISP_SCK = 1;
    ispDelay();
//	ISP_OUT &= ~(1 << ISP_SCK);		/* SCK Low */
	ISP_SCK = 0;
    ispDelay();

	SPI_MasterInit();
}

