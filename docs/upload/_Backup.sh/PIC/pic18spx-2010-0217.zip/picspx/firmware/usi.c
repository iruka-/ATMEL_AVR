/**********************************************************************
 *	SPI
 **********************************************************************
 *

 */
#if	0
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#else
#include "usb/typedefs.h"                   
#include "usb/usb.h"                         
#include "io_cfg.h"                     
#endif

uchar usi_trans(uchar data)
{
	SSPBUF = data;
	while(!SSPSTATbits.BF) {};  // BF = SSP Buffer Full . 1=Full 0=Empty
	return SSPBUF;
}


void usi_init(void)
{
	SSPSTAT=0b01000000;	// SMP=0 , CKE=1;
//	SSPCON1=0b00000000;	// SCK=12MHz/1 , CKP(Clock Polarity)=0
//	SSPCON1=0b00000001;	// SCK=12MHz/16
	SSPCON1=0b00000010;	// SCK=12MHz/64
//	SSPCON1=0b00000011;	// SCK=TMR2/2

	TRISBbits.TRISB1 =1;
	SSPCON1bits.SSPEN=1;// Enable SSP
	TRISBbits.TRISB1 =0;

/*
								#ifdef USE_SPI
								SSPBUF=acc0;
								acc0=bitreverse[*p++];
								while(!SSPSTATbits.BF){};
								#else
								acc0=*p++;
								JTAG_Write(acc0);
								#endif


								#ifdef USE_SPI
								SSPBUF=acc0;
								acc0=bitreverse[*p++];
								while(!SSPSTATbits.BF){};
								enqueue(bitreverse[SSPBUF]);
								#else
								acc0=*p++;
								JTAG_RW(acc0,acc1);
								enqueue(acc1);
								#endif

						#ifdef USE_SPI
						p--;
						SSPCON1bits.SSPEN=0;
						#endif

 */
}


/**********************************************************************
 *	
 **********************************************************************
 */
