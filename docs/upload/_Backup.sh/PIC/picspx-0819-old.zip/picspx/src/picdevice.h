/*********************************************************************
 *	P I C d e v i c e
 *********************************************************************
 */
typedef	struct {
	char *DeviceName;
	int	  DeviceIDWord;
	int	  ProgramMemorySize ;
	int	  EEDataMemorySize ;
	int	  WriteBufferSize ;
	uchar ConfigMask[14];
	uchar ConfigValue[14];
	int	  EraseCommand;
	int	  EEWriteType;
	int	  PanelNum;
	int	  PanelSize;
	int	  ProgrammingWaitP ;
	int	  ProgrammingWaitD ;
	int	  ProgrammingWaitC ;
	int	  ProgrammingWaitID;
	int	  EraseWait;
} DeviceSpec;

enum {
	Command80   = 0,
	Command81   = 1,
	Command3F8F	= 2,
};

enum {
	FixWaitTime = 0,
	PollWRbit = 1,
};


DeviceSpec *FindDevice(int id);

/*********************************************************************
 *
 *********************************************************************
 */

