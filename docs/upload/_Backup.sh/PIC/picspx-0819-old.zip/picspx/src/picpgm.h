#define	PIC_DEVICE_ADR	0x3ffffe
#define	PIC_CONFIG_ADR	0x300000

void	wait_us(int us);
void	SetPGDDir(int f);

// portb , pinb , ddrb �̃A�h���X������.
void	PicInit(void);
// PGM,MCLR�̃Z�b�g�A�b�v.
void	PicPgm(int f);

void	EraseCmd(int cmd05,int cmd04);
void	BulkErase(void);
void	WriteFlash(int adr,uchar *buf,int wlen);
void	WriteFuse(uchar *buf);
void	ReadFlash(int adr,uchar *buf,int len,int dumpf);
void	PicRead(char *buf,int cnt);

