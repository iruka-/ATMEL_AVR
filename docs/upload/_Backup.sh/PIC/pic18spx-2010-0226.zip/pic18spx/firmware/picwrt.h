#ifndef	picwrt_h_
#define	picwrt_h_

void cmd_picspx(void);


#define	SUPPORT_PIC24F	1

#endif

