/********************************************************************
 *	USART �֐�.
 ********************************************************************
 */
#include "GenericTypeDefs.h"
#include "Compiler.h"
#include "HardwareProfile.h"



#if	USART_USE_INTERRUPT			// ���荞�݂��g�p����.
char  mDataRdyUSART(void)
{
	
}
#endif

/********************************************************************
 *	�P�������M
 ********************************************************************
 */
void putcUSART(char	c)
{
	TXREG =	c;
}


/********************************************************************
 *	�P������M
 ********************************************************************
 */
unsigned char getcUSART()
{
	char  c;

	if (RCSTAbits.OERR) { 	//	in case	of overrun error
					//	we should never	see	an overrun error, but if we	do,	
		RCSTAbits.CREN = 0;	 //	reset the port
		c =	RCREG;
		RCSTAbits.CREN = 1;	 //	and	keep going.
	}else{
		c =	RCREG;
	}
// not necessary.  EUSART auto clears the flag when	RCREG is cleared
//	PIR1bits.RCIF =	0;	  // clear Flag

	return c;
}


/********************************************************************
 *
 ********************************************************************
 */
