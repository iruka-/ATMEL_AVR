/*********************************************************************
 *	PIC18 ��Flash��ǂݏo��.
 *********************************************************************

�ڑ�:

 AVR�pISP 6PIN                  PIC18F2550/14K50

	1 MISO    ------------------   PGD
	2 Vcc     ------------------   Vcc
	3 SCK     ------------------   PGC
	4 MOSI    ------------------   PGM
	5 RESET   ------------------   MCLR
	6 GND     ------------------   GND

 *********************************************************************
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "monit.h"
#include "util.h"
#include "hidasp.h"

#define	DEBUG_CMD	0
#define	PIC18F14K50	1

int	portAddress(char *s);

#if	HIDMON88
enum {
	SCK =5,
	MISO=4,
	MOSI=3,
	SS  =2,
};
#else
// tiny2313
enum {
	SCK =7,
	MISO=5,
	MOSI=6,
	SS  =4,
};
#endif

enum {
	b_0000 = 0x00,
	b_1000 = 0x08,
	b_1001 = 0x09,
	b_1100 = 0x0c,	// 
	b_1101 = 0x0d,	// TBLPTR+=2
	b_1111 = 0x0f,	// Write!
};

#define	PGM	 MOSI
#define	PGC	 SCK
#define	PGD	 MISO
#define	MCLR SS

#define	if_D	if(DEBUG_CMD)


/*********************************************************************
 *	�P�~���b�P�ʂ̎��ԑ҂�. Windows�� Sleep()�֐����Ăяo��.
 *********************************************************************
 */

void wait_ms(int ms);

/*********************************************************************
 *	�P�ʕb�P�ʂ̎��ԑ҂�. 
 *********************************************************************
 *	Windows���ł�USB�t���[�����Ԃ̏����������̂ŁA���ۂɂ͕s�v.
 *	�}�C�R���t�@�[�����ɈڐA����Ƃ��̓}�C�R�����ł��ꂼ������̕K�v������.
 */
void wait_us(int us)
{
	int ms = us / 1000;

	if(ms) wait_ms(ms);
}

/*********************************************************************
 *
 *********************************************************************
 */
static  int datab=0;	// PortB �ɍŌ�ɏ������񂾒l���o���Ă���.

//	�e�|�[�g�̎��A�h���X��ێ�����.
static	int	Portb;
static	int Pinb ;
static	int Ddrb ;		// 1=out 0=in

/*********************************************************************
 *	USB���o�R���ă|�[�g�ւ̏������݂��s��.
 *********************************************************************
 */
static void set_port(int adr,int data)
{
	UsbPoke(adr,0,data,0);
}

/*********************************************************************
 *	USB���o�R���ă|�[�g�̓ǂݏo�����s��.
 *********************************************************************
 */
static int  get_port(int adr)
{
	return UsbPeek(adr,0);
}
/*********************************************************************
 *	�|�[�g�a�̏������ݐ�p.�Ō�ɏ������񂾒l���o���Ă���.
 *********************************************************************
 */
static void set_portb(int data)
{
	set_port(Portb,data);
	datab = data;
}

/*********************************************************************
 *	�|�[�g�a�̏������݃f�[�^�ɑ΂��ĔC�Ӄr�b�g��On/Off (���ۂ̏������݂͍s��Ȃ�)
 *********************************************************************
 */
static void set_bitf(int bit,int f)
{
	if(f) {
		datab |=  (1<<bit);
	}else{
		datab &= ~(1<<bit);
	}
}

/*********************************************************************
 *	�|�[�g�a�̏������݃f�[�^�ɑ΂��ĔC�Ӄr�b�g��On/Off���s���A�������݂����s.
 *********************************************************************
 */
static void set_bit(int bit,int f)
{
	set_bitf(bit,f);
	set_portb(datab);
}


/*********************************************************************
 *	PGD�r�b�g�̓��o�͕�����؂�ւ���.(0=����)
 *********************************************************************
 *	f=0 ... PGD=in
 *	f=1 ... PGD=out
 */

void SetPGDDir(int f)
{
	int dirb = (1<<PGC) | (1<<PGM) | (1<<MCLR);

	if(f) dirb |= (1<<PGD);

	set_port(Ddrb ,dirb);
}

/*********************************************************************
 *	������
 *********************************************************************
 */
void PicInit(void)
{
	Portb = portAddress("portb");
	Pinb  = portAddress("pinb");
	Ddrb  = portAddress("ddrb");

	set_portb(0);
	SetPGDDir(1);		// PGD=out
}

/*********************************************************************
 *	PIC�^�[�Q�b�g�ւ̃A�N�Z�X�J�n (f=1) / �I��(f=0)
 *********************************************************************
 */
void PicPgm(int f)
{
	if(f) {
		set_portb(0);	//�S�Ă̐M����L�ɂ���.
		wait_ms(1);
		set_bit(PGM,1);	// PGM=H
		wait_ms(1);
		set_bit(MCLR,1);// MCLR=H
	}else{
		set_portb(0);	//�S�Ă̐M����L�ɂ���.
	}
}

/*********************************************************************
 *	1bit���M.
 *********************************************************************

        +---+
  PGC --+   +---

  PGD [ b=0�Ȃ�L ]
        b=1�Ȃ�H 
 */
void SetCmdb1(int b)
{
	set_bitf(PGD,b);
	set_bit(PGC,1);wait_us(1);
	set_bit(PGC,0);wait_us(1);
if_D	printf("%d",b);
}

/*********************************************************************
 *	1bit��M.
 *********************************************************************
        +---+
  PGC --+   +---

           �� �����œǂ�.

  PGD [ ����    ]
 */
int GetCmdb1(void)
{
	int b;

	set_bit(PGC,1);wait_us(1);

	b = get_port(Pinb) & (1<<PGD);

	set_bit(PGC,0);wait_us(1);

	return b;
}
/*********************************************************************
 *	n bit ���M.
 *********************************************************************
 */
void SetCmdN(int cmdn,int len)
{
	int i,b;
if_D	printf("[");

	for(i=0;i<len;i++) {
		b = cmdn & 1;
		SetCmdb1(b);
		cmdn >>=1;
	}
if_D	printf("]");

	if(len>=16) {
if_D	printf("\n");
	}
}

/*********************************************************************
 *	8 bit ��M.
 *********************************************************************
 */
int GetData8b(void)
{
	int i,data8=0,mask=1;
	SetPGDDir(0);		// PGD=in
	
	for(i=0;i<8;i++,mask<<=1) {
		if( GetCmdb1() ) {
			data8 |= mask;
		}
	}
	SetPGDDir(1);		// PGD=out
	return data8;
}

/*********************************************************************
 *	4bit�̃R�}���h �� 16bit�̃f�[�^�𑗐M.
 *********************************************************************
 */
void SetCmd16(int cmd4,int data16)
{
	SetCmdN(cmd4,4);
	SetCmdN(data16,16);
}

/*********************************************************************
 *	TBLPTR ����P�o�C�g�ǂݏo��. TBLPTR�̓|�X�g�E�C���N�������g�����.
 *********************************************************************
 */
int GetData8(void)
{
	SetCmdN(b_1001,4);
	SetCmdN(0 , 8);
	return GetData8b();
}

/*********************************************************************
 *	TBLPTR[U,H,L] �̂ǂꂩ��8bit�l���Z�b�g����.
 *********************************************************************
 */
void SetAddress8x(int adr,int inst)
{
	adr &= 0x00ff;
	adr |= 0x0e00;

	SetCmd16(b_0000,adr);		// 0E xx  : MOVLW xx
	SetCmd16(b_0000,inst);		// 6E Fx  : MOVWF TBLPTR[U,H,L]
}
/*********************************************************************
 *	TBLPTR ��24bit�A�h���X���Z�b�g����.
 *********************************************************************
 */
void SetAddress24(int adr)
{
	SetAddress8x(adr>>16,0x6ef8);	// TBLPTRU
	SetAddress8x(adr>>8 ,0x6ef7);	// TBLPTRH
	SetAddress8x(adr    ,0x6ef6);	// TBLPTRL
}

/*********************************************************************
 *	�`�b�v�����R�}���h�̔��s.
 *********************************************************************
 */
void EraseCmd(int cmd05,int cmd04)
{
	SetAddress24(0x3c0005);
	SetCmd16(b_1100,cmd05);
	
	SetAddress24(0x3c0004);
	SetCmd16(b_1100,cmd04);

	SetCmd16(b_0000,0x0000);	// NOP
	SetCmd16(b_0000,0x0000);	// NOP
	wait_ms(300);
}
/*********************************************************************
 *	�o���N�E�C���[�X.
 *********************************************************************
 */
void BulkErase(void)
{
	EraseCmd(0x0f0f,0x8787);
}
/*********************************************************************
 *	�������݃e�X�g.
 *********************************************************************
 */
void WriteFlash(void)
{
	int adr = 0;
#if	PIC18F14K50
	int wlen =  8;		// 16byte
#else
	int wlen = 16;		// 32byte
#endif
	int data = 0x0100;
	int i;

	SetCmd16(b_0000,0x8EA6);	//BSF   EECON1, EEPGD
	SetCmd16(b_0000,0x9CA6);    //BCF   EECON1, CFGS
	SetCmd16(b_0000,0x84A6);    //BSF   EECON1, WREN
	SetAddress24(adr);

	for(i=0;i<wlen-1;i++) {
		SetCmd16(b_1101,data);
		data += 0x0202;
	}
	SetCmd16(b_1111,data);
	SetCmd16(b_0000,0x0000);	// NOP
	wait_ms(4);
}
/*********************************************************************
 *	�������݃e�X�g.
 *********************************************************************
 */
void WriteFuse(void)
{
	int adr = 0x300000;
//	int data = 0x0700;
	int data = 0x0500;

	SetCmd16(b_0000,0x8EA6);	//BSF   EECON1, EEPGD
	SetCmd16(b_0000,0x8CA6);    //BSF   EECON1, CFGS
	SetCmd16(b_0000,0x84A6);    //BSF   EECON1, WREN
	SetAddress24(adr);

	SetCmd16(b_1111,data);

	SetCmd16(b_0000,0x0000);	// NOP
	SetCmd16(b_0000,0x0e01);	// 0E 01  : MOVLW xx
	SetCmd16(b_0000,0x6ef6);	// 6E Fx  : MOVWF TBLPTR[U,H,L]
	SetCmd16(b_1111,data);
	SetCmd16(b_0000,0x0000);	// NOP

	wait_ms(4);
}
/*********************************************************************
 *	�ǂݏo���e�X�g���[�`���E���C��.
 *********************************************************************
 */
void ReadFlash(int adr,int len)
{
	int i;
	printf("%06x :",adr);

	SetAddress24(adr);

	for(i=0;i<len;i++) {
		printf(" %02x",GetData8());
	}
	printf("\n");
}
/*********************************************************************
 *
 *********************************************************************
 */

void PicRead(char *buf,int cnt)
{
	int adr=0;
	if( strcmp(buf,"on")==0 ) {
		printf("PGM ON\n");
		PicPgm(1);return;
	}
	if( strcmp(buf,"off")==0 ) {
		printf("PGM OFF\n");
		PicPgm(0);return;
	}
	if( strcmp(buf,"erase")==0 ) {
		printf("ERASE\n");
		BulkErase();return;
	}
	if( strcmp(buf,"write")==0 ) {
		printf("WRITE\n");
		WriteFlash();return;
	}
	if( strcmp(buf,"wfuse")==0 ) {
		printf("WRITE FUSE\n");
		WriteFuse();return;
	}
	
	if( sscanf(buf,"%x",&adr) ) {
		ReadFlash(adr,cnt);
	}
}

/*********************************************************************
 *
 *********************************************************************
 */
