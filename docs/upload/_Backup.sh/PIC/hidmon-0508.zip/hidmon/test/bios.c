/*****************************************************************
 *	B I O S  C a l l
 *****************************************************************
 */
#include <pic18f2550.h>
#include "io_cfg.h"

char str_chr;

/*****************************************************************
 *	Bootloader ���ċN������.
 *****************************************************************
 */
void bootloader_soft_reset(void) __naked
{
	__asm
	goto 0x000c
	__endasm;
}
/*****************************************************************
 *	bios_task() ��main_loop�Ȃǂ���펞�R�[������K�v������.
 *****************************************************************
 */
void bios_task(void) __naked
{
	__asm
		movff _FSR2H,_POSTDEC1
		movff _FSR2L,_POSTDEC1
		call 0x000e
		movff _PREINC1,_FSR2L
		movff _PREINC1,_FSR2H
		return
	__endasm;
}
/*****************************************************************
 *	������.
 *****************************************************************
 */
void bios_puts(void) __naked
{
	__asm
		goto 0x0010
	__endasm;
}
/*****************************************************************
 *	������.
 *****************************************************************
 */
void bios_gets(void) __naked
{
	__asm
		goto 0x0012
	__endasm;
}
/*****************************************************************
 *	�P�����\��.
 *****************************************************************
 */
void bios_putc(void) __naked
{
	__asm
		movf  _PREINC1,W		; WREG�� �������󂯎��.
		movwf _POSTDEC1			; �_�~�[�v�b�V��.

		movff _FSR2H,_POSTDEC1
		movff _FSR2L,_POSTDEC1
		call  0x0014
		movff _PREINC1,_FSR2L
		movff _PREINC1,_FSR2H
		return
	__endasm;
}

/*****************************************************************
 *	
 *****************************************************************
 */
void bios_exit(void) __naked
{
	__asm
	movlw	0xc9		;; pagemode = 0xc9 (RETURN to bios)
	call 	0x0016		;; change report mode
	goto 	0x000c		;; return bios-loop
	return
	__endasm;
}

