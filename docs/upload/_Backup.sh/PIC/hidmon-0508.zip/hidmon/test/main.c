#include <pic18f2550.h>
#include "io_cfg.h"

#include "bios.h"

void puts(char *s)
{
	uchar c;
	while(1) {
		c = *s++;if(c==0) break;
		bios_putc(c);
	}
}

void LED_blink(void)
{
	static word led_count=0;
    
    led_count++;
	if(led_count & 0x8000) {
		mLED_1_On();
		mLED_2_Off();
	}else{
		mLED_1_Off();
		mLED_2_On();
	}
}


void main(void)
{
	int i=0x8000;
	int n=0;
	mInitAllLEDs();
	while(1) {
		bios_task();
		LED_blink();
		i++;
		if( i == 0 ) {
			puts("Hello ");n++;
		}
		if( i == 0x8000 ) {
			puts("World.\n");
		}
		if(n==16) break;
	}
	bios_exit();
}

#if	0

//
//	Run <���̔Ԓn> �Œ��ڃe�X�g�ł��܂�.
//
void test()
{
	while(1) {
		LED_blink();
	}
}
#endif
