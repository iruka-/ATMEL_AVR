
void bios_putc(uchar c);
void bios_puts(char *s);
void bios_task(void);
void bios_exit(void);

