#ifndef KEYBOARD_H
#define KEYBOARD_H


/*Definitions*/
#define	a	4
#define	b	5
#define c	6
#define	d	7
#define	e	8
#define	f	9
#define	g	10
#define	h	11
#define	i	12
#define	j	13
#define	k	14
#define	l	15
#define	m	16
#define	n	17
#define	o	18
#define	p	19
#define	q	20
#define	r	21
#define	s	22
#define	t	23
#define	u	24
#define	v	25
#define	w	26
#define	x	27
#define	y	28
#define z	29

#endif