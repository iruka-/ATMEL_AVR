#include <pic18f2550.h>
#include "io_cfg.h"

void bios_putc(uchar c);
void bios_puts(char *s);

void puts(char *s)
{
	while(*s) {
		bios_putc(*s++);
	}
}

void main(void)
{
	bios_putc('A');
	puts("Hello");
}
