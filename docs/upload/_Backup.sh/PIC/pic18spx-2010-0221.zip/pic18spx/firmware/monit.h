#ifndef	monit_h_
#define	monit_h_

void UserInit(void);
void ProcessIO(void);


/********************************************************************
 *	��`
 ********************************************************************
 */
#define	PACKET_SIZE		64

typedef union {
	uchar raw[PACKET_SIZE];

	struct{
		uchar  cmd;
		uchar  size;
		ushort adrs;
		uchar  data[PACKET_SIZE - 4];
	};

	// PICwriter��p.
	struct{
		uchar  piccmd;
		uchar  picsize;
		uchar  picadrl;
		uchar  picadrh;
		uchar  picadru;
		uchar  piccmd4;
		uchar  picms;
		uchar  picdata[32];
	};
} Packet;


#endif

