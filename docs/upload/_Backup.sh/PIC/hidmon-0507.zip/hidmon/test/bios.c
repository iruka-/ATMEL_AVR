/*****************************************************************
 *	B I O S  C a l l
 *****************************************************************
 */
#include <pic18f2550.h>
#include "io_cfg.h"

void bootloader_soft_reset(void) __naked
{
	__asm
	goto 0x000c
	__endasm;
}
void bios_task(void) __naked
{
	__asm
	movff _FSR2H,_POSTDEC1
	movff _FSR2L,_POSTDEC1
	call 0x000e
	movff _PREINC1,_FSR2L
	movff _PREINC1,_FSR2H
	return
	__endasm;
}
void bios_puts(void) __naked
{
	__asm
	goto 0x0010
	__endasm;
}
void bios_gets(void) __naked
{
	__asm
	goto 0x0012
	__endasm;
}
void bios_putc(void) __naked
{
	__asm
		movf  _PREINC1,W		; WREG�� �������󂯎��.
		movwf _POSTDEC1			; �_�~�[�v�b�V��.
		goto  0x0014
	__endasm;
}
void bios_exit(void) __naked
{
	__asm
	call 0x0016
	goto 0x000c
	__endasm;
}

