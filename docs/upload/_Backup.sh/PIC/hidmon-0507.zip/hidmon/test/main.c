#include <pic18f2550.h>
#include "io_cfg.h"

#include "bios.h"

#define	PutsBuff	0x580

uchar at 0x380 buf[32];

void puts(char *s)
{
	near char *t;
	char cnt=0;
	t = PutsBuff + 3;
	while(*s) {
		*t++ = *s++;
		cnt++;
	}
	t = PutsBuff;
	t[0]=2;
	t[1]=0xc0;
	t[2]=cnt;
}


void LED_blink(void)
{
	static word led_count=0;
    
    led_count++;
	if(led_count & 0x8000) {
		mLED_1_On();
		mLED_2_Off();
	}else{
		mLED_1_Off();
		mLED_2_On();
	}
}


void main(void)
{
	word i;
	mInitAllLEDs();
	puts("Hello\n");
	while(1) {
//	for(i=0;i<100;i++) {
		LED_blink();
//		bios_putc('A');
		bios_task();
	}
//	bios_exit();
}

