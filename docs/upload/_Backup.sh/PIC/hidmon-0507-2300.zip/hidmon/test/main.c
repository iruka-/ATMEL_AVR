#include <pic18f2550.h>
#include "io_cfg.h"

#if	1

void bios_putc(uchar c);
void bios_puts(char *s);
void bios_task(void);
void bios_exit(void);

static char buf0[16];

char at 0x380 putbuf[32];

#define	BUF	0x380
char *t;
char *cnt;

void puts(char *s)
{
	while(*s) {
		bios_putc(*s++);
	}
}


void puts2(char *s)
{
	uchar i=16,c;
	putbuf[0]= 0xaa;
	putbuf[1]= 0x55;
	putbuf[2]= s[0];

#if	1
//	putbuf[2]++;
	while(1) {
		c = *s++;
		if(c==0) break;
		putbuf[i++] = c;
		
//		putbuf[2]++;
	}
#endif	
}

#endif

word led_count=1;

void LED_blink(void)
{
//  static word led_count=0;
    
    led_count++;
	if(led_count & 0x8000) {
		mLED_1_On();
		mLED_2_Off();
	}else{
		mLED_1_Off();
		mLED_2_On();
	}
}

void main(void)
{
	word i;
	mInitAllLEDs();
	while(1) {
//	for(i=0;i<100;i++) {
//		puts("Hello\n");
		LED_blink();
//		bios_putc('A');
		bios_task();
	}
//	bios_exit();
}
