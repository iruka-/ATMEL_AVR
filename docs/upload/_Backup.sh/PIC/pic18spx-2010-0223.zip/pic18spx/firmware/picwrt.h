#ifndef	picwrt_h_
#define	picwrt_h_

void cmd_picspx(void);


#endif

