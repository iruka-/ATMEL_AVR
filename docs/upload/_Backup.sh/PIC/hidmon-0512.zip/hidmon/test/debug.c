/*****************************************************************
 *	DEBUG �x�� ���W�X�^�_���v.
 *****************************************************************
 */
#include <pic18f2550.h>
#include "io_cfg.h"

extern	PCLAT;

/*********************************************************************
 *	WREG �P����print
 *********************************************************************
 */
void bios_putascii() __naked
{
	// WREG �� c �������Ă���.
	__asm
		movff _FSR2H,_POSTDEC1
		movff _FSR2L,_POSTDEC1
		movff _FSR0H,_POSTDEC1
		movff _FSR0L,_POSTDEC1

		movff _TBLPTRU,_POSTDEC1
		movff _TBLPTRH,_POSTDEC1
		movff _TBLPTRL,_POSTDEC1
		movff _TABLAT ,_POSTDEC1

		movff _BSR ,_POSTDEC1
		movff _WREG ,_POSTDEC1
		call  0x0014
		movff _PREINC1,_WREG
		movff _PREINC1,_BSR

		movff _PREINC1,_TABLAT 
		movff _PREINC1,_TBLPTRL
		movff _PREINC1,_TBLPTRH
		movff _PREINC1,_TBLPTRU

		movff _PREINC1,_FSR0L
		movff _PREINC1,_FSR0H
		movff _PREINC1,_FSR2L
		movff _PREINC1,_FSR2H
		return
	__endasm;
}

/*********************************************************************
 *	�P�U�i�P��print
 *********************************************************************
 */
void bios_hex1() __naked
{
	// WREG �� c �������Ă���Ɖ���.
	__asm
		movff _WREG ,_POSTDEC1

		andlw 0x0f
		addlw 0xf6
		bnc	    _0to9
		addlw	0x61-0x30+0xf6	; 'a'..'f'
_0to9:	addlw		 0x30-0xf6	; '0'..'9'
		rcall	_bios_putascii;
		movff _PREINC1,_WREG
		return
	__endasm;
}

/*********************************************************************
 *	�P�U�i�Q��print
 *********************************************************************
 */
void bios_hex2() __naked
{
	// WREG �� c �������Ă���Ɖ���.
	__asm
		movff _WREG ,_POSTDEC1
		swapf _WREG
		rcall	_bios_hex1;
		movff _PREINC1,_WREG
		rcall	_bios_hex1;
		return
	__endasm;
}

/*********************************************************************
 *	���W�X�^Dump
 *********************************************************************
 */
void bios_rname()	__naked
{
	__asm
		rcall	_bios_putascii;
		movlw	':'
		rcall	_bios_putascii;
		return
	__endasm;
}

/*********************************************************************
 *
 *********************************************************************
 */
void bios_putspc()	__naked
{
	__asm
		movff _WREG ,_POSTDEC1
		movlw	' '
		rcall	_bios_putascii;
		movff _PREINC1,_WREG
		return
	__endasm;
}
void bios_putcrlf()	__naked
{
	__asm
		movff _WREG ,_POSTDEC1
		movlw	0x0a
		rcall	_bios_putascii;
		movff _PREINC1,_WREG
		return
	__endasm;
}
void bios_putprod()	__naked
{
	__asm
		movff _WREG ,_POSTDEC1
		movlw	'P'
		rcall	_bios_putascii;
		movlw	'R'
		rcall	_bios_putascii;
		movlw	'O'
		rcall	_bios_putascii;
		movlw	'D'
		rcall	_bios_putascii;
		movlw	':'
		rcall	_bios_putascii;
		movff _PREINC1,_WREG
		return
	__endasm;
}
void bios_putTBLPTR()	__naked
{
	__asm
		movff _WREG ,_POSTDEC1
		movlw	'T'
		rcall	_bios_putascii;
		movlw	'B'
		rcall	_bios_putascii;
		movlw	'L'
		rcall	_bios_putascii;
		movlw	'P'
		rcall	_bios_putascii;
		movlw	'T'
		rcall	_bios_putascii;
		movlw	'R'
		rcall	_bios_putascii;
		movlw	':'
		rcall	_bios_putascii;
		movff _PREINC1,_WREG
		return
	__endasm;
}

void bios_putfsrN()	__naked
{
	__asm
		movff _WREG ,_POSTDEC1
		movlw	'F'
		rcall	_bios_putascii;
		movlw	'S'
		rcall	_bios_putascii;
		movlw	'R'
		rcall	_bios_putascii;
		movlw	' '
		rcall	_bios_putascii;
		movff _PREINC1,_WREG
		movff _WREG ,_POSTDEC1
		rcall	_bios_putascii;
		movlw	':'
		rcall	_bios_putascii;
		movff _PREINC1,_WREG
		return
	__endasm;
}

void bios_putN()	__naked
{
	__asm
		movff _WREG ,_POSTDEC1
		rcall	_bios_putascii;
		movlw	':'
		rcall	_bios_putascii;
		movff _PREINC1,_WREG
		return
	__endasm;
}

void bios_pr_flag1()	_naked
{
	__asm
		bnz		label2
		movlw	'_'
label2:	rcall	_bios_putascii;
		return
	__endasm;
}

void bios_pr_status()	_naked
{
	__asm
		movlw 	2	// status = (FSR1+2)
		movff	_PLUSW1,_WREG
		andlw	0x10
		movlw	'N'
		rcall	_bios_pr_flag1;

		movlw 	2	// status = (FSR1+2)
		movff	_PLUSW1,_WREG
		andlw	0x08
		movlw	'V'
		rcall	_bios_pr_flag1;

		movlw 	2	// status = (FSR1+2)
		movff	_PLUSW1,_WREG
		andlw	0x04
		movlw	'Z'
		rcall	_bios_pr_flag1;

		movlw 	2	// status = (FSR1+2)
		movff	_PLUSW1,_WREG
		andlw	0x02
		movlw	'D'
		rcall	_bios_pr_flag1;

		movlw 	2	// status = (FSR1+2)
		movff	_PLUSW1,_WREG
		andlw	0x01
		movlw	'C'
		rcall	_bios_pr_flag1;
		return
	__endasm;
}
/*********************************************************************
 *	���W�X�^Dump
 *********************************************************************
 */
void bios_regdump()	__naked
{
	__asm
		movff _STATUS ,_POSTDEC1
		movff _WREG   ,_POSTDEC1
		// *PC=xxxx
		movlw	'*'
		rcall	_bios_putascii;
		movlw	'P'
		rcall	_bios_putascii;
		movlw	'C'
		rcall	_bios_rname;

		movf	_TOSH,W
		rcall	_bios_hex2;
		movf	_TOSL,W
		rcall	_bios_hex2;
		rcall	_bios_putspc

		// W=xx
		movlw	'W'
		rcall	_bios_rname;

		movff _PREINC1,_WREG
		movff _WREG ,_POSTDEC1
		rcall	_bios_hex2;
		rcall	_bios_putspc

		// STATUS
		rcall	_bios_pr_status
		rcall	_bios_putspc

		// FSR0=xxxx
		movlw	'0'
		rcall	_bios_putfsrN

		movf	_FSR0H,W
		rcall	_bios_hex1;
		movf	_FSR0L,W
		rcall	_bios_hex2;
		rcall	_bios_putspc

		// FSR1=xxxx
		movlw	'1'
		rcall	_bios_putN

		movf	_FSR1H,W
		rcall	_bios_hex1;
		movf	_FSR1L,W
		addlw	2				// FSR1 �␳.
		rcall	_bios_hex2;
		rcall	_bios_putspc

		// FSR2=xxxx
		movlw	'2'
		rcall	_bios_putN

		movf	_FSR2H,W
		rcall	_bios_hex1;
		movf	_FSR2L,W
		rcall	_bios_hex2;
		rcall	_bios_putspc

		// TBLPTR=xxxxxx TABLAT=yy
		rcall	_bios_putTBLPTR

		movf	_TBLPTRU,W
		rcall	_bios_hex2;
		movf	_TBLPTRH,W
		rcall	_bios_hex2;
		movf	_TBLPTRL,W
		rcall	_bios_hex2;
		rcall	_bios_putspc

		movf	_TABLAT ,W
		rcall	_bios_hex2;
		rcall	_bios_putspc



		// PROD=xxxx
		rcall	_bios_putprod

		movf	_PRODH,W
		rcall	_bios_hex2;
		movf	_PRODL,W
		rcall	_bios_hex2;

		// ���s.
		rcall	_bios_putcrlf

		movff _PREINC1,_WREG
		movff _PREINC1,_STATUS
		return
	__endasm;
}

