/**********************************************************************
 *	8bit TIMER2 ���g�p�������荞�݃n���h���[.
 **********************************************************************
 *	timer2_init()
 *	timer2_wait()
 */
#ifndef _timer2_h_
#define _timer2_h_

void  timer2_init(uchar t2config,uchar period);
uchar timer2_wait(void);
int   timer2_gettime(void);

void  timer0_int_handler(void);

#endif  //_timer2_h_
/**********************************************************************
 *	
 **********************************************************************
 */
