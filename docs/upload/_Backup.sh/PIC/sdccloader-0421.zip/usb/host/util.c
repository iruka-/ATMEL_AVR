/*********************************************************************
 *	�t�r�a�f�o�C�X�̎g�p�J�n�A�I���A�A�N�Z�X���̃��[�e�B���e�B.
 *********************************************************************
 *
 *�`�o�h:
int		UsbInit(int verbose,int enable_bulk);	������.
int		UsbExit(void);	�I��.
void 	UsbBench(int cnt,int psize);
void	UsbDump(int adr,int arena,int size);
void 	UsbPoke(int adr,int arena,int data0,int data1);
int 	UsbPeek(int adr,int arena);
int 	UsbRead(int adr,int arena,uchar *buf,int size);
 *
 *�����֐�:
usb_dev_handle	*open_dev(void);
int 	transfer_test_ctrl(usb_dev_handle *dev,int cnt,int psize);
void	dumpmem(usb_dev_handle *dev,int adr,int cnt);
void	pokemem(usb_dev_handle *dev,int adr,int data0,int data1);
void	memdump(void *ptr,int len,int off);
 */

#include <stdio.h>
#include <time.h>
#include <usb.h>

#include "monit.h"
#include "util.h"

void dump_info(  struct usb_device *dev );

//	obdev

//#define MY_VID 0x16c0
//#define MY_PID 0x05dc

#define MY_VID 0x04d8
#define MY_PID 0x0053

#define	MY_Manufacturer	"AVR"
#define	MY_Product		"t"


/* the device's endpoints */
#define EP_IN  				0x81
#define EP_OUT 				0x01
#define EP_INTR_IN 			0x83

#define PACKET_SIZE 		64
#define	VERBOSE				0
#define	REPORT_MATCH_DEVICE	0
#define	REPORT_ALL_DEVICES	0


#define	TIMEOUT	500

#define	if_V	if(VERBOSE)

usb_dev_handle *usb_dev = NULL; /* the device handle */
static	char verbose_mode = 0;

#define	Printf(...)
#define	Memdump(...)
/****************************************************************************
 *	�������[���e���_���v.
 ****************************************************************************
 */
void memdump(void *ptr,int len,int off)
{
	unsigned char *p = (unsigned char *)ptr;
	int i,j,c;

	for(i=0;i<len;i++) {
		if( (i & 15) == 0 ) printf("%06x",(int)p - (int)ptr + off);
		printf(" %02x",*p);p++;
		if( (i & 15) == 15 ) 
		{
#if	1	// ASCII DUMP
			printf("  ");
			for(j=0;j<16;j++) {
				c=p[j-16];
				if(c<' ') c='.';
				if(c>=0x7f) c='.';
				printf("%c",c);
			}
#endif
			printf("\n");
		}
	}
	printf("\n");
}




/*********************************************************************
 *	�ꎞ�o�b�t�@�ɉ��f�[�^��u��. �����l���O������add
 *********************************************************************
 */
void set_temp(char *tmp,int cnt,int add)
{
	int i;
	int c=0;
	for(i=0;i<cnt;i++,tmp++) {
		*tmp = c;
		c+= add;
	}
}

void inc_txbuf(unsigned char *txbuf)
{
	int i;
	for(i=0;i<4;i++) {
		txbuf[i] += 4;
	}
}

/*********************************************************************
 *
 *********************************************************************
 */
int QueryAVR(usb_dev_handle *dev,RxBuf *cmd,uchar *buf)
{
	int nBytes  = 0;
	int nLength = cmd->wlength;
	int	wValue  = cmd->adr;
	int wIndex  = cmd->data0 | (cmd->data1 << 8);

	nBytes = usb_control_msg(dev,cmd->bmRequestType,cmd->cmd, 
							wValue,wIndex,
							buf, nLength, TIMEOUT);
#if	0
	if(nBytes != 0)	//nLength)
    	{
    	  	printf("error: control write failed %d\n",nBytes);
			return 0;
    	}
#endif

    return nBytes;
}
/*********************************************************************
 *
 *********************************************************************
 */
int dumpmem(usb_dev_handle *dev,int adr,int arena,int size,unsigned char *buf)
{
	RxBuf cmd;
	
	memset(&cmd,0,sizeof(RxBuf));
	cmd.bmRequestType = USB_TYPE_VENDOR | USB_RECIP_DEVICE |USB_ENDPOINT_IN;
	cmd.cmd   = CMD_PEEK | arena;
	cmd.adr   = adr;
	cmd.data0 = size;
	cmd.wlength = 8;

	if( QueryAVR(dev,&cmd,buf) == 0) return 0;	//���s.
	return size;
}
/*********************************************************************
 *
 *********************************************************************
 */
void pokemem(usb_dev_handle *dev,int adr,int arena,int data0,int data1)
{
    RxBuf cmd;
	char buf[16];	// dummy

	memset(&cmd,0,sizeof(RxBuf));

	cmd.bmRequestType = USB_TYPE_VENDOR | USB_RECIP_DEVICE |USB_ENDPOINT_IN;
	cmd.cmd   = CMD_POKE | arena;
	cmd.adr   = adr;
	cmd.data0 = data0;
	cmd.data1 = data1;
	cmd.wlength = 8;

	QueryAVR(dev,&cmd,buf);
}
/*********************************************************************
 *
 *********************************************************************
	  if((nBytes = usb_bulk_write(dev, EP_OUT, tmp, nLength, TIMEOUT) )
	  if((nBytes = usb_bulk_read(dev, EP_IN, tmp, nLength, TIMEOUT) )
 */
int BulkRead(char *buf,int nLength)
{
	int nBytes;
	memset(buf,0,nLength);
	Printf("BulkRead(%d)\n",nLength);
	nBytes = usb_bulk_read(usb_dev, EP_IN, buf, nLength, TIMEOUT);

	Printf("BulkRead(%d)=%d bytes.\n",nLength,nBytes);
	Memdump(buf,nBytes,0);

	return nBytes ;
}

int BulkWrite(char *buf,int nLength)
{
	int nBytes;
	nBytes = usb_bulk_write(usb_dev, EP_OUT, buf, nLength, TIMEOUT);
	return nBytes ;
}


/*********************************************************************
 *
 *********************************************************************
 */
void bulk_bench(usb_dev_handle *dev,int cnt,int psize)
{
    char tmp[1024];
    char tmp2[1024];
	int nBytes  = 0;
	int nLength = PACKET_SIZE;
	int i;
	int total=0;
	
	set_temp(tmp,1024,0);
	tmp[0] = 0x40;	// This is ECHOBACK_TEST command.
   	printf("bulk write start\n");

	int time0 = clock();
	for(i=0;i<cnt;i++) {

	  if((nBytes = usb_bulk_write(dev, EP_OUT, tmp, nLength, TIMEOUT) )
	     != nLength)
    	{
    	  printf("error: bulk write failed %d,%d\n",nBytes,nLength);
    	}
   		 else{
			total += nBytes;
if_V      printf("bulk write nBytes = %d.\n",nBytes);


			BulkRead(tmp2,64);

		}
	}

	int time1 = clock() - time0;
	if(time1 == 0) time1 = 1;
	int rate = total * 1000 / time1;

   	printf("bulk write end %d %d s  %d byte/s\n",total,time1,rate);
}

static int  usbGetStringAscii(usb_dev_handle *dev, int index, int langid, char *buf, int buflen)
{
char    buffer[256];
int     rval, i;

    if((rval = usb_control_msg(dev, USB_ENDPOINT_IN, USB_REQ_GET_DESCRIPTOR, (USB_DT_STRING << 8) + index, langid, buffer, sizeof(buffer), 1000)) < 0)
        return rval;
    if(buffer[1] != USB_DT_STRING)
        return 0;
    if((unsigned char)buffer[0] < rval)
        rval = (unsigned char)buffer[0];
    rval /= 2;
    /* lossy conversion to ISO Latin1 */
    for(i=1;i<rval;i++){
        if(i > buflen)  /* destination buffer overflow */
            break;
        buf[i-1] = buffer[2 * i];
        if(buffer[2 * i + 1] != 0)  /* outside of ISO Latin1 range */
            buf[i-1] = '?';
    }
    buf[i-1] = 0;
    return i-1;
}

int	open_dev_check_string(struct usb_device *dev,usb_dev_handle *handle)
{
	int len1,len2;
	char string1[256];
	char string2[256];

	len1 = usbGetStringAscii(handle, dev->descriptor.iManufacturer, 
							0x0409, string1, sizeof(string1));
    len2 = usbGetStringAscii(handle, dev->descriptor.iProduct, 
							0x0409, string2, sizeof(string2));
	if((len1<0)||(len2<0)) return 0;

#if	1
	printf("iManufacturer:%s\n",string1);
	printf("iProduct:%s\n",string2);
#endif

#ifdef	MY_Manufacturer
	if(strcmp(string1, MY_Manufacturer) != 0) return 0;
#endif

#ifdef	MY_Product
	if(strcmp(string2, MY_Product) != 0)      return 0;
#endif

	return 1;	//���v����.
}


usb_dev_handle *open_dev(void)
{
	struct usb_bus *bus;
	struct usb_device *dev;
	usb_dev_handle *handle;

  	for(bus = usb_get_busses(); bus; bus = bus->next) {
      	for(dev = bus->devices; dev; dev = dev->next) {

#if	REPORT_ALL_DEVICES
			dump_info(dev);
#endif

			//
			//	VendorID,ProductID �̈�v�`�F�b�N.
			//
          if(dev->descriptor.idVendor  == MY_VID &&
             dev->descriptor.idProduct == MY_PID) {
#if	REPORT_MATCH_DEVICE
			  	if(verbose_mode) {
			  		dump_info(dev);
			  	}
#endif
				handle = usb_open(dev);
				if( open_dev_check_string(dev,handle) == 1) {
					return handle;	//��v.
				}
					return handle;	//��Ɉ�v.
                usb_close(handle);
                handle = NULL;
            }
        }
    }
	return NULL;
}


/*********************************************************************
 *
 *********************************************************************
 */
void UsbBench(int cnt,int psize)
{
	bulk_bench(usb_dev,cnt,psize);
}
/*********************************************************************
 *
 *********************************************************************
 */
void UsbSetBaudRate(int ubrr,int ucsrc)
{
	int baud;
	char buf[16];	// dummy
	RxBuf cmd;
	
	memset(&cmd,0,sizeof(RxBuf));
	cmd.bmRequestType = USB_TYPE_VENDOR | USB_RECIP_DEVICE |USB_ENDPOINT_IN;
	cmd.cmd   = CMD_BAUD ;
	cmd.adr   = ubrr;
	cmd.data0 = ucsrc;
	cmd.data1 = 0;
	cmd.wlength = 8;

//	baud = 12000000 / 16 / (ubrr + 1);	/* U2X=0�̂Ƃ� */
	baud = 12000000 /  8 / ( (ubrr & 0xfff) + 1);
	printf("UsbSetBaudRate : ubrr=0x%0x,ucsrc=0x%x TrueBaudRate=%d\n",ubrr,ucsrc,baud);

	//����: ubrr�� 12bit��������܂���. 4095�ȏ�̒l�̐ݒ�͊ԈႢ�ł�.

	QueryAVR(usb_dev,&cmd,buf);
}
/*********************************************************************
 *
 *********************************************************************
 */
void UsbDump(int adr,int arena,int cnt)
{
	unsigned char buf[16];
	int size;
	int rc;
	while(cnt) {
		size = cnt;
		if(size>=8) size = 8;
		rc = dumpmem(usb_dev,adr,arena,size,buf);
		if(rc !=size) return;
		memdump(buf,size,adr);
		adr += size;
		cnt -= size;
	}
}
/*********************************************************************
 *
 *********************************************************************
 */
int UsbRead(int adr,int arena,uchar *buf,int size)
{
	int rc = size;
	int len;
	while(size) {
		len = size;
		if(len >= 8) len = 8;
		int rc = dumpmem(usb_dev,adr,arena,len,buf);
		if( rc!= len) {
			return -1;
		}
		adr  += len;	// �^�[�Q�b�g�A�h���X��i�߂�.
		buf  += len;	// �ǂݍ��ݐ�o�b�t�@��i�߂�.
		size -= len; 	// �c��T�C�Y�����炷.
	}
	return rc;
}
/*********************************************************************
 *
 *********************************************************************
 */
int UsbPeek(int adr,int arena)
{
	unsigned char buf[16];
	int size=1;
	int rc = UsbRead(adr,arena,buf,size);
	if( rc != size) {
		return -1;
	}
	return buf[0];
}
/*********************************************************************
 *
 *********************************************************************
 */
void UsbPoke(int adr,int arena,int data0,int data1)
{
	pokemem(usb_dev,adr,arena,data0,data1);
}

//	Device to Host
#define VRQ_IN  (USB_TYPE_VENDOR | USB_RECIP_INTERFACE | USB_ENDPOINT_IN)

//	Host to Device
#define VRQ_OUT (USB_TYPE_VENDOR | USB_RECIP_INTERFACE | USB_ENDPOINT_OUT)
/*********************************************************************
 *
 *********************************************************************
 */
void CtrlMsg(int bmRequset,int bCount,int wValue,int wIndex, int nLength ,char *buf)
{
	int nBytes = usb_control_msg(usb_dev, bmRequset
				,bCount,wValue,wIndex, buf , nLength, TIMEOUT);

	printf("CtrlMsg(%02x %02x %04x %04x %04x)\n",bmRequset,bCount
							,wValue,wIndex,nLength);

	if(nBytes != nLength) {
		if(nLength) {
			printf("warning: ctrl write failed %d != %d\n",nBytes,nLength);	
		}else{
			printf("error: ctrl write failed %d != %d\n",nBytes,nLength);	
		}
	}
}
/*********************************************************************
 *
 *********************************************************************
  int usb_interrupt_write(usb_dev_handle *dev, int ep, char *bytes, int size,
                          int timeout);
  int usb_interrupt_read(usb_dev_handle *dev, int ep, char *bytes, int size,
                         int timeout);
 */
int IntrRead(char *buf,int nLength)
{
	int nBytes;
	memset(buf,0,nLength);
	printf("IntrRead(%d)\n",nLength);
	nBytes = usb_interrupt_read(usb_dev, EP_INTR_IN, buf, nLength, TIMEOUT);
	printf("IntrRead(%d)=%d bytes.\n",nLength,nBytes);
	memdump(buf,nBytes,0);

	return nBytes ;
}
typedef	struct {
	int id,size;
	char msg[1];
} MESG;

int	getMessage(char *s)
{
	MESG *mes = (MESG *)s;
	int size = 0;
	BulkRead(s,8);
	if(	mes->id == 0x810000) {
		size = BulkRead(s+8,mes->size);
	}
	return size;
}
int putMessage(char *s)
{
	MESG *mes = (MESG *)s;
	int size = 0;

	strcpy(s+8,"Hello World 123456789ABCDEFG        ");
	mes->size = 0;

	if(	mes->id == 0x810000) {
		BulkWrite(s,8);
		if(mes->size) {
			size = BulkWrite(s+8,mes->size);
		}
	}
	return size;
}


/*********************************************************************
 *
 *********************************************************************
 */
int UsbInit(int verbose,int enable_bulk)
{
  verbose_mode = verbose;

  usb_init(); /* initialize the library */
  usb_find_busses(); /* find all busses */
  usb_find_devices(); /* find all connected devices */

  usb_set_debug(3);

  if(!(usb_dev = open_dev()))
    {
      printf("error: device not found!\n");
      return 0;
    }

// if(use_bulk) 
	{		//1:�o���N�]�����g�p����.

	//�o���N�p�G���h�|�C���g�� set_configuration���Ȃ���
	//�g���Ȃ��悤��.

  if(usb_set_configuration(usb_dev, 1 ) < 0)
    {
      printf("error: setting config 1 failed\n");
      usb_close(usb_dev);
      return 0;
    }

#if	1
  if(usb_claim_interface(usb_dev, 0) < 0)
    {
      printf("error: claiming interface 0 failed\n");
      usb_close(usb_dev);
      return 0;
    }
#endif

 }

	return 1;	// OK.
}



/*********************************************************************
 *
 *********************************************************************
 */
int UsbExit(void)
{
	if(	usb_dev ) {
		usb_release_interface(usb_dev, 0);
		usb_close(usb_dev);
	}
	return 0;
}
/*********************************************************************
 *
 *********************************************************************
 */

