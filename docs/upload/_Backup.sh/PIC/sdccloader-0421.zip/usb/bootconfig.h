#ifndef BOOTCONFIG_H
#define BOOTCONFIG_H



//	if you will install libusb driver , Then set this value :1
#define	LIBUSB_DRIVE		1
//	or You can select mchip-usb drvier , Then set this value :0



#define	VID    	0x04D8                 // Vendor ID

#if	LIBUSB_DRIVE
#define	PID		0x0053                 // Product ID: WinUSB / LibUSB
#else
#define	PID		0x000b                 // Product ID: PICDEM FS USB (Boot Mode)
#endif

#endif	//BOOTCONFIG_H

