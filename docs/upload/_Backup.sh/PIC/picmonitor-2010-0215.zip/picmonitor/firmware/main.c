/********************************************************************
 *	���C���֐�  ������  ���荞�݃x�N�^�[�̐ݒ�.
 ********************************************************************
 */
#include "usb/typedefs.h"                   
#include "usb/usb.h"                         
#include "io_cfg.h"                     

#include "monit.h"

#include "fuse-config.h"

void YourHighPriorityISRCode();
void YourLowPriorityISRCode();

/**	VECTOR REMAPPING ***********************************************/
	#if	0
		#define	REMAPPED_RESET_VECTOR_ADDRESS			0x1000
		#define	REMAPPED_HIGH_INTERRUPT_VECTOR_ADDRESS	0x1008
		#define	REMAPPED_LOW_INTERRUPT_VECTOR_ADDRESS	0x1018
	#endif

	#if	1
		#define	REMAPPED_RESET_VECTOR_ADDRESS			0x800
		#define	REMAPPED_HIGH_INTERRUPT_VECTOR_ADDRESS	0x808
		#define	REMAPPED_LOW_INTERRUPT_VECTOR_ADDRESS	0x818
	#endif

	#if	0
		#define	REMAPPED_RESET_VECTOR_ADDRESS			0x00
		#define	REMAPPED_HIGH_INTERRUPT_VECTOR_ADDRESS	0x08
		#define	REMAPPED_LOW_INTERRUPT_VECTOR_ADDRESS	0x18
	#endif

/********************************************************************
 *	0x800�`�̃W�����v�x�N�^�[��ݒ肷��.
 ********************************************************************
 *	0x800 goto _startup
 *	0x808 goto YourHighPriorityISRCode
 *	0x818 goto YourLowPriorityISRCode
 */

	extern void	_startup (void);		// See c018i.c in your C18 compiler	dir
	#pragma	code REMAPPED_RESET_VECTOR = REMAPPED_RESET_VECTOR_ADDRESS
	void _reset	(void)
	{
		_asm goto _startup _endasm
	}


	#pragma	code REMAPPED_HIGH_INTERRUPT_VECTOR	= REMAPPED_HIGH_INTERRUPT_VECTOR_ADDRESS
	void Remapped_High_ISR (void)
	{
		 _asm goto YourHighPriorityISRCode _endasm
	}


	#pragma	code REMAPPED_LOW_INTERRUPT_VECTOR = REMAPPED_LOW_INTERRUPT_VECTOR_ADDRESS
	void Remapped_Low_ISR (void)
	{
		 _asm goto YourLowPriorityISRCode _endasm
	}
	
/********************************************************************
 *	0x008�`�̃W�����v�x�N�^�[��ݒ肷��.
 ********************************************************************
 *	0x008 goto 0x808
 *	0x018 goto 0x818
 */
	#pragma	code HIGH_INTERRUPT_VECTOR = 0x08
	void High_ISR (void)
	{
		 _asm goto REMAPPED_HIGH_INTERRUPT_VECTOR_ADDRESS _endasm
	}


	#pragma	code LOW_INTERRUPT_VECTOR =	0x18
	void Low_ISR (void)
	{
		 _asm goto REMAPPED_LOW_INTERRUPT_VECTOR_ADDRESS _endasm
	}

/********************************************************************
 *	�W�����v�x�N�^�[�ݒ�͂����܂�.
 ********************************************************************
 */


#pragma	code
/********************************************************************
 *	High���荞�ݏ����֐�.
 ********************************************************************
 */
	#pragma	interrupt YourHighPriorityISRCode
	void YourHighPriorityISRCode()
	{
		#if	defined(USB_INTERRUPT)
			USBDeviceTasks();
		#endif
	
	}	//This return will be a	"retfie fast", since this is in	a #pragma interrupt	section	

/********************************************************************
 *	Low ���荞�ݏ����֐�.
 ********************************************************************
 */
	#pragma	interruptlow YourLowPriorityISRCode
	void YourLowPriorityISRCode()
	{
		//Check	which interrupt	flag caused	the	interrupt.
		//Service the interrupt
		//Clear	the	interrupt flag
		//Etc.
	
	}	//This return will be a	"retfie", since	this is	in a #pragma interruptlow section 




#pragma	code

//extern void	InitializeSystem(void);

/*****************************************************************************/
static void InitializeSystem(void)
{
#if defined(USE_USB_BUS_SENSE_IO)
    tris_usb_bus_sense = INPUT_PIN; // See io_cfg.h
#endif

#if defined(USE_SELF_POWER_SENSE_IO)
    tris_self_power = INPUT_PIN;
#endif
    mInitializeUSBDriver();         // See usbdrv.h
    UserInit();                     // See user.c & .h
}
/********************************************************************
 *
 ********************************************************************
 */
void main(void)
{
    InitializeSystem();
	while(1){
	    USBCheckBusStatus();                    // Must use polling method
	    USBDriverService();              	    // Interrupt or polling method
	    if((usb_device_state == CONFIGURED_STATE) && (UCONbits.SUSPND != 1)) {
			ProcessIO();
		}
	}
}
/********************************************************************
 *
 ********************************************************************
 */
