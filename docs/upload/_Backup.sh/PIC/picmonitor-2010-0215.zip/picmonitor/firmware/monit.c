/********************************************************************
 *	�ȈՃ��j�^
 ********************************************************************
 */
#include "usb/typedefs.h"
#include "usb/usb.h"
#include "io_cfg.h"
#include "monit.h"
#include "hidcmd.h"

/********************************************************************
 *	
 ********************************************************************
 */
#define	PACKET_SIZE		64

/********************************************************************
 *	
 ********************************************************************
 */
typedef union {
	uchar raw[PACKET_SIZE];

	struct{
		uchar  cmd;
		uchar  size;
		ushort adrs;
		uchar  data[PACKET_SIZE - 4];
	};
} Packet;

/********************************************************************
 *	
 ********************************************************************
 */
#pragma udata SomeSectionName1
uchar ToPcRdy = 0;


#pragma udata SomeSectionName2
Packet PacketFromPC;

#pragma udata SomeSectionName3
Packet PacketToPC;

void UserInit(void);


#pragma code
/********************************************************************
 *	������.
 ********************************************************************
 */
void UserInit(void)
{
    mInitAllLEDs();		//Init them off.
	ToPcRdy = 0;
}
/********************************************************************
 *	���j�^�R�}���h��M�Ǝ��s.
 ********************************************************************
 */
void ProcessIO(void)
{
	uchar i,size,area,data0,data1;
	uchar *p;
	
	if( ToPcRdy == 0 )
	if(!mHIDRxIsBusy()) {	//��M�f�[�^������΁A��M�f�[�^���󂯎��.
		HIDRxReport((char *)&PacketFromPC, 64);
		PacketToPC.raw[0]=PacketFromPC.raw[0];		// CMD ECHOBACK

		switch(PacketFromPC.cmd) {
		 case HIDASP_TEST:
			PacketToPC.raw[1]=0x25;					// PIC25
			PacketToPC.raw[2]=PacketFromPC.raw[1];	// ECHO
			ToPcRdy = 1;
			break;

		 case HIDASP_PEEK:
		 	size      = PacketFromPC.size;
			area = size & 0xc0;
			size = size & 0x3f;
		 	p = (uchar*)PacketFromPC.adrs;

			if(area) {
				PacketFromPC.data[0]=0;	// TBLPTRU���[���N���A.
				TBLPTR = (unsigned short long)PacketFromPC.adrs;
				
				for(i=0;i<size;i++) {
    					_asm
						tblrdpostinc
						_endasm
					PacketToPC.raw[i]=TABLAT;
				}
			}else{
				for(i=0;i<size;i++) {
					PacketToPC.raw[i]=*p++;
				}
			}
			ToPcRdy = 1;
			break;

		 case HIDASP_POKE:
		 	area = PacketFromPC.size;
		 	p = (uchar*)PacketFromPC.adrs;

#define	mask	PacketFromPC.data[1]
#define	data0	PacketFromPC.data[0]

			if( mask ) {	//�}�X�N��������.
				*p = (*p & mask) | data0;
			}else{			//�ʏ폑������.
				*p = data0;
			}
			break;
			
		}
	}

	if( ToPcRdy ) {
		if(!mHIDTxIsBusy()) {
			HIDTxReport((char *)&PacketToPC, 64);
			ToPcRdy = 0;
		}
	}
}
/********************************************************************
 *	
 ********************************************************************
 */
