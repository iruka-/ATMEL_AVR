#define C_WR_PAGE	0x4C
#define C_LD_ADRX	0x4D
#define	report_update(l)

