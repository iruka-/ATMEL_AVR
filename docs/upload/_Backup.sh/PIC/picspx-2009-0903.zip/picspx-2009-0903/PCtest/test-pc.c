#include <stdio.h>
#include <time.h>
#include <windows.h>

/* �e�X�g�p�̃f�[�^�i�P�ʃ~���b�j�A�Ō��-1�ŏI��邱�� */
static int test_data[] = {100, 50, 30, 20, 10, 5, 3, 2, 1, 0, -1};

#define COUNT 20

int main(void)
{
	int i, j;
	int log[100];
	LARGE_INTEGER nFr, nBf, nAf;

	QueryPerformanceFrequency(&nFr);
	i = 0;
	while (test_data[i] >= 0) {
		log[i] = 0;
        i++;
	}
	printf("�ʏ탂�[�h\n");
	i = 0;
	while (test_data[i] >= 0) {
		for (j = 0; j < COUNT; j++) {
			QueryPerformanceCounter(&nBf);
			Sleep(test_data[i]);
			QueryPerformanceCounter(&nAf);
			log[i] += (nAf.QuadPart - nBf.QuadPart) * 1000 / nFr.QuadPart;
		}
        i++;
	}
	i = 0;
	while (test_data[i] >= 0) {
		printf("%4d.0 --> %6.2lf [mSec]\n",test_data[i], (double)log[i] / (double)COUNT );
        i++;
	}

	// ���x�d�����[�h�̌v��
	printf("\n���x�d��\n");
	i = 0;
	while (test_data[i] >= 0) {
		log[i] = 0;
        i++;
	}
	timeBeginPeriod(1);
	i = 0;
	while (test_data[i] >= 0) {
		for (j = 0; j < COUNT; j++) {
			QueryPerformanceCounter(&nBf);
			Sleep(test_data[i]);
			QueryPerformanceCounter(&nAf);
			log[i] += (nAf.QuadPart - nBf.QuadPart) * 1000 / nFr.QuadPart;
		}
        i++;
	}
	timeEndPeriod(1);	// �ʏ�ɖ߂�
	i = 0;
	while (test_data[i] >= 0) {
		printf("%4d.0 --> %6.2lf [mSec]\n",test_data[i], (double)log[i] / (double)COUNT );
        i++;
	}

	return 0;
}
