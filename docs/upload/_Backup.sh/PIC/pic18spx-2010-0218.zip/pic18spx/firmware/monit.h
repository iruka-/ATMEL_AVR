#ifndef	monit_h_
#define	monit_h_

void UserInit(void);
void ProcessIO(void);

#endif

