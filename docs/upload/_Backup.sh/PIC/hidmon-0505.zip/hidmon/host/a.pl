#!/usr/bin/perl

sub age()
{
	my ($s)=@_;
	return substr($s,30);
}

                   sub byage {
                       &age($a) cmp &age($b);  # presuming numeric
                   }
#                   @sortedclass = sort byage @class;

sub main()
{
	while(<>) {
		$line = $_;
#		$line = substr($line,30);
		push @buf,$line;		
	}

	@buf = sort byage @buf;

	foreach $line(@buf) {
		print $line;
	}

}


&main();
