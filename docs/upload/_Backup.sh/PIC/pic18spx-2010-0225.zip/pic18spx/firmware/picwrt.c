/********************************************************************
 *	�ȈՃ��j�^
 ********************************************************************
 */
#include "usb/typedefs.h"
#include "usb/usb.h"
#include "io_cfg.h"
#include "monit.h"
#include "hidcmd.h"
#include "picwrt.h"

/********************************************************************
 *	
 ********************************************************************
	// PICwriter��p.
	struct{
		uchar  piccmd;
		uchar  picsize;
		uchar  picadrl;
		uchar  picadrh;
		uchar  picadru;
		uchar  piccmd4;
		uchar  picms;
		uchar  picdata[32];
	};
 */
enum CMD_4 {
	b_0000 = 0x00,
	b_1000 = 0x08,
	b_1001 = 0x09,
	b_1100 = 0x0c,	//
	b_1101 = 0x0d,	// TBLPTR+=2
	b_1111 = 0x0f,	// Write!
};


#if defined(__18F14K50)

//	�|�[�g�o�̓f�[�^.    
#define	PGC	 		LATBbits.LATB6		// RB6
#define	PGD	 		LATBbits.LATB4		// RB4
#define	PGM	 		LATCbits.LATC7		// RC7
#define	MCLR 		LATCbits.LATC6		// RC6

//	�|�[�g�ǂݍ���.
#define	inPGC	 	PORTBbits.RB6
#define	inPGD	 	PORTBbits.RB4
#define	inPGM	 	PORTCbits.RC7
#define	inMCLR 		PORTCbits.RC6

//	�������W�X�^ (0=�o��)
#define	dirPGC	 	TRISBbits.TRISB6
#define	dirPGD	 	TRISBbits.TRISB4
#define	dirPGM	 	TRISCbits.TRISC7
#define	dirMCLR 	TRISCbits.TRISC6



#else
//	18F2550/4550

//	�|�[�g�o�̓f�[�^.    
#define	PGC	 		LATBbits.LATB1		// RB1
#define	PGD	 		LATBbits.LATB0		// RB0
#define	PGM	 		LATCbits.LATC7		// RC7
#define	MCLR 		LATCbits.LATC6		// RC6

//	�|�[�g�ǂݍ���.
#define	inPGC	 	PORTBbits.RB1
#define	inPGD	 	PORTBbits.RB0
#define	inPGM	 	PORTCbits.RC7
#define	inMCLR 		PORTCbits.RC6

//	�������W�X�^ (0=�o��)
#define	dirPGC	 	TRISBbits.TRISB1
#define	dirPGD	 	TRISBbits.TRISB0
#define	dirPGM	 	TRISCbits.TRISC7
#define	dirMCLR 	TRISCbits.TRISC6


#endif

/********************************************************************
 *	�f�[�^
 ********************************************************************
 */
//#pragma udata access accessram

//	�R�}���h�̕ԐM���K�v�Ȃ�1���Z�b�g����.
extern	uchar near ToPcRdy;

//#pragma udata SomeSectionName1
extern	Packet PacketFromPC;			//���̓p�P�b�g 64byte

//#pragma udata SomeSectionName2
extern	Packet PacketToPC;				//�o�̓p�P�b�g 64byte


#define	Cmd0	PacketFromPC.cmd
#define	set_bit(Port_,val_) \
				Port_ = val_ 

/********************************************************************
 *	ISP���W���[�� �C���N���[�h.
 ********************************************************************
 */
#pragma code


/*********************************************************************
 *	�P�ʕb�P�ʂ̎��ԑ҂�.
 *********************************************************************
 *	Windows���ł�USB�t���[�����Ԃ̏����������̂ŁA���ۂɂ͕s�v.
 *	�}�C�R���t�@�[�����ɈڐA����Ƃ��̓}�C�R�����ł��ꂼ������̕K�v������.
 */
static	void wait_us(uchar us)
{
	uchar i;
	for(i=0;i<us;i++) {
		_asm 
		nop
		nop
		nop
		nop
		nop
		nop
		nop
		nop
		_endasm;
	}
}
static	void wait_ms(uchar ms)
{
	uchar i;
	for(i=0;i<ms;i++) {
		wait_us(250);
		wait_us(250);
		wait_us(250);
		wait_us(250);
	}
}



/*********************************************************************
 *	1bit���M.
 *********************************************************************

        +---+
  PGC --+   +---

  PGD [ b=0�Ȃ�L ]
        b=1�Ȃ�H
 */
void SetCmdb1(uchar b)
{
	if(b)	set_bit(PGD,1);
	else	set_bit(PGD,0);
	wait_us(1);
	set_bit(PGC,1);wait_us(1);
	set_bit(PGC,0);wait_us(1);
}

void SetCmdb1Long(uchar b,uchar ms)
{
	if(b)	set_bit(PGD,1);
	else	set_bit(PGD,0);

	wait_us(1);
	set_bit(PGC,1);

	if(ms) wait_ms(ms);
	wait_us(1);

	set_bit(PGC,0);

	wait_us(1);
}

/*********************************************************************
 *	1bit��M.
 *********************************************************************
        +---+
  PGC --+   +---

           �� �����œǂ�.

  PGD [ ����    ]
 */
uchar GetCmdb1(void)
{
	uchar b=0;
	set_bit(PGC,1);
	wait_us(1);
//	b = get_port(Pinb) & (1<<PGD);
	if(inPGD) b=1;

	set_bit(PGC,0);
	wait_us(1);
	return b;
}
/*********************************************************************
 *	n bit ���M.
 *********************************************************************
 */
void SetCmdN(ushort cmdn,uchar len)
{
	uchar i,b;
	for(i=0;i<len;i++) {
		b = cmdn & 1;
		SetCmdb1(b);
		cmdn >>=1;
	}
}

/*********************************************************************
 *	4 bit ���M , �Ō�� PGC_H���Ԃ��w��.
 *********************************************************************
 */
void SetCmdNLong(uchar cmdn,uchar len,uchar ms)
{
	uchar i,b;
	for(i=0;i<(len-1);i++) {
		b = cmdn & 1;
		SetCmdb1(b);
		cmdn >>=1;
	}
	{
		b = cmdn & 1;
		SetCmdb1Long(b,ms);
	}
}

/*********************************************************************
 *	PGD�r�b�g�̓��o�͕�����؂�ւ���.(0=����)
 *********************************************************************
 *	f=0 ... PGD=in
 *	f=1 ... PGD=out
 */

void SetPGDDir(uchar f)
{
#if	0
	int dirb = (1<<PGC) | (1<<PGM) | (1<<MCLR);
	if(f) dirb |= (1<<PGD);
	set_port(Ddrb ,dirb);
#else

//	PIC
	if(f) {
		dirPGD=0;	// out
	}else{
		dirPGD=1;	// in
	}

/*	int dirc = (1<<PGM) | (1<<MCLR);

	int dirb = (1<<PGC) ;
	if(f) dirb |= (1<<PGD);

	set_port(Ddrb ,dirb ^ 0xff);
	set_port(Ddrc ,dirc ^ 0xff);
 */

#endif
}


/*********************************************************************
 *	8 bit ��M.
 *********************************************************************
 */
static	uchar GetData8b(void)
{
	uchar i,data8=0,mask=1;
	SetPGDDir(0);		// PGD=in

	for(i=0;i<8;i++,mask<<=1) {
		if( GetCmdb1() ) {
			data8 |= mask;
		}
	}
	SetPGDDir(1);		// PGD=out
	return data8;
}
/*********************************************************************
 *	4bit�̃R�}���h �� 16bit�̃f�[�^�𑗐M.
 *********************************************************************
 */
void SetCmd16(uchar cmd4,ushort data16,uchar ms)
{
	SetCmdNLong(cmd4,4,ms);
	SetCmdN(data16,16);
}

/*********************************************************************
 *	TBLPTR[U,H,L] �̂ǂꂩ��8bit�l���Z�b�g����.
 *********************************************************************
 */
static	void SetAddress8x(uchar adr,uchar inst)
{
	SetCmd16(b_0000,0x0e00 |  adr,0);		// 0E xx  : MOVLW xx
	SetCmd16(b_0000,0x6e00 | inst,0);		// 6E Fx  : MOVWF TBLPTR[U,H,L]
}
/*********************************************************************
 *	TBLPTR ��24bit�A�h���X���Z�b�g����.
 *********************************************************************
 */
void setaddress24(void)
{
	SetAddress8x(PacketFromPC.picadru,0xf8);	// TBLPTRU
	SetAddress8x(PacketFromPC.picadrh,0xf7);	// TBLPTRH
	SetAddress8x(PacketFromPC.picadrl,0xf6);	// TBLPTRL
}

/*********************************************************************
 *	TBLPTR ����P�o�C�g�ǂݏo��. TBLPTR�̓|�X�g�E�C���N�������g�����.
 *********************************************************************
 */
static	uchar GetData8(void)
{
	SetCmdN(b_1001,4);
	SetCmdN(0 , 8);
	return GetData8b();
}

#if	0
void GetData8L(int adr,uchar *buf,int len)
{
	int i,c;
	SetAddress24(adr);
	for(i=0;i<len;i++) {
		c = GetData8();
		*buf++ = c;
//		if(dumpf)printf(" %02x",c);
	}
}
#endif


#if	0
/*********************************************************************
 *	4bit�̃R�}���h �� 16bit�̃f�[�^�𑗐M.
 *********************************************************************
 */
void SetCmd16L(uchar cmd4,ushort *buf,uchar len,uchar ms)
{
	uchar i;
	ushort data16;
	for(i=0;i<len;i++) {
		data16 = *buf++;
		SetCmdNLong(cmd4,4,ms);
		SetCmdN(data16,16);
	}
}
#endif
/********************************************************************
 *	16bit�f�[�^���(size)���[�h����������.
 ********************************************************************
 *	cmd4 �́A�e16bit�f�[�^���������ޑO�ɗ^����4bit�R�}���h.
 *	ms   �́A4bit�R�}���h�̍ŏIbit���o��ɉ��~���b�҂ׂ����̒l.
 *	ms=0 �̂Ƃ��� 1uS �҂�.
 */
void pic_setcmd16L(void)
{
	uchar len = PacketFromPC.picsize;
	uchar cmd4= PacketFromPC.piccmd4;
	uchar ms  = PacketFromPC.picms;
	uchar i;
	ushort *s = (ushort *) PacketFromPC.picdata;
	ushort data16;
	for(i=0;i<len;i++) {
		data16 = *s++;
		SetCmdNLong(cmd4,4,ms);
		SetCmdN(data16,16);
	}
}
/********************************************************************
 *	24bit�A�h���X���Z�b�g���āA 8bit�f�[�^���(size)�o�C�g���擾����.
 ********************************************************************
 */
void pic_getdata8L(void)
{
	uchar i,len;

	setaddress24();

	len =PacketFromPC.picsize;
	for(i=0;i<len;i++) {
		PacketToPC.raw[i] = GetData8();
	}
}
/********************************************************************
 *	PIC�v���O�������[�h
 ********************************************************************
 */
void pic_setpgm(void)
{
	uchar f=PacketFromPC.picsize;

	if(f) {
		//�S�Ă̐M����L�ɂ���.
		set_bit(PGM,0);
		set_bit(PGD,0);
		set_bit(PGC,0);
		set_bit(MCLR,0);

	dirPGM=0;
	dirPGC=0;
	dirMCLR=0;

	SetPGDDir(1);		// PGD=out

		wait_ms(1);
		set_bit(PGM,1);	// PGM=H
		wait_ms(1);
		set_bit(MCLR,1);// MCLR=H
		wait_ms(1);
	}else{
		set_bit(PGD,0);// MCLR=L
		set_bit(PGC,0);// MCLR=L
		wait_ms(1);
		set_bit(MCLR,0);// MCLR=L
		wait_ms(1);
		set_bit(PGM,0);	// PGM=L
		wait_ms(1);
		//�S�Ă̐M����L�ɂ���.
		set_bit(PGM,0);
		set_bit(PGD,0);
		set_bit(PGC,0);
		set_bit(MCLR,0);

	dirPGM=1;
	dirPGC=1;
	dirMCLR=1;

	SetPGDDir(0);		// PGD=out
	}
}

/********************************************************************
 *	PIC���C�^�[�n�R�}���h��M�Ǝ��s.
 ********************************************************************
 *	Cmd0 : 0x10�`0x1F
 */
void cmd_picspx(void)
{
	if(		Cmd0==PICSPX_SETCMD16L) {pic_setcmd16L();}
	else if(Cmd0==PICSPX_SETADRS24) {setaddress24();}
	else if(Cmd0==PICSPX_GETDATA8L) {pic_getdata8L();}
	else if(Cmd0==PICSPX_SETPGM) 	{pic_setpgm();}

	ToPcRdy = Cmd0 & 1;	// LSB��On�Ȃ�ԓ����K�v.
}


/********************************************************************
 *	
 ********************************************************************
 */
