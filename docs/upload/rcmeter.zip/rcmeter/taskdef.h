/**********************************************************************
 *	Tiny Task Controler
 **********************************************************************
 *	�^�X�NID�������Ō��߂Ă悢.
 *	task.h ::MAX_TASKS �ȏ��ID�͋֎~.
 */

#ifndef	_taskdef_h_
#define	_taskdef_h_

#define	ID_main		0
#define	ID_led		1



#endif	//_taskdef_h_
