/********************************************************************
 *	���C������
 ********************************************************************
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "iodefine.h"
#include "usb/usb_hal.h"
#include "usb/usb_core.h"
#include "usb/cdc/usb_cdc.h"
#include "utype.h"


/********************************************************************
 *
 ********************************************************************
 */
#define	ECHOBACK_TEST	(1)	// �G�R�[�o�b�N�e�X�g

extern	uint	SysPCLK;	// ���ӃN���b�N��48MHz	(48,000,000)

/********************************************************************
 *
 ********************************************************************
 */
void LEDon(void)
{
	PORT1.DR.BIT.B5 = 0;		//DR(Data Reg.)
}

/********************************************************************
 *
 ********************************************************************
 */
void LEDoff(void)
{
	PORT1.DR.BIT.B5 = 1;
}

/********************************************************************
 *
 ********************************************************************
 */
void LEDflip(void)
{
	PORT1.DR.BIT.B5 ^= 1;
}

/********************************************************************
 *
 ********************************************************************
 */
void init_LED(void)
{
	PORT1.DDR.BIT.B5 = 1;	//DDR(Data Direction Reg.)
	PORT1.DR.BIT.B5  = 1;	//off
}

#define	LED_MAXCNT	1	//*	�k�d�c���������œ_�ł�����Ԉ����J�E���^.

/********************************************************************
 *	�k�d�c���������œ_�ł�����.
 ********************************************************************
 */
static	void	LED_blink(void)
{
	static int cnt=0;
	cnt++;
	if(	cnt >= LED_MAXCNT ) {
		cnt = 0 ;
		LEDflip();
	}
}

/********************************************************************
 *	�^�C�}�[������.
 ********************************************************************
 */
void init_TMR0(void)
{
	//module stop
	MSTP(TMR0) = 0;			//remove module stop bit (iodefine.h)

	//INT level:7(0:lowest - 15:highest) (CMT0 at IPRJ:15-12)
	IPR(TMR0, CMIA0) = 2;	//lower priority

	TMR0.TCNT = 0;					//(Compare-Match Count Reg.) count-up from 0
//	TMR0.TCORA = MSEC1-1;			//(Compare-Match Constant Reg.) 1msec
	TMR0.TCORA = (SysPCLK/1024)/1000+1;	//(Compare-Match Constant Reg.) 1msec
	
	//clock source
	TMR0.TCCR.BYTE = 0x0d;	//1/1024
	
	//CMCSR(Compare-Match Control/Status Reg.)
	//bit 1-0	CKS		(*00,01,10,11)=(Pclk/8,Pclk/32.Pclk/128,Pclk/512)
	//    6		CMIE	(0/*1)=(disable/enable) INT
	//    7		CMF		(0/1) match flag
	TMR0.TCR.BIT.CCLR = 1;		//clear CNT on (0/1/2/3)=(none/CMA/CMB/Ext)
	TMR0.TCR.BIT.CMIEA = 1;		//enable INT of Compare-Match A

	IEN(TMR0, CMIA0) = 1;
}


/********************************************************************
 *	�^�C�}�[���荞��
 ********************************************************************
 */
void INT_Excep_TMR0_CMIA0(void) __attribute__ ((interrupt));
void INT_Excep_TMR0_CMIA0(void)
{
	//CMCSR(Compare Match Control/Status Reg)
	IR(TMR0, CMIA0) = 0;		//

	//automatical CMCNT=0, then count up
	//__asm__("setpsw I");		//enable multiple INT

}





#define	SZ 256


/********************************************************************
 *
 ********************************************************************
 */
void usbWrite(int size,uchar *buf)
{
	int sz;
	while(size>0) {
		sz = size;
		if(sz>63) sz=63;
		USBCDC_Write(sz,buf);
		buf  += sz;
		size -= sz;
	}
}
/********************************************************************
 *
 ********************************************************************
 */
#if	ECHOBACK_TEST		// �G�R�[�o�b�N�e�X�g


void	loop(void)
{
	uchar  		  buf[SZ]; 
	unsigned long size;
	while(1) {
		size=0;
		USBCDC_Read(SZ,buf,&size);
		usbWrite(size,buf);
		LED_blink();
	}
}

#else

extern	void loop(void);

#endif

/********************************************************************
 *
 ********************************************************************
 */
void setup(void)
{
	init_LED();
	init_TMR0();
	IPR(ICU, SWINT) = 1;	//interrupt priority (0:noINT - 15:highest)
	IEN(ICU, SWINT) = 1;	//enable
	ICU.IER[3].BIT.IEN2 = 1;//IER03.IEN2 (swi26)
	USBCDC_Init();
}

/********************************************************************
 *
 ********************************************************************
 */
int main()
{
	setup();
	while(1) {
		loop();
	}
	return 0;
}

/********************************************************************
 *
 ********************************************************************
 */
