#include <avr/io.h>
#include <avr/pgmspace.h>


#include "ps2keyb.h"

//--------------------------------------------------------------
//	4 * __count  cycles ���ԑ҂�.
//--------------------------------------------------------------
void delay_loop(uchar __count)
{
	__asm__ volatile (
		"1: dec %0" "\n\t"
		"nop\n\t"
		"brne 1b"
		: "=r" (__count)
		: "0" (__count)
	);
}

void delay_us(uchar us)
{
	delay_loop(us);
	delay_loop(us);
}

void delay_100us(uchar us100)
{
	while(us100) {
		delay_loop(200);
		us100--;
	}
}

void delay_ms(uchar ms)
{
	while(ms) {
		delay_100us(10);
		ms--;
	}
}

void delay_100ms(uchar ms100)
{
	while(ms100) {
		delay_ms(100);
		ms100--;
	}
}

