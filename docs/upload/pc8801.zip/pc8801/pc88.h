void pc88_init(void);
void pc88_scan(void);
