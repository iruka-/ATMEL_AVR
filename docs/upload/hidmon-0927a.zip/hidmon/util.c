/*********************************************************************
 *	�t�r�a�f�o�C�X�̎g�p�J�n�A�I���A�A�N�Z�X���̃��[�e�B���e�B.
 *********************************************************************
 *
 *�`�o�h:
int		UsbInit(int verbose,int enable_bulk);	������.
int		UsbExit(void);	�I��.
void 	UsbBench(int cnt,int psize);
void	UsbDump(int adr,int arena,int size);
void 	UsbPoke(int adr,int arena,int data0,int data1);
int 	UsbPeek(int adr,int arena);
int 	UsbRead(int adr,int arena,uchar *buf,int size);
 *
 *�����֐�:
usb_dev_handle	*open_dev(void);
int 	transfer_test_ctrl(usb_dev_handle *dev,int cnt,int psize);
void	dumpmem(usb_dev_handle *dev,int adr,int cnt);
void	pokemem(usb_dev_handle *dev,int adr,int data0,int data1);
void	memdump(void *ptr,int len,int off);



int hidasp_init(char *string);
void hidasp_close();
int hidasp_program_enable(int delay);
int hidasp_cmd(const unsigned char cmd[4],unsigned char res[4]);
int hidasp_page_write(long addr,const unsigned char *wd,int pagesize);
int hidasp_page_read(long addr,unsigned char *wd,int pagesize);

//
int	hidWriteFile(HANDLE hHID, char *buf, int Length, ULONG *sz, void *cb);
int hidReadFile( HANDLE hHID, char *buf, int Length, ULONG *sz, void *cb);

 */

#include <windows.h>
#include <stdio.h>
#include <time.h>

#include "hidasp.h"
#include "monit.h"
#include "util.h"

//void dump_info(  struct usb_device *dev );

//	obdev
#define MY_VID 0x16c0
#define MY_PID 0x05dc

#define	MY_Manufacturer	"AVRetc"
#define	MY_Product		"monky"

/* the device's endpoints */
#define PACKET_SIZE 		8
#define	VERBOSE				0

#define	if_V	if(VERBOSE)

typedef HANDLE usb_dev_handle;

usb_dev_handle usb_dev = 0; /* the device handle */
static	char verbose_mode = 0;
static  int  HidLength = 31;

/****************************************************************************
 *	�������[���e���_���v.
 ****************************************************************************
 */
void memdump(void *ptr,int len,int off)
{
	unsigned char *p = (unsigned char *)ptr;
	int i,j,c;

	for(i=0;i<len;i++) {
		if( (i & 15) == 0 ) printf("%06x",(int)p - (int)ptr + off);
		printf(" %02x",*p);p++;
		if( (i & 15) == 15 ) 
		{
#if	1	// ASCII DUMP
			printf("  ");
			for(j=0;j<16;j++) {
				c=p[j-16];
				if(c<' ') c='.';
				if(c>=0x7f) c='.';
				printf("%c",c);
			}
#endif
			printf("\n");
		}
	}
	printf("\n");
}




/*********************************************************************
 *	�ꎞ�o�b�t�@�ɉ��f�[�^��u��. �����l���O������add
 *********************************************************************
 */
void set_temp(char *tmp,int cnt,int add)
{
	int i;
	int c=0;
	for(i=0;i<cnt;i++,tmp++) {
		*tmp = c;
		c+= add;
	}
}

void inc_txbuf(unsigned char *txbuf)
{
	int i;
	for(i=0;i<4;i++) {
		txbuf[i] += 4;
	}
}

/*********************************************************************
 *
 *********************************************************************
 */
int QueryAVR(usb_dev_handle dev , RxBuf *cmd,uchar *buf,int reply)
{
	int rc = 0;
	int size = cmd->size;
//	DWORD sz = 0;
	char *s;
	rc = hidWriteBuffer((char*) cmd , HidLength );
	if(rc == 0) {
		printf("hidWrite error\n");
		exit(1);
	}
	if(reply) {
		rc = hidReadBuffer((char *)cmd , HidLength );
		if(rc == 0) {
			printf("hidRead error\n");
			exit(1);
		}
		s = (char*) cmd;
		memcpy(buf, s+1 ,size);
	}
    return rc;
}
/*********************************************************************
 *
 *********************************************************************
 */
int dumpmem(usb_dev_handle dev,int adr,int arena,int size,unsigned char *buf)
{
	RxBuf cmd;

	memset(&cmd,0,sizeof(RxBuf));
	cmd.cmd   = CMD_PEEK ;	//| arena;
	cmd.size  = size;
	cmd.adr[0]= adr;
	cmd.adr[1]= adr>>8;

	if( QueryAVR(dev,&cmd,buf,1) == 0) return 0;	//���s.
	return size;
}
/*********************************************************************
 *
 *********************************************************************
 */
void pokemem(usb_dev_handle dev,int adr,int arena,int data0,int data1)
{
    RxBuf cmd;
	char buf[16];	// dummy

	memset(&cmd,0,sizeof(RxBuf));
	cmd.cmd   = CMD_POKE ;	//| arena;
	cmd.size  = 1;
	cmd.adr[0]= adr;
	cmd.adr[1]= adr>>8;
	cmd.data[0] = data0;
	cmd.data[1] = data1;
	QueryAVR(dev,&cmd,buf,0);
}

int hid_ping(int i)
{
 	RxBuf cmd;
	char buf[128];	// dummy
	int rc;
//	DWORD sz;

	memset(&cmd,i,sizeof(RxBuf));
	cmd.cmd   = CMD_PING ;
	QueryAVR(usb_dev,&cmd,buf,0);

	rc = hidReadBuffer(buf , HidLength );
	if(rc == 0) {
		printf("hidRead error\n");
		exit(1);
	}
	return buf[1] & 0xff;
}
/*********************************************************************
 *
 *********************************************************************
 */
void UsbBench(int cnt,int psize)
{
	int i,n,rc;
	int total=0;
	int nBytes  = HidLength ;	//���݌Œ�.

   	printf("hid write start\n");
	int time0 = clock();

	for(i=0;i<cnt;i++) {
		n = i & 0xff;
		rc = hid_ping(n);
		if(rc != n) {
			printf("hid ping mismatch error (%x != %x)\n",rc,n);
			exit(1);
		}
		total += nBytes * 2;
	}

	int time1 = clock() - time0;
	int rate = total * 1000 / time1;

   	printf("hid write end %d %d s  %d byte/s\n",total,time1,rate);
}
/*********************************************************************
 *
 *********************************************************************
 */
void UsbDump(int adr,int arena,int cnt)
{
	unsigned char buf[16];
	int size;
	int rc;
	while(cnt) {
		size = cnt;
		if(size>=8) size = 8;
		rc = dumpmem(usb_dev,adr,arena,size,buf);
		if(rc !=size) return;
		memdump(buf,size,adr);
		adr += size;
		cnt -= size;
	}
}
/*********************************************************************
 *
 *********************************************************************
 */
int UsbRead(int adr,int arena,uchar *buf,int size)
{
	int rc = size;
	int len;
	while(size) {
		len = size;
		if(len >= 8) len = 8;
		int rc = dumpmem(usb_dev,adr,arena,len,buf);
		if( rc!= len) {
			return -1;
		}
		adr  += len;	// �^�[�Q�b�g�A�h���X��i�߂�.
		buf  += len;	// �ǂݍ��ݐ�o�b�t�@��i�߂�.
		size -= len; 	// �c��T�C�Y�����炷.
	}
	return rc;
}
/*********************************************************************
 *
 *********************************************************************
 */
int UsbPeek(int adr,int arena)
{
	unsigned char buf[16];
	int size=1;
	int rc = UsbRead(adr,arena,buf,size);
	if( rc != size) {
		return -1;
	}
	return buf[0];
}
/*********************************************************************
 *
 *********************************************************************
 */
void UsbPoke(int adr,int arena,int data0,int data1)
{
	pokemem(usb_dev,adr,arena,data0,data1);
}
/*********************************************************************
 *
 *********************************************************************
 */
int UsbInit(int verbose,int enable_bulk)
{
	verbose_mode = verbose;
//	hid_set_verbose(verbose);
	if(	hidasp_init(NULL) != 0) {
    	printf("error: device not found!\n");
    	return 0;
	}
//	usb_dev = hidasp_gethandle();
	return 1;	// OK.
}



/*********************************************************************
 *
 *********************************************************************
 */
int UsbExit(void)
{
	hidasp_close();
	return 0;
}
/*********************************************************************
 *
 *********************************************************************
 */

void report_update(int l)
{
}
