#include <plib.h>

#pragma config PMDL1WAY = OFF
#pragma config IOL1WAY = OFF
#pragma config FUSBIDIO = ON
#pragma config FVBUSONIO = ON
#pragma config FPLLIDIV = DIV_2
#pragma config FPLLMUL = MUL_16
#pragma config UPLLIDIV = DIV_5
#pragma config UPLLEN = OFF
#pragma config FPLLODIV = DIV_2
#pragma config FNOSC = PRIPLL
#pragma config FSOSCEN = OFF
#pragma config IESO = OFF
#pragma config POSCMOD = HS
#pragma config OSCIOFNC = OFF
#pragma config FPBDIV = DIV_2
#pragma config FCKSM = CSDCMD
#pragma config WDTPS = PS1
#pragma config WINDIS = OFF
#pragma config FWDTEN = OFF
#pragma config FWDTWINSZ = WISZ_25
#pragma config JTAGEN = OFF
#pragma config ICESEL = ICS_PGx1
#pragma config PWP = OFF
#pragma config BWP = OFF
#pragma config CP = OFF


int main() {
	int count=0;
	mPORTBDirection(0);
	
	while(1){
		mPORTBToggleBits(BIT_7);
		while(count){
			count--;
		}
		count=1000000;
	}
	
	return (EXIT_SUCCESS);
}