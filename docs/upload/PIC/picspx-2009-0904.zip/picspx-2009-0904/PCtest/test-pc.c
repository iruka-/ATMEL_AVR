/*
 * delay_ms�֐��̕]��
 * Written by senshu.
 */

#include <stdio.h>
#include <time.h>
#include <windows.h>

#define COUNT 500

/* �e�X�g�p�̃f�[�^�i�P�ʃ~���b�j�A�Ō��-1�ŏI���A�e�X�g����50�ȓ��Ƃ��� */
static int test_data[] = {10, 5, 2, 1, 0, -1};
static int log[100][COUNT];

void delay_ms(WORD dly)
{
    LARGE_INTEGER val1, val2;

    QueryPerformanceCounter(&val1);
    QueryPerformanceFrequency(&val2);
    val1.QuadPart += val2.QuadPart / 1000 * dly;
    do
        QueryPerformanceCounter(&val2);
    while (val2.QuadPart < val1.QuadPart);

}


int main(int argc, char *argv[])
{
	int i, j;
	int min, max, sum;
	double ave;
	LARGE_INTEGER nFr, nBf, nAf;

	QueryPerformanceFrequency(&nFr);
	timeBeginPeriod(1);
	Sleep(100);
	printf("-----\n delay_ms function:\n");
	i = 0;
	while (test_data[i] >= 0) {
		for (j = 0; j < COUNT; j++) {
			QueryPerformanceCounter(&nBf);
			delay_ms(test_data[i]);
			QueryPerformanceCounter(&nAf);
			log[i][j] = (nAf.QuadPart - nBf.QuadPart) * 1000 / nFr.QuadPart;
		}
        i++;
	}
	timeEndPeriod(1);	// �ʏ�ɖ߂�
	i = 0;
	while (test_data[i] >= 0) {
		sum = 0;
		max = min = log[i][0];
		for (j = 0; j < COUNT; j++) {
//			printf("%2d,", log[i][j]);
			sum += log[i][j];
			if (log[i][j] < min) min = log[i][j];
			if (log[i][j] > max) max = log[i][j];
		}
		ave = (double)sum / (double)COUNT;
		if ((test_data[i] != 0) && (max /test_data[i] > 5)) {
			printf("%4d -> min = %3d, max = %3d, avg = %5.2lf [mSec] <--- ???\n",
				test_data[i], min, max, ave);
		} else {
			printf("%4d -> min = %3d, max = %3d, avg = %5.2lf [mSec]\n",
				test_data[i], min, max, ave);
		}
        i++;
	}

	// ���x�d�����[�h�̌v��
	printf("\n Sleep function:\n");
	timeBeginPeriod(1);
	Sleep(100);
	i = 0;
	while (test_data[i] >= 0) {
		for (j = 0; j < COUNT; j++) {
			QueryPerformanceCounter(&nBf);
			Sleep(test_data[i]);
			QueryPerformanceCounter(&nAf);
			log[i][j] = (nAf.QuadPart - nBf.QuadPart) * 1000 / nFr.QuadPart;
		}
        i++;
	}
	timeEndPeriod(1);	// �ʏ�ɖ߂�
	i = 0;
	while (test_data[i] >= 0) {
		max = min = log[i][0];
		sum = 0;
		for (j = 0; j < COUNT; j++) {
//			printf("%2d,", log[i][j]);
			sum += log[i][j];
			if (log[i][j] < min) min = log[i][j];
			if (log[i][j] > max) max = log[i][j];
		}
		ave = (double)sum / (double)COUNT;
		if ((test_data[i] != 0) && (max /test_data[i] > 5)) {
			printf("%4d -> min = %3d, max = %3d, avg = %5.2lf [mSec] <--- ???\n",
				test_data[i], min, max, ave);
		} else {
			printf("%4d -> min = %3d, max = %3d, avg = %5.2lf [mSec]\n",
				test_data[i], min, max, ave);
		}
        i++;
	}

	return 0;
}
