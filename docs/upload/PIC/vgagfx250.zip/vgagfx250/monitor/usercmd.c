/********************************************************************
 *	���[�U�[��`�֐��̎��s
 ********************************************************************
 */
#include <stdio.h>

#include "../spi2.h"
#include "gpio.h"

int	 get_timer1();
int	 get_timer2();
void set_timer1(int t);
void set_timer2(int t);
void dma_init();
void dma_kick();

int user_putc(char c);
int user_puts(char *s);

#define	HSYNC	0	// PB0
#define	VSYNC	1	// PB1
#define	GREEN	2	// PB2

#define	HSYNC_pin	(PB0+HSYNC)
#define	VSYNC_pin	(PB0+VSYNC)
#define	GREEN_pin	(PB0+GREEN)

/********************************************************************
 *	Timer�e�X�g
 ********************************************************************
 */
void user_cmd1(int arg)
{
	int i;
	int n=0;

	printf("Start\n");
	set_timer1(0);
	set_timer2(0);
	while(n<10) {	//for(i=0;i<1000;i++) {
		int j,k;
		for(j=0;j<100;j++) {
			USBTask();
		}
		j=get_timer1();
		if(j>=31649) {
			printf("get_timer(%3d,%3d)\n",n,j);
			set_timer1(0);n++;
		}
//		k=get_timer2();
	}
	printf("Stop\n");
}

/********************************************************************
 *	SPI�e�X�g.
 ********************************************************************
 */
void user_cmd2(int arg)
{
	int i;

	SPI2_init();
	printf("Start\n");
	for(i=0;i<100;i++) {
		USBTask();
		printf("spi(%d)\n",i);
		SPI2_write(0xffff);
	}
	for(i=0;i<10000;i++) {
		SPI2_write(0xffff);
	}
	printf("Stop\n");
}


void init_vga_port();
/********************************************************************
 *	SPI�e�X�g.
 ********************************************************************
 */
void user_cmd3(int arg)
{
	int i;

	init_vga_port();
	printf("Start\n");
	for(i=0;i<100000;i++) {
		USBTask();wait_us(50);
		digitalWrite(GREEN_pin,HIGH);
		USBTask();wait_us(50);
		digitalWrite(GREEN_pin,LOW);
	}
	printf("Stop\n");
}


extern	volatile int g_Timer1;
extern	volatile int g_Timer2;
/********************************************************************
 *	SPI�e�X�g.
 ********************************************************************
 */
void user_cmd4(int arg)
{
	int j;
	printf("Start\n");
	
//	dma_init();
	for(j=0;j<100;j++) {
//		printf("g_Timer=%d,%d,%d,%d\n",g_Timer1,g_Timer2,g_Guard1,g_Guard2);
		USBTask();
//		dma_kick();
	}
	printf("Stop\n");
}


void user_cmd(int arg)
{
//	user_cmd1(arg);
//	user_cmd2(arg);
//	user_cmd3(arg);
	user_cmd4(arg);
}
