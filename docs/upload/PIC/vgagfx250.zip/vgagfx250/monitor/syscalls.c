/******************************************************************************
 * The MIT License
 *
 * Copyright (c) 2010 Perry Hung.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use, copy,
 * modify, merge, publish, distribute, sublicense, and/or sell copies
 * of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *****************************************************************************/

#include <sys/types.h>
#include <sys/stat.h>
#include "Compiler.h"
#include "HardwareProfile.h"
//#include "uart1.h"

extern int _end;
#define	STACK_TOP	0xa0002000

//
//	malloc���g���ꍇsbrk�͕K�v.
//	libc��printf���g���ꍇwrite�Ȃǂ��K�v�ɂȂ�.
//	MPLAB��<stdio.h>��include�����ꍇ�́A�ȉ��̒u������������.
//		#define printf _dprintf_cdeEfFgGnopsuxX
//	���̏ꍇ�A_dprintf_cdeEfFgGnopsuxX�̎����Ƃ���libce.c ���g�p
//	����̂ŁA�ȉ��̊֐��̓R�����g�A�E�g�����܂܂�OK.

#if	0	//�R�����g�A�E�g����.
int open(const char *path, int flags, ...)
{
	return 1;
}

int close(int fd)
{
	return 0;
}

int fstat(int fd, struct stat *st)
{
	st->st_mode = S_IFCHR;
	return 0;
}

int isatty(int fd)
{
	return 1;
}

int lseek(int fd, off_t pos, int whence)
{
	return -1;
}

int read(int fd, char *buf, size_t cnt)
{
//	*buf = getch();

	return 1;
}

int write(int fd, const char *buf, size_t cnt)
{
	int i;

	for (i = 0; i < cnt; i++) {
//      putch(buf[i]);
	}
	return cnt;
}
#endif

/*
 * sbrk -- changes heap size size. Get nbytes more
 *         RAM. We just increment a pointer in what's
 *         left of memory on the board.
 */
caddr_t sbrk(int nbytes)
{
	static caddr_t heap_ptr = NULL;
	caddr_t        base;

	if (heap_ptr == NULL) {
		heap_ptr = (caddr_t)&_end;
//		UART1PrintString( "sbrk heap=" );
//		UART1PutHex4( &_end );
	}

	if ((STACK_TOP >= (unsigned int) heap_ptr) ) {
		base = heap_ptr;
		heap_ptr += nbytes;
#if	0
		UART1PrintString( "sbrk" );
		UART1PutHex4( nbytes );
		UART1PrintString( "=" );
		UART1PutHex4( base );
		UART1PrintString( "\n" );
#endif
		return (base);
	} else {
//      uart_send("heap full!\r\n");
		return ((caddr_t)-1);
	}
}

