#include <p32xxxx.h>			// always in first place to avoid conflict with const.h ON
