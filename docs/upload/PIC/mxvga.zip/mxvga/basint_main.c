/* A tiny BASIC interpreter */

#include <stdio.h>
#include <string.h>
#include <setjmp.h>
#include <math.h>
#include <stdlib.h>

#define	PROG_SIZE	65536


#if	0
/* Load a program. */
int load_program(char *p,char *fname)
{
	FILE *fp;
	int i=0;

	if(!(fp=fopen(fname, "rb"))) return 0;

	i = 0;
	do {
		*p = getc(fp);
		p++;
		i++;
	} while(!feof(fp) && i<PROG_SIZE);
	*(p-2) = '\0'; /* null terminate the program */
	fclose(fp);
	return 1;
}
#else

extern	const char prime_vanilla[];

/* Load a program. */
int load_program(char *p,char *fname)
{
	int n=strlen(prime_vanilla);
	memcpy(p,prime_vanilla,n);	//PROG_SIZE);
	return 1;
}
#endif

int	main(int argc,char **argv)
{
	char *p_buf;
	if(argc!=2) {
		printf("usage: run <filename>\n");
//		exit(1);
	}

	/* allocate memory for the program */
	if(!(p_buf=(char *) malloc(PROG_SIZE))) {
		printf("allocation failure");
		exit(1);
	}

	/* load the program to execute */
	if(!load_program(p_buf,argv[1])) exit(1);

	basint(p_buf);
	return 0;
}
