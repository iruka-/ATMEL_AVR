/* A tiny BASIC interpreter */

#include <stdio.h>
#include <string.h>
#include <setjmp.h>
#include <math.h>
//#include <ctype.h>
#include <stdlib.h>

#define	USE_DIVINT	0	// div,mul���g��Ȃ�.
#define	ZZ	printf("%s:%d: \n",__FILE__,__LINE__);

#define NUM_LAB 100
#define LAB_LEN 10
#define FOR_NEST 25
#define SUB_NEST 25
#define PROG_SIZE 10000

#define DELIMITER  1
#define VARIABLE  2
#define NUMBER    3
#define COMMAND   4
#define STRING	  5
#define QUOTE	  6
/*
 * AFL has added these new token type
 * see get_token()
 */
#define	ARRAY			7
#define	FUNCTION		8

enum {
 NONE  =0,
 PRINT =1,
 INPUT ,
 IF    ,
 THEN  ,
 FOR   ,
 NEXT  ,
 TO    ,
 GOTO  ,
 EOL   ,
 FINISHED,
 GOSUB ,
 RETURN,
 LET   ,
 STOP  ,
 REM   ,
 END   ,
};
#define	CR		'\r'
#define	LF		'\n'

char *prog;  /* holds expression to be analyzed */
jmp_buf e_buf; /* hold environment for longjmp() */
char *head;

int variables[26];    /* 26 user variables,  A-Z */

typedef struct { /* keyword lookup table */
	const char *command;
	char tok;
} sCommands ;
#if	0
const sCommands keyw_table[] = { /* Commands must be entered lowercase */
	{"print", PRINT}, /* in this table. */
	{"input", INPUT},
	{"if"   , IF},
	{"then" , THEN},
	{"goto" , GOTO},
	{"for"  , FOR},
	{"next" , NEXT},
	{"to"   , TO},
	{"gosub", GOSUB},
	{"return",RETURN},
	{"let"  , LET},
	{"stop" , STOP},
	{"rem"  , REM},
	{"end"  , END},
	{""     , END}  /* mark end of table */
};
#endif
#define	keyw_table_a	NULL
#define	keyw_table_b	NULL
#define	keyw_table_c	NULL
#define	keyw_table_d	NULL
const sCommands keyw_table_e[] = {
	{"end"  , END},
	{NULL   , NONE},
};
const sCommands keyw_table_f[] = {
	{"for"  , FOR},
	{NULL   , NONE},
};
const sCommands keyw_table_g[] = {
	{"gosub", GOSUB},
	{"goto" , GOTO},
	{NULL   , NONE},
};
#define	keyw_table_h	NULL
const sCommands keyw_table_i[] = {
	{"if"   , IF},
	{"input", INPUT},
	{NULL   , NONE},
};
#define	keyw_table_j	NULL
#define	keyw_table_k	NULL
const sCommands keyw_table_l[] = {
	{"let"  , LET},
	{NULL   , NONE},
};
#define	keyw_table_m	NULL
const sCommands keyw_table_n[] = {
	{"next" , NEXT},
	{NULL   , NONE},
};
#define	keyw_table_o	NULL
const sCommands keyw_table_p[] = {
	{"print", PRINT}, /* in this table. */
	{NULL   , NONE},
};
#define	keyw_table_q	NULL
const sCommands keyw_table_r[] = {
	{"rem"  , REM},
	{"return",RETURN},
	{NULL   , NONE},
};
const sCommands keyw_table_s[] = {
	{"stop" , STOP},
	{NULL   , NONE},
};
const sCommands keyw_table_t[] = {
	{"then" , THEN},
	{"to"   , TO},
	{NULL   , NONE},
};

#define	keyw_table_u	NULL
#define	keyw_table_v	NULL
#define	keyw_table_w	NULL
#define	keyw_table_x	NULL
#define	keyw_table_y	NULL
#define	keyw_table_z	NULL

const sCommands *keyw_table_idx[26] = {
	keyw_table_a,	keyw_table_b,	keyw_table_c,	keyw_table_d,
	keyw_table_e,	keyw_table_f,	keyw_table_g,	keyw_table_h,
	keyw_table_i,	keyw_table_j,	keyw_table_k,	keyw_table_l,
	keyw_table_m,	keyw_table_n,	keyw_table_o,	keyw_table_p,
	keyw_table_q,	keyw_table_r,	keyw_table_s,	keyw_table_t,
	keyw_table_u,	keyw_table_v,	keyw_table_w,	keyw_table_x,
	keyw_table_y,	keyw_table_z,
};

char token[80];
char token_type, tok;

struct label {
	char name[LAB_LEN];
	char *p;  /* points to place to go in source file*/
};
struct label label_table[NUM_LAB];

struct for_stack {
	int var; /* counter variable */
	int target;  /* target value */
	char *loc;
	int dummy;
} fstack[FOR_NEST]; /* stack for FOR/NEXT loop */
struct for_stack fpop();

char *gstack[SUB_NEST];	/* stack for gosub */

int ftos;  /* index to top of FOR stack */
int gtos;  /* index to top of GOSUB stack */

//
//	prototypes:
//
int		basint(char *p_buf);
void	assignment(void);
void	print();
void	scan_labels();
void	find_eol(void);
int		get_next_label(char *s);
char	*find_label(char *s);
void	exec_goto();
void	label_init();
void	exec_if();
void	exec_for();
void	next();
struct	for_stack i;;
void	input();
void	gosub();
void	greturn();
void	gpush(char *s);
char	*gpop();
void	get_exp(int *result);
void	print_err_line(void);
void	serror(int error);
inline	int		iswhite(char c);
inline	int		isdelim(char c);
int		get_token(void);
void	putback();
int		look_up(char *s);
void	level2(int *result);
void	level3(int *result);
void	level4(int *result);
void	level5(int *result);
void	level6(int *result);
void	primitive(int *result);
void	arith(char o,int *r, int *h);
void	unary(char o,int *r);
int		find_var(char *s);
void    fpush(struct for_stack i);
char   *progLineNum( char	*p )
{
	int i;

	for(	i=0; i<NUM_LAB && label_table[i].p && label_table[i].p < p;	i++	)
		;
	//printf( "proglineNum: i=%d\n",	i );
	if( i ==	NUM_LAB	)  return( label_table[	NUM_LAB-1 ].name );
	else	if(	i == 0 )   return( label_table[0].name );
	else				   return( label_table[i-1].name );
}

#if	1	//USE_DIVINT		// div,mul���g��Ȃ�.
//	return s/t;
int	divuint(int s,int t)
{
	int i,m=1,q=0;
	if( s<t) return 0;

	for(i=0;i<32;i++) {
		if(s <= t ) {
			if(i) {
				t>>=1;
				m>>=1;
			}
			break;
		}
		t<<=1;
		m<<=1;
	}
	
	for(i=0;i<32;i++) {
		if(s==0) break;
		if(	s >= t) {
			s -= t;
			q |= m;
		}
		t>>=1;
		m>>=1;
	}
	return q;
}

//	return s*t;
int	muluint(int s,int t)
{
	int i,m=1,q=0;
	for(i=0;i<32;i++) {
		if(s & m) {
			q += t;
		}
		t<<=1;
		m<<=1;
	}
	
	return q;
}

int	divint(int s,int t)
{
	int sign=1;
	if(s<0) {s=-s;sign=-sign;}
	if(t<0) {t=-t;sign=-sign;}
	if(sign>=0) {
		return divuint(s,t);
	}
	return (-divuint(s,t));
}

int	mulint(int s,int t)
{
	int sign=1;
	if(s<0) {s=-s;sign=-sign;}
	if(t<0) {t=-t;sign=-sign;}
	if(sign>=0) {
		return muluint(s,t);
	}
	return (-muluint(s,t));
}
#endif
/*
 * EXEC_LET
 * Assign value	to a variable
 */
void exec_let()
{
//	if( Trace ) PRINTF( "%s let\n", progLineNum(	prog ) );
	token_type =	get_token();
	/* check	for	assignment statement */
	if( token_type != VARIABLE && token_type	!= ARRAY ) {
		serror( 0	);
	} else {
		putback();		/* put the variable	token back into	the	queue */
		assignment();		/* and do assignment */
	}
}


int	basint(char *p_buf)
{
	if(setjmp(e_buf)) exit(1); /* initialize the long jump buffer */

	printf(
	"* This is vanilla TinyBASIC One *\n"
	"Ready\n");

	prog = p_buf;
	head = p_buf;
	scan_labels(); /* find the labels in the program */
	ftos = 0; /* initialize the FOR stack index */
	gtos = 0; /* initialize the GOSUB stack index */
	do {
		token_type = get_token();

		/* check for assignment statement */
		if(token_type==VARIABLE) {
			putback(); /* return the var to the input stream */
			assignment(); /* must be assignment statement */
		} else /* is command */
			switch(tok) {
			case PRINT:
				print();
				break;
			case GOTO:
				exec_goto();
				break;
			case IF:
				exec_if();
				break;
			case FOR:
				exec_for();
				break;
			case NEXT:
				next();
				break;
			case INPUT:
				input();
				break;
			case GOSUB:
				gosub();
				break;
			case RETURN:
				greturn();
				break;
			case LET:
				exec_let();
				break;
			case REM:
				find_eol();
				break;
			case STOP:
				//if( showstop ) 
				{
					printf( "program stopped at line %s\n", progLineNum( prog ) );
//					closeScreen( "Program Stop." );
//					execute_time( progStartTime );
				}
				return(0);
				break;
			case END:
				exit(0);
			}
	} while (tok != FINISHED);
	return 0;
}


#ifdef	MSDOS
/* Load a program. */
int load_program(char *p,char *fname)
{
	FILE *fp;
	int i=0;

	if(!(fp=fopen(fname, "rb"))) return 0;

	i = 0;
	do {
		*p = getc(fp);
		p++;
		i++;
	} while(!feof(fp) && i<PROG_SIZE);
	*(p-2) = '\0'; /* null terminate the program */
	fclose(fp);
	return 1;
}
int	main(int argc,char **argv)
{
	char *p_buf;
	if(argc!=2) {
		printf("usage: run <filename>\n");
		exit(1);
	}

	/* allocate memory for the program */
	if(!(p_buf=(char *) malloc(PROG_SIZE))) {
		printf("allocation failure");
		exit(1);
	}

	/* load the program to execute */
	if(!load_program(p_buf,argv[1])) exit(1);

	basint(p_buf);
}
#endif


/* read input */
int my_scanf(char *fmt, int *i)
{
	// ...
	return 1;
}

/* Assign a variable a value. */
void assignment(void)
{
	int var, value;

	/* get the variable name */
	get_token();
	if(!isalpha(*token)) {
		serror(4);
		return;
	}

	var = toupper(*token)-'A';

	/* get the equals sign */
	get_token();
	if(*token!='=') {
		serror(3);
		return;
	}

	/* get the value to assign to var */
	get_exp(&value);

	/* assign the value */
	variables[var] = value;
}

/* Execute a simple version of the BASIC PRINT statement */
void print()
{
	int answer;
	int len=0, spaces;
	char last_delim=0;

	do {
		get_token(); /* get next list item */
		//printf("1) >%s<\n",token);
		if(tok==EOL || tok==FINISHED) break;
		if(token_type==QUOTE) { /* is string */
			printf("%s",token);
			len += strlen(token);
			get_token();
		//printf("2) >%s<\n",token);
		} else { /* is expression */
			putback();
			get_exp(&answer);
			get_token();
		//printf("3) >%s<\n",token);
			len += printf("%d", answer);
		}
		last_delim = *token;

		//printf("\n tok=%d last_delim=0x%x token=0x%x\n",tok,last_delim,*token);

		if(*token==';') {
			/* compute number of spaces to move to next tab */
			spaces = 8 - (len % 8);
			len += spaces; /* add in the tabbing position */
			while(spaces) {
				printf(" ");
				spaces--;
			}
		} else if(*token==',') {
			/* do nothing */;
		} else if(tok!=EOL && tok!=FINISHED) {
			serror(0);
		}
	} while (*token==';' || *token==',');

	if(tok==EOL || tok==FINISHED) {
		if(last_delim != ';' && last_delim!=',') printf("\n");
	} else {
		//printf("tok=%d last_delim=0x%x\n",tok,last_delim);
		serror(0); /* error is not , or ; */
	}
}

/* Find all labels. */
void scan_labels()
{
	int addr;
	char *temp;

	label_init();  /* zero all labels */
	temp = prog;   /* save pointer to top of program */

	/* if the first token in the file is a label */
	get_token();
	if(token_type==NUMBER) {
		strcpy(label_table[0].name,token);
		label_table[0].p=prog;
	}

	find_eol();
	do {
		get_token();
		if(token_type==NUMBER) {
			addr = get_next_label(token);
			if(addr==-1 || addr==-2) {
				(addr==-1) ?serror(5):serror(6);
			}
			strcpy(label_table[addr].name, token);
			label_table[addr].p = prog;  /* current point in program */
		}
		/* if not on a blank line, find next line */
		if(tok!=EOL) find_eol();
	} while(tok!=FINISHED);
	prog = temp;  /* restore to original */
}

/* Find the start of the next line. */
void find_eol(void)
{
	while(*prog!='\n' && *prog!='\0') ++prog;
	if(*prog) prog++;

	head=prog;
}

/* Return index of next free position in label array.
   A -1 is returned if the array is full.
   A -2 is returned when duplicate label is found.
*/
int	get_next_label(char *s)
{
	int t;

	for(t=0; t<NUM_LAB; ++t) {
		if(label_table[t].name[0]==0) return t;
		if(!strcmp(label_table[t].name,s)) return -2; /* dup */
	}

	return -1;
}

/* Find location of given label.  A null is returned if
   label is not found; otherwise a pointer to the position
   of the label is returned.
*/
char *find_label(char *s)
{
	int t;

	for(t=0; t<NUM_LAB; ++t)
		if(!strcmp(label_table[t].name,s)) return label_table[t].p;
	return '\0'; /* error condition */
}

/* Execute a GOTO statement. */
void exec_goto()
{

	char *loc;

	get_token(); /* get label to go to */
	/* find the location of the label */
	loc = find_label(token);
	if(loc=='\0') {
		serror(7); /* label not defined */
	}
	else prog=loc;  /* start program running at that loc */
}

/* Initialize the array that holds the labels.
   By convention, a null label name indicates that
   array position is unused.
*/
void label_init()
{
	int t;

	for(t=0; t<NUM_LAB; ++t) label_table[t].name[0]='\0';
}

/* Execute an IF statement. */
void exec_if()
{
	int x , y, cond;
	char op;

	get_exp(&x); /* get left expression */

	get_token(); /* get the operator */
	if(!strchr("=<>", *token)) {
		serror(0); /* not a legal operator */
		return;
	}
	op=*token;

	get_exp(&y); /* get right expression */

	/* determine the outcome */
	cond = 0;
	switch(op) {
	case '<':
		if(x<y) cond=1;
		break;
	case '>':
		if(x>y) cond=1;
		break;
	case '=':
		if(x==y) cond=1;
		break;
	}
	if(cond) { /* is true so process target of IF */
		get_token();
//		if(tok!=THEN) {
//			serror(8);
//			return;
//		}/* else program execution starts on next line */

		if( tok != THEN ) {
			putback();		/* no THEN,	put	token back to process next */
		}

	} else {
		find_eol(); /* find start of next line */
	}
}

/* Execute a FOR loop. */
void exec_for()
{
	struct for_stack i;
	int value;

	get_token(); /* read the control variable */
	if(!isalpha(*token)) {
		serror(4);
		return;
	}

	i.var=toupper(*token)-'A'; /* save its index */

	get_token(); /* read the equals sign */
	if(*token!='=') {
		serror(3);
		return;
	}

	get_exp(&value); /* get initial value */

	variables[i.var]=value;

	get_token();
	if(tok!=TO) serror(9); /* read and discard the TO */

	get_exp(&i.target); /* get target value */

	/* if loop can execute at least once, push info on stack */
	if(value>=variables[i.var]) {
		i.loc = prog;
		fpush(i);
	} else /* otherwise, skip loop code altogether */
		while(tok!=NEXT) get_token();
}

/* Execute a NEXT statement. */
void next()
{
	int	 varname = -1;
	struct for_stack i;

	/*
	 * was a variable	name given?
	 */
	get_token();
	if( token_type ==	VARIABLE ) {
		/*
		 *	was	was	the	variable name?
		 */
		//printf( "NEXT: varname is %c\n",	*token );
		varname = toupper(	*token ) - 'A';
	} else {
		/*
		 *	it's now an	error for NEXT not to include it's variable-name
		 *	If the token was EOL, call putback() so	the	correct	line is
		 *	identified by serror()
		 */
		putback();
		serror( 8 );
		return;
	}

	i = fpop(); /* read the loop info */

	variables[i.var]++; /* increment control variable */
	if(variables[i.var]>i.target) return;  /* all done */
	fpush(i);  /* otherwise, restore the info */
	prog = i.loc;  /* loop */
}

/* Push function for the FOR stack. */
void fpush(struct for_stack i)
{
	if(ftos>FOR_NEST) {
		serror(10);
	}
	fstack[ftos]=i;
	ftos++;
}

struct for_stack fpop() {
	ftos--;
	if(ftos<0) serror(11);
	return(fstack[ftos]);
}

/* Execute a simple form of the BASIC INPUT command */
void input()
{
	char var;
	int i=0;

	get_token(); /* see if prompt string is present */
	if(token_type==QUOTE) {
		printf("%s",token); /* if so, print it and check for comma */
		get_token();
		if(*token!=',') {
			serror(1);
		}
		get_token();
	} else printf("? "); /* otherwise, prompt with / */
	var = toupper(*token)-'A'; /* get the input var */

	my_scanf("%d", &i); /* read input */

	variables[(int)var] = i; /* store it */
}

/* Execute a GOSUB command. */
void gosub()
{
	char *loc;

	get_token();
	/* find the label to call */
	loc = find_label(token);
	if(loc=='\0')
		serror(7); /* label not defined */
	else {
		gpush(prog); /* save place to return to */
		prog = loc;  /* start program running at that loc */
	}
}

/* Return from GOSUB. */
void greturn()
{
	prog = gpop();
}

/* GOSUB stack push function. */
void gpush(char *s)
{
	gtos++;

	if(gtos==SUB_NEST) {
		serror(12);
		return;
	}

	gstack[gtos]=s;

}

/* GOSUB stack pop function. */
char *gpop()
{
	if(gtos==0) {
		serror(13);
		return 0;
	}

	return(gstack[gtos--]);
}

/* Entry point into parser. */
void get_exp(int *result)
{
	get_token();
	if(!*token) {
		serror(2);
		return;
	}
	level2(result);
	putback(); /* return last token read to input stream */
}


void print_err_line(void)
{
	int c;
//	char *s=head;
	char *s=prog;
	while(*s) {
		c=*s++;
		printf("%c",c);
		if(c==LF) break;
	}
#if	1
	while(*s) {
		c=*s++;
		printf("%c",c);
		if(c==LF) break;
	}
#endif
}
/* display an error message */
void serror(int error)
{
	static char *e[]= {
		"syntax error",
		"unbalanced parentheses",
		"no expression present",
		"equals sign expected",
		"not a variable",
		"Label table full",
		"duplicate label",
		"undefined label",
		"THEN expected",
		"TO expected",
		"too many nested FOR loops",
		"NEXT without FOR",
		"too many nested GOSUBs",
		"RETURN without GOSUB"
	};
	printf("\nFATAL:%s\n", e[error]);
	print_err_line();

	longjmp(e_buf, 1); /* return to save point */
}

/* Return 1 if c is space or tab. */
inline	int	iswhite(char c)
{
	if(c==' ' || c=='\t') return 1;
	else return 0;
}

/* Return true if c is a delimiter. */
inline	int	isdelim(char c)
{
//	if(strchr(" ;,+-<>/*%^=()", c) || c==9 || c==CR || c==LF || c==0) {
	if(strchr("\t\r\n ;,+-<>/*%^=()", c) || c==0) {
		return 1;
	}
	return 0;
}

/* Get a token. */
int	get_token(void)
{
	char *temp;
	int   c;

	token_type=0;
	tok=0;
	temp=token;

	if(*prog=='\0') { /* end of file */
		*token=0;
		tok = FINISHED;
		return(token_type=DELIMITER);
	}

	while(iswhite(*prog)) ++prog;  /* skip over white space */

	c = *prog;
	if((c==CR)) { /* crlf */
		prog+=2;	// CRLF
		tok = EOL;

		token[0]=CR;
		token[1]=LF;
		token[2]=0;
		
		head = prog;
		return (token_type = DELIMITER);
	}

	if((c==LF)) { /* crlf */
		++prog;		// LF only
		tok = EOL;

		token[0]=LF;
		token[1]=0;

		head = prog;

		return (token_type = DELIMITER);
	}

	if(strchr("+-*^/%=;(),><", c)) { /* delimiter */
		*temp++ = *prog++; /* advance to next position */
		*temp=0;
		return (token_type=DELIMITER);
	}

	if(c=='"') { /* quoted string */
		prog++;
		while(*prog!='"'&& *prog!=CR && *prog!=LF) *temp++=*prog++;
		if(*prog==CR) {
			serror(1);
		}
		if(*prog==LF) {
			serror(1);
		}
		prog++;
		*temp=0;
		return(token_type=QUOTE);
	}

	if(isdigit(c)) { /* number */
		while(!isdelim(*prog)) *temp++=*prog++;
		*temp = '\0';
		return(token_type = NUMBER);
	}

	if(isalpha(c)) { /* var or command */
		while(!isdelim(*prog)) *temp++=*prog++;
		token_type=STRING;
	}

	*temp = '\0';

	/* see if a string is a command or a variable */
	if(token_type==STRING) {
		tok=look_up(token); /* convert to internal rep */
		if(!tok) token_type = VARIABLE;
		else token_type = COMMAND; /* is a command */
	}
	return token_type;
}



/* Return a token to input stream. */
void putback()
{

	char *t;

	t = token;
	for(; *t; t++) prog--;
}

int	mystricmp(const char *s,const char *t)
{
	while(*s) {
		if(tolower(*t)!=*s) return -1;
		s++;t++;
	}
	return *t;
}
/* Look up a a token's internal representation in the
   token table.
*/
int	look_up(char *s)
{
#if	0

	int i;
	/* see if token is in table */
	for(i=0; *keyw_table[i].command; i++) {
		if(!mystricmp(keyw_table[i].command, s)) return keyw_table[i].tok;
	}
	return 0; /* unknown command */

#else
	const sCommands *keyw;
	int c=tolower(*s);
	if((c<'a')||(c>'z')) {
		return 0; /* unknown command */
	}
	keyw=keyw_table_idx[c-'a'];if(keyw==NULL) {
		return 0; /* unknown command */
	}
	while(keyw->command) {
		if(!mystricmp(keyw->command, s)) return keyw->tok;
		keyw++;
	}
	return 0; /* unknown command */
	
#endif
}




/*  Add or subtract two terms. */
void level2(int *result)
{
	char  op;
	int hold;

	level3(result);
	while((op = *token) == '+' || op == '-') {
		get_token();
		level3(&hold);
		arith(op, result, &hold);
	}
}

/* Multiply or divide two factors. */
void level3(int *result)
{
	char  op;
	int hold;

	level4(result);
	while((op = *token) == '*' || op == '/' || op == '%') {
		get_token();
		level4(&hold);
		arith(op, result, &hold);
	}
}

/* Process integer exponent. */
void level4(int *result)
{
	int hold;

	level5(result);
	if(*token== '^') {
		get_token();
		level4(&hold);
		arith('^', result, &hold);
	}
}

/* Is a unary + or -. */
void level5(int *result)
{
	char op = 0;
	if((token_type==DELIMITER) && ( *token=='+' || *token=='-') ){
		op = *token;
		get_token();
	}
	level6(result);
	if(op)
		unary(op, result);
}

/* Process parenthesized expression. */
void level6(int *result)
{
	if((*token == '(') && (token_type == DELIMITER)) {
		get_token();
		level2(result);
		if(*token != ')') {
			serror(1);
		}
		get_token();
	} else
		primitive(result);
}

/* Find value of number or variable. */
void primitive(int *result)
{
	switch(token_type) {
	case VARIABLE:
		*result = find_var(token);
		get_token();
		return;
	case NUMBER:
		*result = atoi(token);
		get_token();
		return;
	default:
		serror(0);
	}
}

/* Perform the specified arithmetic. */
void arith(char o,int *r, int *h)
{
	int t, ex;

	switch(o) {
	case '-':
		*r = *r-*h;
		break;
	case '+':
		*r = *r+*h;
		break;
	case '*':
		*r = *r * *h;
		break;
	case '/':
#if	USE_DIVINT		// div,mul���g��Ȃ�.
		*r = divint((*r),(*h));
#else
		*r = (*r)/(*h);
#endif
		break;
	case '%':
#if	USE_DIVINT		// div,mul���g��Ȃ�.
		t = divint((*r),(*h));
		*r = *r-(mulint(t,(*h)));
#else
		t = (*r)/(*h);
		*r = *r-(t*(*h));
#endif
		break;
	case '^':
		ex = *r;
		if(*h==0) {
			*r = 1;
			break;
		}
		for(t=*h-1; t>0; --t) *r = (*r) * ex;
		break;
	}
}

/* Reverse the sign. */
void unary(char o,int *r)
{
	if(o=='-') *r = -(*r);
}

/* Find the value of a variable. */
int find_var(char *s)
{
	if(!isalpha(*s)) {
		serror(4); /* not a variable */
		return 0;
	}
	return variables[toupper(*token)-'A'];
}

