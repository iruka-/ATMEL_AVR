/**********************************************************************
 *	WindowsCE���C�u����: OWN_CODE
 *		stdio.c �̂悤�Ȃ��́iShift-JIS�̂݃T�|�[�g�j
 *
 *		�S�̓I�Ɏ蔲�������ł�.
 **********************************************************************
 */
#include <stdio.h>
//#include "stat.h"
//#include "conslib.h"

#define	MAX_FILES	16
#define	DEBUG	0
#define	TTY_FD	(-2)

void _user_puts(char *s);
int	divint(int s,int t);

int	errprintf(char *fmt,... );
/**********************************************************************
 *		�}�N���A��`
 **********************************************************************
 */
static	char	*vp;
static	void vputc(int c)
{
	*vp++ = c;
}

static	int is_num(int c)
{
	if((c<'0')||(c>'9')) return(-1);
	return(c-'0');
}

/**********************************************************************
 *		���������o���B
 **********************************************************************
 */
static char *getnum(char *s,int *val)
{
	int v,r,sgn;
	v=0;
	sgn=1;

	if(*s=='-') {
		s++;
		sgn=(-1);
	}

	if(is_num(*s)>=0) {
		while( (r=is_num(*s)) >=0) {
			v*=10;
			v+=r;
			s++;
		}
		*val=v*sgn;
	}
	return(s);
}

/**********************************************************************
 *		�T�u���[�`��
 **********************************************************************
 */
static	int hexch(int c,int alp)
{
	if(c>=10)	 c += alp;	/* 'A'��'a' �������� */
	c += '0';
	return(c);
}

static	void hexprint(int val,int column,int radix,int fmt,int filler)
{
	static char hexbuf[32];
	int i,minus=0;
	int alp;

	if(fmt=='x') alp=0x27;
	else		 alp=0x07;

	if(radix==10) {
		if(val < 0) {
			val = -val ;
			minus=1;
		}
	}

	i=0;
	do {
		hexbuf[i++] = hexch( (unsigned) val %  radix,alp);
//		val /= radix;
		val = divint( val , radix);
	} while(val!=0);

	if(minus && (filler=='0') ) {
		vputc('-');
		while(column>(i+1)) {
			vputc(filler);
			column--;
		}
	} else {
		if(minus) hexbuf[i++]='-';
		while(column>i) {
			vputc(filler);
			column--;
		}
	}

	while(i>0) {
		vputc(hexbuf[--i]);
	}
}

static	void strprint(char *s,int column)
{
	int	l;
	int slen;
	slen=strlen(s);

	/* ���]�����K�v�Ȃ�� */
	if(   column > slen ) {
		l=column - slen;
		while(l) {
			vputc(' ');
			l--;
		}
	}

	while(*s) {
		vputc(*s++);
	}

	/* �E�]�����K�v�Ȃ�� */
	if( column<0 ) {
		if(   (-column) > slen ) {
			l=(-column) - slen;
			while(l) {
				vputc(' ');
				l--;
			}
		}
	}
}

static	void chrprint(int c)
{
	vputc(c);
}

/**********************************************************************
 *		�����������������i�j
 **********************************************************************
 */
int	vsprintf(char *buf , char *fmt , va_list ap)
{
	int  column;
	int  c,filler;

	vp=buf;

	while(*fmt) {
		if(*fmt=='%') {					/* ���G�X�P�[�v���� */
			column=1;
			if(fmt[1]=='0') filler='0';
			else		    filler=' ';

			fmt=getnum(fmt+1,&column);	/* ���̌��̐��� => column */

			c = *fmt++;
			if(c=='l') {
				c = *fmt++;
			}
			switch(c) {
			case 'd':
			case 'D':
				hexprint(  va_arg (ap, int) ,column,10,c,filler );
				break;
			case 'x':
			case 'X':
				hexprint(  va_arg (ap, int) ,column,16,c,filler );
				break;
			case 's':
				strprint(  va_arg (ap, char *),column);
				break;
			case 'c':
				chrprint(  va_arg (ap, int) );
				break;
#if	0
			case 'f':
			case 'F':
			case 'g':
			case 'G':
				dblprint( ap,c );
#endif
			case '%':
				chrprint( '%' );
				break;
			default:
				break;
			}
		} else {
			if(*fmt == '\n')
				vputc( '\r');	/* �l�r-�c�n�r�̎d�l(CR+LF)�Ɉ˂� */
			vputc(*fmt++);
		}
	}
	vputc(0);
	return( vp - buf );		/* �o�͂�����������Ԃ� */
}

/**********************************************************************
 *
 **********************************************************************
 */
int	 printf(char *format, ...)
{
	static char _prbuf[256];
	int i,len;
	va_list ap;

	va_start (ap, format);
	i = vsprintf(_prbuf,format,ap);
	va_end (ap);

//	len=strlen(_prbuf);
	_user_puts(_prbuf);
//	fwrite(_prbuf,1,len,stdout);
	return i;
}
/**********************************************************************
 *
 **********************************************************************
 */
int	 sprintf(char *buffer, char *format, ...)
{
	int ret;
	va_list	 va_ptr;

	va_start( va_ptr, format ) ;
	ret = vsprintf(buffer,format,va_ptr);
	va_end( va_ptr );
	return ret;
}

/**********************************************************************
 *
 **********************************************************************
 */
