#include <p32xxxx.h>			// always in first place to avoid conflict with const.h ON
#include <typedef.h>			// Pinguino's types definitions
#include <const.h>				// Pinguino's constants definitions
#include <macro.h>				// Pinguino's macros definitions
//#include <system.c>				// PIC32 System Core Functions
//#include "define.h"				// Pinguino Sketch Constants
//#include <io.c>					// Pinguino Boards Peripheral Remappage and IOs configurations
#ifndef __32MX220F032D__
//	#include <newlib.c>
#endif	
#include <cdc.h>

int sub()
{
	return 0;
}
void setup()
{
	int i;
	pinmode(13, OUTPUT);
	sub();
}

void loop()
{
	toggle(13);
	Delayms(500);
}

