/*
 * The following sample application prompts the user (via HyperTerminal) to
 * enter a digit between 0 and 9.  Upon receiving a character from the USART,
 * the program will then either output a string from an array of data or if the
 * character received is not between 0 and 9, output an error string.
 * The command line used to build this application is:
 * 
 * mcc18 -p 18f452 -I c:\mcc18\h example2.c
 * 
 * where c:\mcc18 is the directory in which the compiler is installed.
 * This sample application is designed for use with the MPLAB ICD2, the
 * PICDEM 2 Plus demo board, and the PIC18F452 device.  This sample covers the
 * following items:
 * 
 * 1.  Creating large data objects
 * 2.  Reading from and writing to the USART. 
 * 3.  Interrupt handling (#pragma interrupt, interrupt vectors, and
 *     interrupt service routines)
 * 4.  System header files
 * 5.  Processor-specific header files
 * 6.  #pragma sectiontype
 * 7.  Inline assembly
 */
#include <p18cxxx.h>
#include <usart.h>

void rx_handler (void);

#define BUF_SIZE 25

/*
 * Step #1  The data is allocated into its own section.
 */
#pragma idata bigdata
char data[11][BUF_SIZE+1] = {
  { "String #0\n\r" },
  { "String #1\n\r" },
  { "String #2\n\r" },
  { "String #3\n\r" },
  { "String #4\n\r" },
  { "String #5\n\r" },
  { "String #6\n\r" },
  { "String #7\n\r" },
  { "String #8\n\r" },
  { "String #9\n\r" },
  { "Invalid key (0-9 only)\n\r" }
};
#pragma idata

#pragma code rx_interrupt = 0x8
void rx_int (void)
{
  _asm goto rx_handler _endasm
}
#pragma code

#pragma interrupt rx_handler
void rx_handler (void)
{
  unsigned char c;

  /* Get the character received from the USART */
  c = ReadUSART();
  if (c >= '0' && c <= '9')
    {
      c -= '0';
      /* Display value received on LEDs */
      PORTB = c;

      /*
       * Step #2  This example did not need an additional
       * pointer to access the large memory because of the
       * multi-dimension array.
       *
       * Display the string located at the array offset
       * of the character received
       */
      putsUSART (data[c]);
    }
  else
    {
      /*
       * Step #2  This example did not need an additional
       * pointer to access the large memory because of the
       * multi-dimension array.
       *
       * Invalid character received from USART.
       * Display error string.
       */
      putsUSART (data[10]);

      /* Display value received on LEDs */
      PORTB = c;
    }

    /* Clear the interrupt flag */
    PIR1bits.RCIF = 0;
}

void main (void)
{
  /* Configure all PORTB pins for output */
  TRISB = 0;

  /*
   * Open the USART configured as
   * 8N1, 2400 baud, in polled mode
   */
  OpenUSART (USART_TX_INT_OFF &
             USART_RX_INT_ON &
             USART_ASYNCH_MODE &
             USART_EIGHT_BIT &
             USART_CONT_RX &
             USART_BRGH_HIGH, 103);

  /* Display a prompt to the USART */
  putrsUSART (
    (const far rom char *)"\n\rEnter a digit 0-9!\n\r");

  /* Enable interrupt priority */
  RCONbits.IPEN = 1;

  /* Make receive interrupt high priority */
  IPR1bits.RCIP = 1;

  /* Enable all high priority interrupts */
  INTCONbits.GIEH = 1;

  /* Loop forever */
  while (1)
    ;
}

#include <p18cxxx.h>
#include <usart.h>


/********************************************************************
*    Function Name:  ReadUSART                                      *
*    Return Value:   char: received data                            *
*    Parameters:     void                                           *
*    Description:    This routine reads the data from the USART     *
*                    and records the status flags for that byte     *
*                    in USART_Status (Framing and Overrun).         *
********************************************************************/
#if defined (AUSART_V1) || defined (EAUSART_V3) || defined (EAUSART_V4) || defined (EAUSART_V5)

char ReadUSART(void)		//this function can be removed by macro #define ReadUSART RCREG
{
  char data;   // Holds received data

  USART_Status.val &= 0xf2;          // Clear previous status flags

  if(RCSTAbits.RX9)                  // If 9-bit mode
  {
    USART_Status.RX_NINE = 0;        // Clear the receive bit 9 for USART
    if(RCSTAbits.RX9D)               // according to the RX9D bit
      USART_Status.RX_NINE = 1;
  }

  if(RCSTAbits.FERR)                 // If a framing error occured
    USART_Status.FRAME_ERROR = 1;    // Set the status bit

  if(RCSTAbits.OERR)                 // If an overrun error occured
    USART_Status.OVERRUN_ERROR = 1;  // Set the status bit

  data = RCREG;                      // Read data

  return (data);                     // Return the received data
}

#endif

#include <p18cxxx.h>
#include <usart.h>


/********************************************************************
*    Function Name:  WriteUSART                                     *
*    Return Value:   none                                           *
*    Parameters:     data: data to transmit                         *
*    Description:    This routine transmits a byte out the USART.   *
********************************************************************/
#if defined (AUSART_V1) || defined (EAUSART_V3) || defined (EAUSART_V4) || defined (EAUSART_V5)

void WriteUSART(char data)
{
  if(TXSTAbits.TX9)  // 9-bit mode?
  {
    TXSTAbits.TX9D = 0;       // Set the TX9D bit according to the
    if(USART_Status.TX_NINE)  // USART Tx 9th bit in status reg
      TXSTAbits.TX9D = 1;
  }

  TXREG = data;      // Write the data byte to the USART
}

#endif



#if defined (EAUSART_V5) 

void OpenUSART( unsigned char config, unsigned int spbrg)
{
  TXSTA = 0;           // Reset USART registers to POR state
  RCSTA = 0;
 
  if(config&0x01)      // Sync or async operation
    TXSTAbits.SYNC = 1;

  if(config&0x02)      // 8- or 9-bit mode
  {
    TXSTAbits.TX9 = 1;
    RCSTAbits.RX9 = 1;
  }

  if(config&0x04)      // Master or Slave (sync only)
    TXSTAbits.CSRC = 1;

  if(config&0x08)      // Continuous or single reception
    RCSTAbits.CREN = 1;
  else
    RCSTAbits.SREN = 1;

  if(config&0x10)      // Baud rate select (asychronous mode only)
    TXSTAbits.BRGH = 1;
  
    PIR1bits.TXIF = 0;
	
  if(config&0x20)  // Address Detect Enable
	 RCSTAbits.ADEN = 1;
	 
  if(config&0x40)      // Interrupt on receipt
    PIE1bits.RCIE = 1;
  else
    PIE1bits.RCIE = 0;

  PIR1bits.RCIF = 0;

  if(config&0x80)      // Interrupt on transmission
    PIE1bits.TXIE = 1;
  else
    PIE1bits.TXIE = 0;

  SPBRG = spbrg;       // Write baudrate to SPBRG1
  SPBRGH = spbrg >> 8; // For 16-bit baud rate generation

  TXSTAbits.TXEN = 1;  // Enable transmitter
  RCSTAbits.SPEN = 1;  // Enable receiver

#if defined (USART_IO_V1)
	TRISBbits.TRISB1 = 0;TRISBbits.TRISB4 = 1;
	if(TXSTAbits.SYNC && !TXSTAbits.CSRC)	//synchronous  slave mode
		TRISBbits.TRISB1 = 1;

#elif defined (USART_IO_V2)
	TRISAbits.TRISA2 = 0;TRISAbits.TRISA3 = 1;
	if(TXSTAbits.SYNC && !TXSTAbits.CSRC)	//synchronous  slave mode
		TRISAbits.TRISA2 = 1;
#else
	TRISCbits.TRISC6 = 0;TRISCbits.TRISC7 = 1; 
	if(TXSTAbits.SYNC && !TXSTAbits.CSRC)	//synchronous  slave mode
		TRISCbits.TRISC6 = 1;

#endif
	
}

#endif




/******************************************************************
 *	USART ����M���W���[��
 ******************************************************************
 *	�{�[���[�g�ݒ� (U2X���g�p)
	static	void USART_init(uchar baud_h);
 *
 *	RS232C����M�^�X�N.
	static	void USART_RecvTask(void);
	static	void USART_SendTask(void);
 */


/******************************************************************
 *
 ******************************************************************
 */
//#define F_CPU 12000000      	/* MCU�N���b�N���g�� */
//#define BAUD 9600             	/* �ړIUSART�{�[���[�g���x */
//#define MYUBRR F_CPU/16/BAUD-1 	/* �ړIUBRR�l */


#ifndef TXBUF_SIZE			// ���M�o�b�t�@�T�C�Y
#error Define TXBUF_SIZE in Makefile
#endif
#ifndef RXBUF_SIZE			// ��MFIFO�T�C�Y.
#error Define RXBUF_SIZE in Makefile
#endif

uchar rsbuf[TXBUF_SIZE];// RS232C���M�o�b�t�@.
// REGISTER uchar rsptr ASM("r7");	 // ���o���n�_ (0..3) �A4 �̎��͋�.

uchar USART_rxbuf[RXBUF_SIZE];	// ��MFIFO.
//REGISTER uchar USART_rxptr ASM("r7");	// FIFO�������ݒn�_.

REGISTER uint8_t RxRp ASM("r8");	//��M�f�[�^�ǂݍ���
REGISTER uint8_t RxWp ASM("r9");	//��M�f�[�^��������

REGISTER uint8_t TxRp ASM("r10");	//���M�f�[�^�ǂݍ���
REGISTER uint8_t TxWp ASM("r11");	//���M�f�[�^��������

//#define	 USART_default_baud  19200,0


//	baud_rate�� ubrr�ɃZ�b�g����l�ɕϊ�����.
void baud_calc(void);	 // asm.S

uchar USART_getc(void);
static void USART_putc(uchar);

/******************************************************************
 *	USART�̏�����.
 ******************************************************************
 */
/******************************************************************
 *	�{�[���[�g�ݒ�.
 *  ����: int baud_l  �{�[���[�g(����16bit)         [15:0]
 *      uchar baud_h  �{�[���[�g(��� 8bit) [23:16]
 ******************************************************************
 */
static void USART_Init(void)
{
	uchar csrc=0x0e;	// 8N2

	baud_calc();
//	UBRRH = brr>>8; 		/* �{�[���[�g�ݒ�(��ʃo�C�g) */
//	UBRRL = brr;     	/* �{�[���[�g�ݒ�(���ʃo�C�g) */
	UCSRC = csrc;		/* �t���[���`���ݒ�(8�r�b�g,2�X�g�b�v �r�b�g) */
//	UCSRB = (1<<RXEN)|(1<<TXEN);      /* ����M���� */
	UCSRA = (1<<U2X);	// �v���X�P�[���� 1/16 �� 1/8 �ɕύX.

//	rsptr = TXBUF_SIZE;

	RxRp = RxWp = 0;
	TxRp = TxWp = 0;
	UCSRB = (1<<RXEN)|(1<<TXEN) | (1<<RXCIE);      /* ����M���� & ��M�����݋���*/
}

#if 0	//@@kuga �폜
/******************************************************************
 *	RS232C��M�^�X�N.
 ******************************************************************
 */
static void USART_RecvTask(void)
{
	while( UCSRA & (1<<RXC) ) {					// ��M����? .
		uchar rxchr = UDR;    					// ��M�f�[�^�擾.
		USART_rxbuf[USART_rxptr] = rxchr;		// FIFO�̏������݃|�C���^.
		// FIFO��t�Ȃ�A�|�C���^���X�V���Ȃ�.
		if(	USART_rxptr < (RXBUF_SIZE-1)) {
			USART_rxptr++;
		}
	}
}

/******************************************************************
 *	RS232C���M�^�X�N.
 ******************************************************************
 */
static void USART_SendTask(void)
{
	if(	rsptr < TXBUF_SIZE ) {
		//���M�o�b�t�@�Ƀf�[�^���c���Ă���Ȃ�,
		//
		//	1�������M���s��.
		//
		if ( !(UCSRA & (1<<UDRE)) ) {
			return ;	/* 2:���M�o�b�t�@�󂫑ҋ@ */
		}
	    UDR = rsbuf[rsptr++];     			/* ���M */
	}else{
        if( usbAllRequestsAreDisabled() ) {
            usbEnableAllRequests();
        }
	}
	return ;			/* 0:���M�o�b�t�@�� */
}

#endif


static void USART_SendTask(void)
{
	if ( (TxWp!=TxRp) && (UCSRA & (1<<UDRE)) ) {
		UDR=rsbuf[TxRp++];
		TxRp &= (TXBUF_SIZE-1);
	   if( usbAllRequestsAreDisabled() ) {
			uchar used=(TxWp-TxRp) & (TXBUF_SIZE-1);
	 		if ( used<=(TXBUF_SIZE-HW_CDC_PACKET_SIZE-1) ) {		//���M�ɋ󂠂�?
	            usbEnableAllRequests();
	        }
		}
	}
}


static void USART_putc(uchar data)
{
	rsbuf[TxWp]=data;
	TxWp++;
	TxWp &= (TXBUF_SIZE-1);
}


