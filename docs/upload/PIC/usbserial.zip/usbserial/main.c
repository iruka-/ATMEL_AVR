/********************************************************************
 *	���C���֐�  ������  ���荞�݃x�N�^�[�̐ݒ�.
 ********************************************************************
 */
#include "GenericTypeDefs.h"
#include "Compiler.h"
#include "usb_config.h"
#include "./USB/usb_device.h"
#include "./USB/usb.h"
#include "./USB/usb_function_cdc.h"
#include "HardwareProfile.h"
#include "eusart.h"


void YourHighPriorityISRCode();
void YourLowPriorityISRCode();


/**	VECTOR REMAPPING ***********************************************/
#if	0
	#define	REMAPPED_RESET_VECTOR_ADDRESS			0x1000
	#define	REMAPPED_HIGH_INTERRUPT_VECTOR_ADDRESS	0x1008
	#define	REMAPPED_LOW_INTERRUPT_VECTOR_ADDRESS	0x1018
#endif

#if	1
	#define	REMAPPED_RESET_VECTOR_ADDRESS			0x800
	#define	REMAPPED_HIGH_INTERRUPT_VECTOR_ADDRESS	0x808
	#define	REMAPPED_LOW_INTERRUPT_VECTOR_ADDRESS	0x818
#endif

#if	0
	#define	REMAPPED_RESET_VECTOR_ADDRESS			0x00
	#define	REMAPPED_HIGH_INTERRUPT_VECTOR_ADDRESS	0x08
	#define	REMAPPED_LOW_INTERRUPT_VECTOR_ADDRESS	0x18
#endif

/********************************************************************
 *	0x800�`�̃W�����v�x�N�^�[��ݒ肷��.
 ********************************************************************
 *	0x800 goto _startup
 *	0x808 goto YourHighPriorityISRCode
 *	0x818 goto YourLowPriorityISRCode
 */

extern void	_startup (void);		// See c018i.c in your C18 compiler	dir
#pragma	code REMAPPED_RESET_VECTOR = REMAPPED_RESET_VECTOR_ADDRESS
void _reset	(void)
{
	_asm goto _startup _endasm
}


#pragma	code REMAPPED_HIGH_INTERRUPT_VECTOR	= REMAPPED_HIGH_INTERRUPT_VECTOR_ADDRESS
void Remapped_High_ISR (void)
{
	 _asm goto YourHighPriorityISRCode _endasm
}


#pragma	code REMAPPED_LOW_INTERRUPT_VECTOR = REMAPPED_LOW_INTERRUPT_VECTOR_ADDRESS
void Remapped_Low_ISR (void)
{
	 _asm goto YourLowPriorityISRCode _endasm
}

/********************************************************************
 *	0x008�`�̃W�����v�x�N�^�[��ݒ肷��.
 ********************************************************************
 *	0x008 goto 0x808
 *	0x018 goto 0x818
 */
#pragma	code HIGH_INTERRUPT_VECTOR = 0x08
void High_ISR (void)
{
	 _asm goto REMAPPED_HIGH_INTERRUPT_VECTOR_ADDRESS _endasm
}


#pragma	code LOW_INTERRUPT_VECTOR =	0x18
void Low_ISR (void)
{
	 _asm goto REMAPPED_LOW_INTERRUPT_VECTOR_ADDRESS _endasm
}

/********************************************************************
 *	�W�����v�x�N�^�[�ݒ�͂����܂�.
 ********************************************************************
 */


#pragma	code
/********************************************************************
 *	High���荞�ݏ����֐�.
 ********************************************************************
 */
//#pragma	interrupt YourHighPriorityISRCode
#pragma	interrupt YourHighPriorityISRCode nosave=TBLPTR,TBLPTRU,TABLAT,PCLATH,PCLATU,PROD,section("MATH_DATA")

void YourHighPriorityISRCode()
{
#if	USART_USE_INTERRUPT			// ���荞�݂��g�p����.
	USART_RxIntHandler();
#endif

#if	defined(USB_INTERRUPT)
	USBDeviceTasks();
#endif

}	//This return will be a	"retfie fast", since this is in	a #pragma interrupt	section	

/********************************************************************
 *	Low ���荞�ݏ����֐�.
 ********************************************************************
 */
//#pragma	interruptlow YourLowPriorityISRCode
#pragma	interruptlow YourLowPriorityISRCode nosave=TBLPTR,TBLPTRU,TABLAT,PCLATH,PCLATU,PROD,section("MATH_DATA")

void YourLowPriorityISRCode()
{

#if	USART_USE_INTERRUPT			// ���荞�݂��g�p����.
#if	USART_USE_TX_INTERRUPT			// ���荞�݂��g�p����.
	USART_TxIntHandler();
#endif
#endif

}	//This return will be a	"retfie", since	this is	in a #pragma interruptlow section 




#pragma	code
/********************************************************************
 *
 ********************************************************************
 */
static void	InitializeSystem(void)
{
#if RAM_SERIAL
	extern void set_serial_number(void);

	set_serial_number();
#endif

	ADCON1 |= 0x0F;					// Default all pins	to digital
	InitializeUSART();
	mInitAllLEDs();
	USBDeviceInit();
}
/********************************************************************
 *
 ********************************************************************
 */
void main(void)
{
	InitializeSystem();
	while(1){
#if	defined(USB_POLLING)
		USBDeviceTasks();
#endif
		ProcessIO();		
	}
}
/********************************************************************
 *
 ********************************************************************
 */
