/********************************************************************
 *
 ********************************************************************
 */
#include "GenericTypeDefs.h"
#include "Compiler.h"
#include "usb_config.h"
#include "./USB/usb_device.h"
#include "./USB/usb.h"
#include "./USB/usb_function_cdc.h"
#include "HardwareProfile.h"
#pragma	code

/********************************************************************
 *
 ********************************************************************
 */
static void	InitializeSystem(void)
{
	ADCON1 |= 0x0F;					// Default all pins	to digital
	InitializeUSART();
	mInitAllLEDs();
	USBDeviceInit();
}
#if	0
/********************************************************************
 *
 ********************************************************************
 */
void ProcessIO(void)
{	
	BlinkUSBStatus();
	if((USBDeviceState < CONFIGURED_STATE)||(USBSuspendControl==1))	return;

	if (RS232_Out_Data_Rdy == 0)  // only check	for	new	USB	buffer if the old RS232	buffer is
	{						  // empty.	 This will cause additional	USB	packets	to be NAK'd
		LastRS232Out = getsUSBUSART(RS232_Out_Data,64);	//until	the	buffer is free.
		if(LastRS232Out	> 0)
		{	
			RS232_Out_Data_Rdy = 1;	 //	signal buffer full
			RS232cp	= 0;  // Reset the current position
		}
	}

	if(RS232_Out_Data_Rdy && mTxRdyUSART())
	{
		putcUSART(RS232_Out_Data[RS232cp]);
		++RS232cp;
		if (RS232cp	== LastRS232Out)
			RS232_Out_Data_Rdy = 0;
	}

	if(mDataRdyUSART())
	{
		USB_Out_Buffer[NextUSBOut] = getcUSART();
		++NextUSBOut;
		USB_Out_Buffer[NextUSBOut] = 0;
	}

	if((USBUSARTIsTxTrfReady())	&& (NextUSBOut > 0))
	{
		putUSBUSART(&USB_Out_Buffer[0],	NextUSBOut);
		NextUSBOut = 0;
	}

	CDCTxService();
}
#endif
/********************************************************************
 *
 ********************************************************************
 */
void main(void)
{
	InitializeSystem();
	while(1){
#if	defined(USB_POLLING)
		USBDeviceTasks();
#endif
		ProcessIO();		
	}
}
/********************************************************************
 *
 ********************************************************************
 */
