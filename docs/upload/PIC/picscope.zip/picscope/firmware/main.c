/********************************************************************
 *	main
 ********************************************************************
 */

#include "USB/usb.h"
#include "HardwareProfile.h"
#include "USB/usb_function_generic.h"


//-------------------------------------------------------------------
//
#if defined(__18F14K50)
#pragma udata usbram2
#else
#pragma udata
#endif
extern unsigned char OUTPacket[64];
extern unsigned char INPacket[64];

//-------------------------------------------------------------------
//
#pragma udata
extern BOOL blinkStatusValid;
extern USB_HANDLE USBGenericOutHandle;
extern USB_HANDLE USBGenericInHandle;

//-------------------------------------------------------------------
//
#pragma code

/** PRIVATE PROTOTYPES *********************************************/
void InitializeSystem(void);
void USBDeviceTasks(void);
void YourHighPriorityISRCode(void);
void YourLowPriorityISRCode(void);
void USBCBSendResume(void);
void UserInit(void);
void ProcessIO(void);
void BlinkUSBStatus(void);

/** DECLARATIONS ***************************************************/

void main(void)
{
	InitializeSystem();

#if defined(USB_INTERRUPT)
	USBDeviceAttach();
#endif

	while(1) {
#if defined(USB_POLLING)
		USBDeviceTasks();
#endif
		ProcessIO();
	}
}

#if	0
void UserInit(void)
{
	mInitAllLEDs();
	mInitAllSwitches();
	blinkStatusValid = TRUE;	//Blink the normal USB state on the LEDs.
}


void ProcessIO(void)
{
	if(blinkStatusValid) {
		BlinkUSBStatus();
	}
	if((USBDeviceState < CONFIGURED_STATE)||(USBSuspendControl==1)) {
		return;
	}
	if(!USBHandleBusy(USBGenericOutHandle)) {	
		//Check if the endpoint has received any data from the host.
		switch(OUTPacket[0]) {				//Data arrived, check what kind of command might be in the packet of data.
		case 0x80:  //Toggle LED(s) command from PC application.
			blinkStatusValid = FALSE;		//Disable the regular LED blink pattern indicating USB state, PC application is controlling the LEDs.
			if(mGetLED_1() == mGetLED_2()) {
				mLED_1_Toggle();
				mLED_2_Toggle();
			} else {
				mLED_1_On();
				mLED_2_On();
			}
			break;
		case 0x81:  //Get push button state command from PC application.
			INPacket[0] = 0x81;				//Echo back to the host PC the command we are fulfilling in the first byte.  In this case, the Get Pushbutton State command.
			if(sw2 == 1) {
				INPacket[1] = 0x01;
			} else {
				INPacket[1] = 0x00;
			}
			if(!USBHandleBusy(USBGenericInHandle)) {
				USBGenericInHandle = USBGenWrite(USBGEN_EP_NUM,(BYTE*)&INPacket,USBGEN_EP_SIZE);
			}
			break;
		}

		USBGenericOutHandle = USBGenRead(USBGEN_EP_NUM,(BYTE*)&OUTPacket
							  ,USBGEN_EP_SIZE);
	}
}


void BlinkUSBStatus(void)
{
	static WORD led_count=0;

	if(led_count == 0)led_count = 10000U;
	led_count--;

#define mLED_Both_Off()         {mLED_1_Off();mLED_2_Off();}
#define mLED_Both_On()          {mLED_1_On();mLED_2_On();}
#define mLED_Only_1_On()        {mLED_1_On();mLED_2_Off();}
#define mLED_Only_2_On()        {mLED_1_Off();mLED_2_On();}

	if(USBSuspendControl == 1) {
		if(led_count==0) {
			mLED_1_Toggle();
			if(mGetLED_1()) {
				mLED_2_On();
			} else {
				mLED_2_Off();
			}
		}//end if
	} else {
		if(USBDeviceState == DETACHED_STATE) {
			mLED_Both_Off();
		} else if(USBDeviceState == ATTACHED_STATE) {
			mLED_Both_On();
		} else if(USBDeviceState == POWERED_STATE) {
			mLED_Only_1_On();
		} else if(USBDeviceState == DEFAULT_STATE) {
			mLED_Only_2_On();
		} else if(USBDeviceState == ADDRESS_STATE) {
			if(led_count == 0) {
				mLED_1_Toggle();
				mLED_2_Off();
			}//end if
		} else if(USBDeviceState == CONFIGURED_STATE) {
			if(led_count==0) {
				mLED_1_Toggle();
				if(mGetLED_1()) {
					mLED_2_Off();
				} else {
					mLED_2_On();
				}
			}
		}
	}
}
#endif


/********************************************************************
 *	64�Х��Ȥ��®��memcpy
 ********************************************************************
 */
void memcpy64()		//(char *t,char *s)
{
	_asm
		movff  FSR2L, POSTINC1
		movff  FSR2H, POSTINC1

		// FSR2=t;
		movlw  0xfa
		movff  PLUSW1, FSR2L
		movlw  0xfb
		movff  PLUSW1, FSR2H

		// FSR0=s;
		movlw  0xfc
		movff  PLUSW1, FSR0L
		movlw  0xfd
		movff  PLUSW1, FSR0H

		movlw  4

memcpy64_loop:	// 16byte copy
		//		  *t++ = *s++  x 16
		movff     POSTINC2, POSTINC0
		movff     POSTINC2, POSTINC0
		movff     POSTINC2, POSTINC0
		movff     POSTINC2, POSTINC0

		movff     POSTINC2, POSTINC0
		movff     POSTINC2, POSTINC0
		movff     POSTINC2, POSTINC0
		movff     POSTINC2, POSTINC0

		movff     POSTINC2, POSTINC0
		movff     POSTINC2, POSTINC0
		movff     POSTINC2, POSTINC0
		movff     POSTINC2, POSTINC0

		movff     POSTINC2, POSTINC0
		movff     POSTINC2, POSTINC0
		movff     POSTINC2, POSTINC0
		movff     POSTINC2, POSTINC0

		decfsz	WREG,1,0
		bra		memcpy64_loop


		movlw  0xff
		movff  PLUSW1, FSR2H
		movf   POSTDEC1,0,0
		movlw  0xff
		movff  PLUSW1, FSR2L
		movf   POSTDEC1,0,0
	_endasm
}
