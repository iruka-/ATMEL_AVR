#ifndef	_eusart_h_
#define	_eusart_h_

typedef	unsigned char uchar;

/********************************************************************
 *	USART �֐�.
 ********************************************************************
 */
void  initUSART(void);
uchar getcUSART(void);
void  putcUSART(char c);

void  USART_RxIntHandler(void);
void  USART_TxIntHandler(void);


#define	USART_USE_INTERRUPT		0		// 1=USART ���荞�݂��g�p����.
#define	USART_USE_TX_INTERRUPT	0		// ���M�ɂ����荞�݂��g�p����.

/********************************************************************
 *
 ********************************************************************
 */
#endif

