/********************************************************************
 *	PIC32MX SPI2 (Serial Peripheral Interface) for mx220f032b
 ********************************************************************
 */

/********************************************************************
�ؿ�����:
	void	SPI2_init();						�����
	void	SPI2_mode(uchar mode);				�⡼������
	void	SPI2_clock(unsigned int speed);		�����å�����
	void	SPI2_close() //(u8 num);				��λ

unsigned int SPI2_write(unsigned int data_out);	32bit����
unsigned int SPI2_read(void);					32bit����
void  _ISR  _SPI2Interrupt(void);				�����ߥϥ�ɥ顼

�����ߵ��Ĥʤ�
unsigned int IntGetFlag(u8 numinter);
	void	IntEnable(u8 numinter);
	void	IntDisable(u8 numinter);
	void	IntClearFlag(u8 numinter);
 ********************************************************************
 */
#include <p32xxxx.h>			// always in first place to avoid conflict with const.h ON
#include "interrupt.h"
#include "HardwareProfile.h"
#include "spi2.h"

#define SPIBUFFER	SPI2BUF
#define STATUS		SPI2STATbits.SPIROV	// Receive Overflow Flag bit
#define STATRX  	SPI2STATbits.SPIRBF	// Receive buffer full
#define STATTX		SPI2STATbits.SPITBF	// Transmit buffer full
#define SPICONF		SPI2CON
#define SPICONCLR	SPI2CONCLR
#define SPIENHBUF	SPI2CONbits.ENHBUF
#define CLKSPD		SPI2BRG
#define INTFAULT	INT_SPI2_FAULT
#define INTTXDONE 	52 	//INT_SPI2_TRANSFER_DONE
#define INTRXDONE 	INT_SPI2_RECEIVE_DONE
#define INTVECTOR 	36	//INT_SPI2_VECTOR

// SPIxCON.MSTEN
#define SPI2_MASTER			1
#define SPI2_SLAVE			0
#define SPI2_PBCLOCK_DIV2	2
#define SPI2_PBCLOCK_DIV4	4
#define SPI2_PBCLOCK_DIV8	8
#define SPI2_PBCLOCK_DIV16	16
#define SPI2_PBCLOCK_DIV32	32
#define SPI2_PBCLOCK_DIV64	64


#define	SAMPLES		128
static short sin_table[SAMPLES];
void calcsine();
unsigned int SPI2_write(unsigned int data_out);

/********************************************************************
 *	
 ********************************************************************
 */
void SPI2_mode(uchar mode)
{
	STATUS = 0;					// clear the Overflow
	if (mode == SPI2_MASTER) {
#if	DDS_TEST
		SPICONF=0x882c;		// 32 bits transfer, Master mode SDI disable
#else
		SPICONF=0x8824;		// 32 bits transfer, Master mode SDI disable
#endif
	}
	if (mode == SPI2_SLAVE) {
		SPICONF=0x8000;		// SPI ON, 8 bits transfer, Slave mode
	}
	SPI2CON2=0x300;	//AUDEN=1 (32bit)
}
/********************************************************************
 *	
 ********************************************************************
 */
// Fsck = Fpb / (2 * (SPIxBRG + 1)
// SPIxBRG = (Fpb / (2 * Fsck)) - 1 
// speed must be in bauds
void SPI2_clock(unsigned int speed)
{
	unsigned int Fpb;
	unsigned short clk;

	Fpb = GetPeripheralClock();
	if (speed > (Fpb / 2)){
		CLKSPD = 0;			// use the maximum baud rate possible
		return;
	}else{
		clk = (Fpb / (2 * speed)) - 1;
		if (clk > 511)
			CLKSPD = 511;	// use the minimum baud rate possible
		else					// ** fix for bug identified by dk=KiloOne
			CLKSPD = clk;	// use calculated divider-baud rate
	}
}

/********************************************************************
 *	
 ********************************************************************
 */
void SPI2_close() //(u8 num)
{
	unsigned char rData;
	IntDisable(INTFAULT); 
	IntDisable(INTTXDONE); 
	IntDisable(INTRXDONE);
	SPICONF=0;
	rData=SPIBUFFER;
}

/********************************************************************
 *	
 ********************************************************************
 */
void SPI2_init()
{
	unsigned char rData;
	calcsine();
	SPICONCLR = 0x8000; // bit 15
	rData = SPIBUFFER;
#if	USE_SPI2_INTERRUPT
	IntClearFlag(INTTXDONE);
	IntEnable(INTTXDONE); 

//	IntSetVectorPriority(INTVECTOR, 3, 1);
	int pri=7;	//3;
	int sub=1;
			IPC9bits.SPI2IP = pri;
			IPC9bits.SPI2IS = sub;
#endif
#if	DDS_TEST
	SPI2_clock(800000); //  800k bps 
#else
	SPI2_clock(20000000); // 20M bps
#endif
	SPI2_mode(SPI2_MASTER);

	RPB2R=0x04;		// PB2=SDO2
	TRISBCLR=1<<2;	// PB2 output.
#if	TEST_SPI2_TONE
	int i;
	for(i=0;i<32;i++) {
		SPI2_write(0xffff0000);
	}
#endif
}

/********************************************************************
 *	
 ********************************************************************
 */
unsigned int SPI2_write(unsigned int data_out)
{
	SPIBUFFER = data_out;	// write to buffer for TX
	while (!STATRX);		// wait for the receive flag (transfer complete)
	return SPIBUFFER;
}

/********************************************************************
 *	
 ********************************************************************
 */
unsigned int SPI2_read(void)
{
	SPIBUFFER = 0x00;			// dummy byte to capture the response
	while (!STATRX);		// wait until cycle complete
	return SPIBUFFER;			// return with byte read
}


static unsigned short val=0;

int	_MIPS32 gen_val()
{
	static int idx=0;
	val = sin_table[idx & (SAMPLES-1)] + 0x8000;
	idx++;
	return val;
}
/********************************************************************
 *	
 ********************************************************************
 */
int	_MIPS32 gen_data()
{
	// MSB first
	static int data=0;
	int i;
	int d=0;

	gen_val();

	for(i=0;i<4;i++) {
		d<<=1;	data += val; d |= (data>>16); data &= 0xffff;
		d<<=1;	data += val; d |= (data>>16); data &= 0xffff;
		d<<=1;	data += val; d |= (data>>16); data &= 0xffff;
		d<<=1;	data += val; d |= (data>>16); data &= 0xffff;
		d<<=1;	data += val; d |= (data>>16); data &= 0xffff;
		d<<=1;	data += val; d |= (data>>16); data &= 0xffff;
		d<<=1;	data += val; d |= (data>>16); data &= 0xffff;
		d<<=1;	data += val; d |= (data>>16); data &= 0xffff;
	}
	return d;
}
/********************************************************************
 *	
 ********************************************************************
 */
void _ISR _SPI2Interrupt(void)
{
	if (IntGetFlag(INTTXDONE)) {
		SPIBUFFER = gen_data();
		if(!STATTX) {
			SPIBUFFER = gen_data();
		}
		if(!STATTX) {
			SPIBUFFER = gen_data();
		}
		if(!STATTX) {
			SPIBUFFER = gen_data();
		}
		IntClearFlag(INTTXDONE);
	}
}

/********************************************************************
 *	�����Ȥäݤ���Τ����
 ********************************************************************
 */
#define	FIXBASE		0x10000000
#define	FIXDELTA 	(int)(SAMPLES/(3.1415926*2))
#define	SHORTMAX	32767

int	delta(int d)
{
	return d / (FIXDELTA);
}

void calcsine()
{
	int sin1,cos1;
	int i,s;
	sin1=0;cos1=FIXBASE;
	for(i=0;i<(SAMPLES);i++) {
		s=(sin1>>(16-4));
		if(s>= SHORTMAX) s=   SHORTMAX;
		if(s< -SHORTMAX) s= -(SHORTMAX+1);
		sin_table[i]=s;
		sin1+=delta(cos1);
		cos1-=delta(sin1);
	}
}
/*********************************************************************
 *
 *********************************************************************
 */

