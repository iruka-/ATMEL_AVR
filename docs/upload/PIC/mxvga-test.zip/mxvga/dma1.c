/********************************************************************
 *	DMA KICKER
 ********************************************************************
 */
#include <stdlib.h>
#include <plib.h>
#include "spi2.h"

/********************************************************************
 *	�錾
 ********************************************************************
 */
extern const uchar font16[];

#if	SVGA_MODE		// 0:VGA 1:SVGA
#define	WIDTH		48	// 4�̔{���Ɍ���.
#define	HEIGHT		36
#else
#define	WIDTH		60	// 4�̔{���Ɍ���.
#define	HEIGHT		30
#endif

#define	WIDTH_DMA	WIDTH	//(32bit) �S�̔{���Ɍ���. WIDTH�Ɠ��l.
#define	WIDTH_WORD	(WIDTH/sizeof(int))	// WORD��.

static unsigned int	txferTxBuff[2][WIDTH_WORD];
static uchar vram_buf[ HEIGHT * WIDTH ];

/********************************************************************
 *	����������X�Ə������ށB�댯�B
 ********************************************************************
 */
uchar *t=vram_buf;
void draw_line(char *p)
{
	int c;
	while(*p) {
		c = *p++;
		*t++ = c;
		wait_ms(50);
	}
}
/********************************************************************
 *	����������X�Ə������ށB�댯�B
 ********************************************************************
 */
void draw_screen()
{
	while(1) {
		draw_line("**MZ-80K MONITOR SP-1002**   ");
	}
}
/********************************************************************
 *	HSYNC���荞�݂�DMA KICK�������ƂɌĂ΂��B��LINE�̍쐬����.
 ********************************************************************
 *	line : �������̔ԍ��i0�`799)
 *	font : 8x16dot �t�H���g�\�@�� font16 + (line & 15)
 *	vram : �e�L�X�gVRAM�́A�Y���s���w���|�C���^.
 *	t    : ���Ɏg�p����1 LINE ���̃s�N�Z���f�[�^( SPI out )
 */
void font_draw(int line)
{
	int x;
	int cnt = line & 15;
	int   y = line >> 4;
	const uchar *font = font16+cnt;
	uchar *vram = &vram_buf[WIDTH*y];
	uchar *t    = (uchar*) txferTxBuff[cnt & 1];

	// 48������. ��F���� "ABCD" --> (32bit SPI) 0x44434241
	for(x=0;x<WIDTH;x+=4) {
		t[0]=font[ (vram[3]<<4) ];
		t[1]=font[ (vram[2]<<4) ];
		t[2]=font[ (vram[1]<<4) ];
		t[3]=font[ (vram[0]<<4) ];

		t+=4;vram+=4;
	}
}


/********************************************************************
 *	
 ********************************************************************
 */
void dma_init()
{
	int x,y,c=0;
	uchar *vram = vram_buf;
	for(y=0;y<HEIGHT;y++) {
		for(x=0;x<WIDTH;x++) {
			*vram++ = c;
			c++;
		}
	}
	DmaChnOpen(DMA_CHANNEL1, DMA_CHN_PRI2, DMA_OPEN_DEFAULT);
	DmaChnSetEventControl(DMA_CHANNEL1, DMA_EV_START_IRQ_EN|DMA_EV_START_IRQ(_SPI2_TX_IRQ));
}

/********************************************************************
 *	
 ********************************************************************
 */
void dma_kick(int cnt)
{
//	DmaChnOpen(DMA_CHANNEL1, DMA_CHN_PRI2, DMA_OPEN_DEFAULT);
//	DmaChnSetEventControl(DMA_CHANNEL1, DMA_EV_START_IRQ_EN|DMA_EV_START_IRQ(_SPI2_TX_IRQ));
	int *p = txferTxBuff[cnt & 1];cnt++;
	DmaChnSetTxfer(DMA_CHANNEL1, p, (void*)&SPI2BUF, WIDTH_DMA, 4, 4);
	DmaChnStartTxfer(DMA_CHANNEL1, DMA_WAIT_NOT, 0);
	font_draw(cnt);
}

/********************************************************************
 *	
 ********************************************************************
 */
void dma_clearbuf(void)
{
	int i,j;
	for(i=0;i<2;i++) {
		for(j=0;j<WIDTH_WORD;j++) {
			txferTxBuff[i][j]=0;
		}
	}
}

/********************************************************************
 *	
 ********************************************************************
 */
void _ISR DmaHandler1(void)
{
	int	evFlags;
	INTClearFlag(INT_SOURCE_DMA(DMA_CHANNEL1));
	evFlags=DmaChnGetEvFlags(DMA_CHANNEL1);
    if(evFlags&DMA_EV_BLOCK_DONE) {
        DmaChnClrEvFlags(DMA_CHANNEL1, DMA_EV_BLOCK_DONE);
    }
}


