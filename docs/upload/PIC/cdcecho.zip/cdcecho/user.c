





unsigned int counter=0;


void ISR_wrapper_vector_4(void) __attribute__ ((section (".vector_4")));


void ISR_wrapper_vector_4(void)
{
	Tmr1Interrupt();
}


void Tmr1Interrupt(void) __attribute__ ((interrupt));



void Tmr1Interrupt(void)
{
	if (IFS0bits.T1IF) {	
		TMR1=0;			
		IFS0CLR=0x10;		
		counter++;		
	}
}


void init_timer1(void)
{
	IntConfigureSystem(INT_SYSTEM_CONFIG_MULT_VECTOR);	
#ifdef	USE_SELFBOOT
	_CP0_SET_EBASE(0xBFC00000); // ���荞�݃x�N�^�[�����Z�b�g���̂��̂ɖ߂�.
#endif

	T1CON=0;		
	TMR1=0;			
	PR1=0x9999;		
	IPC1SET=0x7;		
	IFS0CLR=0x10;		
	IEC0SET=0x10;		
	T1CONSET=0x8010;	
}

void setup()
{
	pinmode(13, OUTPUT);
	init_timer1();
}

void loop()
{
    static int cnt=0;
	static char buffer[256];
	int numBytesRead = USB_Service_CDC_GetString( buffer );
	if(numBytesRead>0) {
		CDCputs(buffer,numBytesRead);
 	}
  	cnt++;
  	if(	cnt >= 500000 ) {
    	cnt=0;
    	toggle(13);
	}
//	Delayus(125);
}



