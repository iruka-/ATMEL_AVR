#!/bin/sh

./mp.sh io_cfg.h 
./mp.sh usbcfg.h 
./mp.sh BootModified.18f14k50.lkr 
./mp.sh usbdsc.c 
./mp.sh main.c 
./mp.sh BootPIC18NonJ.h 
./mp.sh usbdrv.h 
./mp.sh BootModified.18f4550.lkr 
./mp.sh HIDBootloaderPIC18NonJ.mcp 
./mp.sh usbmmap.h 
./mp.sh typedefs.h 
./mp.sh BootPIC18NonJ.c 
./mp.sh usbmmap.c 
./mp.sh usbctrltrf.c 
./mp.sh usbdefs_ep0_buff.h 
./mp.sh usbdefs_std_dsc.h 
./mp.sh usb.h 
./mp.sh usb9.h 
./mp.sh hid.h 
./mp.sh usbdrv.c 
./mp.sh hid.c 
./mp.sh usbdsc.h 
./mp.sh usb9.c 
./mp.sh usbctrltrf.h 
