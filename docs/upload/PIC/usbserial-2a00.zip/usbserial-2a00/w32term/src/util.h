
void	memdump(void *ptr,int len,int off);
int		UsbInit(int verbose,int enable_bulk);	
int		UsbExit(void);
void 	UsbBench(int cnt,int psize);
void	UsbDump(int adr,int arena,int size);
void 	UsbPoke(int adr,int arena,int data0,int data1);
int 	UsbPeek(int adr,int arena);
int 	UsbRead(int adr,int arena,uchar *buf,int size);
void 	UsbBench2(int cnt,int psize);
void 	UsbSetBaudRate(int ubrr,int bits);

int QueryAVR(usb_dev_handle *dev,RxBuf *cmd,uchar *buf);

