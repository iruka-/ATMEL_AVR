/********************************************************************
 *
 ********************************************************************
 */
#include <string.h>

#include "platform_config.h"
#include "hidcmd.h"
#include "monit.h"

#include "usbio.h"

void USBTask(void);


#define	PUTBUF_SIZE	(64-8)

extern	uchar puts_buf[];		//[PUTBUF_SIZE];
extern	uchar puts_ptr;

/********************************************************************
 *	
 ********************************************************************
 */
int user_putc(char c)
{
	uchar flush = 0;
	if( c == 0x0a) { flush = 1; }
	if( puts_ptr >= PUTBUF_SIZE ) {flush = 1;}

	if( flush ) {
		while(puts_ptr) {
			USBTask();
		}
	}

	if(	puts_ptr < PUTBUF_SIZE ) {
		puts_buf[puts_ptr++]=c;
	}

	return 1;
}
#if	0
/********************************************************************
 *	
 ********************************************************************
 */
void *memcpy(void *dst,const void *src,size_t size)
{
	char *t = (char*)dst;
	char *s = (char*)src;
	while(size--) {*t++=*s++;}
	return t;
}
#endif

int user_puts(char *s)
{
	while(*s) {
		user_putc(*s++);
	}
	return 0;
}

