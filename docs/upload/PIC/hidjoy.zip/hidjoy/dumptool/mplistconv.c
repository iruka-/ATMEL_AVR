/**********************************************************************
	���g���[���r�t�H�[�}�b�g���o�C�i���[������.
 **********************************************************************
 */
#include "easy.h"
#include <malloc.h>
#include <string.h>

Usage(
	" ===== MPLINK .LST format converter =====\n"
	"Usage:\n"
	"$ mplistconv [-m80] infile.lst outfile.txt\n"
	"\n"
	"Option:\n"
	"  -m<MAXLENGTH>   set line max length\n"
	"\n"
);

#define CRLF "\r\n"

static	char	infile[256];
static	char	outfile[256];

static	char 	curfile[256];

static	int		start_adr=0;
static	int		end_adr=0;

static	int		adr_u = 0;		// hexrec mode 4
static	unsigned char	maxlength=0;

/**********************************************************************
 *		
 **********************************************************************
 */
static int rindex(char *s,int c)
{
	int n = strlen(s);
	int i;
	for(i=n-1;i>=0;i--) {
		if(s[i]==c) return i;
	}
	return -1;
}

void chop_sp(char *s)
{
	int n = strlen(s);
	int i;
	int c = ' ';
	for(i=n-1;i>=0;i--) {
		if(	s[i] != c) {
			s[i+1]=0;
			return;
		}
	}
	
}

/**********************************************************************
 *		
 **********************************************************************
 */
static	int	isALPHA(int c)
{
	if((c>='A')&&(c<='Z'))return 1;
	return 0;
}
/**********************************************************************
 *		
 **********************************************************************
 */
int	read_line(char *s)
{
	int n = strlen(s);
	int m = rindex(s,' ');
	char *t;
	if(m>=0) {
		t = s+m+1;
		if(isALPHA(t[0]) && (t[1]==':')) {
			s[m]=0;
			if(	strcmp(curfile,t)!=0) {
				strcpy(curfile,t);
				fprintf(ofp,"FILE:%s" CRLF,curfile);
			}
		}
	}
	
	chop_sp(s);
	if(	maxlength>=32 ) {
		s[maxlength]=0;
	}
	chop_sp(s);
	fprintf(ofp,"%s" CRLF,s);
}

/**********************************************************************
 *		
 **********************************************************************
 */
void read_srec(void)
{
	char buf[4096];
	int rc,eof;
	Ropen(infile);
	Wopen(outfile);
	while(1) {
		eof = getln(buf,ifp);
		rc  = read_line(buf);
		if(eof == EOF) break;
	}
	Wclose();
	Rclose();
}

/**********************************************************************
 *		
 **********************************************************************
 */
int	main(int argc,char **argv)
{
	int m=80;
	Getopt(argc,argv);
	if(argc<3) {
		usage();
	}
	strcpy(infile,argv[1]);
	strcpy(outfile,argv[2]);

	if(IsOpt('m')) {
		sscanf(Opt('m'),"%d",&m);
		maxlength=m;
	}
	read_srec();

	return 0;
}

/**********************************************************************
 *		
 **********************************************************************
 */
