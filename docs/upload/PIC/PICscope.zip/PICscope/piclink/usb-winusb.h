#ifndef	_usb_winusb_h
#define	_usb_winusb_h

#include "packet.h"

int		usbOpen();
int		usbWrite(uchar *usbBuf,int len,uchar *readBuf,int readlen);
void	usbClose(void);

#endif
