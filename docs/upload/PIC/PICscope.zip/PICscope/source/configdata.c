#include "config.h"

CONFIG_DATA conf={
	0x000000,			//wave_bgcolor 
	0x18ff70,			//wave_fgcolor 
	0x0030ff,			//scaler_color 
	0x8098b0,			//clear_color 
	0x202020,			//btn_textcolor1 
	0x204040,			//btn_textcolor2 
	0x606060,			//btn_framecolor1 
	0xd0d0d0,			//btn_framecolor2 
	0,			//window_size_w 
	0,			//window_size_h 
	0,			//gain 
	0,			//dc_offset 
};


void ConfigSetup(void)
{
	ConfigInteger("wave_bgcolor"	,	&conf.wave_bgcolor);
	ConfigInteger("wave_fgcolor"	,	&conf.wave_fgcolor);
	ConfigInteger("scaler_color"	,	&conf.scaler_color);
	ConfigInteger("clear_color"	,	&conf.clear_color);
	ConfigInteger("btn_textcolor1"	,	&conf.btn_textcolor1);
	ConfigInteger("btn_textcolor2"	,	&conf.btn_textcolor2);
	ConfigInteger("btn_framecolor1"	,	&conf.btn_framecolor1);
	ConfigInteger("btn_framecolor2"	,	&conf.btn_framecolor2);
	ConfigInteger("window_size_w"	,	&conf.window_size_w);
	ConfigInteger("window_size_h"	,	&conf.window_size_h);
	ConfigDouble("gain"	,	&conf.gain);
	ConfigDouble("dc_offset"	,	&conf.dc_offset);
}
