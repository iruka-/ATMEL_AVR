#!/usr/bin/perl

my $file1='config.tbl';

my @hdr;
my @ini;
my @data;
my @load;

# =====================================================
#      
# =====================================================
sub loadfile()
{
	my ($file)=@_;
	my @buf;
	open(FILE,$file) || die("Can't open file $file");
	@buf = <FILE>;
	close(FILE);
	return @buf;
}

sub remcut()
{
	my ($line)=@_;
	$line =~ s/\n//;
	$line =~ s/\r//;
	$line =~ s|/\*.*\*/||;

	return $line;
}


sub read_line1()
{
	my ($line)=@_;
	my %tabs=(
		'i',"int\t",
		'f',"float",
		'd',"double",
	);
	$line = &remcut($line);
	if($line eq '') {return;}

	my ($fmt,$key,$value) = split(/[ \t]+/,$line);
	my $type = $tabs{$fmt};
	my $scan = $fmts{$fmt};

	push @hdr, "\t$type $key;";
	push @data, "\t$value,\t\t\t//$key ";

	push @ini, "$key=$value";

	if($fmt eq 'i') {
		push @load,"	ConfigInteger(\"$key\"	,	&conf.$key);";
	}else{
		push @load,"	ConfigDouble(\"$key\"	,	&conf.$key);";
	}
}

sub write()
{
	my ($file,@buf)=@_;
	my $line;
	open(FILE,">$file") || die("Can't create file $file");
	foreach $line(@buf) {
		print FILE $line . "\n";
	}
	close(FILE);
}

sub main()
{
	my $line;
	my @buf1=&loadfile($file1);




	push @hdr,"#ifndef _config_h";
	push @hdr,"#define _config_h";
	push @hdr,"";
	push @hdr,"typedef struct {";

	push @data,"#include \"config.h\"";
	push @data,"";
	push @data,"CONFIG_DATA conf={";

	push @load,"";
	push @load,"void ConfigSetup(void)";
	push @load,"{";

	foreach $line(@buf1) {
		&read_line1($line);
	}

	push @hdr,"} CONFIG_DATA;";
	push @hdr,"";
	push @hdr,"extern CONFIG_DATA conf;";
	push @hdr,"";
	push @hdr,"int	ConfigInit(char *fname);";
	push @hdr,"void ConfigInteger(char *str,int  *var);";
	push @hdr,"void ConfigDouble(char *str,double *var);";
	push @hdr,"";
	push @hdr,"#endif //config_h__";


	push @load,"}";


	push @data,"};";
	push @data,"";
	push @data,@load;

	&write("config.h",@hdr);
	&write("configdata.c",@data);
	&write("cdcscope.ini",@ini);

}


&main();

