#ifndef _config_h
#define _config_h

typedef struct {
	int	 wave_bgcolor;
	int	 wave_fgcolor;
	int	 scaler_color;
	int	 clear_color;
	int	 btn_textcolor1;
	int	 btn_textcolor2;
	int	 btn_framecolor1;
	int	 btn_framecolor2;
	int	 window_size_w;
	int	 window_size_h;
	double gain;
	double dc_offset;
} CONFIG_DATA;

extern CONFIG_DATA conf;

int	ConfigInit(char *fname);
void ConfigInteger(char *str,int  *var);
void ConfigDouble(char *str,double *var);

#endif //!< config_h__
