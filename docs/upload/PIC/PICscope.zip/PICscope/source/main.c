/*!
 *************************************************************************
 *	OpenGL (GLUT) ���C�����[�`��.
 *************************************************************************
 */
#include <windows.h>
#include <math.h>

#include <GL/gl.h>
#include "glut.h"


#include "config.h"
#include "window.h"
#include "dllcall.h"
#include "disp.h"
#include "menu.h"

void exit_all(int rc);


/*!
 *************************************************************************
 *	[ESC] �������ꂽ��A�A�v���P�[�V�������I��.
 *************************************************************************
 */
void keyboard(unsigned char c, int x, int y)
{
	switch (c) {
	case 27:
		exit_all(0);
		break;
	default:
		break;
	}
}

void MyExitFunction(void)
{
	UnloadDLL();
}
/*!
 *************************************************************************
 *	OpenGL (GLUT) ���C��.
 *************************************************************************
 */
int main(int argc , char ** argv) 
{
	atexit(MyExitFunction);
	ConfigInit("picscope.ini");

	glutInit(&argc , argv);
	glutInitWindowSize(WINDOW_W , WINDOW_H);		// 960 x 640�ō쐬����.
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);

	glutCreateWindow( WINDOW_TITLE );

	initdisp();

	glutDisplayFunc(disp);
	glutKeyboardFunc(keyboard);
	glutReshapeFunc(reshape);
	glutIdleFunc(anim);
	glutMouseFunc(mouse);

	if( LoadDLL("piclink.dll") < 0 ) return -1;

#if	1
//	glutReshapeWindow(480,320);		//���Ƃ�Window�T�C�Y��ύX����.
//	glutReshapeWindow(360,240);		//���Ƃ�Window�T�C�Y��ύX����.
	if( conf.window_size_w ) {
		glutReshapeWindow(conf.window_size_w,conf.window_size_h);
	}
#endif

	glutMainLoop();

	exit_all(0);

	return 0;
}
/*!
 *************************************************************************
 *	
 *************************************************************************
 */
void exit_all(int rc)
{
	UnloadDLL();
	exit(0);
}
/*!
 *************************************************************************
 *
 *************************************************************************
 */
