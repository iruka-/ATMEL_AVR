#include <sys/timeb.h>
#include <sys/times.h>

//	Bogus Times... for Bcc32 / win

int times(struct tms *t)
{
	struct timeb tb;
	long   tick60;
	
	ftime(&tb);
	tick60 = (tb.millitm * 60) / 1000;	//  unit : 1/60 sec.
	
	t->tms_utime	=tb.time * 60 + tick60;
	t->tms_stime	=0;
	return t->tms_utime;
}
