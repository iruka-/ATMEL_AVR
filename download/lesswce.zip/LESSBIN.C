/**********************************************************************
 *		less binary dump
 **********************************************************************
 */
#include <stdio.h>
#include <malloc.h>
#include <stat.h>
#include <conslib.h>

#include "less.h"

extern int	ScreenWidth ;
extern int	ScreenHeight;
extern PRBUF prbuf[];//�������p�� ascii �o�b�t�@.
extern TCHAR Tbuf[];	// �܂Ƃ߂�Cputs()���邽�߂�unicode�o�b�t�@.
extern TCHAR *Tp;

extern	void endless(void);

static unsigned char *top;
static unsigned char *lp;
static unsigned char *endp;

static int	wmax=16;	// 16 or 8
#define	WMAX16	(6+1 + 3*16+1 +16)

/**********************************************************************
 *		�o�C�i���[����.
 **********************************************************************
 */
int isbinary(unsigned char *filebuf,int filesize)
{
	int i,c;
	int bincnt=0;
	int asccnt=0;
	
	for(i=0;i<filesize;i++) {
		c = *filebuf++;
		if( c>=0x20 && c<0x7f ) asccnt++;
		else if(c>=0x81 && c<=0xfc) asccnt++;
		else if(c== '\t') asccnt++;
		else if(c== '\r') asccnt++;
		else if(c== '\n') asccnt++;
		else bincnt++;
	}
	
	if( (bincnt * 16)>=asccnt ) return 1;
	return 0;
}

/**********************************************************************
 *		
 **********************************************************************
 */
int is_printable(int c)
{
	if((c>=0x20)&&(c<0x7f)) return 1;
	return 0;
}

static unsigned char *hexline(PRBUF *b,unsigned char *p,int off)
{
	int i;
	int c;
	int w;
	char *t = b->buf;
	unsigned char *ascp=p;

	w = endp - p;
	if(w<=0) {
		strcpy(t,"~");return p;
	}
	
	if(w>=wmax) w=wmax;

	//�P�U�i�_���v �P�s��.
	sprintf(t,"%06X:",off);t+=7;		//�A�h���X.
	for(i=0;i<w;i++) {
		sprintf(t,"%02X ",*p++);t+=3;	//�g�d�w.
	}
	for(   ;i<wmax;i++) {
		sprintf(t,"   ");t+=3;
	}

	for(i=0;i<w;i++) {
		c = *ascp++;
		if(is_printable(c)) *t++ = c;	//�`�r�b�h�h.
		else				*t++ = '.';
	}
	*t = 0;
	return p;
}
/**********************************************************************
 *		���������Ă݂�.
 **********************************************************************
 */
static void hexunderwrite(char *p)
{
	int i;
	PRBUF *b=prbuf;
	for(i=0;i<ScreenHeight;i++,b++) {
		b->p = p;
			p = hexline(b,p,p-top);
		b->l = p - b->p;
	}
}
/**********************************************************************
 *		
 **********************************************************************
 */
void hexdispline(int y)
{
	int n;
	PRBUF *b=&prbuf[y];

	n = sjis2TCHAR( b->buf,Tp,1020 );	// n = bytes of output
	Tp += (n>>1) -1;

	if(y!=(ScreenHeight-1)) {	//�ŏI�s�͉��s���Ȃ�.
		*Tp++ = '\n';
	}
}

/**********************************************************************
 *		�\����ł̂P�s���i��.
 **********************************************************************
 */
static char *nextline(char *lp)
{
	lp += 16;
	if(lp >= endp) lp = endp;
	return lp;
}

/**********************************************************************
 *		�\����ł̂P�s���߂�.
 **********************************************************************
 */
static char *prevline(char *lp)
{
	lp -= 16;
	if(lp <= top) lp = top;
	return lp;
}

/**********************************************************************
 *		
 **********************************************************************
 */
static char *nextlines(char *lp,int n)
{
	if(n<0) {
		while(n<0) {
			lp = prevline(lp);
			n++;
		}
		return lp;
	}else{
		while(n) {
			lp = nextline(lp);
			n--;
		}
		return lp;
	}
}



/**********************************************************************
 *		�e�L�X�g�\��.
 **********************************************************************
 */
static void hexdisp(char *lp)
{
	int y;

	hexunderwrite(lp);

	Cls();
	SetCurPos(0,0);

	Tp = Tbuf;
	for(y=0;y<ScreenHeight;y++) {
		hexdispline(y);
	}
	Cputs( Tbuf );
	SetCurPos(0,ScreenHeight-1);
}

/**********************************************************************
 *		�e�L�X�g�\��:�P�s�X�N���[���A�b�v
 **********************************************************************
 */
static void disp_up(char *lp)
{
	hexunderwrite(lp);
	SetCurPos(0,ScreenHeight-1);
	{
		Tp = Tbuf;
		*Tp++ = '\n';
		hexdispline(ScreenHeight-1);
		Cputs( Tbuf );
	}
	SetCurPos(0,ScreenHeight-1);
}
/**********************************************************************
 *		�e�L�X�g�\��:�P�s�X�N���[���_�E��
 **********************************************************************
 */
static void disp_dn(char *lp)
{
	hexunderwrite(lp);
	ScrollDown(0,ScreenHeight-1);
	SetCurPos(0,0);
	{
		Tp = Tbuf;
		hexdispline(0);
		*Tp = 0;
		Cputs( Tbuf );
	}
	SetCurPos(0,ScreenHeight-1);
}

/**********************************************************************
 *		
 **********************************************************************
 */
int lessbin(char *filebuf,int filesize)
{
	int c;
	
	top = filebuf;
	endp= filebuf + filesize;
	
	lp  = filebuf;
	if(ScreenWidth >= WMAX16) wmax = 16;
	else					  wmax = 8;
	
	while(1) {
		hexdisp(lp);
redo:	c = Getch();
		if((c==0x1b)||(c=='q')||(c=='Q')) break;
		switch(c) {

			case 'n':
			case 'j':
			case C_('E'):
			case C_('N'):
			case C_('J'):
			case 0x0d:
						if(lp>=endp) break;
						lp=nextline(lp);disp_up(lp);goto redo;

			case 'k':
			case C_('K'):
			case 'y':
			case C_('Y'):
			case 'p':
			case C_('P'):
						if(lp==filebuf) goto redo;
						lp=prevline(lp);disp_dn(lp);goto redo;

			case '\\':
			case C_('V'):
			case C_('F'):
			case 'f':
			case 0x20:	lp=nextlines(lp,ScreenHeight);break;

			
			case '^':
			case 'b':
			case C_('B'):
			case 0x08:
						if(lp==filebuf) goto redo;
						lp=nextlines(lp,-ScreenHeight);break;

			
			case C_('U'):
			case 'u':
						if(lp==filebuf) goto redo;
						lp=nextlines(lp,-ScreenHeight/2);break;

			case C_('D'):
			case 'd':	lp=nextlines(lp,ScreenHeight/2);break;

			case '<':
						lp=filebuf;break;
			case '>':
						lp=nextlines(endp,-ScreenHeight+2);break;
			case 'r':
			case C_('R'):
			case C_('L'):
						Cls();break;
			default:	break;
		}
	}
	endless();
	return 0;
}
/**********************************************************************
 *		
 **********************************************************************
 */
