/**********************************************************************
 *		less���ǂ�
 **********************************************************************
 */
#include <stdio.h>
#include <malloc.h>
#include <stat.h>
#include <conslib.h>

#include "less.h"

/**********************************************************************
 *		
 **********************************************************************
 */
static char USAGE[]=
"Usage:\n"
"%% less [-Options] filename\n"
"Option:\n"
"  -h   force hex mode\n"
"  -a   force text mode\n"
;

/**********************************************************************
 *	���[�J���ȃ��[�N�G���A.
 **********************************************************************
 */

PRBUF prbuf[ScreenHeightMAX];//�������p�� ascii �o�b�t�@.
TCHAR Tbuf[ScreenWidthMAX*ScreenHeightMAX];	// �܂Ƃ߂�Cputs()���邽�߂�unicode�o�b�t�@.
TCHAR *Tp;

int	ScreenWidth =80;
int	ScreenHeight=12;
char *opt[128];

/**********************************************************************
 *	LESS�������t�@�C���Ɋւ�����.
 **********************************************************************
 */
static FILE *fp;
static int fd=0;
static int filesize=0;
static char *filename;
static char *filebuf;
static char *lp;
static char *endp;
static char searchbuf[128];
static int 	tabsize = 8;

static void Usage(void)
{
	fprintf(stderr,USAGE);
	exit(1);
}


/**********************************************************************
 *		�t�@�C���� *filebuf �ɑS���ǂݍ���.
 **********************************************************************
 */
static int readstream(FILE *fp)
{
	struct stat sbuf;
	int blks;

	fd = fileno(fp);
	if( fstat(fd,&sbuf) != 0 ) {
		fprintf(stderr,"less:Can't Get file size.\n");
		exit(1);
	}
	filesize = sbuf.st_size;

	filebuf = xmalloc(filesize+1);
	blks = fread(filebuf,1,filesize,fp);
	if(blks != filesize) {
		fprintf(stderr,"less:Can't read file.\n");
		exit(1);
	}
	
	endp = &filebuf[filesize];
	*endp = 0x0a;	// �I�[���s���ɂȂ��Ă��Ȃ��e�L�X�g�΍�.
	return 0;
}

/**********************************************************************
 *		
 **********************************************************************
 */
static int readfile(char *filename)
{
	int rc;
	fp=fopen(filename,"rt");
	if(fp==NULL) {
		fprintf(stderr,"less:Can't open file %s.\n",filename);
		exit(1);
	}
	rc = readstream(fp);
	fclose(fp);
	return rc;
}

/**********************************************************************
 *		
 **********************************************************************
 */
static int isank(int c)
{
	c &= 0xff;
	if	    ( 0x20<=c && c < 0x7f ) return 1;
	return	( 0xa0<=c && c < 0xe0 );
}
/**********************************************************************
 *		
 **********************************************************************
 */
static int iskanji1(int c)
{
	c &= 0xff;
	return	((0x81<=c && c<=0x9f)||
			 (0xe0<=c && c<=0xfc));
}
/**********************************************************************
 *		
 **********************************************************************
 */
static int iskanji2(int c)
{
	c &= 0xff;
	return ( (0x40<= c
			&&  c <= 0xfc)
			&&  c != 0x7f);
}
/**********************************************************************
 *		
 **********************************************************************
 */
static int tabcnt(int x,int w)
{
	int n;
	if(x>=w) return 0;
	n = ( (x+tabsize) / tabsize) * tabsize;
	if(n>=w) n = w;
	
	return n - x;
}
/**********************************************************************
 *		�P�s���A���������Ă݂�.
 **********************************************************************
 */
static char *uwline(PRBUF *b,char *p,int w)
{
	int x=0;
	int c,tw;
	char *t=b->buf;
	
	if(p>=endp) {	// [EOF]�ɓ��B���Ă����� ~(�`���_) ������.
		*t++ = '~';
		*t = 0;
		b->w = 1;
		return p;
	}
	
	while(1) {
		if(p>=endp) break;
		c = *p & 0xff;
		if( iskanji1(c) && iskanji2(p[1]) ) {
			//=== �r-�i�h�r�����̏ꍇ:
			if( (x+2)>w ) break;
				x += 2;
			*t++ = *p++;
			*t++ = *p++;
		}else{
			//=== �r-�i�h�r�����ȊO:
			if( isank(c) ) {
				//=== ���p�`�r�b�h�h���J�i:
				if( (x+1)>w ) break;
					x += 1;
				*t++ = *p++;
			}else if( c==0x09) {
				//=== [TAB]�̏���:
				p++;
				tw = tabcnt(x,w);
				while(tw) {*t++ = ' ';x++;tw--;};
				if( x>= w ) break;
			}else if( c==0x0d && (p[1]==0x0a) ) {
				//=== [CR LF] �̏���:
				p+=2;break;
			}else if( c==0x0a) {
				//=== [LF]�̂� �̏���:
				p++ ;break;
			}else if( c< 0x20) {
				//=== �R���g���[���R�[�h(^@�`^Z�Ȃ�):
				if( (x+2)>w ) break;
					x += 2;
				*t++ = '^';
				*t++ = c + 0x40;
				p++;
			}else{
				//=== �c��́A�Q�o�C�g�����ɂȂ肻���Ȃ��̃R�[�h(0x80�`0x9f,0xe0�`0xff):
				if( (x+4)>w ) break;
					x += 4;
				sprintf(t,"<%02X>",c);t+=4;
				p++;
			}
		}
	}
	*t = 0;
	b->w = x;
	return p;
}
/**********************************************************************
 *		���������Ă݂�.
 **********************************************************************
 */
static void underwrite(char *p)
{
	int i;
	PRBUF *b=prbuf;
	for(i=0;i<ScreenHeight;i++,b++) {
		b->p = p;
			p = uwline(b,p,ScreenWidth);
		b->l = p - b->p;
	}
}
/**********************************************************************
 *		�\����ł̂P�s���i��.
 **********************************************************************
 */
static char *nextline1(char *lp)
{
	return prbuf[1].p;
}
/**********************************************************************
 *		�P�s�i��.
 **********************************************************************
 */
static char *nextline(char *lp)
{
	while(lp <= endp) {
		if(*lp == 0x0a) {lp++;break;}
		lp++;
	}
	return lp;
}

/**********************************************************************
 *		�P�s�߂�.
 **********************************************************************
 */
static char *prevline(char *lp)
{
	if(lp > filebuf) lp--;
	
	while(lp > filebuf) {
		lp--;
		if(*lp == 0x0a) {lp++;break;}
	}
	return lp;
}
/**********************************************************************
 *		�\����ł̂P�s���߂�.
 **********************************************************************
 */
static char *prevline1(char *lp)
{
	char *lp1;		//��O�̉��s���w��.
	int i;

	if(lp <= filebuf) return filebuf;	//�őO�s�ɓ��B�ς݂Ȃ̂ŁA�ȉ���[�܂�.

	lp1 = prevline(lp);	//��O�̉��s����������.
	underwrite(lp1);	//�������玎���������Ă݂�.

	//��O�̈ʒu�͂ǂ��Ȃ̂��T��.
	for(i=1;i<ScreenHeight-1;i++) {
		if(lp == prbuf[i].p) return prbuf[i-1].p;	//���ݍs�Ɠ����|�C���^������������A����.
	}
	//������߂�.
	return lp1;
}

/**********************************************************************
 *		
 **********************************************************************
 */
static char *nextlines(char *lp,int n)
{
	if(n<0) {
		while(n<0) {
			lp = prevline1(lp);	//������ƒx�����E�E�E.
			n++;
		}
		return lp;
	}else{
		int incr;
		while(n) {
			if(n<ScreenHeight-1) incr=n;	//�\������Ă���͈͓��̈ړ��Ȃ�A�ꔭ.
			else incr = ScreenHeight-1;		//�����łȂ���΁A���킶��i��.

			underwrite(lp);	//�������玎���������Ă݂�.
			lp = prbuf[incr].p;
			n -= incr;
		}
		return lp;
	}
}


/**********************************************************************
 *		
 **********************************************************************
 */
void displine(int y)
{
	int n;
	PRBUF *b=&prbuf[y];

	n = sjis2TCHAR( b->buf,Tp,1020 );	// n = bytes of output
	Tp += (n>>1) -1;

	if(y!=(ScreenHeight-1)) {	//�ŏI�s�͉��s���Ȃ�.
		*Tp++ = '\n';
	}
}

/**********************************************************************
 *		�e�L�X�g�\��.
 **********************************************************************
 */
static void disp(char *lp)
{
	int y;

	underwrite(lp);

	Cls();
	SetCurPos(0,0);

	Tp = Tbuf;
	for(y=0;y<ScreenHeight;y++) {
		displine(y);
	}
	Cputs( Tbuf );
	SetCurPos(0,ScreenHeight-1);
}


/**********************************************************************
 *		�ŉ��s�Ƀ��b�Z�[�W��\������.
 **********************************************************************
 */
static void pr_status(char *s)
{
	SetCurPos(0,ScreenHeight-1);
	sjis2TCHAR(s,Tbuf,256 );	// n = bytes of output

	SetCurPos(0,ScreenHeight-1);
	Cputs( Tbuf );ClearEol();
}
/**********************************************************************
 *		�e�L�X�g�\��:�P�s�X�N���[���A�b�v
 **********************************************************************
 */
static void disp_up(char *lp)
{
	underwrite(lp);
	SetCurPos(0,ScreenHeight-1);
	{
		Tp = Tbuf;
		*Tp++ = '\n';
		displine(ScreenHeight-1);
		Cputs( Tbuf );
	}
	SetCurPos(0,ScreenHeight-1);
}
/**********************************************************************
 *		�e�L�X�g�\��:�P�s�X�N���[���_�E��
 **********************************************************************
 */
static void disp_dn(char *lp)
{
	underwrite(lp);
	ScrollDown(0,ScreenHeight-1);
	SetCurPos(0,0);
	{
		Tp = Tbuf;
		displine(0);
		*Tp = 0;
		Cputs( Tbuf );
	}
	SetCurPos(0,ScreenHeight-1);
}


/**********************************************************************
 *		
 **********************************************************************
 */
void endless()
{
	SetCurPos(0,ScreenHeight-1);
	ClearEol();
}


static int is_num(int c)
{
	return (c>='0')&&(c<='9');
}

static int getnum(int c,int *num)
{
	char buf[128];
	int n=0;
	while( is_num(c) ) {
		n = (n*10) + (c-'0'); 
		sprintf(buf,":%d  ",n);
		pr_status(buf);
		c=Getch();
	}
	*num = n;	//����ꂽ���l.
	return c;	//�Ō�ɓ��͂��ꂽ����(�����ȊO)
}

static int calc_line(char *p)
{
	char *l;
	int num=1;
	l = filebuf;
	while( l < p ) {
		if(*l == '\n') num++;
		l++;
	}
	return num;
}

/**********************************************************************
 *		
 **********************************************************************
 */
static DWORD unicode2sjis( LPCTSTR src, BYTE *dst, DWORD max )
{
	return WideCharToMultiByte( CP_ACP, 0, src, -1, dst, max, NULL, NULL ) ;
}
/**********************************************************************
 *		
 **********************************************************************
 */
static int search_str(char *s,char *t,int l)
{
	while(*s != '\n') {
		if(strncmp(s,t,l)==0) return 1;	//����.
		s++;
	}
	return 0;
}
/**********************************************************************
 *		
 **********************************************************************
 */
static int next_search(int f)
{
	char buf[128];
	char *p = lp;
	int l;

	l = strlen(searchbuf);
	if( l==0 ) return 0;

	if(f>0) p = nextline(p);	//�O��T�[�`�����Ȃ�A���̍s����,
	if(f<0) p = prevline(p);	//f�����̏ꍇ�͑O�̍s������.
	
	while( p < endp) {
		if( search_str(p,searchbuf,l) ) {lp = p;return 1;}
		if(f>=0) {
			p = nextline(p);
		}else {
			if(p <= filebuf) break	;	//���łɐ擪�s.
			p = prevline(p);
		}
	}
	
	if(f==0) {	//���������񂪓��͂��ꂽ����Ɍ���A��ʂ̗����}���邽�ߍĕ`��.
		disp(lp);
	}
	
	sprintf(buf,": '%s' not found.(PRESS [CR])",searchbuf);
	pr_status(buf);
	Getch();
	
	return 0;			//�����o����.
}
/**********************************************************************
 *		
 **********************************************************************
 */
static void enter_search(void)
{
	TCHAR tbuf[256];
	
	pr_status(":/");
	SetCurPos(2,ScreenHeight-1);
	Cgets(tbuf);
	unicode2sjis(tbuf,searchbuf,128);
	next_search(0);
}

/**********************************************************************
 *		
 **********************************************************************
 */
static void file_status(void)
{
	char buf[256];
	int current_line;
	int max_lines;
	int percent;
	
	current_line = calc_line(lp);
	max_lines    = calc_line(endp);
	percent = current_line * 100 / max_lines;
	sprintf(buf,":[ %d/%d (%d%%) %s  ] ",current_line,max_lines,percent,filename);
	pr_status(buf);
}

/**********************************************************************
 *		
 **********************************************************************
 */
void Goto_line(int num)
{
	lp=filebuf;	//�s��.
	while( --num ) {
		lp = nextline(lp);		// ���� '\n' ��T��.
		if(lp >= endp) break;
	}
}

/**********************************************************************
 *		
 **********************************************************************
 */
static char *convpath(char *t,const char *s)
{
	char *r = t;
	while(*s) {
		if(*s =='/' ) *t++ = '\\';
		else *t++ = *s;
		
		s++;
	}
	*t=0;
	return r;
}
/**********************************************************************
 *		ng�̋N��.
 **********************************************************************
 */
void edit_file(char *s)
{
	static char exefile[]="ng";
	TCHAR Texefile[256];

	char name[256];
	TCHAR tbuf[256];
	TCHAR Tcmdline[256];

	sjis2TCHAR( convpath(name,s) ,tbuf,256 );
	rel2absdir( Tcmdline,256,tbuf );
	
	sjis2TCHAR(exefile,Texefile,256);
	if ( !ExecuteProcess( Texefile , Tcmdline ) ) {
		fprintf(stderr,"Can't exec: %s\n",exefile);
	}
}

/**********************************************************************
 *		less �̃��C�����[�`��.
 **********************************************************************
 */
int main(int argc,char **argv)
{
	int c;
	int num;

	Getopt(argc,argv);

	GetWH( &ScreenWidth, &ScreenHeight);
	if(ScreenWidth >= ScreenWidthMAX) ScreenWidth = ScreenWidthMAX;
	if(ScreenHeight>= ScreenHeightMAX)ScreenHeight= ScreenHeightMAX;

	if(argc<=1) {
		fp = stdin;
		if(isatty(fileno(fp))) {
			Usage();
		}
		readstream(fp);
		filename = "\\windows\\pipe.$$$";	//���ߑł�:�Ⴄ����...
	}else{
		filename = argv[1];
		readfile(argv[1]);
	}
	lp = filebuf;
	
	//�o�C�i���[�t�@�C���������ꍇ�̏���.
	if(!IsOpt('a') ) {
		if( isbinary(filebuf,filesize) || IsOpt('h') ) {
			return lessbin(filebuf,filesize);
		}
	}
	
	while(1) {
		disp(lp);
redo:	c = Getch();
redo2:	if((c==0x1b)||(c=='q')||(c=='Q')) break;

		num = 1;
		if(is_num(c)) c = getnum(c,&num);	//�������͂���.

		switch(c) {

			case 'N':
					if(searchbuf[0]) {
						next_search(-1);
					}
					break;
			case 'n':
					if(searchbuf[0]) {
						next_search(1);break;
					}
			case 'j':
			case C_('E'):
			case C_('N'):
			case C_('J'):
			case 0x0d:
						if(lp>=endp) break;
						lp=nextline1(lp);disp_up(lp);goto redo;

			case 'k':
			case C_('K'):
			case 'y':
			case C_('Y'):
			case 'p':
			case C_('P'):
						if(lp==filebuf) goto redo;
						lp=prevline1(lp);disp_dn(lp);goto redo;

			case '\\':
			case C_('V'):
			case C_('F'):
			case 'f':
			case 0x20:	lp=nextlines(lp,ScreenHeight);break;

			
			case '^':
			case 'b':
			case C_('B'):
			case 0x08:
						if(lp==filebuf) goto redo;
						lp=nextlines(lp,-ScreenHeight);break;

			
			case C_('U'):
			case 'u':
						if(lp==filebuf) goto redo;
						lp=nextlines(lp,-ScreenHeight/2);break;

			case C_('D'):
			case 'd':	lp=nextlines(lp,ScreenHeight/2);break;

			case 'g':
			case '<':
						//lp=filebuf;break;
						Goto_line(num);break;
			case 'G':
			case '>':
						lp=nextlines(endp,-ScreenHeight+2);break;
			case 'r':
			case C_('R'):
			case C_('L'):
						Cls();break;
			case C_('I'):	// [TAB]
						if(	tabsize==8) {
							tabsize = 4;
						}else{
							tabsize = 8;
						}
						break;

			case C_('G'):
						file_status();
						c = Getch();disp(lp);
						goto redo2;
			case '/':
						enter_search();
						break;
			case 'e':
						edit_file( filename );
						endless();
						return 0;

			default:	break;
		}
	}
	endless();
	return 0;
}
/**********************************************************************
 *		
 **********************************************************************
 */
