#include <windows.h>
#include "times.h"

//	Bogus Times... for WinCE

int times(struct tms *t)
{
	t->tms_utime	= GetTickCount();
	t->tms_stime	=0;
	return t->tms_utime;
}
