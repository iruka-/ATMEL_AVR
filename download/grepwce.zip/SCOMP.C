/* scomp.c -- stream editor main and compilation phase

   The stream editor compiles its command input	 (from files or -e options)
into an internal form using compile() then executes the compiled form using
execute(). Main() just initializes data structures, interprets command line
options, and calls compile() and execute() in appropriate sequence.
   The data structure produced by compile() is an array of compiled-command
structures (type sedcmd).  These contain several pointers into pool[], the
regular-expression and text-data pool, plus a command code and g & p flags.
In the special case that the command is a label the struct  will hold a ptr
into the labels array labels[] during most of the compile,  until resolve()
resolves references at the end.
   The operation of execute() is described in its source module.

====   Written for the GNU operating system by Eric S. Raymond	====
====               For Kanji use by pcs19614 serow              ====
*/
/*
char id_scomp[] = "$Header: rcs/scomp.c 1.5 88/03/02 06:01:13 serow Exp $";
*/

/* debug & ext. by LOGOS
*
* 1989.02/03 :	SKIPWS(), recognize kanji space
* 1989.02/14 :	cmdline(), exesc() escape character, USAGE
* 1989.03/10 :	main(), add -o option
* 1989.06/21 :	compile(), cmdline(), exesc(), commandline escape character
* 1989.07/11 :	compile(), cmdcomp(), gettext(), debug multicolumn statement';'
* 1989.07/14 :	cmdcomp(), substitute match times
* 1989.07/26 :  recomp(), debug escape character
* 1989.08/28 :  main(), add -a option
* 1990.02/10 :  exesc(),cmdcomp(), #n, #g, #g- and misc.
* 1990.02/14 :  cmdcomp(), debug 'a' command, misc.
* 1990.02/26 :  main(), usage(), misc.
* 1990.12/15 :  misc., correspond serow 88/03/02 & CR-X 90/09/14
* 1990.12/19 :  cmdcomp(), use lastrhs at rhs is %
* 1990.12/26 :  cmdcomp(), error messages
* 1991.02/07 :	main(), debug -a, -o file name. future use.
* 1991.03/18 :  exesc(), debug Kanji escape char.
* 1991.04/17 :  main(), use xargs().
* 1991.06/03 :  cmdlin(), main(), debug error message.
* 1991.06/06 :  main(), add -i option.
* 1991.06/07 :  main(), catchsig(), test_signal(), add user interrupt.
* 1991.08/03 :  cmdcomp(), rhscomp(), check poolend.
* 1991.09/25 :  main(), cmdcomp(), add w, W command with append mode.
* 1991.10/17 :	ycmd(), debug escape delimitter.
* 1991.12/02 :	changed WFILES, error message and add disendsp().
* 1992.05/27 :	cmdcomp(), debug lastrhs at rhs is only %
*/

#include <stdio.h>		/* uses getc, fprintf, fopen, fclose */
#include <stdlib.h>
#include <string.h>		/* uses strcpy, strlen, strcmp, strtok */
#include "kanji.h"              /* for kanji use */
#include "sed.h"		/* command type struct and name defines */

/* sed command file search path */

#define SEDFILE         "SEDFILE"

/* imported functions */
/* extern int strcmp();	*/	/* test strings for equality */
extern void execute();		/* execute compiled command */
extern void xargs(int *, char ***);

/* functions */
void ABORT( char * );
void usage();
static int cmdcomp( khar );
static khar * recomp( khar*, khar );
static int cmdline( khar * );

				/* discarding ending whitespace enable */
#ifndef DISENDSP
#define DISENDSP 1
#endif
				/* control break check enable */
#ifndef BREAK
#define BREAK 1
#endif

#if BREAK
#include <signal.h>
void catchsig( int );		/* user interrupt break */
void test_signal( void );	/* check ^C key in buffer */
#endif

/***** public stuff ******/

#define MAXCMDS	 2500		/* maximum number of compiled commands */
#define MAXLINES 512		/* max # numeric addresses to compile */

/* main data areas */
khar	linebuf[MAXBUF+1];	/* current-line buffer */
sedcmd	*cmds;			/* hold compiled commands */
long	linenum[MAXLINES];	/* numeric-addresses table */

/* miscellaneous shared variables */
int	nflag = NO;		/* -n option flag */
int	eargc;			/* scratch copy of argument count */
sedcmd	*pending	= NULL; /* next command to be executed */


/***** module common stuff *****/
#define POOLSIZE        30000   /* size of string-pool space */
#define WFILES		11	/* max # w output files that can be compiled */
#define RELIMIT		256	/* max khars in compiled RE */
#define MAXDEPTH	20	/* maximum {}-nesting level */
#define MAXLABS		50	/* max # of labels that can be handled */

				/* skip white space ( space, tab, kanji space ) */
#define SKIPWS(pc)	while ((*pc==' ') || (*pc=='\t') || (*pc==(khar)0x8140)) pc++

#define IFEQ(x, v)	if (*x == v) x++ , /* do expression */

/* error messages */
static char AGMSG[] = "garbled address %s\n";
static char CGMSG[] = "garbled command %s\n";
static char TMTXT[] = "too much text: %s\n";
static char AD1NG[] = "no addresses allowed for %s\n";
static char AD2NG[] = "only one address allowed for %s\n";
static char TMCDS[] = "too many commands, last was %s\n";
static char COCFI[] = "cannot open command-file %s\n";
static char UFLAG[] = "unknown flag '%c'\n";
static char CCOFI[] = "cannot create '%s'\n";
static char ULABL[] = "undefined label '%s'\n";
static char TMLBR[] = "too many {'s\n";
static char FRENL[] = "first RE must be non-null\n";
static char NSCAX[] = "no such command as %s\n";
static char TMRBR[] = "too many }'s\n";
static char DLABL[] = "duplicate label '%s'\n";
static char TMLAB[] = "too many labels: '%s'\n";
static char TMWFI[] = "too many w files\n";
static char REITL[] = "RE too long: %s\n";
static char TMLNR[] = "too many line numbers\n";
static char TRAIL[] = "command \"%s\" has trailing garbage\n";
static char CNOFI[] = "cannot open %s\n";
static char NOLRH[] = "no previous replace pattern %s\n";

#ifndef FLIST
//#define FLIST 1
#endif

/*	version & usage message	*/
static char	VERNO[] = "@(#)sed	Ver2.42"
#ifdef MINOR
			MINOR
#endif
			"\t" __DATE__ "\n";

static char	USAGE[] = "usage: %s [-n] [-g] [{-O|-A}] [{-o|-a} <output file>] "
#if FLIST
				"[-i <datalist file>] "
#endif
				"\n{[-e] <script> | -f <script file>}... [-] [<data file>...]\n";
static char     *sed_exe;

/* label handling */
typedef struct			/* represent a command label */
{
	char		*name;		/* the label name */
	sedcmd		*last;		/* it's on the label search list */
	sedcmd		*address;	/* pointer to the cmd it labels */
} label;

static label	labels[MAXLABS];	/* here's the label table */
static label	*lab	= labels + 1;	/* pointer to current label */
static label	*lablst = labels;	/* header for search list */

/* string pool for regular expressions, append text, etc. etc. */
static khar	*pool;				/* the pool */
static khar	*fp  ;				/* current pool pointer */
static khar	*poolend;			/* pointer past pool end */


/* compilation state */
static FILE	*cmdf	= NULL;		/* current command source */
#if FLIST
static FILE	*infl	= NULL;		/* input-file-list file */
#endif
static khar	*cp	= linebuf;	/* compile pointer */
static sedcmd	*cmdp	;		/* current compiled-cmd ptr */
static khar	*lastre = NULL;		/* old RE pointer */
static khar	*lastrhs = NULL;	/* old rhs pointer */
static int	bdepth	= 0;		/* current {}-nesting level */
static int	bcount	= 0;		/* # tagged patterns in current RE */
static char	**eargv;		/* scratch copy of argument list */

/* compilation flags */
static int	eflag	= 0;		/* -e option flag */
static int	gflag	= ONCE;		/* -g option flag */
static char 	*wmode	= "w";		/* w command, over write mode */
static char		crlfmode = 0;	/* output text format , 0: LF only  1: CR+LF */

#if 0
static char	*o_file = NULL;		/* output file name */
static char	*a_file = NULL;		/* output file name */
static char	*t_file = "tmXXXXXX";	/* temp file name */
#endif

#if FLIST
static char	*i_file = NULL;		/* input file list name */
#endif

static char	*scr_name = NULL;	/* script filename */
static unsigned	line_no = 0;		/* script line num. */

#if 0
char *xmalloc(long);
#endif

#if	GREP
char grepcmd[256];
char grepmode=0;
#endif


void
main(argc, argv)        /* main sequence of the stream editor */
int	argc;
char	*argv[];
{
	void compile(), resolve();
	char * cp, * np,* mmalloc();
	int i;

#if FLIST
#define SBUFLEN 81
	char sbuf[SBUFLEN];	/* input file list buffer */
#endif

#if BREAK
	signal(SIGINT, catchsig);	/* user interrupt */
#endif

#if 0
// MS-DOS�ł�  wildcard expand ���Ȃ��̂�xargs���Ă�ł���.
// Windows�ł� WinMain.c �����s����̂ŕs�v.
	xargs( &argc, &argv );
	for(i=0;i<argc;i++) {
		printf("[%s]",argv[i]);
	}
#endif


#if 1
// Windows�łł̓������[�m�ۂɂ��z��̈���m�ۂ���.
// ���̂ق���sed�X�N���v�g�̃T�C�Y�������ɂ��Ȃ�.
	pool    = (khar *) xmalloc(POOLSIZE);
	fp      = pool;
	poolend = pool +  POOLSIZE;
	
	cmds    = (sedcmd *) xmalloc( sizeof(sedcmd) * (MAXCMDS+1) );
	cmdp    = cmds;
	
/*	printf("sizeof(sedcmd)=%d\n",sizeof(sedcmd));*/
	
#endif
	eargc = argc;		/* set local copy of argument count */
	eargv = argv;		/* set local copy of argument list */
	cmdp->addr1 = pool;	/* 1st addr expand will be at pool start */

						/* get command name */
	if ((np = jrindex(*eargv,'.')) != NULL)
		*np = '\0';
	if ((np = jrindex(*eargv,'\\')) != NULL){
		++np;
		sed_exe = strcpy( mmalloc(strlen(np)+1), np );
	}
	else
		sed_exe = strcpy( mmalloc(4), "sed");    /* other MS-DOS v3.x */
	if (eargc == 1) {
		fprintf(stderr, "%s%s", sed_exe, VERNO+7);
		fprintf(stderr, USAGE, sed_exe);
		exit(1);		/* exit immediately if no arguments */
	}
		/* scan through the arguments, interpreting each one */
	while ((--eargc > 0) && (**++eargv == '-'))
		switch (eargv[0][1]){
		case 'e':
		case 'E':
			if (eargc > 1) {
				eflag++;
				scr_name = "(cmdline)";
				compile();	/* compile with e flag on */
				eflag = 0;
			}
			continue;		/* get another argument */
		case 'f':
		case 'F':
			if (--eargc <= 0)	/* barf if no -f file */
				usage();
			++eargv;
			if (eargv[0][0] == '-' && eargv[0][1] == NULL ) {
				cmdf = stdin;
				scr_name = "(stdin)";
			}
			else if ((cmdf = fopen(scr_name=*eargv,"r")) == NULL){
				if (cp=getenv(SEDFILE) ){
					if ((np = jrindex( *eargv,'\\'))
				 	 || (np = jrindex( *eargv,'/' ))
					 || (np = jrindex( *eargv,':' ))){
						*eargv = np+1;
					}
					switch (cp[i = strlen(cp)-1]){
					case '/':
					case ':':
						break;
					case '\\':
						if (jrindex(cp, '\\') == &cp[i])
							break;
					default :
						cp=strcat(strcpy(mmalloc(strlen(cp)+2),cp),"\\");
					}
                         		*eargv = strcat(strcpy(mmalloc(strlen(cp)+strlen(*eargv)+1),cp ),*eargv );
					cmdf = fopen(scr_name=*eargv,"r" );
				}
			}
			if (cmdf == NULL){
				fprintf(stderr, COCFI, *eargv);
				exit(2);
			}
			line_no = 0;
			compile();	/* file is O.K., compile it */
			fclose(cmdf);
			continue;	/* go back for another argument */
		case 'g':
		case 'G':
			gflag = GLOBAL;	/* set global flag on all s cmds */
			continue;
		case 'n':
		case 'N':
			nflag = YES;	/* no print except on p flag or w */
			continue;
		case 'O':
			wmode = "w";
			continue;
		case 'A':
			wmode = "a";
			continue;
		case 'r':
			crlfmode = 1;
			continue;
		case 'o':		/* output file name (over write)*/
			if (--eargc <= 0)	/* barf if no -o file */
				usage();
			if (freopen(*++eargv, "w", stdout) == NULL) {
				fprintf(stderr, CNOFI, *eargv);
				exit(2);
			}
#if 0
			o_file = *eargv;
#endif
			continue;
		case 'a':		/* output file name (append)*/
			if (--eargc <= 0)	/* barf if no -a file */
				usage();
			if (freopen(*++eargv, "a", stdout) == NULL) {
				fprintf(stderr, CNOFI, *eargv);
				exit(2);
			}
#if 0
			a_file = *eargv;
#endif
			continue;
#if FLIST
		case 'i':
		case 'I':		/* input file list file*/
			if (--eargc <= 0)	/* barf if no -i file */
				usage();
			++eargv;
			if (eargv[0][0] == '-' && eargv[0][1] == NULL )
				infl = NULL;	/* file list in stdin */
			else if ((infl = fopen(*eargv, "r")) == NULL) {
				fprintf(stderr, CNOFI, *eargv);
				exit(2);
			}
			i_file = *eargv;
			continue;

		case NULL:
			goto stdin_data;
#endif
		default:
			fprintf(stderr, UFLAG, eargv[0][1]);
			continue;
		}

	if (cmdp == cmds){		/* no commands have been compiled */

#if	GREP	// GREP���[�h�ł́A -e -f�Ƃ��ɗ^�����Ȃ�������grep�Ƃ��ċ@�\����.
		scr_name = "(cmdline)";
		eargv--; eargc++;
		{
			nflag = YES;	/* no print except on p flag or w */
			grepmode =1;
			eflag++;
				sprintf(grepcmd,"/%s/p",eargv[1]);
				//printf("GREP %s\n",grepcmd);
				eargv[1] = grepcmd;
				compile();
			eflag = 0;
		}
		eargv++; eargc--;
#else
		scr_name = "(cmdline)";
		eargv--; eargc++;
		eflag++; compile(); eflag = 0;
		eargv++; eargc--;
#endif
	}
#if FLIST
stdin_data:;
#endif
	if (bdepth)		/* we have unbalanced squigglies */
		ABORT(TMLBR);

	lablst->address = cmdp; /* set up header of label linked list */
	resolve();		/* resolve label table indirections */

#if FLIST
	if (i_file != NULL) {		/* get input file list */
		if (infl == NULL)	/* from stdin */
			infl = fdopen(dup(fileno(stdin)), "r");
		while( fgets( sbuf, SBUFLEN-1, infl ) != NULL ) {
			i_file = strtok( sbuf, " \t\n" );
			while ( i_file != NULL ) {
				if (freopen(i_file, "r", stdin) == NULL){
					fprintf(stderr, CNOFI, i_file);
					exit(1);
				}
				execute(i_file);
				i_file = strtok( NULL, " \t\n" );
			}
		}
		fclose(infl);
	}

#endif

	if (eargc <= 0)	{	/* if there were no -e commands */

#if	1
// Windows�łł́A���_�C���N�g���͂̃T�|�[�g������܂���B
// �܂��A�W�����͂���̃T�|�[�g������܂���B
	if(isatty(fileno(stdin))) {
		fprintf(stderr,"sed: no input file.\n");
		exit(1);
	}
#endif

		execute(NULL);	/*   execute commands from stdin only */
	}else{
		while(--eargc>=0){	/* else execute only -e commands */
#if FLIST
			if (eargv[0][0] == '-' && eargv[0][1] == NULL) {
				execute(NULL);	/* read data from stdin */
				++eargv;
			}
			else {			/* read data from file */
#endif
				if (freopen(*eargv, "r", stdin) == NULL){
					fprintf(stderr, CNOFI, *eargv);
					exit(1);
				}
				execute(*eargv++);
#if FLIST
			}
#endif
		}
	}
	exit(0);		/* everything was O.K. if we got here */
}

void
ABORT(msg)
char *msg;
{
	khar *pl;
	char *pe;
	char ebuf[MAXBUF*2+2];

	for( pl = linebuf,pe = ebuf; *pl ; pl++,pe++ ){
		if (( *pl <= 0 )||( 256 <= *pl)){
			*pe ++ = (char)(*pl >> 8)&0xFF;
		}
		*pe = (char)*pl & 0xFF;
	}
	*pe = '\0';
	fprintf( stderr, "%s  %u : ", scr_name, line_no);
	fprintf( stderr, "%s : ", sed_exe);
	fprintf( stderr, msg, ebuf );
	exit(2);
}


void
usage()
{
	fprintf(stderr, USAGE, sed_exe);
	exit( 2 );
}


char *
mmalloc(s)
short	s;
{
	register char * cp;
	void * malloc();

	if (!(cp= malloc(s)))
		ABORT("Out of memory");
	return cp;
}

#define H	0x80	/* 128 bit, on if there's really code for command */
#define LOWCMD	56	/* = '8', lowest char indexed in cmdmask */

/* indirect through this to get command internal code, if it exists */
static unsigned char	cmdmask[] =
{
	0,	0,	H,	0,	0,	H+EQCMD,0,	0,
	0,	0,	0,	0,	H+CDCMD,0,	0,	CGCMD,
	CHCMD,	0,	0,	0,	0,	0,	CNCMD,	0,
	CPCMD,	0,	0,	0,	H+CTCMD,0,	0,	H+CWCMD,
	0,	0,	0,	0,	0,	0,	0,	0,
	0,	H+ACMD, H+BCMD, H+CCMD, DCMD,	0,	0,	GCMD,
	HCMD,	H+ICMD, 0,	0,	H+LCMD, 0,	NCMD,	0,
	PCMD,	H+QCMD, H+RCMD, H+SCMD, H+TCMD, 0,	0,	H+WCMD,
	XCMD,	H+YCMD, 0,	H+BCMD, 0,	H,	0,	0,
};

void
compile()
/* precompile sed commands out of a file */
{
	char	ccode=0;
	khar	*address();
	int     cmdcomp();
	int     exesc();

	for(;;){				/* main compilation loop */
		if (*cp != ';') {		/* get a new command line */
			if (cmdline(cp = linebuf) < 0)
				break;
			exesc(cp);		/* expand escape character */
		}

lb_comp:
		SKIPWS(cp);
		if (*cp=='\0')
			continue;
		if (*cp=='#'){			/* a comment */
			cp++;
			if (*cp=='g'){		/* #g */
				gflag = GLOBAL;
				if (*++cp=='-')	/* #g- */
					gflag = ONCE;
			}
			else if (*cp=='n'){		/* #n */
				nflag = YES;
			}
			continue;
		}
		if (*cp == ';'){		/* ; separates cmds */
			cp++;
		}

		/* compile first address */
		if (fp > poolend)
			ABORT(TMTXT);
		if ((fp = address(cmdp->addr1 = fp)) == BAD)
			ABORT(AGMSG);

		if (fp == cmdp->addr1){		/* if empty RE was found */
			if (lastre)		/* if there was previous RE */
				cmdp->addr1 = lastre;	/* use it */
			else
				ABORT(FRENL);
		}else if (fp == NULL){		/* if fp was NULL */
			fp = cmdp->addr1;	/* use current pool location */
			cmdp->addr1 = NULL;
		}else{
			lastre = cmdp->addr1;
			if (*cp == ',' || *cp == ';'){	/* there's 2nd addr */
				cp++;
				if (fp > poolend) ABORT(TMTXT);
				fp = address(cmdp->addr2 = fp);
				if (fp == BAD || fp == NULL) ABORT(AGMSG);
				if (fp == cmdp->addr2)
					cmdp->addr2 = lastre;
				else
					lastre = cmdp->addr2;
			}else
				cmdp->addr2 = NULL;	/* no 2nd address */
		}
		if (fp > poolend) ABORT(TMTXT);

		SKIPWS(cp);		/* discard whitespace after address */
		IFEQ(cp, '!') cmdp->flags.allbut = 1;

		SKIPWS(cp);		/* get cmd khar, range-check it */
		if ((*cp < LOWCMD) || (*cp > '~')
			|| ((ccode = cmdmask[*cp - LOWCMD]) == 0))
				ABORT(NSCAX);
		cmdp->command = ccode & ~H;	/* fill in command value */
		if ((ccode & H) == 0)		/* if no compile-time code */
			cp++;			/* discard command khar */

		else if (cmdcomp(*cp++)) {	/* execute it; if ret = 1 */
			if (*(cp-1)=='{')
				goto lb_comp;	/* continue compile */
			else
				continue;	/* skip next line read */
		}
		if (++cmdp >= cmds + MAXCMDS) ABORT(TMCDS);

		SKIPWS(cp);			/* look for trailing stuff */
		if (*cp != '\0' && *cp != ';' && *cp != '#')
			ABORT(TRAIL);
	}
}

static int cmdcomp(ckhar)	/* compile a single command */
register khar	ckhar;		/* character name of command */
{
	khar            *gettext(), *rhscomp(), *ycomp();
#if DISENDSP
	char		*disendsp();
#endif
	static sedcmd	**cmpstk[MAXDEPTH];	/* current cmd stack for {} */
	static char	*fname[WFILES];		/* w file name pointers */
	static FILE	*fout[WFILES]={stdout}; /* w file file ptrs */
	static int	nwfiles = 1;		/* count of open w files */
	int		i;			/* indexing dummy used in w */
	sedcmd		*sp1, *sp2;		/* temps for label searches */
	label		*lpt, *search();	/* ditto, and the searcher */
	khar		redelim;		/* current RE delimiter */

	switch(ckhar){
	case '{':	/* start command group */
		cmdp->flags.allbut = (unsigned char)!cmdp->flags.allbut;
		cmpstk[bdepth++] = &(cmdp->u.link);
		if (++cmdp >= cmds + MAXCMDS) ABORT(TMCDS);
		return(1);

	case '}':	/* end command group */
		if (cmdp->addr1) ABORT(AD1NG);	/* no addresses allowed */
		if (--bdepth < 0) ABORT(TMRBR); /* too many right braces */
		*cmpstk[bdepth] = cmdp;		/* set the jump address */
		return(1);

	case '=':			/* print current source line number */
	case 'q':			/* exit the stream editor */
		if (cmdp->addr2) ABORT(AD2NG);
		break;

	case ':':	/* label declaration */
		SKIPWS(cp);
		if (cmdp->addr1) ABORT(AD1NG);	/* no addresses allowed */
		fp = gettext(lab->name=(char *)fp);/* get the label name */
#if DISENDSP
		disendsp(lab->name);
#endif
		if (lpt = search(lab)){		/* does it have a double? */
			if (lpt->address) ABORT(DLABL); /* yes, abort */
		}else{	/* check that it doesn't overflow label table */
			lab->last = NULL;
			lpt = lab;
			if (++lab >= labels + MAXLABS) ABORT(TMLAB);
		}
		lpt->address = cmdp;
		return(1);

	case 'b':	/* branch command */
	case 't':	/* branch-on-succeed command */
	case 'T':	/* branch-on-fail command */
		SKIPWS(cp);
		if (*cp == '\0' || *cp == ';'){ /* if branch is to start of cmds... */
			/* add current command to end of label last */
			if (sp1 = lablst->last) {
				while (sp2 = sp1->u.link)
					sp1 = sp2;
				sp1->u.link = cmdp;
			}else	/* lablst->last == NULL */
				lablst->last = cmdp;
			break;
		}
		fp=gettext(lab->name=(char *)fp);/* else get label into pool */
#if DISENDSP
		disendsp(lab->name);
#endif
		if (lpt = search(lab)){		/* enter branch to it */
			if (lpt->address)
				cmdp->u.link = lpt->address;
			else{
				sp1 = lpt->last;
				while(sp2 = sp1->u.link)
					sp1 = sp2;
				sp1->u.link = cmdp;
			}
		}else{		/* matching named label not found */
			lab->last = cmdp;	/* add the new label */
			lab->address = NULL;	/* it's forward of here */
			if (++lab >= labels + MAXLABS)	/* overflow if last */
				ABORT(TMLAB);
		}
		break;

	case 'a':	/* append text */
	case 'i':	/* insert text */
	case 'r':	/* read file into stream */
		if (cmdp->addr2) ABORT(AD2NG);
	case 'c':	/* change text */
		if ((*cp == '\\') && (*(cp+1) == '\n')) cp += 2;
		fp = gettext(cmdp->u.lhs = fp);
		break;

	case 'D':	/* delete current line in hold space */
		cmdp->u.link = cmds;
		break;

	case 's':	/* substitute regular expression */
		redelim = *cp++;		/* get delimiter from 1st ch */
		if ((fp = recomp(cmdp->u.lhs = fp, redelim)) == BAD)
			ABORT(CGMSG);
		if (fp == cmdp->u.lhs)		/* if compiled RE zero len */
			cmdp->u.lhs = lastre;	/* use the previous one */
		else				/* otherwise */
			lastre = cmdp->u.lhs;	/*   save the one just found */

		if ((cmdp->rhs = fp) > poolend) ABORT(TMTXT);
		if ((fp = rhscomp(cmdp->rhs, redelim)) == BAD) ABORT(CGMSG);
						/* if compiled rhs is only % */
		if (*cmdp->rhs == (khar)'%' && *(cmdp->rhs + 1) == NULL){
			if (lastrhs)		/* use previous one */
				cmdp->rhs = lastrhs;
			else
				ABORT(NOLRH);
		} else
			lastrhs = cmdp->rhs;	/* save the just found */

		cmdp->flags.global = (unsigned char)gflag; /* global option */
		while (*cp == 'g' || *cp == 'p' || *cp == 'P'
				  || (*cp >= '0' && *cp <= '9')){
			IFEQ(cp, 'g') cmdp->flags.global = GLOBAL;
			IFEQ(cp, 'p') cmdp->flags.print = 1;
			IFEQ(cp, 'P') cmdp->flags.print = 2;
			if (*cp >= '0' && *cp <= '9') {	/* get match times */
				i = 0;
				while (*cp >= '0' && *cp <= '9'){
					i = i * 10 + *cp++ - '0';
					if ( i > 255 )	ABORT(CGMSG);
				}
								/* times */
				if (i)  cmdp->flags.global = (unsigned char)i;
			}
		}

	case 'l':	/* list pattern space */
		if (*cp == 'w')
			cp++;		/* and execute a w command! */
		else
			break;		/* s or l is done */

	case 'w':	/* write-pattern-space command */
	case 'W':	/* write-first-line command */
		if (nwfiles >= WFILES) ABORT(TMWFI);
		fp=gettext(fname[nwfiles]=(char *)fp);
		for(i = nwfiles-1; i >= 0; i--) /* match it in table */
			if (strcmp(fname[nwfiles], fname[i]) == 0){
				cmdp->fout = fout[i];
				return(0);
			}
		/* if didn't find one, open new out file */
		if ((cmdp->fout = fopen(fname[nwfiles], wmode)) == NULL){
			fprintf(stderr, CCOFI, fname[nwfiles]);
			exit(2);
		}
		fout[nwfiles++] = cmdp->fout;
		break;

	case 'y':	/* transliterate text */
		fp = ycomp(cmdp->u.lhs = fp, *cp++);	/* compile translit */
		if (fp == BAD) ABORT(CGMSG);		/* fail on bad form */
		if (fp > poolend) ABORT(TMTXT);		/* fail on overflow */
		break;
	}
	return(0);	/* succeeded in interpreting one command */
}

khar *
rhscomp(rhsp, delim)	/* uses bcount */
/* generate replacement string for substitute command right hand side */
register khar	*rhsp;		/* place to compile expression to */
register khar	delim;		/* regular-expression end-mark to look for */
{
	register khar	*p = cp;		/* strictly for speed */

	for(;;)
		if (rhsp >= poolend)		/* fail on overflow */
			ABORT(TMTXT);
		else if ((*rhsp = *p++) == '\\'){/* copy; if it's a \, */
			*rhsp = *p++;		/* copy escaped khar */
			/* check validity of pattern tag */
			if (*rhsp > bcount + '0' && *rhsp <= '9')
				return(BAD);
			*rhsp++ |= 0x0100;	/* mark the good ones */
			continue;
		}else if (*rhsp == delim){	/* found RE end, hooray... */
			*rhsp++ = '\0';		/* cap the expression string */
			cp = p;
			return(rhsp);		/* pt at 1 past the RE */
		}else if (*rhsp++ == '\0')	/* last ch not RE end, help! */
			return(BAD);
}

static khar *recomp(expbuf, redelim)	/* uses cp, bcount */
/* compile a regular expression to internal form */
khar	*expbuf;			/* place to compile it to */
khar	redelim;			/* RE end-marker to look for */
{
	register khar	*ep = expbuf;	/* current-compiled-khar pointer */
	register khar	*sp = cp;	/* source-kharacter ptr */
	register khar	c;		/* current-kharacter pointer */
	khar		*lastep;	/* ptr to last expr compiled */
	khar		*svclass;	/* start of current khar class */
	khar		brnest[MAXTAGS];	/* bracket-nesting array */
	khar		*brnestp;	/* ptr to current bracket-nest */
	khar		*pp;		/* scratch pointer */
	int		tags;		/* # of closed tags */

	if (*cp == redelim)		/* if first khar is RE endmarker */
		return(cp++, expbuf);	/* leave existing RE unchanged */

	lastep = NULL;			/* there's no previous RE */
	brnestp = brnest;		/* initialize ptr to brnest array */
	tags = bcount = 0;		/* initialize counters */

	if (*ep++ = (*sp == '^'))	/* check for start-of-line syntax */
		sp++;

	for (;;){
		if (ep >= expbuf + RELIMIT)	/* match is too large */
				ABORT(REITL);
		if ((c = *sp++) == redelim){	/* found the end of the RE */
			cp = sp;
			if (brnestp != brnest)	/* \(, \) unbalanced */
				return(BAD);
			*ep++ = CEOF;		/* write end-of-pattern mark */
			return(ep);		/* return ptr to compiled RE */
		}
		if ((c != '*') && (c != '+'))	/* if we're a postfix op */
			lastep = ep;		/*   get ready to match last */

		switch (c){
		case '\\':
			if ((c = *sp++) == '('){ /* start tagged section */
				if (bcount >= MAXTAGS)
					return(cp = sp, BAD);
				*brnestp++ = bcount;	/* update tag stack */
				*ep++ = CBRA;		/* enter tag-start */
				*ep++ = bcount++;	/* bump tag count */
				continue;
			}else if (c == ')'){	/* end tagged section */
				if (brnestp <= brnest)	/* extra \) */
					return(cp = sp, BAD);
				*ep++ = CKET;		/* enter end-of-tag */
				*ep++ = *--brnestp;	/* pop tag stack */
				tags++;			/* count closed tags */
				continue;
			}else if (c >= '1' && c <= '9'){ /* tag use */
				if ((c -= '1') >= tags) /* too few */
					return(BAD);
				*ep++ = CBACK;		/* enter tag mark */
				*ep++ = c;		/* and the number */
				continue;
			}
			goto defkhar;		/* else match \c */

		case '\0':	/* ignore nuls */
			continue;

		case '\n':	/* trailing pattern delimiter is missing */
			return(cp = sp, BAD);

		case '.':	/* match any khar except newline */
			*ep++ = CDOT;
			continue;

		case '+':	/* 1 to n repeats of previous pattern */
			if (lastep == NULL)	/* if + not first on line */
				goto defkhar;	/*   match a literal + */
			if (*lastep == CKET)	/* can't iterate a tag */
				return(cp = sp, BAD);
			pp = ep;		/* else save old ep */
			while (lastep < pp)	/* so we can blt the pattern */
				*ep++ = *lastep++;
			*lastep |= STAR;	/* flag the copy */
			continue;

		case '*':	/* 0..n repeats of previous pattern */
			if (lastep == NULL)	/* if * isn't first on line */
				goto defkhar;	/*   match a literal * */
			if (*lastep == CKET)	/* can't iterate a tag */
				return(cp = sp, BAD);
			*lastep |= STAR;	/* flag previous pattern */
			continue;

		case '$':	/* match only end-of-line */
			if (*sp != redelim)	/* if we're not at end of RE */
				goto defkhar;	/*   match a literal $ */
			*ep++ = CDOL;		/* insert end-symbol mark */
			continue;

		case '[':	/* begin kharacter set pattern */
			*ep++ = CKLIST;
			if (((c = *sp++) == '^')){
				*ep++ = CKNEG;
				c = *sp++;
			}
			svclass = sp;		/* save ptr to class start */
			do {
				if (c == '\0') ABORT(CGMSG);

				/* handle kharacter ranges */
				if (c == '-' && sp > svclass && *sp != ']'){
					ep[-2] = CKRANGE;
					c = *sp++;
				} else
					*ep++ = CKHAR;

				/* handle escape sequences in sets */
				if (c == '\\')
					c = *sp++;

				*ep++ = c;
			} while((c = *sp++) != ']');
			*ep++ = CKEND;
			continue;

		defkhar:	/* match literal kharacter */
		default:	/* which is what we'd do by default */
			*ep++ = CCHR;		/* insert kharacter mark */
			*ep++ = c;
		}
	}
}

static int
cmdline(cbuf)		/* uses eflag, eargc, cmdf */
/* read next command from -e argument or command file */
register khar	*cbuf;
{
	register int	inc;	/* not khar because must hold EOF */

	cbuf--;			/* so pre-increment points us at cbuf */

	/* e command flag is on */
	if (eflag){
		char	*p;	/* ptr to current -e argument */
		static char *savep; /* saves previous value of p */

		if (eflag > 0){	/* there are pending -e arguments */
			eflag = -1;
			if (--eargc <= 0)
				usage();	/* if no arguments, barf */

			/* else transcribe next e argument into cbuf */
			p = *++eargv;
			while(*++cbuf = takek(&p) )
				if (*cbuf == '\\'){
					if ((*++cbuf = takek(&p)) == '\0')
						return(savep = NULL, -1);
					else
						continue;
				}else if (*cbuf=='\n'){ /* end of 1 cmd line */
					*cbuf = '\0';
					return(savep = p, 1);
					/* we'll be back for the rest... */
				}

			/* found end-of-string; can advance to next argument */
			return(savep = NULL, 1);
		}

		if ((p = savep) == NULL)
			return(-1);

		while(*++cbuf = takek(&p))
			if (*cbuf == '\\'){
				if ((*++cbuf = takek(&p)) == '\0')
					return(savep = NULL, -1);
				else
					continue;
			}else if (*cbuf == '\n'){
				*cbuf = '\0';
				return(savep = p, 1);
			}
		return(savep = NULL, 1);
	}

	/* if no -e flag read from command file descriptor */

	if ((inc = getk(cmdf)) == KEOF)
		return (*++cbuf = '\0' , -1 );
	do{
		if ((*++cbuf = inc) == '\\') {		/* if it's escape */
			*++cbuf = inc = getk(cmdf);	/* get next khar */
			if (*cbuf == '\n')		/* escaped newline */
				line_no++;
		}
		else if (*cbuf == '\n') {		/* end on newline */
			line_no++;
			return(*cbuf = '\0', 1);	/* cap the string */
		}
	}while((inc = getk(cmdf)) != KEOF);		/* get next khar */
	return(*++cbuf = '\0', 1);
/*return(*++cbuf = '\0', -1);*/ /* end-of-file, no more khars */
}

khar *
address(expbuf)		/* uses cp, linenum */
/* expand an address at *cp... into expbuf, return ptr at following khar */
register khar	*expbuf;
{
	static int      numl = 0;       /* current ind in addr-number table */
	register khar	*rcp;		/* temp compile ptr for forwd look */
	long		lno;		/* computed value of numeric address */

	if (*cp == '$'){		/* end-of-source address */
		*expbuf++ = CEND;	/* write symbolic end address */
		*expbuf++ = CEOF;	/* and the end-of-address mark (!) */
		cp++;			/* go to next source kharacter */
		return(expbuf);		/* we're done */
	}
	if (*cp == '/')			/* start of regular-expression match */
		return(recomp(expbuf, *cp++));	/* compile the RE */

	rcp = cp; lno = 0;		/* now handle a numeric address */
	while (*rcp >= '0' && *rcp <= '9')	/* collect digits */
		lno = lno*10 + *rcp++ - '0';	/*  compute their value */

	if (rcp > cp){			/* if we caught a number... */
		*expbuf++ = CLNUM;	/* put a numeric-address marker */
		*expbuf++ = numl;	/* and the address table index */
		linenum[numl++] = lno;	/* and set the table entry */
		if (numl >= MAXLINES)	/* oh-oh, address table overflow */
			ABORT(TMLNR);	/*   abort with error message */
		*expbuf++ = CEOF;	/* write the end-of-address marker */
		cp = rcp;		/* point compile past the address */
		return(expbuf);		/* we're done */
	}
	return(NULL);		/* no legal address was found */
}

khar *
gettext(txp)				/* uses global cp */
/* accept multiline input from *cp..., discarding leading whitespace */
register char	*txp;			/* where to put the text */
{
	khar		ch;
	register khar	*p = cp;		/* this is for speed */

	SKIPWS(p);				/* discard whitespace */
	do{
		if ((ch = *p++)=='\\'){		/* escape */
			ch = *p++;
			if (ch == ';'){		/* ";" character. */ 
				*txp = (char)ch;
				continue;
			}
		}
		if (iskanji(ch)){
			*txp++ = (char)(ch>>8); /* upper byte	*/
			*txp = (char)(ch&0xFF); /* get lower byte */
		}else{
			*txp = (char)(ch&0xFF); /* only lower byte */
		}
		if (*txp == '\0')		/* we're at end of input */
			break;
		else if (*txp == '\n')		/* also SKIPWS after newline */
			SKIPWS(p);
		else if (*txp == ';'){		/* multi statement */
			*txp = '\0';
			break;
		}
	}while (txp++);		/* keep going till we find that nul */

#if	0
	return(cp = --p, (khar *)++txp);
#else	// WCE:alignment������̈�.

	cp = --p;
	txp++;
	if( ((int)txp) & 1 ) txp++;	//�|�C���^����ɋ����ɂ���.

	return (khar *)txp;

#endif
}

label *
search(ptr)			/* uses global lablst */
/* find the label matching *ptr, return NULL if none */
register label	*ptr;
{
	register label	*rp;
	for (rp = lablst; rp < ptr; rp++) {
		if (rp->name != NULL) {			// WCE:�k���|�C���^�Q�Ƒ΍�. WCE�̏ꍇ0�Ԓn�ɃA�N�Z�X����Ǝ���.
		 if (strcmp(rp->name, ptr->name) == 0) {
			return(rp);
		 }
		}
	}
	return(NULL);
}

void
resolve()				/* uses global lablst */
/* write label links into the compiled-command space */
{
	register label		*lptr;
	register sedcmd		*rptr, *trptr;

	/* loop through the label table */
	for(lptr = lablst; lptr < lab; lptr++){
		if (lptr->address == NULL){	/* barf if not defined */
			fprintf(stderr, ULABL, lptr->name);
			exit(2);
		}else if (lptr->last){		/* if last is non-null */
			rptr = lptr->last;		/* chase it */
			while(trptr = rptr->u.link){	/* resolve refs */
				rptr->u.link = lptr->address;
				rptr = trptr;
			}
			rptr->u.link = lptr->address;
		}
	}
}

khar *
ycomp(ep, delim)		/* compile a y (transliterate) command */
register khar	*ep;		/* where to compile to */
khar		delim;		/* end delimiter to look for */
{
	register khar	*tp, *sp;

	/* scan the 'from' section for invalid khars */
	for(sp = tp = cp; *tp != delim; tp++){
		if (*tp == '\\')
			tp++;
		if ((*tp == '\n') || (*tp == '\0'))
			return(BAD);
	}
	tp++;	/* tp now points at first khar of 'to' section */

	/* now rescan the 'from' section */

	while((*ep = *sp++) != delim){

		if ((*tp == delim) || ( *tp == '\0')){
			return(BAD);
		}
		if (*ep == '\\')
			*ep = *sp++;
		ep++;
		if ((*ep = *tp++) == '\\')
			*ep = *tp++;
		ep++;
	}
	*ep++ = CYEND;		/* End mark */
	if (*tp != delim)	/* 'to', 'from' parts have unequal lengths */
		return(BAD);
	cp = ++tp;		/* point compile ptr past translit */
	return(ep);		/* return first free location past table end */
}

/*	EXtended ESCape character	*/
/*			by LOGOS	*/
/*	mode x:heX & S-jis kanji  j:Jis kanji code   k:Kuten kanji code */
int exesc( cbuf )
khar *cbuf;
{
register khar c, d;
int i;
khar *buf;
khar digit, inc;

	buf = --cbuf;
	while ((c = *++buf = *++cbuf) != '\0') {
		if ( c == '\\' ) {
			switch((c = *++cbuf)) {
			case 'e': inc = '\x1B'; break;	/* escape */
			case 'a': inc = '\a'; break;	/* bell */
			case 'b': inc = '\b'; break;	/* backspace */
			case 'c': inc = '\f'; break;	/* formfeed */
			case 'n': inc = '\n'; break;	/* newline */
			case 'r': inc = '\r'; break;	/* return */
			case 't': inc = '\t'; break;	/* hor. tab */
			case 'v': inc = '\v'; break;	/* ver. tab */
			case 'x':		/* hex and Shift JIS */
			case 'j':		/* JIS */
				for(i = 0, inc = 0; i < 4; ++i) {
					if ((d = *++cbuf) == '\0')
						return( *++buf = '\0', -1 );
					if (d >= '0' && d <= '9')
						digit = d - '0';
					else if (d >= 'a' && d <= 'f')
						digit = d - 'a' + 10;
					else if (d >= 'A' && d <= 'F')
						digit = d - 'A' + 10;
					else {
						--cbuf;
						break;
					}
					inc = inc * 16 + digit;
				}
				if (c == 'j')
						/* JIS -> S-JIS */
					inc = jis2sjis(inc);
				break;
			case 'k':		/* ��_ */
				for(i = 0, inc = 0; i < 5; ++i) {
					if ((d = *++cbuf) == '\0')
						return( *++buf = '\0', -1 );
					if (d >= '0' && d <= '9')
						digit = d - '0';
					else {
						--cbuf;
						break;
					}
					inc = inc * 10 + digit;
				}
						/* ��_ -> JIS -> S-JIS */
				inc = jis2sjis( ktn2jis(inc) );
				break;
			default:
				inc = c;
			}
			if ( inc >> 8 )
				--buf;		/* no escape in kanji char */
			*++buf = inc;
		}
	}
	return( 1 );
}

#if DISENDSP

char *disendsp(txp)
/* discarding ending whitespace */
register char	*txp;				/* where to put the text */
{
	register char	*p = txp;
	register char	*ch = txp;

	for ( ; *p != NULL; p++ ) {
		if ( *p == '#' )
			break;
		else if ( *p != ' ' && *p != '\t' )
			ch = p;
	}
	if ( ch != p )
		*++ch = NULL;
	return txp;
}

#endif

#if BREAK

#include <dos.h>

/* user interrupt routine */
void
catchsig( sig )
int sig;
{
/*	fprintf( stderr, "\aUser interrupt!\n" );	*/
	exit(1);
}

/* check ^C key in buffer */
void
test_signal( void )
{
	union REGS reg;
static int thin = 0;

	if ((thin++ & 0xFF) == 0) {
		reg.h.ah = 0x0B;
		intdos(&reg, &reg);
	}
}
#endif
