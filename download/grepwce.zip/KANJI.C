/*
**             Kanji char I/O for sed
**               written by serow
**
*/
/*
char id_kanji[] = "$Header: rcs/kanji.c 1.4 88/03/02 06:10:43 serow Exp $";
*/
#define __NO_STDIO_INLINE__
#include  <stdio.h>
#include  "kanji.h"
#include  "sed.h"

static khar ungetbuf = 0;

void
ungetk(c)
khar c;
{
     ungetbuf = c;
}

khar
fgetk(streem)
FILE *streem;
{
static khar lastc = 0;
     register khar  c,c2;

     if (c = ungetbuf) {
          ungetbuf = 0;
          return c; 
     } else {
          if (!(c = lastc))
               c = dosgetc(streem);
          lastc = 0;
     }
     if ((signed short)c == EOF) return c;
     c &= 0xFF;
     if (is1kanji(c)) {
          if ((signed short)(c2 = dosgetc(streem)) == EOF) {
               lastc = c2;
               return c;
          }
          if (is2kanji(c2)) {
               return (c<<8) + c2;
          } else {
               lastc = c2;
               return c;
          }
     }
     return c;
}

fputk(c,streem)
register khar c;
FILE * streem;
{
     if (!((0 <= c)&&(c <= 255))) {
          putc((c>>8)&0xFF,streem);
     }
     return putc((int)c,streem);
}


khar
takek( cp )
register char ** cp;
{
     khar kc;

     if (is1kanji((*cp)[0]) && is2kanji((*cp)[1])) {
          kc = ((int)(*cp)[0]<<8)+(*cp)[1];
          (*cp)++;(*cp)++;
     } else {
          kc = (*cp)[0];
          (*cp)++;
     }
     return kc;
}

kstrlen( cp )
register khar * cp;
{
     register int   count = 0;

     while (*cp++) count++;
     return count;
}

khar *
fgetks(s, n, streem)
register khar * s;
int n;
register FILE * streem;
{
     khar *    s1 = s;
     int  c;

     if (n) n--;
     while (n-- && (c = getk(streem)) != KEOF && (*s++ = c) != '\n')
          ;
     *s = 0;
     if (s == s1)
          return((khar *)NULL);
     return(s1);
}

khar *
getks(s)
register khar * s;
{
     int l;

     if ((s = fgetks(s, MAXBUF, stdin)) == (khar *)NULL)
          return((khar *)NULL);

     if (s[l = kstrlen(s) - 1] == '\n')
          s[l] = 0;
     return(s);
}

void
fputks(s, streem)
register khar * s;
FILE *    streem;
{
     while (*s)
          putk(*s++, streem);
}

putks(s)
khar *         s;
{
     fputks(s, stdout);
     return putchar('\n');
}

unsigned char *
jrindex(p,c)
unsigned char *p;
unsigned char c;
{
	unsigned char *oldp;

	for (oldp = (unsigned char *)0; *p; p++) {
		if (is1kanji(*p) && is2kanji(p[1])) {
			p++;
		} else if (*p == c) {
			oldp = p;
		}
	}
	return oldp;
}


/*
*            ASCII MS-DOS PROGRAMMING TECHNIQUE
*/

khar
jis2sjis( c )
khar c;
{
int hi, lo;

	hi = ( c >> 8 ) & 0xff;
	lo = c & 0xff;
	if( hi & 1 )
		lo += 0x1f;
	else
		lo += 0x7d;
	if( lo >= 0x7f )
		lo++;
	hi = ( hi - 0x21 >> 1 ) + 0x81;
	if ( hi > 0x9f )
		hi += 0x40;
	return ( hi << 8 | lo );
}


/*
*            written by LOGOS	1989/03/03
*/

khar
ktn2jis( c )
khar c;
{
	return ((c/100 + 0x20)<<8) + c%100 + 0x20;
}


// WinCE
char wildargs = 2;
