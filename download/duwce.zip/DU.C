/**********************************************************************
 *		du���ǂ�
 **********************************************************************
 */
#include <stdio.h>
#include <malloc.h>
#include <stat.h>
#include <conslib.h>

static char USAGE[]=
"Usage:\n"
"%% du [-Option] [ dirname ]\n"
"Option:\n"
"   -l   long format\n"
"   -r   calculate filesize recursively\n"
"	-R   Recursively listing\n"
"   -d   hide normal files ( listing ONLY directories )\n"
"\n"
;

#define	SHOW	1
#define	NOSHOW	0


#define	ScreenWidthMAX	128
#define	ScreenHeightMAX	 32
#define Getopt(argc,argv)  \
 {int i;for(i=0;i<128;i++) opt[i]=NULL; \
   while( ( argc>1 )&&( *argv[1]=='-') ) \
    { opt[ argv[1][1] & 0x7f ] = &argv[1][2] ; argc--;argv++; } \
 }

#define IsOpt(c) ((opt[ c & 0x7f ])!=NULL)
#define   Opt(c)   opt[ c & 0x7f ]

int sjis2TCHAR( const BYTE *src, LPTSTR dst, DWORD max );

/**********************************************************************
 *	���[�J���ȃ��[�N�G���A.
 **********************************************************************
 */
static int	ScreenWidth =80;
static int	ScreenHeight=12;
static char *opt[128];
static char recurse=0;
/**********************************************************************
 *	�g�p�@.
 **********************************************************************
 */
static void Usage(void)
{
	fprintf(stderr,USAGE);
	exit(1);
}

/**********************************************************************
 *	����.
 **********************************************************************
 */


static DWORD unicode2sjis( LPCTSTR src, BYTE *dst, DWORD max )
{
	return WideCharToMultiByte( CP_ACP, 0, src, -1, dst, dst ? max : 0, NULL, NULL ) ;
}

static char *u2a(LPCTSTR src)
{
	static char u2abuf[256];
	unicode2sjis( src,u2abuf,255 );
	return u2abuf;
}

void add_comma(char *t,char *s,int n)
{
	int l = strlen(s);	//����.
	int i;
	int digit=0;
	char *p;
	p=t+n;
	*p=0;
	
	for(i=l-1;i>=0;i--,digit++) {
		if( (digit!=0) && (digit % 3)==0 ) {
			*(--p) = ',';
		}
		*(--p) = s[i];
	}
	while(p>t) {
		*(--p) = ' ';
	}
}

void totalPrint(int sp)
{
	char  fsizef0[16];
	char  fsizef1[16];
	sprintf(fsizef0,"%d",sp);	//�P�O�i��Print.

	add_comma(fsizef1,fsizef0,10+4);	//�R���ÂJ���}��؂�.
	if(IsOpt('l')) {
		printf("                         ");
	}
	printf("%s bytes.\n",fsizef1+2);
}

void dirPrint(WIN32_FIND_DATA *fd,int sp)
{
	char  fname[256];	// ASCII�����ł̃t�@�C����.
	char  fsizef0[16];
	char  fsizef1[16];
	char  fatr[8];
	char  timestamps[32];
	char  *fdir;
	SYSTEMTIME systime;
	FILETIME   localft;

	//�t�@�C����     ===> fname[]
	unicode2sjis(fd->cFileName , fname , 255 );

	//�t�@�C���T�C�Y ===> fsizef1[]
	sprintf(fsizef0,"%d",sp);	//�P�O�i��Print.
	add_comma(fsizef1,fsizef0,10+4);	//�R���ÂJ���}��؂�.
	
	//�t�@�C������   ===> fatr[]
	strcpy(fatr,"----");
	if( fd->dwFileAttributes & FILE_ATTRIBUTE_ARCHIVE   ) fatr[0]='A';
	if( fd->dwFileAttributes & FILE_ATTRIBUTE_SYSTEM    ) fatr[1]='S';
	if( fd->dwFileAttributes & FILE_ATTRIBUTE_HIDDEN    ) fatr[2]='H';
	if( fd->dwFileAttributes & FILE_ATTRIBUTE_READONLY  ) fatr[3]='R';
	
	//�f�B���N�g��   ===> fdir[]
	if( fd->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ) {
		fdir="<dir>";
	}else{
		fdir="     ";
	}
	//���t           ===> timestamps[]
	FileTimeToLocalFileTime(&fd->ftLastWriteTime,&localft);	//�^�C���X�^���v�����[�J�����ɒ���.
	FileTimeToSystemTime(&localft,&systime);				//�����yy,mm,dd�̒l�ɕϊ�����.
	sprintf(timestamps,"%02d-%02d-%02d %02d:%02d",			//�󎚂���.
		systime.wYear % 100,
		systime.wMonth	,
		systime.wDay	,
		systime.wHour	,
		systime.wMinute
	);
	if(IsOpt('l')) {
		printf("%s %s %s%s %s\n",timestamps,fatr,fdir,fsizef1+2,fname);
	}else{
		printf(		   "%s %s\n",fsizef1+2,fname);
	}
}

unsigned int dirSpace( int showmode, LPTSTR s )
{
	HANDLE	ffh;
	WIN32_FIND_DATA	fd;
	BOOL rc;
	ULONG sp = 0, tsp = 0;
//	TCHAR	MessageBuf[ 256 ] ;
	TCHAR path_buffer[_MAX_PATH];

	ffh = FindFirstFile( s, &fd );

	if ( ffh != INVALID_HANDLE_VALUE )
	{
		rc = TRUE;
		while ( rc )
		{
			if ( fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY )
			{
				if( recurse ) {
					wcscpy(path_buffer, s);
					UpDir(path_buffer);
					if(	wcscmp(path_buffer,TEXT("\\"))!=0) {	// root�̓p�X�������O.
						wcscat(path_buffer,TEXT("\\"));
					}
					wcscat(path_buffer, fd.cFileName);
					wcscat(path_buffer, TEXT("\\*"));

					if(IsOpt('R')){
						printf("Directory %s\n",u2a(path_buffer));
						sp = dirSpace( SHOW, path_buffer );
					}else{
						sp = dirSpace( NOSHOW, path_buffer );
					}
				}else{
					sp = 0;
				}
			}
			else 
				sp = fd.nFileSizeLow;
			
			if ( showmode == SHOW )
			{
				if(IsOpt('d')) {
					if( fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ) {
						dirPrint(&fd,sp);
					}
				}else{
					dirPrint(&fd,sp);
				}
			}
			tsp += sp;

			rc = FindNextFile( ffh, &fd );
		}
	}
	return tsp;
}

int is_absdir(char *s)
{
	return (*s=='\\') || (*s=='/');
}

/**********************************************************************
 *		du �̃��C�����[�`��.
 **********************************************************************
 */
int du(int argc,char **argv)
{
	long	sp = 0;
	TCHAR	MessageBuf[ 256 ] ;
	TCHAR	Tdir[ 256 ] ;
//	LPTSTR	arg;
	DWORD	rc;

	rc = GetCurDir( 256, Tdir );

	// MessageBuf[] �ɁA�t��PATH�̃f�B���N�g���p�^�[��������.
	if ( argc >= 2 ) {
		if( is_absdir(argv[1]) ) {
			sjis2TCHAR( argv[1] , MessageBuf ,255 );
		}else{
			// relative directory.
			sjis2TCHAR( argv[1] , Tdir ,255 );
			rel2absdir( MessageBuf, 255, Tdir ) ;
		}
	}else{
		sjis2TCHAR( "*" , Tdir ,255 );
		rel2absdir( MessageBuf, 255, Tdir ) ;
	}

	sp = dirSpace( SHOW, MessageBuf );

	totalPrint(sp);

	return 0 ;
}

/**********************************************************************
 *		������.
 **********************************************************************
 */
int main(int argc,char **argv)
{

	GetWH( &ScreenWidth, &ScreenHeight);
	if(ScreenWidth >= ScreenWidthMAX) ScreenWidth = ScreenWidthMAX;
	if(ScreenHeight>= ScreenHeightMAX)ScreenHeight= ScreenHeightMAX;

	Getopt(argc,argv);

	if( IsOpt('r')||IsOpt('R')||IsOpt('d') ) recurse = 1;

	du(argc,argv);			  
	
	return 0;
}
/**********************************************************************
 *		
 **********************************************************************
 */
