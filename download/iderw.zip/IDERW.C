#include "easy.h"
#include <dos.h>
#include <bios.h>


int	drv=0x80,trk,head,sect;
void usage(void)
{
	chkinst(drv,1);
	printf(
	"***** �g�� �h�m�s�P�R�g �ǂݏ����c�[�� Ver 0.01 *****\n"
	"> iderw  [-i] [-write] drv,cyl,head,sect  sects  file\n"
	"   drv�� Master�� 80 , Slave�� 81 ...(16�i)\n"
	"   cyl,head,sect  sects ��10�i�� sect�̂�1�`63 ���ʗ�\n"
	"��:\n"
	"  iderw 80,0,0,1 64 cboot.bin    �h���C�uC:��cyl0 head0 sct1����64����ǂ�\n"
	"  iderw 80,0,1,2 64 cfat.bin     �h���C�uC:��cyl0 head1 sct2����64����ǂ�\n"
	"  -i    �͑Θb���[�h\n"
	"  -write�͏����݁F�T�d�ɁI\n"
	);
	exit(1);
}

#define	UP		0x0101
#define	DOWN	0x0102
#define	LEFT	0x0103
#define	RIGHT	0x0104
#define	PGUP	0x0105
#define	PGDOWN	0x0106
#define	HOME	0x0107
#define	END		0x0108

#define	F5		0x0205
#define	F6		0x0206
#define	F11		0x020b
#define	F12		0x020c


static	int ibmpc_biosdisk(int cmd,int drv,int head,int trk,int sect,int ss,char *dskbuf);
int dskbuf[0x4000];
long sects=0;
int	ss;
int cmd;
int r;

char filename[128];
int	 key;
int  dump_off=0;

typedef struct {
	short size;
	short flags;
	long  Cyls;
	long  Heads;
	long  Sects;
	long  TTLSects;
	short BytesPerSect;
	char  rsv[32];
} DRIVE_PARAM;

DRIVE_PARAM param;

#define	NumHeads	param.Heads
#define	SPT			param.Sects

static	int ibmpc_biosdisk_dummy(int cmd,int drv,int head,int trk,int sect,int ss,char *dskbuf)
{
	printf("cmd=%x,drv=%x,head=%d,trk=%d,sect=%d,sects=%d,dskbuf=%x\n"
		,cmd,drv,head,trk,sect,ss,dskbuf);
	return 0;
}

static	int	chkinst(int drv,int vflag)
{
	int bx,ax,cx,dx;

	_DL=drv;	_BX=0x55aa;	_AH=0x41;
	__int__(0x13);
	ax = _AX;	bx = _BX;	cx = _CX;	dx = _DX;

	if(bx != 0xaa55) {
		printf("IBM/MS INT 13 Extensions NOT INSTALLED\n");
		exit(1);
	}
	
	param.size = 0x1a;
	_DL=drv;	_SI=&param;	_AH=0x48;
	__int__(0x13);
	ax = _AX;	bx = _BX;	cx = _CX;	dx = _DX;
	

	if(vflag) {
		printf("\n ****** IBM/MS INT 13 Extensions ******\n");
		printf(" Version   =%02x\n",ax>>8);
		printf(" SupportMap=%04x\n",cx);
		printf(" Extension Version=%02x\n",dx>>8);

		printf("\n ****** Drive(%x) Params ******\n",drv);
		printf(" Cylinders   =%ld(%lx)\n",param.Cyls ,param.Cyls );
		printf(" Heads       =%ld(%lx)\n",param.Heads,param.Heads);
		printf(" SectorPerTrk=%ld(%lx)\n",param.Sects,param.Sects);
		printf(" Total Sector=%ld(%lx)\n",param.TTLSects,param.TTLSects);
		printf(" BytesPerSect=%d(%x)\n",param.BytesPerSect,param.BytesPerSect);


	}
}

/********************************************
 *
 *	IBM/MS INT 13 Extensions - EXTENDED READ
 *
 *	AH = 42h
 *	DL = drive number
 *	DS:SI -> disk address packet (see #00272)
 *
 *	Return:
 *	CF clear if successful
 *	AH = 00h
 *	CF set on error
 *	AH = error code (see #00234)
 *	disk address packet's block count field set to number of blocks
 *	successfully transferred
 *
 *	See Also: AH=02h - AH=41h"INT 13 Ext" - AH=43h"INT 13 Ext" 
 *
 *
 *	Format of disk address packet:
 *
 *	Offset  Size    Description     (Table 00272)
 *	00h    BYTE    size of packet (10h or 18h)
 *	01h    BYTE    reserved (0)
 *	02h    WORD    number of blocks to transfer (max 007Fh for Phoenix EDD)
 *	04h    DWORD   -> transfer buffer
 *	08h    QWORD   starting absolute block number
 *	(for non-LBA devices, compute as
 *	(Cylinder*NumHeads + SelectedHead) * SectorPerTrack +
 *	SelectedSector - 1
 *	10h    QWORD   (EDD-3.0, optional) 64-bit flat address of transfer buffer;
 *	used if DWORD at 04h is FFFFh:FFFFh
 *
 ********************************************/

typedef struct {
	char  packet_size;
	char  filler;
	short blocks;
	short buf_off;
	short buf_seg;
	long  lba_low;
	long  lba_high;
} DISK_PACKET;

DISK_PACKET packet;

static	int ibmpc_biosdisk(int cmd,int drv,int head,int trk,int sect,int ss,char *dskbuf)
{
	int bx,ax,cx,dx,ah;
	long lba;
	lba = (long)trk * NumHeads + (long) head;
	lba = lba * SPT + (long) sect - 1L;

	packet.packet_size = 16;
	packet.filler = 0;
	packet.blocks = ss;
	packet.buf_off = FP_OFF(dskbuf);
	packet.buf_seg = FP_SEG(dskbuf);
	packet.lba_low = lba;
	packet.lba_high = 0;
	
	_SI=&packet;
	_DL=drv;
	_AX=0x4200;
	__int__(0x13);
	ax = _AX;
	bx = _BX;
	cx = _CX;
	dx = _DX;
	ah = ax >> 8;
	return ah;
}

static	int ibmpc_bioswrite(int cmd,int drv,int head,int trk,int sect,int ss,char *dskbuf)
{
	int bx,ax,cx,dx,ah;
	long lba;
	lba = (long)trk * NumHeads + (long) head;
	lba = lba * SPT + (long) sect - 1L;

	packet.packet_size = 16;
	packet.filler = 0;
	packet.blocks = ss;
	packet.buf_off = FP_OFF(dskbuf);
	packet.buf_seg = FP_SEG(dskbuf);
	packet.lba_low = lba;
	packet.lba_high = 0;
	
	_SI=&packet;
	_DL=drv;
	_AX=0x4300;
	__int__(0x13);
	ax = _AX;
	bx = _BX;
	cx = _CX;
	dx = _DX;
	ah = ax >> 8;
	return ah;
}

void print_hdr(void)
{
	printf("%02x Cyl%5d Hd%3d Sct%2d\n",drv,trk,head,sect);
}

void dump_buf(unsigned char *s)
{
	int i,j,c;

		printf("\x1b[1;1H");
		printf("    : ");
		for(i=0;i<16;i++) {
			printf("+%x ",i);
			if(i==7) printf(" ");
		}
		print_hdr();

	s += (dump_off * 16);

	for(j=0;j<22;j++) {
		
		printf("%04x: ",(j+dump_off) *16);
		for(i=0;i<16;i++) {
			printf("%02x ",s[i]);
			if(i==7) printf(" ");
		}

		printf(" ");
		for(i=0;i<16;i++) {
			c = *s++;
			if((c<0x20)||(c>=0x7f)) {c='.';}
			printf("%c",c);
			//if(i==7) printf(" ");
		}
		printf("\n");
	}
}

void inc_sect()
{
	sect ++;
	if(sect >= (SPT+1)) {
		sect =1;
		head ++;
		if(head >= NumHeads) {
			head = 0;
			trk++;
		}
	}
}

void dec_sect()
{
	sect --;
	if(sect <= 0) {
		sect = SPT;
		head --;
		if(head < 0) {
			head = NumHeads - 1;
			trk--;
			if(trk < 0) {
				trk = 0;
			}
		}
	}
}

int inc_head(void)
{
		head ++;
		if(head >= NumHeads) {
			head = 0;
			trk++;
			if(trk >= param.Cyls) {
				trk--;
				return 1;
			}
		}
	return 0;
}

void dec_head()
{
		head --;
		if(head < 0) {
			head = NumHeads - 1;
			trk--;
			if(trk < 0) {
				trk = 0;
			}
		}
}

int inc_cyl()
{
			trk++;
			if(trk >= param.Cyls) {
				trk--;
				return 1;
			}
	return 0;
}

void dec_cyl()
{
			trk--;
			if(trk < 0) {
				trk = 0;
			}
}

void inc_off()
{
	dump_off++;
	if(	dump_off >= (32-22)) {
		dump_off = (32-22);
	}
}

void dec_off()
{
	if(dump_off>0) {
		dump_off--;
	}
}

void mdump(unsigned char *s)
{
	int i;
	for(i=0;i<16;i++) {
		printf("%02x ",s[i]);
	}
	printf("\n");
}

void search(int headskip)
{
	int endf=0;
	char *p = dskbuf;

	if(headskip==0) {
		inc_head();
	}else{
		inc_cyl();
	}

	do {
		r = ibmpc_biosdisk(2,drv,head,trk,sect,1,dskbuf);
		printf("Search MSWIN , Cyl = %5d : Head = %3d\r",trk,head);

		if(strcmp(p+3,"MSWIN4.1")==0) break;

		//if(head == 1) { printf("\n[%s]\n",dskbuf); break;}
		
		if(headskip==0) {
			endf=inc_head();
		}else{
			endf=inc_cyl();
		}
	}while(endf==0);
}

void key_cmd(int c)
{
	switch(c) {
	case UP		:dec_sect();break;
	case DOWN	:inc_sect();break;
	case LEFT	:dec_head();break;
	case RIGHT	:inc_head();break;
	case PGUP	:dec_cyl();break;
	case PGDOWN	:inc_cyl();break;
	case HOME	:dec_off();break;
	case END	:inc_off();break;

	case F11	:search(0);break;
	case F12	:search(1);break;
	}
}

void dump_uty()
{
	int c,r;
	int endf = 0;

	printf("\x1b[2J");
	do {
		r = ibmpc_biosdisk(2,drv,head,trk,sect,1,dskbuf);

		dump_buf(dskbuf);

		c=getch_usr();
		key_cmd(c);
		
		if(c==0x1b) endf=1;
		if(c=='q') endf=1;
		if(c=='Q') endf=1;
		if(c==0x03) endf=1;
	}while(endf==0);
}

getch_usr()
{
	int c,c2;

	c=getch();
	if(c==0) {	// ����L�[
		c2=getch();
		if(c2==0x48) return UP;
		if(c2==0x50) return DOWN;
		if(c2==0x4b) return LEFT;
		if(c2==0x4d) return RIGHT;

		if(c2==0x49) return PGUP;
		if(c2==0x51) return PGDOWN;
		if(c2==0x47) return HOME;
		if(c2==0x4f) return END;

		if(c2==0x3f) return F5;
		if(c2==0x40) return F6;
		if(c2==0x85) return F11;
		if(c2==0x86) return F12;
		
		printf("\nc2 = %02x\n",c2);
	}
	return(c);
}


Main

	sscanf(argv[1],"%x,%d,%d,%d",&drv,&trk,&head,&sect);
	if(argc<3) { usage(); }
	sscanf(argv[2],"%ld",&sects);
	
	
	if(sects==0) usage();
	if( (drv & 0xf0)!= 0x80 ) usage();

	chkinst(drv,0);
	if(IsOpt('i')) {
		dump_uty();
		exit(0);
	}
	
	if(IsOpt('w')) {
		printf("�f�B�X�N %c: �ɏ������݂܂���(y/n) ?\n",drv-0x80+'C');
		key=getch();
		if( key != 'y' ) {
			printf("���f���܂�\n");
			exit(1);
		}
		/*exit(2);*/
		Ropen(argv[3]);
		while(sects) {
			ss = sects;
				if(sects>=63) ss=63;
				Read(dskbuf,ss * 512);
				printf("dsk_bios( %x %5d %3d %2d %d ) = ",drv,trk,head,sect,ss);
			    r=ibmpc_bioswrite(3,drv,head,trk,sect,ss,dskbuf);
				printf("%x\r",r);
				if(r) break;
			sects -= ss;
			addsect(ss);
		}
		Rclose();
	}else{
	Wopen(argv[3]);
		while(sects) {
			ss = sects;
				if(sects>=63) ss=63;
				printf("dsk_bios( %x %5d %3d %2d %d ) = ",drv,trk,head,sect,ss);
			    r=ibmpc_biosdisk(2,drv,head,trk,sect,ss,dskbuf);
				printf("%x\r",r);
				if(r) break;
				Write(dskbuf,ss * 512);
			sects -= ss;
			addsect(ss);
		}
	Wclose();
	}
End

addsect(ss)
{
	sect += ss;
	if(	sect >= 64) {
		sect -= 63;
		head ++;
		if(head >= NumHeads) {
			head = 0;
			trk++;
		}
	}
}

