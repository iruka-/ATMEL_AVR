/**********************************************************************
 *		sort ���ǂ�
 **********************************************************************
 */
#include <stdio.h>
#include <malloc.h>
#include <stat.h>
#include <conslib.h>

static char USAGE[]=
"Usage:\n"
"%% sort [-Option] [ < file ] [ > output ]\n"
"Option:\n"
"    +pos1       �\�[�g�L�[�� pos1 �����ڂ���ɐݒ肷��.\n"
"    -r          �t���Ń\�[�g����.\n"
"    -f          �啶���Ə������𓯈ꎋ����.\n"
"    -ofilename  �o�̓t�@�C����filename�ɂ���.\n"
"\n"
;
/**********************************************************************
 *	LESS�������t�@�C���Ɋւ�����.
 **********************************************************************
 */
static FILE *fp;
static int fd=0;
static int filesize=0;
static char *filebuf;
static char *lp;
static char *endp;

typedef struct {
	char *p;
	int  l;
} LINE;

static LINE *linep;
static int   lines;
static int   sidx = 0;	//�\�[�g�L�[�̈ʒu.

#define	ScreenWidthMAX	128
#define	ScreenHeightMAX	 32

#define Getopt(argc,argv)  \
 {int i;for(i=0;i<128;i++) opt[i]=NULL; \
   while( ( argc>1 )&&(( *argv[1]=='-')||( *argv[1]=='+')) ) { \
     if( *argv[1]=='+') opt[ (int) '+'         ] = &argv[1][1] ; \
     else               opt[ argv[1][1] & 0x7f ] = &argv[1][2] ; \
    	argc--;argv++; } \
 }

#define IsOpt(c) ((opt[ c & 0x7f ])!=NULL)
#define   Opt(c)   opt[ c & 0x7f ]


int sjis2TCHAR( const BYTE *src, LPTSTR dst, DWORD max );
unsigned int dirSpace( const char *dir,const char *name ,int showmode);
char *xstrdup(char *string);

/**********************************************************************
 *	���[�J���ȃ��[�N�G���A.
 **********************************************************************
 */
static int	ScreenWidth =80;
static int	ScreenHeight=12;
static char *opt[128];		// �I�v�V�����������I������Ă���΁A���̒���̕�����ւ̃|�C���^.
/**********************************************************************
 *	�g�p�@.
 **********************************************************************
 */
static void Usage(void)
{
	fprintf(stderr,USAGE);
	exit(1);
}

/**********************************************************************
 *	����.
 **********************************************************************
 */
static int unicode2sjis( LPCTSTR src, BYTE *dst, DWORD max )
{
	return WideCharToMultiByte( CP_ACP, 0, src, -1, dst, dst ? max : 0, NULL, NULL ) ;
}
static int sjis2TCHAR( const BYTE *src, LPTSTR dst, DWORD max )
{
	return MultiByteToWideChar( CP_ACP, 0, src, -1, dst, dst ? max / sizeof (TCHAR) : 0  ) ;
}

static int isnum(int c)
{
	return (c>='0') && (c<='9');
}

//	�R sscanf
static int sscanf(char *buf,char *fmt,int *x)
{
	int c;
	int d=0;

	if(isnum(*buf)==0) return 0;
	
	while( c = *buf++ ) {
		if(isnum(c)==0) break;
		d*=10;d+=(c-'0');
	}
	*x = d;
	return 1;
}


/**********************************************************************
 *	u2a a2u ��260�o�C�g�܂�. �߂�l�̕�����́A�R�s�[���Ďg������.
 **********************************************************************
 */
static char *u2a(TCHAR *src)
{
	static char u2abuf[_MAX_PATH];
	unicode2sjis( src,u2abuf,_MAX_PATH );
	return u2abuf;
}

static TCHAR *a2u(char *src)
{
	static TCHAR a2ubuf[_MAX_PATH];
	sjis2TCHAR( src,a2ubuf,_MAX_PATH );
	return a2ubuf;
}


static int to_upper(int c)
{
	if( (c >= 'a') && (c <= 'z') ) return c - 0x20;
	return c;
}

static int stricmp(unsigned char *s,unsigned char *t)
{
	int cs,ct;
	while(*s) {
		cs = to_upper(*s++);
		ct = to_upper(*t++);
		if(cs != ct) return cs - ct;
	}
	return *s - *t;
}


int comp(int i,int j)
{
	int rc;
//	printf("comp(a[%d],a[%d])\n",i,j);

	//��r������̂ǂ��炩���\�[�g�L�[�̈ʒu���Z���ꍇ.
	if( ( linep[i].l < sidx ) || ( linep[j].l < sidx ) ) {
		if( ( linep[i].l < sidx ) && ( linep[j].l < sidx ) ) {
			return 0;		//�����Z��.
		}
		if( linep[i].l < sidx ) {
			rc = - 1;
		}else{
			rc =   1;
		}
		
		if(IsOpt('r')) rc = (-rc);	//�t���\�[�g.
		return rc;
	}


	if(IsOpt('f')) {
		rc = stricmp( linep[i].p + sidx , linep[j].p + sidx );
	}else{
		rc = strcmp(  linep[i].p + sidx , linep[j].p + sidx );
	}
	if(IsOpt('r')) rc = (-rc);	//�t���\�[�g.
	return rc;
}

void exch(int i,int j)
{
	LINE t;
//	printf("exch(%d,%d)\n",i,j);

	t=linep[i];
	  linep[i] =linep[j];
			    linep[j]=t;
}

static void sort_buf(void)
{
	extern void combsort(int size,int (*comp)(),void (*exch)());
	combsort(lines,comp,exch);
}

static void print_buf(void)
{
	int i;
	for(i=0;i<lines;i++) {
		puts(linep[i].p);
	}
}


/**********************************************************************
 *		�t�@�C���� *filebuf �ɑS���ǂݍ���.
 **********************************************************************
 */
static int readstream(FILE *fp)
{
	struct stat sbuf;
	int blks;

	fd = fileno(fp);
	if( fstat(fd,&sbuf) != 0 ) {
		fprintf(stderr,"less:Can't Get file size.\n");
		exit(1);
	}
	filesize = sbuf.st_size;

	filebuf = xmalloc(filesize+1);
	blks = fread(filebuf,1,filesize,fp);
	if(blks != filesize) {
		fprintf(stderr,"less:Can't read file.\n");
		exit(1);
	}
	
	endp = &filebuf[filesize];
	*endp = 0x0a;	// �I�[���s���ɂȂ��Ă��Ȃ��e�L�X�g�΍�.
	return 0;
}

/**********************************************************************
 *		
 **********************************************************************
 */
static int readfile(char *filename)
{
	int rc;
	fp=fopen(filename,"rt");
	if(fp==NULL) {
		fprintf(stderr,"less:Can't open file %s.\n",filename);
		exit(1);
	}
	rc = readstream(fp);
	fclose(fp);
	return rc;
}

/**********************************************************************
 *		�s���J�E���g.
 **********************************************************************
 */
int line_count(char *p0,char *p1,LINE *lp)
{
	char *p = p0;
	char *t;
	int line_cnt = 0;

	while(p < p1) {	//�ŏI�s�ɒB����܂�.
		t = p;		//���̍s�̐擪.
		while(*p != '\n') p++;	// ���s��T��.
		p++;		// '\n' ���X�L�b�v.
		line_cnt++;	//�s�ԍ��{�{.
		
		if(	lp != NULL) {
			lp->p = t;			//�s���A�h���X.
			lp->l = (p-t) -1 ;	//�s�̒���( '\n' ���܂܂� ).
			p[-1] = 0;			// '\n' �� 0x00 �ɏ�������.
			lp++;
		}
	}
	
	return line_cnt;
}

/**********************************************************************
 *		������.
 **********************************************************************
 */
int main(int argc,char **argv)
{
	Getopt(argc,argv);

	if(IsOpt('+')) {
		sscanf(Opt('+'),"%d",&sidx);
		if(sidx>0) sidx--;	//�P�����ځ��I�t�Z�b�g 0.
	}

	GetWH( &ScreenWidth, &ScreenHeight);
	if(ScreenWidth >= ScreenWidthMAX) ScreenWidth = ScreenWidthMAX;
	if(ScreenHeight>= ScreenHeightMAX)ScreenHeight= ScreenHeightMAX;

	if(argc<=1) {
		fp = stdin;
		if(isatty(fileno(fp))) {
			Usage();
		}
		readstream(fp);
	}else{
		readfile(argv[1]);
	}
	lp = filebuf;

	//�s�����J�E���g����.
	lines = line_count(lp,endp,NULL);
	linep = (LINE *) xmalloc(sizeof(LINE) * lines);

	//�s�|�C���^���Z�b�g����.
	line_count(lp,endp,linep);

	//�\�[�g����.
	sort_buf();
	//�o�͂���.
	print_buf();

	free(linep);
	free(filebuf);
	
	return 0;
}
/**********************************************************************
 *		
 **********************************************************************
 */
