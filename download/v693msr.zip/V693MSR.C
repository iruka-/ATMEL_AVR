//=========================================================
//	ZIDA TOMATO V693 �ɕ�����.
//=========================================================

#include <stdio.h>
#include <go32.h>
#include <dpmi.h>
#include <time.h>
#include <sys/farptr.h>
#include <pc.h>
#include <string.h>


void usage(void)
{
	printf(
	"Usage is:\n"
	"  v693msr [Options] [MemorySizeInMBytes]\n"
	"Option:\n"
	"  -d   dump MSR , MTTRs\n"
	"  -s   set MTTR (use only VIA C3 on ZIDA-V693 v1.0 AMI-BIOS)\n"
	"\n"
	);
}


static char  *opt[128];
#define Getopt(argc,argv)  \
 {int i;for(i=0;i<128;i++) opt[i]=NULL; \
   while( ( argc>1 )&&( *argv[1]=='-') ) \
    { opt[ argv[1][1] & 0x7f ] = &argv[1][2] ; argc--;argv++; } \
 }
#define IsOpt(c) ((opt[ c & 0x7f ])!=NULL)
#define   Opt(c)   opt[ c & 0x7f ]
static	int	othercpu=0;
static	int memsize = 128;	// Mbyte

typedef unsigned char   BYTE;
typedef unsigned short  WORD;
typedef unsigned long   DWORD;
typedef unsigned long   u32;

/*  These are the region types  */
#define MTRR_TYPE_UNCACHABLE 0
#define MTRR_TYPE_WRCOMB     1
#define MTRR_TYPE_WRTHROUGH  4
#define MTRR_TYPE_WRPROT     5
#define MTRR_TYPE_WRBACK     6
#define MTRR_NUM_TYPES       7

#if	0
static char *mtrr_strings[] = {
    "uncachable",               /* 0 */
    "write-combining",          /* 1 */
    "?",                        /* 2 */
    "?",                        /* 3 */
    "write-through",            /* 4 */
    "write-protect",            /* 5 */
    "write-back",               /* 6 */
    "?",
};
#endif

//=========================================================
//	CPUID�擾
//=========================================================
inline void cpuid(int op, int *eax, int *ebx, int *ecx, int *edx)
{
	__asm__("cpuid"
		: "=a" (*eax),
		  "=b" (*ebx),
		  "=c" (*ecx),
		  "=d" (*edx)
		: "a" (op));
}

inline unsigned int cpuid_eax(unsigned int op)
{
	unsigned int eax, ebx, ecx, edx;

	__asm__("cpuid"
		: "=a" (eax), "=b" (ebx), "=c" (ecx), "=d" (edx)
		: "a" (op));
	return eax;
}

inline unsigned int cpuid_ecx(unsigned int op)
{
	unsigned int eax, ebx, ecx, edx;

	__asm__("cpuid"
		: "=a" (eax), "=b" (ebx), "=c" (ecx), "=d" (edx)
		: "a" (op));
	return ecx;
}

//=========================================================
//	cr4 ��������
//=========================================================
inline void set_in_cr4 (unsigned long mask)
{
	__asm__ __volatile__("movl %%cr4,%%eax\n\t"
		"orl %0,%%eax\n\t"
		"movl %%eax,%%cr4\n"
		: : "irg" (mask)
		:"ax");
}

inline void clear_in_cr4 (unsigned long mask)
{
	__asm__ __volatile__("movl %%cr4,%%eax\n\t"
		"andl %0,%%eax\n\t"
		"movl %%eax,%%cr4\n"
		: : "irg" (~mask)
		:"ax");
}
inline int get_cr4()
{
	unsigned int eax;
	
	__asm__ __volatile__("movl %%eax,%%cr4\n\t"
		: "=a"(eax)
		: );
	return eax;
}
#if	0
inline void set_in_cr0 (unsigned long mask)
{
    unsigned long tmp;
    __asm__ __volatile__("movl  %%cr0, %0\n\t"
		  "orl   $0x40000000, %0\n\t"
		  "wbinvd\n\t"
		  "movl  %0, %%cr0\n\t"
		  "wbinvd\n\t"
		  : "=r" (tmp) : : );
}

inline void clear_in_cr0 (unsigned long mask)
    unsigned long tmp;
    /*  Enable caches  */
    __asm__("movl  %%cr0, %0\n\t"
		  "andl  $0xbfffffff, %0\n\t"
		  "movl  %0, %%cr0\n\t"
		  : "=r" (tmp) : : "memory");
}

#endif
inline void wbinvd ()
{
    /*  Flush caches and TLBs  */
    __asm__ __volatile__ ("wbinvd" : : : "memory" );
}
//=========================================================
//	msr �̓ǂݏ����}�N��
//=========================================================
#define rdmsr(msr,val1,val2) \
       __asm__ __volatile__("rdmsr" \
			    : "=a" (val1), "=d" (val2) \
			    : "c" (msr))

#define wrmsr(msr,val1,val2) \
     __asm__ __volatile__("wrmsr" \
			  : /* no outputs */ \
			  : "c" (msr), "a" (val1), "d" (val2))

//=========================================================
//	msr �̓ǂݏ����֐�
//=========================================================
void readmsr(DWORD _ecx, DWORD* _edx, DWORD* _eax)
{
	DWORD d,a;
	rdmsr(_ecx,a,d);
	*_edx = d;
	*_eax = a;
}

void writemsr(DWORD _ecx, DWORD _edx, DWORD _eax)
{
	wrmsr(_ecx,_eax,_edx);
}

//=========================================================
//	
//=========================================================
void set_timer(int div)
{
    __asm__ __volatile__ ("cli");
   outportb(0x43, 0x36);
   outportb(0x40, div & 0xFF);
   outportb(0x40, (div >> 8) & 0xFF);
    __asm__ __volatile__ ("sti");
}


//=========================================================
//	���[�J���ϐ�
//=========================================================
static	int	x86_cache_size;
static	int	cpuid_level;
static	char vendor_id[16];
static	char capability[16];
static	int	x86;
static	int	x86_model;
static	int	x86_mask;


//=========================================================
//	�L���b�V�����̕\��
//=========================================================
static void display_cacheinfo(void)
{
	unsigned int n, dummy, ecx, edx, eax;

	n = cpuid_eax(0x80000000);

	//printf("cpuid_eax=%x\n",n);

	cpuid(0x80000000, &eax, &dummy, &ecx, &edx);
	printf("cpuid_eax=%x\n",eax);
		

	if (n >= 0x80000005) {
		cpuid(0x80000005, &dummy, &dummy, &ecx, &edx);
		printf("CPU: L1 I Cache: %dK (%d bytes/line), D cache %dK (%d bytes/line)\n",
			edx>>24, edx&0xFF, ecx>>24, ecx&0xFF);
		x86_cache_size=(ecx>>24)+(edx>>24);	
	}
#if	0
	{unsigned int l2size;
	if (n < 0x80000006)	/* Some chips just has a large L1. */
		return;

	ecx = cpuid_ecx(0x80000006);
	l2size = ecx >> 16;
	if ( l2size == 0 )
		return;		/* Again, no L2 cache is possible */

	printf("CPU: L2 Cache: %dK (%d bytes/line)\n",
	       l2size, ecx & 0xFF);
	}
#endif
}


//=========================================================
//	CPUID �̎擾
//=========================================================
void get_cpuid(void)
{
	int junk;
	u32 tfms;

		cpuid(0x00000000, &cpuid_level,
		      (int *)&vendor_id[0],
		      (int *)&vendor_id[8],
		      (int *)&vendor_id[4]);
		
		/* Intel-defined flags: level 0x00000001 */
		if ( cpuid_level >= 0x00000001 ) {
			cpuid(0x00000001, (int*)&tfms, &junk, &junk,
			      (int*)&capability[0]);
			x86 = (tfms >> 8) & 15;
			x86_model = (tfms >> 4) & 15;
			x86_mask = tfms & 15;
		}
	
}


//=========================================================
//	msr ��ǂ�ŕ\������
//=========================================================
void read_msr(int ecx)
{
	DWORD edx,eax;
	readmsr(ecx,&edx,&eax);

	printf("read_msr(%x)=%x,%x\n",ecx,(int)edx,(int)eax);
}

//=========================================================
//	mtrr �̐ݒ�f�[�^
//=========================================================
typedef	struct {
	int	ecx,edx,eax;
} MTRR;

#if	0
MTRR	tbl[]={
	{0x200,0,4},				// 6��WRITE_BACK
	{0x201,0x0f,0xf0000800},	// f0000800�̓������[256MB�̂Ƃ�.

	{0x208,0,0xd8000001},		// 1��WRITE_COMBINED
	{0x209,0,0xf8000800},		// f8000800��VRAM(AGP)128MB�̂Ƃ�.

//MTRRfix64K_00000         250h    Control bits    Control bits
	{0x250,0x04040404,0x04040404},	// DOS�������[�� 0�`512KB�܂� 64K�P�� WRITEBACK
//MTRRfix16K_80000         258h    Control bits    Control bits
	{0x258,0x04040404,0x04040404},	// DOS�������[�� 512KB�`640kB 16K�P�� WRITEBACK
//MTRRfix4K_C0000          268h    Control bits    Control bits
	{0x268,0x05050505,0x05050505},
	{0x26e,0x05050505,0x05050505},
	{0x26f,0x05050505,0x05050505},
};
#endif

#if	1
MTRR	tbl[]={
	{0x200,0,6},				// 6��WRITE_BACK
	{0x201,0x0f,0xf0000800},	// f0000800�̓������[256MB�̂Ƃ�.

	{0x208,0,0xd8000001},		// 1��WRITE_COMBINED
	{0x209,0,0xf8000800},		// f8000800��VRAM(AGP)128MB�̂Ƃ�.

//MTRRfix64K_00000         250h    Control bits    Control bits
	{0x250,0x06060606,0x06060606},	// DOS�������[�� 0�`512KB�܂� 64K�P�� WRITEBACK
//MTRRfix16K_80000         258h    Control bits    Control bits
	{0x258,0x06060606,0x06060606},	// DOS�������[�� 512KB�`640kB 16K�P�� WRITEBACK
//MTRRfix4K_C0000          268h    Control bits    Control bits
	{0x268,0x05050505,0x05050505},
	{0x26e,0x05050505,0x05050505},
	{0x26f,0x05050505,0x05050505},
};
#endif

#if	0
MTRR	tbl[]={
	{0x200,0,6},
	{0x201,0x0f,0xe0000800},
	{0x202,0x00,0x08000000},
	{0x203,0x0f,0xf8000800},
	{0x204,0x00,0xd8000001},
	{0x205,0x0f,0xf8000800},
	{0x250,0x06060606,0x06060606},
	{0x258,0x06060606,0x06060606},
	{0x268,0x05050505,0x05050505},
	{0x26e,0x05050505,0x05050505},
	{0x26f,0x05050505,0x05050505},
};
#endif

#define	TBLSIZE	(sizeof(tbl) / sizeof(MTRR) )

//=========================================================
//	msr�Q��ݒ肷��
//=========================================================
void set_msr()
{
	int i;

	tbl[1].eax =  -(memsize << 20) | 0x800;
	//printf("0x%x\n",tbl[1].eax);

	if(strcmp(vendor_id,"CentaurHauls")==0) {
		wbinvd();
		for(i=0;i<TBLSIZE;i++) {
			writemsr(tbl[i].ecx,tbl[i].edx,tbl[i].eax);
		}
		wbinvd();
	}
}


//=========================================================
//	���C�����[�`��
//=========================================================
void info()
{
	get_cpuid();
		printf("cpuid = %s\n",vendor_id);
		printf("model = %d.%d.%d\n",x86,x86_model,x86_mask);

	if(strcmp(vendor_id,"CentaurHauls")==0) {
//		display_cacheinfo();
	}else{
		othercpu=1;
	}
}

void dump_msr()
{
	int i;

	if(othercpu==0) {
//VIA Only MSRs:
//BBL_CR_CTL3     L2 Hardware Disabled      11Eh        n/a         00800000h       RO
		read_msr(0x011e);
//FCR              Feature Control Reg      1107h          n/a     FCR value         RW
		read_msr(0x1107);
//FCR2            Feature Control Reg 2     1108h    FCR2_Hi      FCR2 value         RW
		read_msr(0x1108);
//FCR3            Feature Control Reg 3     1109h    FCR3_Hi      FCR3 value         WO
//		read_msr(0x1109);
//1147H: BCR2 (BUS CONTROL REGISTER 2)
		read_msr(0x1147);

	}

	// MTRR:
	for(i=0x200;i<0x210;i++) {
		read_msr(i);
	}
		read_msr(0x250);
		read_msr(0x258);
		read_msr(0x259);

	for(i=0x268;i<0x270;i++) {
		read_msr(i);
	}
	read_msr(0x2ff);

	printf("read_cr4()=%x\n",get_cr4());
}
//=========================================================
//	���C�����[�`��
//=========================================================
int main(int argc, char **argv)
{
	if(argc==1) usage();
	Getopt(argc,argv);
	if(argc>=2) sscanf(argv[1],"%d",&memsize);
	
	if(IsOpt('?')) {usage();exit(0);}
	if(IsOpt('h')) {usage();exit(0);}

	info();

	if(IsOpt('d')) dump_msr();
	if(IsOpt('s')) set_msr();

	return 0;
}
//=========================================================
//	
//=========================================================
