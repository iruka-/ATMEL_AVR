/* ���ʊ֐���` */

#ifndef _COMMON_H_
#define _COMMON_H_

void wait_ms(uint16_t time);
void wait_us(uint16_t time);

#endif
