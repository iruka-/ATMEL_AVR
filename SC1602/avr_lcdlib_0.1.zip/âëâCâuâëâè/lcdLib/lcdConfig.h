/* LCD���䃉�C�u���� */
/* �|�[�g�ݒ� */

#ifndef _LCD_LIB_CONFIG_H_
#define _LCD_LIB_CONFIG_H_

#include "def.h"

/****************************************/
/* �L���ɂ���ƃr�W�[���m�F�����삵�܂� */
/* #define CONF_LCD_BUSY_READ           */
/****************************************/
#define CONF_LCD_BUSY_READ


/*******************************************/
/* SC1602  SC2004�̎�ʑI��                */
/* SC1602 : 0                              */
/* SC2004 : 1                              */
/* ������͑I����                          */
/*******************************************/
#define DEF_LCD_TYPE_1602	0
#define DEF_LCD_TYPE_2004	1

/*******************************************/
/* �R�R�ɐݒ�                              */
#define CONF_LCD_TYPE	DEF_LCD_TYPE_1602
/*******************************************/






/******************************************************/
/* �e�|�[�g�ւ̃A�N�Z�Xdefine                         */
/* �e�|�[�g�Ǝ��|�[�g��g�ݍ��킹�Ă�������           */
/******************************************************/

/* �T���v�� */
/*#define LCD_PORTB	((volatile ST_PORT_BITFLD*)&PORTB)->uni.bit */
/*#define LCD_DDRB	((volatile ST_PORT_BITFLD*)&DDRB)->uni.bit */
/*#define LCD_PINB	((volatile ST_PORT_BITFLD*)&PINB)->uni.bit */

/********************************************************/


/*++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/* �g�p�|�[�g�̐ݒ� */
/* PORTB */
#define LCD_PORTB	((volatile ST_PORT_BITFLD*)&PORTB)->uni.bit
#define LCD_DDRB	((volatile ST_PORT_BITFLD*)&DDRB)->uni.bit
#define LCD_PINB	((volatile ST_PORT_BITFLD*)&PINB)->uni.bit

/* PORTC */
#define LCD_PORTC	((volatile ST_PORT_BITFLD*)&PORTC)->uni.bit
#define LCD_DDRC	((volatile ST_PORT_BITFLD*)&DDRC)->uni.bit
#define LCD_PINC	((volatile ST_PORT_BITFLD*)&PINC)->uni.bit

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++*/



/********************************/
/* �e���䃌�W�X�^�ƃ|�[�g�̐ݒ� */
/********************************/

/* ���W�X�^�I�� */
#define PIN_LCD_RS_PORT		LCD_PORTB.P0
#define PIN_LCD_RS_DDR		LCD_DDRB.P0
#define PIN_LCD_RS_PIN		LCD_PINB.P0

/* Read/Write�I�� */
#define PIN_LCD_RW_PORT		LCD_PORTC.P5
#define PIN_LCD_RW_DDR		LCD_DDRC.P5
#define PIN_LCD_RW_PIN		LCD_PINC.P5

/* Enable�M�� */
#define PIN_LCD_E_PORT		LCD_PORTC.P4
#define PIN_LCD_E_DDR		LCD_DDRC.P4
#define PIN_LCD_E_PIN		LCD_PINC.P4

/* DB4 */
#define PIN_LCD_DB4_PORT	LCD_PORTC.P3
#define PIN_LCD_DB4_DDR		LCD_DDRC.P3
#define PIN_LCD_DB4_PIN		LCD_PINC.P3

/* DB5 */
#define PIN_LCD_DB5_PORT	LCD_PORTC.P2
#define PIN_LCD_DB5_DDR		LCD_DDRC.P2
#define PIN_LCD_DB5_PIN		LCD_PINC.P2

/* DB6 */
#define PIN_LCD_DB6_PORT	LCD_PORTC.P1
#define PIN_LCD_DB6_DDR		LCD_DDRC.P1
#define PIN_LCD_DB6_PIN		LCD_PINC.P1

/* DB7 */
#define PIN_LCD_DB7_PORT	LCD_PORTC.P0
#define PIN_LCD_DB7_DDR		LCD_DDRC.P0
#define PIN_LCD_DB7_PIN		LCD_PINC.P0

#endif
